package io.naraplatform.artcenter.domain.drama.command.model.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ServiceFeature {
    //
    String name();
    int order() default 0;
    String[] editions();
    String[] authorizedRoles();
}
