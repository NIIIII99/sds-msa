package io.naraplatform.artcenter.query.rest.nation;

import io.naraplatform.artcenter.domain.nation.command.model.Nation;
import io.naraplatform.artcenter.domain.nation.query.spec.NationQueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value="/nation")
public class NataionQueryResource implements NationQueryService {

    @Autowired
    NationQueryService nationQueryService;

    @Override
    @GetMapping(value="/{id}")
    public Nation findNation(@PathVariable(name="id") String nationId) {
        //
        return nationQueryService.findNation(nationId);
    }

    @Override
    @GetMapping(value={"/", ""})
    public List<Nation> findAllNations() {
        //
        return nationQueryService.findAllNations();
    }
}
