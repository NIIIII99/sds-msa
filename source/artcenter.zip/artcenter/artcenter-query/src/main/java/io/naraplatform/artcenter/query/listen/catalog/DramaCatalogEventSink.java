package io.naraplatform.artcenter.query.listen.catalog;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

public interface DramaCatalogEventSink {

    String DRAMA_CATALOG_INPUT = "dramaCatalogInput";

	@Input(DRAMA_CATALOG_INPUT)
    MessageChannel dramaCatalogInput();

}
