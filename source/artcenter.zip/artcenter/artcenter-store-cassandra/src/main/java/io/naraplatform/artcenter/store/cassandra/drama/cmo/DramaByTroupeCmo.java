package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.Drama;
import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_by_troupe")
@Getter
@Setter
@NoArgsConstructor
public class DramaByTroupeCmo implements JsonSerializable {

    @PrimaryKeyColumn(name = "troupeId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String troupeId;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;

    private String categoryId;
    private String defaultLang;
    private String categoryNamesJson;
    private String titlesJson;
    private String descriptionsJson;
    private String troupeJson;
    private String base64Icon;
    private String feedbackId;
    private String date;

    public DramaByTroupeCmo(Drama drama) {
        //
        BeanUtils.copyProperties(drama, this);

        this.troupeId = drama.getTroupe().getId();
        this.categoryNamesJson = drama.getCategoryNames().toJson();
        this.titlesJson = drama.getTitles().toJson();
        this.descriptionsJson = drama.getDescriptions().toJson();
        this.troupeJson = drama.getTroupe().toJson();
    }

    public Drama toDomain() {
        //
        Drama drama = new Drama(this.id);
        BeanUtils.copyProperties(this, drama);
        drama.setCategoryNames(LangStrings.fromJson(this.categoryNamesJson));
        drama.setTitles(LangStrings.fromJson(this.titlesJson));
        drama.setDescriptions(LangStrings.fromJson(this.descriptionsJson));
        drama.setTroupe(IdLangName.fromJson(this.troupeJson));

        return drama;
    }

}
