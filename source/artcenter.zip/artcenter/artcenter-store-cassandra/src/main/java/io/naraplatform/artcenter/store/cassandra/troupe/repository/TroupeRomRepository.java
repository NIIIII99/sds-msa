package io.naraplatform.artcenter.store.cassandra.troupe.repository;

import io.naraplatform.artcenter.store.cassandra.troupe.cmo.TroupeRomCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TroupeRomRepository extends CassandraRepository<TroupeRomCmo, String> {
}
