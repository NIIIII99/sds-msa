package io.naraplatform.artcenter.store.cassandra.order.cmo;

import io.naraplatform.artcenter.domain.order.command.model.Subscription;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("subscription_by_subscriber")
@Getter
@Setter
@NoArgsConstructor
public class SubscriptionBySubscriberCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "subscriberId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String subscriberId;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;

    private String json;

    public SubscriptionBySubscriberCmo(Subscription subscription){
        //
        BeanUtils.copyProperties(subscription, this);

        this.subscriberId = subscription.getSubscriber().getId();
        this.json = subscription.toJson();
    }

    public Subscription toDomain(){
        //
        return Subscription.fromJson(this.json);
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubscriptionBySubscriberCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubscriptionBySubscriberCmo.class);
    }

    public static SubscriptionBySubscriberCmo sample() {
        //
        return new SubscriptionBySubscriberCmo(Subscription.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
