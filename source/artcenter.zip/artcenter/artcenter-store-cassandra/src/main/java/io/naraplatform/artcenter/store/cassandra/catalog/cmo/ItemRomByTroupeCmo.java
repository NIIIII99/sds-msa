package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.command.model.SalesSummary;
import io.naraplatform.artcenter.domain.catalog.query.model.ItemRom;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("item_rom_by_troupe")
@Getter
@Setter
@NoArgsConstructor
public class ItemRomByTroupeCmo implements JsonSerializable{
    //
    @PrimaryKeyColumn(name = "troupeId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String troupeId;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;

    private String title;
    private String dramaVersionId;
    private String versionName;
    private String base64Icon;
    private String troupeName;
    private String releaseDate;
    private String priceJson;
    private String salesSummaryJson;
    private String categoryName;
    private String catalogId;
    private String categoryId;


    public ItemRomByTroupeCmo(ItemRom itemRom) {
        //
        BeanUtils.copyProperties(itemRom, this);

        this.troupeId = itemRom.getTroupe().getId();
        this.troupeName = itemRom.getTroupe().getName();
        this.dramaVersionId = itemRom.getDramaVersion().getId();
        this.versionName = itemRom.getDramaVersion().getName();
        this.priceJson = itemRom.getPrice().toJson();
        this.salesSummaryJson = itemRom.getSalesSummary().toJson();
    }

    public ItemRom toDomain() {
        //
        ItemRom itemRom = new ItemRom(id);

        BeanUtils.copyProperties(this, itemRom);
        itemRom.setPrice(GlobalPrice.fromJson(priceJson));
        itemRom.setSalesSummary(SalesSummary.fromJson(salesSummaryJson));
        itemRom.setDramaVersion(new IdName(dramaVersionId, versionName));
        itemRom.setTroupe(new IdName(troupeId, troupeName));

        return itemRom;
    }

    public String toString() {
        //
        return toJson();
    }

    public static ItemRomByTroupeCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ItemRomByTroupeCmo.class);
    }

    public static ItemRomByTroupeCmo sample() {
        //
        ItemRom itemRom = ItemRom.sample();
        itemRom.setSalesSummary(SalesSummary.sample());
        return new ItemRomByTroupeCmo(itemRom);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
