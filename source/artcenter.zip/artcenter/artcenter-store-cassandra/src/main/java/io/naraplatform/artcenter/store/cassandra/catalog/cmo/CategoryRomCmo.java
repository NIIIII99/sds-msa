package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.query.model.CategoryRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("category_rom")
@Getter
@Setter
@NoArgsConstructor
public class CategoryRomCmo implements JsonSerializable{
    //
    @PrimaryKeyColumn(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;

    private String name;
    private String memo;
    private String catalogId;

    public CategoryRomCmo(CategoryRom categoryRom){
        //
        BeanUtils.copyProperties(categoryRom, this);
    }

    public CategoryRom toDomain(){
        //
        CategoryRom categoryRom = new CategoryRom(this.id);
        BeanUtils.copyProperties(this, categoryRom);

        return categoryRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static CategoryRomCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CategoryRomCmo.class);
    }

    public static CategoryRomCmo sample() {
        //
        return new CategoryRomCmo(CategoryRom.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
