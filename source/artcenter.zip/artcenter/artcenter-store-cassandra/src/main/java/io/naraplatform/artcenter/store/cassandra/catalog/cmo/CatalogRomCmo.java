package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("catalog_rom")
@Getter
@Setter
@NoArgsConstructor
public class CatalogRomCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "nationId", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String nationId;
    private String nationName;
    private String title;
    private String memo;
    private boolean global;

    public CatalogRomCmo(CatalogRom catalogRom){
        //
        BeanUtils.copyProperties(catalogRom,this);
    }

    public CatalogRom toDomain(){
        //
        CatalogRom catalogRom = new CatalogRom(this.id);
        BeanUtils.copyProperties(this, catalogRom);

        return catalogRom;
    }

    public String toString() {
        //
        return toJson();
    }

    public static CatalogRomCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CatalogRomCmo.class);
    }

    public static CatalogRomCmo sample() {
        //
        return new CatalogRomCmo(CatalogRom.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
