package io.naraplatform.artcenter.store.cassandra.catalog.repository;

import io.naraplatform.artcenter.store.cassandra.catalog.cmo.ItemRomByTroupeCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ItemRomByTroupeRepository extends CassandraRepository<ItemRomByTroupeCmo, String> {
    //
    List<ItemRomByTroupeCmo> findAllByTroupeIdAndLangCode(String troupeId, String langCode, Pageable pageable);

    //void deleteByTroupeIdAndLangCodeAndId(String troupeId, String langCode, String itemId);
}
