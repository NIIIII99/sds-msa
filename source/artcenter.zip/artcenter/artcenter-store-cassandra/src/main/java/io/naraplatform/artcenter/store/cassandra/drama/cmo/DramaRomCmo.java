package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.query.model.DramaRom;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_rom")
@Getter
@Setter
@NoArgsConstructor
public class DramaRomCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String id;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String langCode;

    private String title;
    private String description;
    private String troupeJson;
    private String base64Icon;
    private String feedbackId;
    private String categoryName;

    public DramaRomCmo(DramaRom dramaRom){
        //
        BeanUtils.copyProperties(dramaRom, this);
        this.troupeJson = dramaRom.getTroupe().toJson();
    }

    public DramaRom toDomain(){
        //
        DramaRom dramaRom = new DramaRom(this.id);
        BeanUtils.copyProperties(this, dramaRom);
        dramaRom.setTroupe(IdName.fromJson(this.troupeJson));

        return dramaRom;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaRomCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaRomCmo.class);
    }

    public static DramaRomCmo sample() {
        //
        DramaRom dramaRom = DramaRom.sample();
        return new DramaRomCmo(dramaRom);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
