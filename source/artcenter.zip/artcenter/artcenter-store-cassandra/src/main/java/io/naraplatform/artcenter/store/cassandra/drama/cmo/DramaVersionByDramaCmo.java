package io.naraplatform.artcenter.store.cassandra.drama.cmo;

import io.naraplatform.artcenter.domain.drama.command.model.DramaVersion;
import io.naraplatform.artcenter.domain.drama.command.model.contents.DramaContents;
import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("drama_version_by_drama")
@Getter
@Setter
@NoArgsConstructor
public class DramaVersionByDramaCmo implements JsonSerializable {

    @PrimaryKeyColumn(name = "dramaId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String dramaId;
    @PrimaryKeyColumn(name = "versionName", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String versionName;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;

    private String releaseNotesJson;
    private String supportLangsJson;
    private String priceJson;
    private String releaseDate;

    private String dramaContentsJson;

    public DramaVersionByDramaCmo(DramaVersion dramaVersion) {
        //
        BeanUtils.copyProperties(dramaVersion, this);
        this.releaseNotesJson = dramaVersion.getReleaseNotes().toJson();
        this.supportLangsJson = dramaVersion.getSupportLangs().toJson();
        this.priceJson = dramaVersion.getPrice().toJson();
        this.dramaContentsJson = dramaVersion.getDramaContents().toJson();
    }

    public DramaVersion toDomain() {
        //
        DramaVersion dramaVersion = new DramaVersion(this.id);
        BeanUtils.copyProperties(this, dramaVersion);
        dramaVersion.setReleaseNotes(LangStrings.fromJson(this.releaseNotesJson));
        dramaVersion.setSupportLangs(LangStrings.fromJson(this.supportLangsJson));
        dramaVersion.setPrice(GlobalPrice.fromJson(this.priceJson));
        dramaVersion.setDramaContents(DramaContents.fromJson(this.dramaContentsJson));

        return dramaVersion;
    }

    public String toString(){
        //
        return toJson();
    }

    public static DramaVersionByDramaCmo fromJson(String json){
        //
        return JsonUtil.fromJson(json, DramaVersionByDramaCmo.class);
    }

    public static DramaVersionByDramaCmo sample() {
        //
        DramaVersion dramaVersion = DramaVersion.sample();
        return new DramaVersionByDramaCmo(dramaVersion);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }

}
