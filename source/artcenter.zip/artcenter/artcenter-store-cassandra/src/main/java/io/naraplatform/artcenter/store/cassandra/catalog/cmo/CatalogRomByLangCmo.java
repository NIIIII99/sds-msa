package io.naraplatform.artcenter.store.cassandra.catalog.cmo;

import io.naraplatform.artcenter.domain.catalog.query.model.CatalogRom;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("catalog_rom_by_lang")
@Getter
@Setter
@NoArgsConstructor
public class CatalogRomByLangCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "langCode", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String langCode;
    @PrimaryKeyColumn(name = "nationId", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String nationId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    private String id;
    private String nationName;
    private String title;
    private String memo;
    private boolean global;

    public CatalogRomByLangCmo(CatalogRom catalogRom){
        //
        BeanUtils.copyProperties(catalogRom,this);
    }

    public CatalogRom toDomain(){
        //
        CatalogRom catalogRom = new CatalogRom(this.id);
        BeanUtils.copyProperties(this, catalogRom);

        return catalogRom;
    }

    public String toString() {
        //
        return toJson();
    }

    public static CatalogRomByLangCmo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CatalogRomByLangCmo.class);
    }

    public static CatalogRomByLangCmo sample() {
        //
        return new CatalogRomByLangCmo(CatalogRom.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
