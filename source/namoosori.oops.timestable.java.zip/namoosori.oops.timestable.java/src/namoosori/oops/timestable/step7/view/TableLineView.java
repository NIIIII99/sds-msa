/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step7.view;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.UnitTable;

public class TableLineView implements LineView {
	//
	private static final int DefaultTableLength = 20; 
	
	private int columnSize; 
	private ExpressionStyle style; 
	private List<UnitTable> unitTables; 
	
	public TableLineView(int columnSize) {
		// 
		this.columnSize = columnSize; 
		this.unitTables = new ArrayList<UnitTable>(); 
	}
	
	@Override
	public void takeTables(LinkedList<UnitTable> sourceTables) {
		// 
		for(int i = 0; i<columnSize; i++) {
			this.unitTables.add(sourceTables.removeFirst());
			if (sourceTables.size() == 0) {
				break; 
			}
		}
	}
	
	@Override
	public void showLine() {
		//
		String lineExpression = null;  
		for (int rightNumber = 1; rightNumber<=9; rightNumber++) {
			lineExpression = getLineExpression(rightNumber); 
			System.out.println(lineExpression); 
		}
		
		System.out.println("..."); 
	}
	
	@Override
	public void setStyle(ExpressionStyle style) {
		this.style = style; 
	}
	
	public void addUnitTable(UnitTable unitTable) {
		// 
		this.unitTables.add(unitTable); 
	}
	
	private String getLineExpression(int rightNumber) {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		for(UnitTable unitTable : unitTables) {
			if (style != null) {
				unitTable.setStyle(style);
			}
			String line = unitTable.getFormattedExpression(rightNumber); 
			builder.append(fillSpace(line, DefaultTableLength)); 
		}
		
		return builder.toString(); 
	}
	
	private String fillSpace(String str, int size) {
		// 
		char[] charArray = new char[size]; 
		for(int i=0; i<size; i++) {
			if(i>=str.length()) {
				charArray[i] = ' '; 
			} else {
				charArray[i] = str.charAt(i); 
			}
		}
		
		return String.valueOf(charArray); 
	}
}
