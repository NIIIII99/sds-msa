/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step7.view;

import java.util.LinkedList;

import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.UnitExpression;
import namoosori.oops.timestable.step6.table.UnitTable;

public class SimpleLineView implements LineView {
	//
	private UnitTable unitTable; 

	public SimpleLineView() {
		//
	}
	
	@Override
	public void takeTables(LinkedList<UnitTable> sourceUnitTables) {
		// 
		unitTable = sourceUnitTables.removeFirst(); 
	}

	@Override
	public void showLine() {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(UnitExpression expression: unitTable.getExpressions()) {
			builder.append(String.format(" %2d ", expression.getResultValue())); 
		}
		System.out.println(builder.toString()); 
	}

	@Override
	public void setStyle(ExpressionStyle style) {
		//
		// doing nothing
	}
}