/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step7.view;

import java.util.LinkedList;

import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.UnitTable;

public interface LineView {
	//
	public void takeTables(LinkedList<UnitTable> unitTables); 
	public void setStyle(ExpressionStyle style); 
	public void showLine();
}