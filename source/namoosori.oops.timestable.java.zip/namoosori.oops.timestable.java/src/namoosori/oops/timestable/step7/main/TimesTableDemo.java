/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step7.main;

import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.TimesTable;
import namoosori.oops.timestable.step7.view.ConsoleView;
import namoosori.oops.timestable.step7.view.LineType;

public class TimesTableDemo {
	//
	public static void main(String[] args) {
		// 
		TimesTableDemo demo = new TimesTableDemo(); 

		demo.showTableLineDemo(new TimesTable()); 
		demo.showSimpleLineDemo(new TimesTable());
	}
	
	public void showTableLineDemo(TimesTable timesTable) {
		//
		ConsoleView consoleView = new ConsoleView(LineType.TableLine);  
		consoleView.setColoumnSize(4); 
		consoleView.setStyle(ExpressionStyle.InMath);
		consoleView.show(timesTable); 
	}
	
	public void showSimpleLineDemo(TimesTable timesTable) {
		//
		ConsoleView consoleView = new ConsoleView(LineType.SimpleLine); 
		consoleView.setColoumnSize(4); 		// ignored
		consoleView.show(timesTable); 
	}
	
}