/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.ui.consoleview;

import java.util.LinkedList;

import namoosori.oops.timestable.step8.logic.concept.ExpressionStyle;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public interface LineView {
	//
	public void takeTables(LinkedList<UnitTable> unitTables); 
	public void setStyle(ExpressionStyle style); 
	public void showLine();
	public int getLineLength(); 
}