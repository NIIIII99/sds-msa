package namoosori.oops.timestable.step8.data.store;

import namoosori.oops.timestable.step8.data.repo.mem.TimesTableMemRepository;

public class TimesTableStoreFactory {
	//
	public static TimesTableStore getTimesTableStore() {
		// 
		return new TimesTableMemRepository();
	}
}
