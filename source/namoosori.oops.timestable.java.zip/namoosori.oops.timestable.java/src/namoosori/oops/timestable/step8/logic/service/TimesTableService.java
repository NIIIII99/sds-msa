package namoosori.oops.timestable.step8.logic.service;

import namoosori.oops.timestable.step8.logic.concept.TimesTable;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public interface TimesTableService {
	//
	public void registerTimesTable(int maxLeftNumber);  
	public TimesTable findTimesTable(int maxLeftNumber); 
	public UnitTable findUnitTable(int leftNumber); 
}