package namoosori.oops.timestable.step8.logic.process;

import namoosori.oops.timestable.step8.data.store.TimesTableStore;
import namoosori.oops.timestable.step8.data.store.TimesTableStoreFactory;
import namoosori.oops.timestable.step8.logic.concept.TimesTable;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;
import namoosori.oops.timestable.step8.logic.service.TimesTableService;

public class TimesTableServiceLogic implements TimesTableService {
	//
	private TimesTableStore timesTableStore; 

	public TimesTableServiceLogic() {
		// 
		this.timesTableStore = TimesTableStoreFactory.getTimesTableStore(); 
	}
	
	@Override
	public void registerTimesTable(int maxLeftNumber) {
		// 
		if (timesTableStore.existMaxLeftNumber(maxLeftNumber)) {
			// 
			System.out.format("%n ## Already exist --> %d", maxLeftNumber); 
			return; 
		}
		
		timesTableStore.addMaxLeftNumber(maxLeftNumber);
		
		for (int leftNumber=2; leftNumber<=maxLeftNumber; leftNumber++) {
			if (timesTableStore.exist(leftNumber)) {
				continue; 
			}
			System.out.format(" > storing.. [%d]%n", leftNumber);
			timesTableStore.create(new UnitTable(leftNumber)); 
		}
	}

	@Override
	public TimesTable findTimesTable(int maxLeftNumber) {
		// 
		if (!timesTableStore.existMaxLeftNumber(maxLeftNumber)) {
			// 
			System.out.format("%n ## Does not exist --> %d", maxLeftNumber); 
			return null; 
		}

		TimesTable timesTable = new TimesTable(maxLeftNumber); 
		
		for(int leftNumber=2; leftNumber<=maxLeftNumber; leftNumber++) {
			UnitTable unitTable = timesTableStore.retrieve(leftNumber); 
			timesTable.addTable(unitTable);
		}
		
		return timesTable;
	}

	@Override
	public UnitTable findUnitTable(int leftNumber) {
		// 
		return timesTableStore.retrieve(leftNumber);
	}
}