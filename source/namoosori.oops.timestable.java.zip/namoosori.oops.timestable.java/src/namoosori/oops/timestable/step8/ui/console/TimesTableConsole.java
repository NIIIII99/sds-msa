/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.step8.ui.console;

import java.util.Scanner;

import namoosori.oops.timestable.step8.logic.concept.TimesTable;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;
import namoosori.oops.timestable.step8.logic.service.TimesTableService;
import namoosori.oops.timestable.step8.logic.service.TimesTableServiceFactory;
import namoosori.oops.timestable.step8.ui.consoleview.ConsoleView;
import namoosori.oops.timestable.step8.ui.consoleview.TableLineView;

public class TimesTableConsole {
	//
	private TimesTableService timesTableService; 
	private Scanner scanner;

	public static void main(String[] args) {
		// 
		TimesTableConsole console = new TimesTableConsole(); 
		console.showMenu(); 
	}
	
	public TimesTableConsole() {
		//
		this.timesTableService = TimesTableServiceFactory.getTimesTableService(); 
		this.scanner = new Scanner(System.in);
	}

	public void showMenu() {
		//
		int inputNumber = 0;

		while (true) {
			displayMainMenu();
			inputNumber = selectMainMenu();

			switch (inputNumber) {
			//
			case 1:
				registerTimesTable();
				break;
			case 2:
				findAndShowTimesTable();
				break;
			case 3:
				findAndShowUnitTable();
				break;
			case 0:
				exitProgram();
				return;

			default:
				System.out.println("Choose again!");
			}
		}
	}

	private void displayMainMenu() {
		//
		System.out.println("");
		System.out.println("..............................");
		System.out.println(" TimesTable2 menu ");
		System.out.println("..............................");
		System.out.println(" 1. Register TimesTable2");
		System.out.println(" 2. Find and show TimesTable2");
		System.out.println(" 3. Find and show UnitTable");
		System.out.println(" 0. Program exit");
		System.out.println("..............................");
	}

	private int selectMainMenu() {
		//
		String menuNumber = getValueOf("Select menu"); 
		return Integer.valueOf(menuNumber); 
	}
 
	private void exitProgram() {
		//
		System.out.println("Program exit. Bye...");
		scanner.close(); 
		System.exit(0);
	}

	private void registerTimesTable() {
		//
		String maxLeftNumberStr = getValueOf("Max left number"); 
		int maxLeftNumber = Integer.valueOf(maxLeftNumberStr); 
		timesTableService.registerTimesTable(maxLeftNumber);
	}

	private void findAndShowTimesTable() {
		//
		String maxLeftNumberStr = getValueOf("Max left number"); 
		int maxLeftNumber = Integer.valueOf(maxLeftNumberStr); 
		
		TimesTable timesTable = timesTableService.findTimesTable(maxLeftNumber);
		
		if (timesTable == null) {
			return; 
		}
		
		ConsoleView consoleView = new ConsoleView();
		consoleView.setColoumnSize(4); 
		consoleView.show(timesTable);
	}
	
	private void findAndShowUnitTable() {
		//
		String leftNumberStr = getValueOf("Left number"); 
		int leftNumber = Integer.valueOf(leftNumberStr); 
		
		UnitTable unitTable = timesTableService.findUnitTable(leftNumber);
		
		if (unitTable == null) {
			return; 
		}
		
		TableLineView tableLineView = new TableLineView(); 
		tableLineView.addUnitTable(unitTable);
		
		tableLineView.showLine(); 
	}
	
	public String getValueOf(String label){
		//
		System.out.print(label + ": ");
		String inputStr = scanner.nextLine();
		inputStr = inputStr.trim();
		return inputStr;
	}
}