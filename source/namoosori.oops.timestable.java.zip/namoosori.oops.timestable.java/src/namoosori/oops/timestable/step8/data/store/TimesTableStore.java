package namoosori.oops.timestable.step8.data.store;

import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public interface TimesTableStore {
	//
	public void addMaxLeftNumber(int maxLeftNumber); 
	public boolean existMaxLeftNumber(int maxLeftNumber); 
	public int create(UnitTable unitTable); 
	public boolean exist(int leftNumber); 
	public UnitTable retrieve(int leftNumber); 
}