/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.ui.consoleview;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import namoosori.oops.timestable.step8.logic.concept.ExpressionStyle;
import namoosori.oops.timestable.step8.logic.concept.TimesTable;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public class ConsoleView {
	//
	private int columnCount; 
	private LineType lineType; 
	private ExpressionStyle style; 
	private List<LineView> lineViews; 

	public ConsoleView() {
		//
		this(LineType.TableLine); 
	}
	
	public ConsoleView(LineType lineType) {
		//
		this.columnCount = 1; 
		this.lineType = lineType; 
		this.lineViews = new ArrayList<>(); 
	}

	public void setLineType(LineType lineType) {
		//
		this.lineType = lineType; 
	}
	
	public void setColoumnSize(int columnSize) {
		//
		this.columnCount = columnSize; 
	}
	
	public void clearCommonStyle() {
		// 
		this.style = null; 
	}
	
	public boolean hasStyle() {
		// 
		if (this.style != null) {
			return true; 
		}
		
		return false; 
	}
	
	public void setStyle(ExpressionStyle style) {
		// 
		this.style = style; 
	}
	
	public void showWithDumbLineView(TimesTable timesTable) {
		// 
		List<UnitTable> unitTables = timesTable.getUnitTables();
		int tableCount = unitTables.size(); 
		
		for(int i=0; i<tableCount;) {
			TableLineView lineView = new TableLineView(columnCount); 
			for(int j=0; j<columnCount; j++) {
				if (i == tableCount) {
					break; 
				}
				lineView.addUnitTable(unitTables.get(i++)); 
			}
			lineViews.add(lineView); 
		}
		
		showLines(); 
	}
	
	public void show(TimesTable timesTable) {
		//
		if (lineType.equals(LineType.SimpleLine) && !timesTable.isBasicTable()) {
			throw new RuntimeException("Simple line type only accept basic tables."); 
		}
		
		lineViews.clear(); 
		
		LinkedList<UnitTable> sourceTables; 
		if (lineType.equals(LineType.SimpleLine) && timesTable.isBasicTable()) { 
			sourceTables = new LinkedList<>(timesTable.getUnitTablesFromOne());   
		} else {
			sourceTables = new LinkedList<>(timesTable.getUnitTables());   
		}
		
		while(sourceTables.size() > 0) {
			//
			LineView lineView = buildLineView(); 
			lineView.takeTables(sourceTables);
			if (hasStyle()) {
				lineView.setStyle(style); 
			}
			
			lineViews.add(lineView); 
 		}
 		
		showLines(); 
	}
	
	public void showLineSeparator() {
		//
		int lineLength = 10; 
		if (lineViews.size() != 0) {
			lineLength = lineViews.get(0).getLineLength(); 
		}
		
		StringBuilder builder = new StringBuilder(); 
		for(int i=0; i<lineLength; i++) {
			builder.append("."); 
		}
		
		System.out.println(builder.toString()); 
	}
	
	private LineView buildLineView() {
		// 
		LineView lineView = null; 
		
		switch(this.lineType) {
		case TableLine:
			lineView = new TableLineView(columnCount); 
			break; 
		case SimpleLine: 
			lineView = new SimpleLineView(); 
			break; 
		}
		
		return lineView; 
		
	}
	
	private void showLines() {
		// 
		for (LineView tableLine : lineViews) {
			// 
			tableLine.showLine(); 
		}
	}
}