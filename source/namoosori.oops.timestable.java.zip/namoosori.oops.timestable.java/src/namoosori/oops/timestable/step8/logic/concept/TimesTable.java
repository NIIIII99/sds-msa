/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.logic.concept;

import java.util.ArrayList;
import java.util.List;

public class TimesTable {
	//
	private int maxLeftNumber; 
	private boolean basicTable; 
	private List<UnitTable> unitTables; 
	
	public TimesTable(int maxLeftNumber) {
		// 
		this.maxLeftNumber = maxLeftNumber; 
		this.basicTable = false; 
		this.unitTables = new ArrayList<>();
	}
	
	public int getMaxLeftNumber() {
		return maxLeftNumber; 
	}
	
	public void clear() {
		this.unitTables.clear(); 
	}

	public boolean isBasicTable() {
		return basicTable; 
	}
	
	public List<UnitTable> getUnitTables() {
		//
		if (basicTable) {
			int size = unitTables.size(); 
			return unitTables.subList(1, size); 
		} else {
			return unitTables; 
		}
	}

	public List<UnitTable> getUnitTablesFromOne() {
		// 
		if (!basicTable) {
			throw new RuntimeException("Can't use this method."); 
		}
		return unitTables; 
	}

	public void addTable(UnitTable unitTable) {
		// 
		if(basicTable) {
			throw new RuntimeException("You can't add a table into a basic times table."); 
		}
		
		this.unitTables.add(unitTable); 
	}

	public void addTable(int leftNumber) {
		// 
		this.unitTables.add(new UnitTable(leftNumber)); 
	}

	public void initialize() {
		// 
		this.basicTable = true; 
		for (int leftNumber = 1; leftNumber<=9; leftNumber++) {
			unitTables.add(new UnitTable(leftNumber)); 
		}
	}
 }