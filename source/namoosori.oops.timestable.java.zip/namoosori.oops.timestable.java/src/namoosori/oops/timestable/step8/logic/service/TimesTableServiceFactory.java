package namoosori.oops.timestable.step8.logic.service;

import namoosori.oops.timestable.step8.logic.process.TimesTableServiceLogic;

public class TimesTableServiceFactory {
	//
	public static TimesTableService getTimesTableService() {
		// 
		return new TimesTableServiceLogic(); 
	}
}