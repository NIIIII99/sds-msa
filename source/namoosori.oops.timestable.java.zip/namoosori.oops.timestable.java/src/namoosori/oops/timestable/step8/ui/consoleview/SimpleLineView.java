/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.ui.consoleview;

import java.util.LinkedList;

import namoosori.oops.timestable.step8.logic.concept.ExpressionStyle;
import namoosori.oops.timestable.step8.logic.concept.UnitExpression;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public class SimpleLineView implements LineView {
	//
	private int lineLength; 
	private UnitTable unitTable; 

	public SimpleLineView() {
		//
		this.lineLength = 10; 
	}
	
	@Override
	public void takeTables(LinkedList<UnitTable> sourceUnitTables) {
		// 
		unitTable = sourceUnitTables.removeFirst(); 
	}

	@Override
	public void showLine() {
		// 
		StringBuilder builder = new StringBuilder(); 
		for(UnitExpression expression: unitTable.getExpressions()) {
			builder.append(String.format(" %2d ", expression.getResultNumber())); 
		}
		this.lineLength = builder.length(); 
		System.out.println(builder.toString()); 
	}

	@Override
	public void setStyle(ExpressionStyle style) {
		//
		// doing nothing
	}
	
	@Override
	public int getLineLength() {
		return lineLength; 
	}
}