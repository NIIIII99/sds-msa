/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.step8.data.repo.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import com.google.gson.Gson;

import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public class UnitTableFile {
	//
	private String fileName;
	private String tempFileName; 
	private String delimiter;
	
	public UnitTableFile() {
		// 
		this.fileName = "UnitTableFile.db"; 
		this.tempFileName = "UnitTableTempFile.txt"; 
		this.delimiter = "||"; 
	}
	
	public String getTempFileName() {
		return tempFileName; 
	}
	
	public int count() {
		// 
		int count = 0; 
        BufferedReader reader; 
        
		try {
	        reader = requestReader(fileName);
			
			while(true) {
				if(reader.readLine() == null) {
					break; 
				}
				count++; 
			}
			reader.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return count; 
	}
	
	public boolean exist(String name) {
		// 
        boolean found = false;
        BufferedReader reader; 
        
		try {
	        reader = requestReader(fileName);
			
	        String line = null; 
			while(true) {
				if((line = reader.readLine()) == null) {
					break; 
				}
				
				if (hasName(line, name)) {
					found = true; 
					break; 
				}; 
			}
			reader.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return found; 
	}
	
	public void create(UnitTable unitTable) {
		//
		if (this.exist(String.valueOf(unitTable.getLeftNumber()))) {
			return;
		}
		
		FileWriter fileWriter;
		try {
			fileWriter = requestFileWriter(fileName);
			fileWriter.write(convertToStr(unitTable)); 
			fileWriter.write("\r\n"); 
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			return ; 
		}
	}
	
	public UnitTable retrieve(int leftNumber) {
		// 
		UnitTable unitTable = null; 
        BufferedReader reader; 
		try {
	        reader = requestReader(fileName);
			
	        String line = null; 
			while(true) {
				if((line = reader.readLine()) == null) {
					return null;
				}
				
				if (hasName(line, String.valueOf(leftNumber))) {
					unitTable = convertToObject(line); 
					break; 
				}; 
			}
			reader.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return unitTable; 
	}
	
	private boolean hasName(String line, String name) {
		// 
		StringTokenizer tokenizer = new StringTokenizer(line, delimiter);

		String token = tokenizer.nextToken();
		if (name.equals(token)) {
			return true;
		} else {
			return false;
		}
	}
	
	private String convertToStr(UnitTable unitTable) {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append(String.valueOf(unitTable.getLeftNumber())); 
		builder.append(this.delimiter); 
		builder.append(new Gson().toJson(unitTable));  
		
		return builder.toString(); 
	}
	
	private UnitTable convertToObject(String unitTableStr) {
		// 
		StringTokenizer tokenizer = new StringTokenizer(unitTableStr, this.delimiter); 
		UnitTable unitTable = null; 
		
		try {
			@SuppressWarnings("unused")
			String leftNumber = tokenizer.nextToken(); 
			String unitTableJson = tokenizer.nextToken(); 
			unitTable = new Gson().fromJson(unitTableJson, UnitTable.class); 
		} catch (NoSuchElementException e) {
			//
			e.printStackTrace(); 
		}

		return unitTable; 
	}

	private BufferedReader requestReader(String fileName) throws IOException {
		//
		return new BufferedReader(new FileReader(createFile(fileName)));
	}

	private FileWriter requestFileWriter(String fileName) throws IOException {
		//
		return new FileWriter(createFile(fileName), true);
	}
	
	private File createFile(String fileName) throws IOException {
		//
		String typeFolderName = "filedb"; 
		String folderName = "step8"; 
		File resourceFile = null; 
		
		try {
			String fullFileName; 
			String pathName; 

			String cannonicalPath = (new File(".")).getCanonicalPath();
		    String fileSeparator = System.getProperty("file.separator"); 

		    StringBuilder builder = new StringBuilder(); 
		    builder.append(cannonicalPath).append(fileSeparator);
		    builder.append("resource").append(fileSeparator); 
	    	builder.append(typeFolderName).append(fileSeparator);
    		builder.append(folderName); 
		    pathName = builder.toString();

		    builder.append(fileSeparator).append(fileName); 
		    fullFileName = builder.toString();

			Path path = Paths.get(pathName); 
	        if (!Files.exists(path)) {
                Files.createDirectories(path);
	        }
	        
			resourceFile = new File(fullFileName);
			if (!resourceFile.exists()) {
				resourceFile.createNewFile(); 
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return resourceFile; 
	}
	
	public static void main(String[] args) {
		// 
		UnitTableFile unitTableFile = new UnitTableFile(); 
		int leftNumber = 4; 
		UnitTable sample = new UnitTable(4); 
		
		unitTableFile.create(sample); 
		
		UnitTable unitTable = unitTableFile.retrieve(leftNumber);
		System.out.println("read club --> " + unitTable.toString()); 
	}

}