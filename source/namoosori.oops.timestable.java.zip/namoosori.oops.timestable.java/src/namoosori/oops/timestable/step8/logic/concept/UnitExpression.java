/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.logic.concept;

public class UnitExpression {
	// 
	private int leftNumber; 
	private int rightNumber; 
	private int resultNumber; 
	
	public UnitExpression(int leftNumber, int rightNumber) {
		//
		this.leftNumber = leftNumber; 
		this.rightNumber = rightNumber; 
		this.resultNumber = leftNumber * rightNumber; 
	}

	@Override
	public String toString() {
		//
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("{"); 
		builder.append("leftNumber:").append(leftNumber); 
		builder.append(", rightNumber:").append(rightNumber); 
		builder.append(", resultNumber:").append(resultNumber); 
		builder.append("}"); 
		
		return builder.toString(); 
	}
	
	public void show(ExpressionStyle style) {
		// 
		System.out.println(
				String.format(style.formatStr(),leftNumber, rightNumber, resultNumber)); 
	}
	
	public static UnitExpression getSample() {
		// 
		return new UnitExpression(4, 5); 
	}
	
	public int getLeftNumber() {
		return leftNumber;
	}

	public void setLeftNumber(int leftNumber) {
		this.leftNumber = leftNumber;
	}

	public int getRightNumber() {
		return rightNumber;
	}

	public void setRightNumber(int rightNumber) {
		this.rightNumber = rightNumber;
	}

	public int getResultNumber() {
		return resultNumber;
	}

	public void setResultNumber(int resultNumber) {
		this.resultNumber = resultNumber;
	}
	
	public static void main(String[] args) {
		// 
		System.out.println(UnitExpression.getSample()); 
	}
}
