package namoosori.oops.timestable.step8.data.repo.mem;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;

import namoosori.oops.timestable.step8.data.store.TimesTableStore;
import namoosori.oops.timestable.step8.logic.concept.UnitTable;

public class TimesTableMemRepository implements TimesTableStore {
	//
	public Set<Integer> maxLeftNumberSet; 
	public Map<Integer,String> unitTableMap; 
	
	public TimesTableMemRepository() {
		// 
		this.maxLeftNumberSet = new HashSet<>(); 
		this.unitTableMap = new HashMap<Integer,String>(); 
	}
	
	@Override
	public int create(UnitTable unitTable) {
		// 
		int leftNumber = unitTable.getLeftNumber(); 
		String unitTableStr = new Gson().toJson(unitTable); 
		unitTableMap.put(leftNumber, unitTableStr); 
		
		return leftNumber; 
	}

	@Override
	public boolean exist(int leftNumber) {
		// 
		if (unitTableMap.get(leftNumber) != null) {
			return true; 
		}
		
		return false; 
	}
	
	@Override
	public UnitTable retrieve(int leftNumber) {
		// 
		String unitTableStr = unitTableMap.get(leftNumber); 
		
		return new Gson().fromJson(unitTableStr, UnitTable.class); 
	}

	@Override
	public void addMaxLeftNumber(int maxLeftNumber) {
		//
		maxLeftNumberSet.add(maxLeftNumber); 
	}

	@Override
	public boolean existMaxLeftNumber(int maxLeftNumber) {
		//
		if (maxLeftNumberSet.contains(maxLeftNumber)) {
			return true; 
		}
		
		return false; 
	}
}