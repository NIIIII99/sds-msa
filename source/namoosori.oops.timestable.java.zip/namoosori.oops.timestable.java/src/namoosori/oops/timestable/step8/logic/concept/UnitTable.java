/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step8.logic.concept;

import java.util.ArrayList;
import java.util.List;

public class UnitTable {
	//
	private int leftNumber; 
	private ExpressionStyle style; 
	private List<UnitExpression> expressions; 
	
	public UnitTable(int leftNumber) {
		// 
		this(leftNumber, ExpressionStyle.InEnglish); 
	}

	public UnitTable(int leftNumber, ExpressionStyle style) {
		// 
		this.leftNumber = leftNumber; 
		this.style = style; 
		this.expressions = new ArrayList<>(); 
		
		this.init(); 
	}
	
	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("leftNumber:").append(leftNumber); 
		builder.append(", style:").append(style); 
		builder.append(", expressions:").append(expressions); 
		
		return builder.toString(); 
	}
	
	private void init() {
		// 
		for(int rightNumber = 1; rightNumber<=9; rightNumber++) {
			//
			expressions.add(new UnitExpression(leftNumber, rightNumber)); 
		}
	}
	
	public static UnitTable getSample() {
		// 
		UnitTable sample = new UnitTable(4); 
		return sample; 	
	}

	public void show() {
		// 
		for(UnitExpression unitExpression : expressions) {
			unitExpression.show(style);
		}
	}
	
	public String getFormattedExpression(int rightNumber) {
		//
		UnitExpression targetExpression = expressions.get(rightNumber-1); 
			
		return String.format(style.formatStr(), 
				targetExpression.getLeftNumber(), 
				targetExpression.getRightNumber(), 
				targetExpression.getResultNumber()); 
	}
	
	public int getLeftNumber() {
		return leftNumber;
	}

	public void setLeftNumber(int leftNumber) {
		this.leftNumber = leftNumber;
	}

	public ExpressionStyle getStyle() {
		return style;
	}

	public void setStyle(ExpressionStyle style) {
		this.style = style;
	}

	public List<UnitExpression> getExpressions() {
		return expressions;
	}

	public void setExpressions(List<UnitExpression> expressions) {
		this.expressions = expressions;
	}
	
	public static void main(String[] args) {
		// 
		UnitTable sample = UnitTable.getSample(); 
		System.out.println(sample);
		sample.show();
	}
}