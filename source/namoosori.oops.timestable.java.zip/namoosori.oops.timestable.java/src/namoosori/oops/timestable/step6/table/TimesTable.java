/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step6.table;

import java.util.LinkedList;

public class TimesTable {
	//
	private LinkedList<UnitTable> unitTables; 
	
	public TimesTable() {
		// 
		this.unitTables = new LinkedList<>();
		this.initialize(); 
	}
	
	private void initialize() {
		// 
		for (int leftNumber = 2; leftNumber<=9; leftNumber++) {
			unitTables.add(new UnitTable(leftNumber)); 
		}
	}

	public LinkedList<UnitTable> getUnitTables() {
		//
		return unitTables; 
	}
 }