package namoosori.oops.timestable.step6.main;

/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.TimesTable;
import namoosori.oops.timestable.step6.view.ConsoleView;

public class TimesTableDemo {
	//
	public static void main(String[] args) {
		// 
		startDemo(); 
	}
	
	private static void startDemo() {
		//
		TimesTable timesTable = new TimesTable(); 
		
		ConsoleView consoleView = new ConsoleView(); 
		consoleView.setColoumnSize(4); 
		consoleView.setStyle(ExpressionStyle.InMath); 
		consoleView.show(timesTable); 
		
		consoleView.setColoumnSize(1); 
		consoleView.setStyle(ExpressionStyle.InMath); 
		consoleView.show(timesTable);
	}
}