/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step6.view;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import namoosori.oops.timestable.step6.table.ExpressionStyle;
import namoosori.oops.timestable.step6.table.TimesTable;
import namoosori.oops.timestable.step6.table.UnitTable;

public class ConsoleView {
	//
	private int columnCount; 
	private ExpressionStyle style; 
	private List<TableLineView> tableLines; 

	public ConsoleView() {
		//
		this.columnCount = 1; 
		this.tableLines = new ArrayList<>(); 
	}
	
	public void setColoumnSize(int columnSize) {
		//
		this.columnCount = columnSize; 
	}
	
	public void clearCommonStyle() {
		// 
		this.style = null; 
	}
	
	public boolean hasStyle() {
		// 
		if (this.style != null) {
			return true; 
		}
		
		return false; 
	}
	
	public void setStyle(ExpressionStyle style) {
		// 
		this.style = style; 
	}
	
	public void show(TimesTable timesTable) {
		//
		tableLines.clear(); 
		LinkedList<UnitTable> sourceTables = new LinkedList<>(timesTable.getUnitTables());   
		
		while(sourceTables.size() > 0) {
			//
			TableLineView lineView = new TableLineView(columnCount); 
			lineView.takeTables(sourceTables);
			if (hasStyle()) {
				lineView.setStyle(style); 
			}
			
			tableLines.add(lineView); 
 		}
 		
		showLines(); 
	}
	
	private void showLines() {
		// 
		System.out.println(""); 
		for (TableLineView tableLine : tableLines) {
			// 
			tableLine.show(); 
		}
	}
}