/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.step1;

public class TimesTable1 {
	//
	public static void main(String[] args) {
		//
		TimesTable1 table = new TimesTable1(); 
		table.showTable(); 
	}
	
	public void showTable() {  
		//
		for (int i = 2; i<=9; i++) {
			for (int j = 1; j <=9; j++) {
				System.out.format(" %2d x %d = %2d%n", i, j, (i*j)); 
			}
			
			System.out.println(" ------------"); 
		}
	}
}