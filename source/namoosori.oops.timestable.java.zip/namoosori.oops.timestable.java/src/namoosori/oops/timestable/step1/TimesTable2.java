/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */

package namoosori.oops.timestable.step1;

public class TimesTable2 {
	//
	public static void main(String[] args) {
		//
		TimesTable2 table = new TimesTable2(); 
		table.showTable(); 
	}
	
	public void showTable() {  
		//
		for (int leftNumber = 2; leftNumber<=9; leftNumber++) {
			for (int rightNumber = 1; rightNumber <=9; rightNumber++) {
				System.out.format(" %2d x %d = %2d%n", 
								leftNumber, 
								rightNumber, 
								(leftNumber*rightNumber)); 
			}
			
			System.out.println(" ------------"); 
		}
	}
}