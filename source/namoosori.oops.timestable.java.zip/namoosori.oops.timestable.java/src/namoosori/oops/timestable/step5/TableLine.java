/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */package namoosori.oops.timestable.step5;

import java.util.ArrayList;
import java.util.List;

public class TableLine {
	//
	private static final int DefaultTableLength = 20; 
	
	private List<UnitTable> unitTables; 
	
	public TableLine(List<UnitTable> unitTables, int startIndex, int count) {
		// 
		this.unitTables = new ArrayList<UnitTable>(); 
		this.takeUnitTables(unitTables, startIndex, count);
	}
 
	private void takeUnitTables(List<UnitTable> sourceUnitTables, int startIndex, int count) {
		// 
		int tableCount = sourceUnitTables.size(); 
		for(int i = startIndex; i<(startIndex+count); i++) {
			if (i==tableCount) {
				break; 
			}
			this.unitTables.add(sourceUnitTables.get(i));
		}
	}
	
	public void show() {
		//
		String lineExpression = null;  
		for (int rightNumber = 1; rightNumber<=9; rightNumber++) {
			lineExpression = getLineExpression(rightNumber); 
			System.out.println(lineExpression); 
		}
		
		System.out.println("..."); 
		
		//System.out.println(fillDot((lineExpression == null)? DefaultTableLength : lineExpression.length())); 
	}
	
	private String getLineExpression(int rightNumber) {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		for(UnitTable unitTable : unitTables) {
			String line = unitTable.getFormattedExpression(rightNumber); 
			builder.append(fillSpace(line, DefaultTableLength)); 
		}
		
		return builder.toString(); 
	}
	
	private String fillSpace(String str, int size) {
		// 
		char[] charArray = new char[size]; 
		for(int i=0; i<size; i++) {
			if(i>=str.length()) {
				charArray[i] = ' '; 
			} else {
				charArray[i] = str.charAt(i); 
			}
		}
		
		return String.valueOf(charArray); 
	}
//	
//	private String fillDot(int size) {
//		// 
//		char[] charArray = new char[size]; 
//		for (int i=0; i<size; i++) {
//			charArray[i] = '-'; 
//		}
//		
//		return String.valueOf(charArray); 
//	}
}
