/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step5;

public class TimeTableDemo {
	//
	public static void main(String[] args) {
		// 
		TimesTable timesTable = new TimesTable(); 
		timesTable.initWithDefault();
		timesTable.setColumn(2); 
		timesTable.show(); 
		timesTable.clear(); 
		
		timesTable.addTable(4);
		timesTable.addTable(5);
		timesTable.addTable(6);
		timesTable.addTable(7);
		timesTable.setColumn(3); 
		timesTable.changeStyle(ExpressionStyle.InMath); 
		timesTable.show(); 
	}
}