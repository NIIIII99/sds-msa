/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step5;

public enum ExpressionStyle {
	//
	InEnglish(" %d times %d is %2d"), 
	InJavaCode(" %d * %d = %2d"), 
	InMath(" %d x %d = %2d"), 
	InKorean(" %d 곱하기 %d 는 %2d");
	
	private String formatStr; 
	
	private ExpressionStyle(String formatStr) {
		this.formatStr = formatStr; 
	}
	
	public String formatStr() {
		return formatStr; 
	}
	
	public static void main(String[] args) {
		// 
		UnitExpression sample = UnitExpression.getSample(); 
		
		System.out.format(InEnglish.formatStr(), 
						sample.getLeftNumber(), 
						sample.getRightNumber(), 
						sample.getResultNumber()); 

		System.out.format(InMath.formatStr(), 
						sample.getLeftNumber(), 
						sample.getRightNumber(), 
						sample.getResultNumber()); 

	}
}