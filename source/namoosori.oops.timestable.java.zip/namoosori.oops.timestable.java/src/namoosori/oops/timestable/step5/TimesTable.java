/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step5;

import java.util.ArrayList;
import java.util.List;

public class TimesTable {
	//
	private List<UnitTable> unitTables; 
	private Console console; 
	
	public TimesTable() {
		// 
		this.unitTables = new ArrayList<>();
		this.console = new Console(1); 
	}
	
	public void clear() {
		this.unitTables.clear(); 
	}
	
	public void setColumn(int column) {
		// 
		this.console = new Console(column); 
	}
	
	public void changeStyle(ExpressionStyle style) {
		// 
		for(UnitTable unitTable : unitTables) {
			unitTable.setStyle(style);
		}
	}
	
	public void addTable(UnitTable unitTable) {
		// 
		this.unitTables.add(unitTable); 
	}

	public void addTable(int leftNumber) {
		// 
		this.unitTables.add(new UnitTable(leftNumber)); 
	}

	public void initWithDefault() {
		// 
		for (int leftNumber = 2; leftNumber<=9; leftNumber++) {
			unitTables.add(new UnitTable(leftNumber)); 
		}
	}
	
	public void show() {
		// 
		console.show(unitTables); 
	}
 }