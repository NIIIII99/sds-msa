/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.oops.timestable.step5;

import java.util.ArrayList;
import java.util.List;

public class Console {
	//
	private int columnSize; 
	private List<TableLine> tableLines; 

	public Console(int columnSize) {
		//
		this.columnSize = columnSize; 
		this.tableLines = new ArrayList<>(); 
	}
	
	public void show(List<UnitTable> unitTables) {
		//
		this.tableLines.clear(); 
		
		int unitTableCount = unitTables.size(); 
		for(int i=0; i<unitTableCount;) {
			//
			tableLines.add(new TableLine(unitTables, i, columnSize)); 
			i += columnSize; 
		}
 		
		showLines(); 
	}
	
	private void showLines() {
		// 
		for (TableLine tableLine : tableLines) {
			// 
			tableLine.show(); 
		}
	}
}