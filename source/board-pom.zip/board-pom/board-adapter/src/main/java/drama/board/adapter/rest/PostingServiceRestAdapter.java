package drama.board.adapter.rest;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.spec.posting.PostingService;
import drama.board.domain.spec.posting.sdo.PostingCdo;
import nara.share.domain.NameValueList;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class PostingServiceRestAdapter implements PostingService {

    private NaraRestClient naraRestClient;

    public PostingServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public PostingBody registerPosting(PostingCdo postingCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_REGISTER)
            .setRequestBody(postingCdo)
            .setResponseType(PostingBody.class)
        );
    }

    @Override
    public Posting findPosting(String postingId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_FIND)
            .addPathParam("postingId", postingId)
            .setResponseType(Posting.class)
        );
    }

    @Override
    public PostingBody findPostingBody(String postingId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_BODY_FIND)
                .addPathParam("postingId", postingId)
                .setResponseType(PostingBody.class)
        );
    }

    @Override
    public List<Posting> findPostingsLatest(String boardId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_FIND_LATEST_BY)
                .addQueryParam("boardId", boardId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(Posting[].class)
        ));
    }

    @Override
    public List<Posting> findPostingsOldest(String boardId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_FIND_OLDEST_BY)
                .addQueryParam("boardId", boardId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(Posting[].class)
        ));
    }

    @Override
    public List<Posting> findPostingsByTag(String boardId, String tag, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_FIND_OLDEST_BY)
                .addQueryParam("boardId", boardId)
                .addQueryParam("tag", tag)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(Posting[].class)
        ));
    }

    @Override
    public void modifyPosting(String postingId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_MODIFY)
            .addPathParam("postingId", postingId)
            .setRequestBody(nameValues)
        );
    }

    @Override
    public void modifyPostingBody(String postingId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_BODY_MODIFY)
                .addPathParam("postingId", postingId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removePosting(String postingId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_REMOVE)
                .addPathParam("postingId", postingId)
        );
    }

    @Override
    public void removeAllPosting(String boardId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_REMOVE)
                .addQueryParam("boardId", boardId)
        );
    }
}
