package drama.board.adapter.rest;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.spec.comment.CommentService;
import drama.board.domain.spec.comment.sdo.CommentCdo;
import drama.board.domain.spec.comment.sdo.CommentVoteCdo;
import drama.board.domain.spec.comment.sdo.SubCommentCdo;
import nara.share.domain.NameValueList;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class CommentServiceRestAdapter implements CommentService {
    //
    private NaraRestClient naraRestClient;

    public CommentServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerComment(String postingId, CommentCdo commentCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_REGISTER)
            .addQueryParam("postingId", postingId)
            .setRequestBody(commentCdo)
            .setResponseType(String.class)
        );
    }

    @Override
    public Comment findComment(String commentId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_FIND)
            .addPathParam("commentId", commentId)
            .setResponseType(Comment.class)
        );
    }

    @Override
    public List<Comment> findCommentsByPosting(String postingId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_FIND_BY)
            .addQueryParam("postingId", postingId)
            .addQueryParam("offset", offset)
            .addQueryParam("limit", limit)
            .setResponseType(Comment[].class)
        ));
    }

    @Override
    public List<Comment> findCommentsByPlayer(String playerId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_FIND_BY)
                .addQueryParam("playerId", playerId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(Comment[].class)
        ));
    }

    @Override
    public long countCommentsByPlayer(String playerId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_COUNT_BY)
                .addQueryParam("playerId", playerId)
                .setResponseType(long.class)
        );
    }

    @Override
    public void modifyComment(String commentId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_MODIFY)
                .addPathParam("commentId", commentId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeComment(String commentId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_REMOVE)
                .addPathParam("commentId", commentId)
        );
    }

    @Override
    public void removeCommentsByPosting(String postingId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_REMOVE_BY)
                .addQueryParam("postingId", postingId)
        );
    }

    @Override
    public long countCommentsByPosting(String postingId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_COUNT_BY)
                .addQueryParam("postingId", postingId)
                .setResponseType(long.class)
        );
    }

    @Override
    public long addCommentVote(String commentId, CommentVoteCdo commentVoteCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_COMMENT_VOTE_REGISTER)
                .addPathParam("commentId", commentId)
                .setRequestBody(commentVoteCdo)
                .setResponseType(long.class)
        );
    }

    @Override
    public String registerSubComment(String commentId, SubCommentCdo subCommentCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_REGISTER)
                .addPathParam("commentId", commentId)
                .setRequestBody(subCommentCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public List<SubComment> findSubCommentsByComment(String commentId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_FIND_BY)
                .addPathParam("commentId", commentId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(SubComment[].class)
        ));
    }

    @Override
    public long countSubCommentsByComment(String commentId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_COUNT_BY)
                .addQueryParam("commentId", commentId)
                .setResponseType(long.class)
        );
    }

    @Override
    public void updateSubComment(String subCommentId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_UPDATE)
                .addPathParam("subCommentId", subCommentId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeSubComment(String subCommentId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_REMOVE)
                .addPathParam("subCommentId", subCommentId)
        );
    }

    @Override
    public void removeSubCommentsByComment(String commentId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SUB_COMMENT_REMOVE_BY)
                .addQueryParam("commentId", commentId)
        );
    }
}
