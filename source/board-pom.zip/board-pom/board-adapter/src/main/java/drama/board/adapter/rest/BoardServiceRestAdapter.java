package drama.board.adapter.rest;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import drama.board.domain.spec.board.BoardService;
import drama.board.domain.spec.board.sdo.BoardCdo;
import nara.share.domain.NameValueList;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class BoardServiceRestAdapter implements BoardService {
    //
    private NaraRestClient naraRestClient;

    public BoardServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerBoard(String panelId, BoardCdo boardCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_REGISTER)
            .addQueryParam("panelId", panelId)
            .setRequestBody(boardCdo)
            .setResponseType(String.class)
        );
    }

    @Override
    public Board findBoard(String boardId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_FIND)
            .addPathParam("boardId", boardId)
            .setResponseType(Board.class)
        );
    }

    @Override
    public List<Board> findBoards(String panelId) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_FIND_BY)
                .addQueryParam("panelId", panelId)
                .setResponseType(Board[].class)
        ));
    }

    @Override
    public List<Board> findPublicBoards(String panelId) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_PUBLIC_BOARD_FIND_BY)
                .addQueryParam("panelId", panelId)
                .setResponseType(Board[].class)
        ));
    }

    @Override
    public PostingRule findPostingRule(String boardId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_POSTING_RULE_FIND)
                .addPathParam("boardId", boardId)
                .setResponseType(PostingRule.class)
        );
    }

    @Override
    public void modifyBoard(String boardId, NameValueList nameValus) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_MODIFY)
            .addPathParam("boardId", boardId)
            .setRequestBody(nameValus)
        );
    }

    @Override
    public void removeBoard(String boardId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_REMOVE)
                .addPathParam("boardId", boardId)
        );
    }

    @Override
    public void enforceRemoveBoard(String boardId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_REMOVE_ENFORCE)
                .addPathParam("boardId", boardId)
        );
    }
}
