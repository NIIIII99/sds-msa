package drama.board.adapter.rest;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.spec.panel.BoardPanelService;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import nara.share.domain.NameValueList;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class BoardPanelServiceRestAdapter implements BoardPanelService {
    //
    private NaraRestClient naraRestClient;

    public BoardPanelServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public BoardPanel buildBoardPanel(BoardPanelCdo boardPanelCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_BUILD)
            .setRequestBody(boardPanelCdo)
            .setResponseType(BoardPanel.class)
        );
    }

    @Override
    public BoardPanel findBoardPanel(String panelId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_FIND)
            .addPathParam("panelId", panelId)
            .setResponseType(BoardPanel.class)
        );
    }

    @Override
    public List<PreSetting> findPreSettings(String panelId) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_PRE_SETTINGS_FIND)
            .addPathParam("panelId", panelId)
            .setResponseType(PreSetting[].class)
        ));
    }

    @Override
    public PreSetting findPreSetting(String panelId, String title) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_PRE_SETTINGS_FIND)
                .addPathParam("panelId", panelId)
                .addQueryParam("title", title)
                .setResponseType(PreSetting.class)
        );
    }

    @Override
    public void modifyBoardPanel(String panelId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_MODIFY)
            .addPathParam("panelId", panelId)
            .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeBoardPanel(String panelId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_BOARD_PANEL_REMOVE)
                .addPathParam("panelId", panelId)
        );
    }
}
