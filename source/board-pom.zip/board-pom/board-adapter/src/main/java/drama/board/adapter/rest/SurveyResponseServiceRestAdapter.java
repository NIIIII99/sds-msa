package drama.board.adapter.rest;

import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.spec.survey.SurveyResponseService;
import drama.board.domain.spec.survey.sdo.SurveyResponseCdo;
import nara.share.domain.NameValueList;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class SurveyResponseServiceRestAdapter implements SurveyResponseService {
    //
    private NaraRestClient naraRestClient;

    public SurveyResponseServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerResponse(SurveyResponseCdo responseCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_REGISTER)
                .setRequestBody(responseCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_REGISTER)
                .addQueryParam("postingId", postingId)
                .setResponseType(long.class)
        );
    }

    @Override
    public String markResponseAsAnswered(SurveyResponseCdo responseCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_CHECKED)
            .setRequestBody(responseCdo)
            .setResponseType(String.class)
        );
    }

    @Override
    public SurveyResponse findResponse(String responseId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_FIND)
                .addPathParam("responseId", responseId)
                .setResponseType(SurveyResponse.class)
        );
    }

    @Override
    public List<SurveyResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_FIND_BY)
                .addQueryParam("postingId", postingId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(SurveyResponse[].class)
        ));
    }

    @Override
    public List<SurveyResponse> findResponsesByPostingAnswered(String postingId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_CHECKED_FIND_BY)
                .addQueryParam("postingId", postingId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(SurveyResponse[].class)
        ));
    }

    @Override
    public void modifyResponse(String responseId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_MODIFY)
                .addPathParam("responseId", responseId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeResponse(String responseId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_REMOVE)
                .addPathParam("responseId", responseId)
        );
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_SURVEY_RESPONSE_REMOVE_BY)
                .addPathParam("postingId", postingId)
        );
    }
}
