package drama.board.adapter.rest;

import nara.share.restclient.HttpMethod;
import nara.share.restclient.NaraRestUrl;

public enum BoardRestUrl implements NaraRestUrl {
    //
    // BoardPanelService
    URL_S_BOARD_PANEL_BUILD             ("board-api/s/board-panels",                        HttpMethod.POST),
    URL_S_BOARD_PANEL_FIND              ("board-api/s/board-panels/{panelId}",              HttpMethod.GET),
    URL_S_BOARD_PANEL_PRE_SETTINGS_FIND ("board-api/s/board-panels/{panelId}/pre-settings", HttpMethod.GET),
    URL_S_BOARD_PANEL_MODIFY            ("board-api/s/board-panels/{panelId}",              HttpMethod.PUT),
    URL_S_BOARD_PANEL_REMOVE            ("board-api/s/board-panels/{panelId}",              HttpMethod.DELETE),

    // BoardService
    URL_S_BOARD_REGISTER                ("board-api/s/boards",                              HttpMethod.POST),
    URL_S_BOARD_FIND                    ("board-api/s/boards/{boardId}",                    HttpMethod.GET),
    URL_S_BOARD_FIND_BY                 ("board-api/s/boards",                              HttpMethod.GET),
    URL_S_PUBLIC_BOARD_FIND_BY          ("board-api/s/boards/public",                       HttpMethod.GET),
    URL_S_POSTING_RULE_FIND             ("board-api/s/boards/{boardId}/posting-rule",       HttpMethod.GET),
    URL_S_BOARD_MODIFY                  ("board-api/s/boards/{boardId}",                    HttpMethod.PUT),
    URL_S_BOARD_REMOVE                  ("board-api/s/boards/{boardId}",                    HttpMethod.DELETE),
    URL_S_BOARD_REMOVE_ENFORCE          ("board-api/s/boards/{boardId}/enforce",            HttpMethod.DELETE),

    // PostingService
    URL_S_POSTING_REGISTER              ("board-api/s/postings",                            HttpMethod.POST),
    URL_S_POSTING_FIND                  ("board-api/s/postings/{postingId}",                HttpMethod.GET),
    URL_S_POSTING_BODY_FIND             ("board-api/s/postings/{postingId}/body",           HttpMethod.GET),
    URL_S_POSTING_FIND_LATEST_BY        ("board-api/s/postings/latest",                     HttpMethod.GET),
    URL_S_POSTING_FIND_OLDEST_BY        ("board-api/s/postings/oldest",                     HttpMethod.GET),
    URL_S_POSTING_MODIFY                ("board-api/s/postings/{postingId}",                HttpMethod.PUT),
    URL_S_POSTING_BODY_MODIFY           ("board-api/s/postings/{postingId}/body",           HttpMethod.PUT),
    URL_S_POSTING_REMOVE                ("board-api/s/postings/{postingId}",                HttpMethod.DELETE),
    URL_S_POSTING_REMOVE_BY             ("board-api/s/postings",                            HttpMethod.DELETE),

    // CommentService
    URL_S_COMMENT_REGISTER              ("board-api/s/comments",                            HttpMethod.POST),
    URL_S_COMMENT_FIND                  ("board-api/s/comments/{commentId}",                HttpMethod.GET),
    URL_S_COMMENT_FIND_BY               ("board-api/s/comments",                            HttpMethod.GET),
    URL_S_COMMENT_COUNT_BY              ("board-api/s/comments/count",                      HttpMethod.GET),
    URL_S_COMMENT_MODIFY                ("board-api/s/comments/{commentId}",                HttpMethod.PUT),
    URL_S_COMMENT_REMOVE                ("board-api/s/comments/{commentId}",                HttpMethod.DELETE),
    URL_S_COMMENT_REMOVE_BY             ("board-api/s/comments",                            HttpMethod.DELETE),
    URL_S_COMMENT_VOTE_REGISTER         ("board-api/s/comments/{commentId}/vote",           HttpMethod.PUT),

    URL_S_SUB_COMMENT_REGISTER          ("board-api/s/comments/{commentId}/sub-comments",         HttpMethod.POST),
    URL_S_SUB_COMMENT_FIND_BY           ("board-api/s/comments/{commentId}/sub-comments",         HttpMethod.GET),
    URL_S_SUB_COMMENT_COUNT_BY          ("board-api/s/comments/{commentId}/sub-comments/count",   HttpMethod.GET),
    URL_S_SUB_COMMENT_UPDATE            ("board-api/s/sub-comments/{subCommentId}",               HttpMethod.PUT),
    URL_S_SUB_COMMENT_REMOVE            ("board-api/s/sub-comments/{subCommentId}",               HttpMethod.DELETE),
    URL_S_SUB_COMMENT_REMOVE_BY         ("board-api/s/comments/{commentId}/sub-comments",         HttpMethod.DELETE),

    // NotifyingResponseService
    URL_S_NOTIFYING_RESPONSE_REGISTER           ("board-api/s/notifying-responses",               HttpMethod.POST),
    URL_S_NOTIFYING_RESPONSE_CHECKED            ("board-api/s/notifying-responses/checked",       HttpMethod.PUT),
    URL_S_NOTIFYING_RESPONSE_FIND               ("board-api/s/notifying-responses/{responseId}",  HttpMethod.GET),
    URL_S_NOTIFYING_RESPONSE_FIND_BY            ("board-api/s/notifying-responses",               HttpMethod.GET),
    URL_S_NOTIFYING_RESPONSE_CHECKED_FIND_BY    ("board-api/s/notifying-responses/checked",       HttpMethod.GET),
    URL_S_NOTIFYING_RESPONSE_REMOVE             ("board-api/s/notifying-responses/{responseId}",  HttpMethod.DELETE),
    URL_S_NOTIFYING_RESPONSE_REMOVE_BY          ("board-api/s/notifying-responses",               HttpMethod.DELETE),

    // NotifyingResponseService
    URL_S_SURVEY_RESPONSE_REGISTER              ("board-api/s/survey-responses",               HttpMethod.POST),
    URL_S_SURVEY_RESPONSE_CHECKED               ("board-api/s/survey-responses/checked",       HttpMethod.PUT),
    URL_S_SURVEY_RESPONSE_FIND                  ("board-api/s/survey-responses/{responseId}",  HttpMethod.GET),
    URL_S_SURVEY_RESPONSE_FIND_BY               ("board-api/s/survey-responses",               HttpMethod.GET),
    URL_S_SURVEY_RESPONSE_CHECKED_FIND_BY       ("board-api/s/survey-responses/checked",       HttpMethod.GET),
    URL_S_SURVEY_RESPONSE_MODIFY                ("board-api/s/survey-responses/{responseId}",  HttpMethod.PUT),
    URL_S_SURVEY_RESPONSE_REMOVE                ("board-api/s/survey-responses/{responseId}",  HttpMethod.DELETE),
    URL_S_SURVEY_RESPONSE_REMOVE_BY             ("board-api/s/survey-responses",               HttpMethod.DELETE),

    ;
    private String serviceUrl;
    private HttpMethod method;

    BoardRestUrl(String serviceUrl, HttpMethod httpMethod) {
        //
        this.serviceUrl = serviceUrl;
        this.method = httpMethod;
    }


    @Override
    public String getUrl() {
        return this.serviceUrl;
    }

    @Override
    public HttpMethod getMethod() {
        return this.method;
    }
}
