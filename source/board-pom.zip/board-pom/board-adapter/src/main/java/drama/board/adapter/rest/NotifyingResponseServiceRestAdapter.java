package drama.board.adapter.rest;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.spec.notifying.NotifyingResponseService;
import drama.board.domain.spec.notifying.sdo.NotifyingResponseCdo;
import nara.share.restclient.NaraRestClient;
import nara.share.restclient.RequestBuilder;

import java.util.Arrays;
import java.util.List;

public class NotifyingResponseServiceRestAdapter implements NotifyingResponseService {
    //
    private NaraRestClient naraRestClient;

    public NotifyingResponseServiceRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerResponse(NotifyingResponseCdo responseCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_REGISTER)
                .setRequestBody(responseCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_REGISTER)
                .addQueryParam("postingId", postingId)
                .setResponseType(long.class)
        );
    }

    @Override
    public String markResponseAsChecked(NotifyingResponseCdo responseCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_CHECKED)
            .setRequestBody(responseCdo)
            .setResponseType(String.class)
        );
    }

    @Override
    public NotifyingResponse findResponse(String responseId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_FIND)
                .addPathParam("responseId", responseId)
                .setResponseType(NotifyingResponse.class)
        );
    }

    @Override
    public List<NotifyingResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_FIND_BY)
                .addQueryParam("postingId", postingId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(NotifyingResponse[].class)
        ));
    }

    @Override
    public List<NotifyingResponse> findResponsesByCheckedPosting(String postingId, int offset, int limit) {
        //
        return Arrays.asList(naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_CHECKED_FIND_BY)
                .addQueryParam("postingId", postingId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(NotifyingResponse[].class)
        ));
    }

    @Override
    public void removeResponse(String responseId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_REMOVE)
                .addPathParam("responseId", responseId)
        );
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(BoardRestUrl.URL_S_NOTIFYING_RESPONSE_REMOVE_BY)
                .addPathParam("postingId", postingId)
        );
    }
}
