package drama.board.sp.spring.web;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import drama.board.domain.logic.BoardLogic;
import drama.board.domain.spec.board.BoardService;
import drama.board.domain.spec.board.sdo.BoardCdo;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("board-api/s/boards")
public class BoardServiceResource implements BoardService {
    //
    @Autowired
    private BoardLogic boardLogic;

    @Override
    @PostMapping
    public String registerBoard(@RequestParam String panelId, @RequestBody BoardCdo boardCdo) {
        //
        return boardLogic.registerBoard(panelId, boardCdo);
    }

    @Override
    @GetMapping("{boardId}")
    public Board findBoard(@PathVariable String boardId) {
        //
        return boardLogic.findBoard(boardId);
    }

    @Override
    @GetMapping(params = "panelId")
    public List<Board> findBoards(@RequestParam String panelId) {
        //
        return boardLogic.findBoards(panelId);
    }

    @Override
    @GetMapping(value = "public", params = "panelId")
    public List<Board> findPublicBoards(@RequestParam String panelId) {
        //
        return boardLogic.findPublicBoards(panelId);
    }

    @Override
    @GetMapping("{boardId}/posting-rule")
    public PostingRule findPostingRule(@PathVariable String boardId) {
        //
        return boardLogic.findPostingRule(boardId);
    }

    @Override
    @PutMapping("{boardId}")
    public void modifyBoard(@PathVariable String boardId, @RequestBody NameValueList nameValus) {
        //
        boardLogic.modifyBoard(boardId, nameValus);
    }

    @Override
    @DeleteMapping("{boardId}")
    public void removeBoard(@PathVariable String boardId) {
        //
        boardLogic.removeBoard(boardId);
    }

    @Override
    @DeleteMapping("{boardId}/enforce")
    public void enforceRemoveBoard(@PathVariable String boardId) {
        //
        boardLogic.enforceRemoveBoard(boardId);
    }
}
