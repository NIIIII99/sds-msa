package drama.board.sp.spring.web;

import drama.board.domain.entity.posting.Content;
import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.logic.PostingLogic;
import drama.board.domain.spec.posting.PostingService;
import drama.board.domain.spec.posting.sdo.PostingCdo;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Screen;
import nara.stage.context.DramaContext;
import nara.stage.context.DramaRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("board-api/s/postings")
public class PostingServiceResource implements PostingService {
    //
    @Autowired
    private PostingLogic postingLogic;


    @GetMapping("{boardId}/init/{title}")
    public PostingBody testInit(@PathVariable String boardId, @PathVariable String title) {
        //
        Screen screen = Screen.getSample();
        Actor actor = Actor.getSample();
        DramaRequest current = new DramaRequest(screen, actor);
        DramaContext.setCurrentRequest(current);

        Content content = new Content("안녕하세요. 인사글입니다.");
        boolean anonymous = false;

        PostingCdo cdo = new PostingCdo(title, content, anonymous, boardId);

        return this.registerPosting(cdo);
    }

    @Override
    @PostMapping
    public PostingBody registerPosting(@RequestBody PostingCdo postingCdo) {
        //
        return postingLogic.registerPosting(postingCdo);
    }

    @Override
    @GetMapping("{postingId}")
    public Posting findPosting(@PathVariable String postingId) {
        //
        return postingLogic.findPosting(postingId);
    }

    @Override
    @GetMapping("{postingId}/body")
    public PostingBody findPostingBody(@PathVariable String postingId) {
        //
        return postingLogic.findPostingBody(postingId);
    }

    @Override
    @GetMapping(value = "latest", params = {"boardId", "offset", "limit"})
    public List<Posting> findPostingsLatest(@RequestParam String boardId, @RequestParam int offset, @RequestParam int limit) {
        //
        return postingLogic.findPostingsLatest(boardId, offset, limit);
    }

    @Override
    @GetMapping(value = "oldest", params = {"boardId", "offset", "limit"})
    public List<Posting> findPostingsOldest(@RequestParam String boardId, @RequestParam int offset, @RequestParam int limit) {
        //
        return postingLogic.findPostingsOldest(boardId, offset, limit);
    }

    @Override
    @GetMapping(params = {"boardId", "tag", "offset", "limit"})
    public List<Posting> findPostingsByTag(@RequestParam String boardId, @RequestParam String tag, @RequestParam int offset, @RequestParam int limit) {
        //
        return postingLogic.findPostingsByTag(boardId, tag, offset, limit);
    }

    @Override
    @PutMapping("{postingId}")
    public void modifyPosting(@PathVariable String postingId, @RequestBody NameValueList nameValues) {
        //
        postingLogic.modifyPosting(postingId, nameValues);
    }

    @Override
    @PutMapping("{postingId}/body")
    public void modifyPostingBody(@PathVariable String postingId, @RequestBody NameValueList nameValues) {
        //
        postingLogic.modifyPostingBody(postingId, nameValues);
    }

    @Override
    @DeleteMapping("{postingId}")
    public void removePosting(@PathVariable String postingId) {
        //
        postingLogic.removePosting(postingId);
    }

    @Override
    @DeleteMapping
    public void removeAllPosting(@RequestParam String boardId) {
        //
        postingLogic.removeAllPosting(boardId);
    }
}
