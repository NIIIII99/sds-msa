package drama.board.sp.spring.web;

import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Screen;
import nara.stage.context.DramaContext;
import nara.stage.context.DramaRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BoardPlayResource {
    //
    @Value("${nara.common.asset.location}")
    private String commonAssetLocation;

    @RequestMapping("/**")
    public String index(Model model) {
        //
        model.addAttribute("commonAssetLocation", commonAssetLocation);

        return "index";
    }

    @GetMapping("/board-api/s/test-context")
    @ResponseBody
    public boolean initTestContext() {
        Screen screen = Screen.getSample();
        Actor actor = Actor.getSample();

        DramaRequest current = new DramaRequest(screen, actor);
        DramaContext.setCurrentRequest(current);

        return true;
    }
}
