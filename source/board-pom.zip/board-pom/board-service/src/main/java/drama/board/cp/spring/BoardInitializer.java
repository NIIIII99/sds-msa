package drama.board.cp.spring;

import nara.share.domain.RoleLevel;
import nara.stage.context.DramaContext;
import nara.stage.domain.entity.dramarepo.dramaspec.model.DramaEdition;
import nara.stage.domain.entity.dramarepo.dramaspec.model.DramaRole;
import nara.stage.domain.entity.dramarepo.dramaspec.model.DramaSettings;
import nara.stage.domain.entity.dramarepo.dramaspec.model.DramaSpec;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.Locale;

public class BoardInitializer {
    //
    @Value("${nara.stage.host}")
    private String stageHost;

    @Value("${nara.drama.host}")
    private String dramaHost;

    @Value("${nara.drama.usid}")
    private String dramaUsid;

    @Value("${nara.drama.version}")
    private String version;

    @Value("${nara.drama.spec.scan.package}")
    private String specScanPackage;

    @PostConstruct
    public void initialize() {
        //
        DramaSettings dramaSettings = new DramaSettings(dramaHost, "/", "/board-api", "/resources");
        dramaSettings.setSupportMultiLanguage(true);
        dramaSettings.setDefaultLanguage(Locale.US.getLanguage());

        DramaSpec dramaSpec = new DramaSpec(
                dramaUsid, version,
                Arrays.asList(
                        new DramaEdition(0, "Community"),
                        new DramaEdition(1, "Professional"),
                        new DramaEdition(2, "Enterprise")),
                Arrays.asList(
                        new DramaRole("Admin", RoleLevel.Admin),
                        new DramaRole("User", RoleLevel.Normal))
        );

        DramaContext dramaContext = DramaContext.getInstance();
        dramaContext.setStageHost(stageHost);
        dramaContext.setTroupeName("Nextree");
        dramaContext.setTroupeEmail("kchuh@nextree.co.kr");
        dramaContext.setSpecPackage(specScanPackage);

        dramaContext.addLanguageCaption(Locale.KOREA.getLanguage(), "caption_ko.json");
        dramaContext.addLanguageCaption(Locale.US.getLanguage(), "caption_en.json");

        dramaContext.initialize(dramaSpec, dramaSettings);
    }
}
