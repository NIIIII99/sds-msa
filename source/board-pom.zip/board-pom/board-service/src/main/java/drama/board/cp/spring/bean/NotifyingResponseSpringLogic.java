package drama.board.cp.spring.bean;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.logic.NotifyingResponseLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.notifying.sdo.NotifyingResponseCdo;
import drama.board.domain.store.BoardStoreLycler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class NotifyingResponseSpringLogic extends NotifyingResponseLogic {
    //
    @Autowired
    public NotifyingResponseSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        super(proxyLycler, storeLycler);
    }

    @Override
    public String registerResponse(NotifyingResponseCdo responseCdo) {
        return super.registerResponse(responseCdo);
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        return super.buildFullResponsesForPosting(postingId);
    }

    @Override
    public String markResponseAsChecked(NotifyingResponseCdo responseCdo) {
        return super.markResponseAsChecked(responseCdo);
    }

    @Override
    public NotifyingResponse findResponse(String responseId) {
        return super.findResponse(responseId);
    }

    @Override
    public List<NotifyingResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        return super.findResponsesByPosting(postingId, offset, limit);
    }

    @Override
    public List<NotifyingResponse> findResponsesByCheckedPosting(String postingId, int offset, int limit) {
        return super.findResponsesByCheckedPosting(postingId, offset, limit);
    }

    @Override
    public void removeResponse(String responseId) {
        super.removeResponse(responseId);
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        super.removeAllResponsesByPosting(postingId);
    }
}
