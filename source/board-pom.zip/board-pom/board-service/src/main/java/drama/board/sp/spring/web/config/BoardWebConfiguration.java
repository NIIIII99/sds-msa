package drama.board.sp.spring.web.config;

import nara.stage.context.spring.interceptor.DramaRequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

@Configuration
public class BoardWebConfiguration extends WebMvcConfigurationSupport {

    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        //
        registry.addResourceHandler("/res/**").addResourceLocations("classpath:/dist/app/");
        registry.setOrder(0);
    }

    @Override
    public RequestMappingHandlerMapping requestMappingHandlerMapping() {
        //
        RequestMappingHandlerMapping handler = super.requestMappingHandlerMapping();
        handler.setOrder(1);
        return handler;
    }

    @Override
    protected void addInterceptors(InterceptorRegistry registry) {
        //
        registry.addInterceptor(boardDramaRequestInterceptor());
    }

    @Bean
    public DramaRequestInterceptor boardDramaRequestInterceptor() {
        return new DramaRequestInterceptor();
    }
}
