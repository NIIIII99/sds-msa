package drama.board.cp.spring.bean;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.logic.PostingLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.posting.sdo.PostingCdo;
import drama.board.domain.store.BoardStoreLycler;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PostingSpringLogic extends PostingLogic {
    //
    @Autowired
    public PostingSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        super(proxyLycler, storeLycler);
    }

    @Override
    public PostingBody registerPosting(PostingCdo postingCdo) {
        return super.registerPosting(postingCdo);
    }

    @Override
    public Posting findPosting(String postingId) {
        return super.findPosting(postingId);
    }

    @Override
    public PostingBody findPostingBody(String postingId) {
        return super.findPostingBody(postingId);
    }

    @Override
    public List<Posting> findPostingsLatest(String boardId, int offset, int limit) {
        return super.findPostingsLatest(boardId, offset, limit);
    }

    @Override
    public List<Posting> findPostingsOldest(String boardId, int offset, int limit) {
        return super.findPostingsOldest(boardId, offset, limit);
    }

    @Override
    public List<Posting> findPostingsByTag(String boardId, String tag, int offset, int limit) {
        return super.findPostingsByTag(boardId, tag, offset, limit);
    }

    @Override
    public void modifyPosting(String postingId, NameValueList nameValues) {
        super.modifyPosting(postingId, nameValues);
    }

    @Override
    public void modifyPostingBody(String postingId, NameValueList nameValues) {
        super.modifyPostingBody(postingId, nameValues);
    }

    @Override
    public void removePosting(String postingId) {
        super.removePosting(postingId);
    }

    @Override
    public void removeAllPosting(String boardId) {
        super.removeAllPosting(boardId);
    }
}
