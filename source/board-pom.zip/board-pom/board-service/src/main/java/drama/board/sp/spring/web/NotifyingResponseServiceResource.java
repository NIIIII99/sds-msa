package drama.board.sp.spring.web;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.logic.NotifyingResponseLogic;
import drama.board.domain.spec.notifying.NotifyingResponseService;
import drama.board.domain.spec.notifying.sdo.NotifyingResponseCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("board-api/s/notifying-responses")
public class NotifyingResponseServiceResource implements NotifyingResponseService {
    //
    @Autowired
    private NotifyingResponseLogic responseLogic;

    @Override
    @PostMapping
    public String registerResponse(@RequestBody NotifyingResponseCdo responseCdo) {
        //
        return responseLogic.registerResponse(responseCdo);
    }

    @Override
    @PostMapping(params = "postingId")
    public long buildFullResponsesForPosting(@RequestParam String postingId) {
        //
        return responseLogic.buildFullResponsesForPosting(postingId);
    }

    @Override
    @PutMapping(value = "checked")
    public String markResponseAsChecked(@RequestBody NotifyingResponseCdo responseCdo) {
        //
        return responseLogic.markResponseAsChecked(responseCdo);
    }

    @Override
    @GetMapping("{responseId}")
    public NotifyingResponse findResponse(@PathVariable String responseId) {
        //
        return responseLogic.findResponse(responseId);
    }

    @Override
    @GetMapping(params = {"postingId", "offset", "limit"})
    public List<NotifyingResponse> findResponsesByPosting(@RequestParam String postingId, @RequestParam int offset, @RequestParam int limit) {
        //
        return responseLogic.findResponsesByPosting(postingId, offset, limit);
    }

    @Override
    @GetMapping(value = "checked", params = {"postingId", "offset", "limit"})
    public List<NotifyingResponse> findResponsesByCheckedPosting(@RequestParam String postingId, @RequestParam int offset, @RequestParam int limit) {
        //
        return responseLogic.findResponsesByCheckedPosting(postingId, offset, limit);
    }

    @Override
    @DeleteMapping("{responseId}")
    public void removeResponse(@PathVariable String responseId) {
        //
        responseLogic.removeResponse(responseId);
    }

    @Override
    @DeleteMapping(params = "postingId")
    public void removeAllResponsesByPosting(@RequestParam String postingId) {
        //
        responseLogic.removeAllResponsesByPosting(postingId);
    }
}
