package drama.board.cp.spring.bean;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.logic.CommentLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.comment.sdo.CommentCdo;
import drama.board.domain.spec.comment.sdo.CommentVoteCdo;
import drama.board.domain.spec.comment.sdo.SubCommentCdo;
import drama.board.domain.store.BoardStoreLycler;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CommentSpringLogic extends CommentLogic {
    //
    @Autowired
    public CommentSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        super(proxyLycler, storeLycler);
    }

    @Override
    public String registerComment(String postingId, CommentCdo commentCdo) {
        return super.registerComment(postingId, commentCdo);
    }

    @Override
    public Comment findComment(String commentId) {
        return super.findComment(commentId);
    }

    @Override
    public List<Comment> findCommentsByPosting(String postingId, int offset, int limit) {
        return super.findCommentsByPosting(postingId, offset, limit);
    }

    @Override
    public List<Comment> findCommentsByPlayer(String playerId, int offset, int limit) {
        return super.findCommentsByPlayer(playerId, offset, limit);
    }

    @Override
    public long countCommentsByPlayer(String playerId) {
        return super.countCommentsByPlayer(playerId);
    }

    @Override
    public void modifyComment(String commentId, NameValueList nameValues) {
        super.modifyComment(commentId, nameValues);
    }

    @Override
    public void removeComment(String commentId) {
        super.removeComment(commentId);
    }

    @Override
    public void removeCommentsByPosting(String postingId) {
        super.removeCommentsByPosting(postingId);
    }

    @Override
    public long countCommentsByPosting(String postingId) {
        return super.countCommentsByPosting(postingId);
    }

    @Override
    public long addCommentVote(String commentId, CommentVoteCdo commentVoteCdo) {
        return super.addCommentVote(commentId, commentVoteCdo);
    }

    @Override
    public String registerSubComment(String commentId, SubCommentCdo subCommentCdo) {
        return super.registerSubComment(commentId, subCommentCdo);
    }

    @Override
    public List<SubComment> findSubCommentsByComment(String commentId, int offset, int limit) {
        return super.findSubCommentsByComment(commentId, offset, limit);
    }

    @Override
    public long countSubCommentsByComment(String commentId) {
        return super.countSubCommentsByComment(commentId);
    }

    @Override
    public void updateSubComment(String subCommentId, NameValueList nameValues) {
        super.updateSubComment(subCommentId, nameValues);
    }

    @Override
    public void removeSubComment(String subCommentId) {
        super.removeSubComment(subCommentId);
    }

    @Override
    public void removeSubCommentsByComment(String commentId) {
        super.removeSubCommentsByComment(commentId);
    }
}
