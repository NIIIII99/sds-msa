package drama.board.sp.spring.web;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.logic.CommentLogic;
import drama.board.domain.spec.comment.CommentService;
import drama.board.domain.spec.comment.sdo.CommentCdo;
import drama.board.domain.spec.comment.sdo.CommentVoteCdo;
import drama.board.domain.spec.comment.sdo.SubCommentCdo;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("board-api/s")
public class CommentServiceResource implements CommentService {
    //
    @Autowired
    private CommentLogic commentLogic;

    @Override
    @PostMapping("comments")
    public String registerComment(@RequestParam String postingId, @RequestBody CommentCdo commentCdo) {
        //
        return commentLogic.registerComment(postingId, commentCdo);
    }

    @Override
    @GetMapping("comments/{commentId}")
    public Comment findComment(@PathVariable String commentId) {
        //
        return commentLogic.findComment(commentId);
    }

    @Override
    @GetMapping(value = "comments", params = {"postingId", "offset", "limit"})
    public List<Comment> findCommentsByPosting(@RequestParam String postingId, @RequestParam int offset, @RequestParam int limit) {
        //
        return commentLogic.findCommentsByPosting(postingId, offset, limit);
    }

    @Override
    @GetMapping(value = "comments", params = {"playerId", "offset", "limit"})
    public List<Comment> findCommentsByPlayer(@RequestParam String playerId, @RequestParam int offset, @RequestParam int limit) {
        //
        return commentLogic.findCommentsByPlayer(playerId, offset, limit);
    }

    @Override
    @GetMapping(value = "comments/count", params = "playerId")
    public long countCommentsByPlayer(@RequestParam String playerId) {
        //
        return commentLogic.countCommentsByPlayer(playerId);
    }

    @Override
    @PutMapping("comments/{commentId}")
    public void modifyComment(@PathVariable String commentId, @RequestBody NameValueList nameValues) {
        //
        commentLogic.modifyComment(commentId, nameValues);
    }

    @Override
    @DeleteMapping("comments/{commentId}")
    public void removeComment(@PathVariable String commentId) {
        //
        commentLogic.removeComment(commentId);
    }

    @Override
    @DeleteMapping(value = "comments", params = "postingId")
    public void removeCommentsByPosting(@RequestParam String postingId) {
        //
        commentLogic.removeCommentsByPosting(postingId);
    }

    @Override
    @GetMapping(value = "comments/count", params = "postingId")
    public long countCommentsByPosting(@RequestParam String postingId) {
        //
        return commentLogic.countCommentsByPosting(postingId);
    }

    @Override
    @PutMapping("comments/{commentId}/vote")
    public long addCommentVote(@PathVariable String commentId, @RequestBody CommentVoteCdo commentVoteCdo) {
        //
        return commentLogic.addCommentVote(commentId, commentVoteCdo);
    }

    @Override
    @PostMapping("comments/{commentId}/sub-comments")
    public String registerSubComment(@PathVariable String commentId, @RequestBody SubCommentCdo subCommentCdo) {
        //
        return commentLogic.registerSubComment(commentId, subCommentCdo);
    }

    @Override
    @GetMapping(value = "comments/{commentId}/sub-comments", params = {"offset", "limit"})
    public List<SubComment> findSubCommentsByComment(@PathVariable String commentId, @RequestParam int offset, @RequestParam int limit) {
        //
        return commentLogic.findSubCommentsByComment(commentId, offset, limit);
    }

    @Override
    @GetMapping("comments/{commentId}/sub-comments/count")
    public long countSubCommentsByComment(@PathVariable String commentId) {
        //
        return commentLogic.countSubCommentsByComment(commentId);
    }

    @Override
    @PutMapping("sub-comments/{subCommentId}")
    public void updateSubComment(@PathVariable String subCommentId, @RequestBody NameValueList nameValues) {
        //
        commentLogic.updateSubComment(subCommentId, nameValues);
    }

    @Override
    @DeleteMapping("sub-comments/{subCommentId}")
    public void removeSubComment(@PathVariable String subCommentId) {
        //
        commentLogic.removeSubComment(subCommentId);
    }

    @Override
    @DeleteMapping("comments/{commentId}/sub-comments")
    public void removeSubCommentsByComment(@PathVariable String commentId) {
        //
        commentLogic.removeSubCommentsByComment(commentId);
    }


}
