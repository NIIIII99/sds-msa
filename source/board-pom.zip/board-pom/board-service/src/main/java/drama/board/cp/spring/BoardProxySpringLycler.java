package drama.board.cp.spring;

import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.proxy.StageProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BoardProxySpringLycler implements BoardProxyLycler {
    //
    @Autowired
    private StageProxy stageProxy;

    @Override
    public StageProxy requestStageProxy() {
        //
        return stageProxy;
    }
}
