package drama.board.cp.spring;

import drama.board.domain.store.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BoardStoreSpringLycler implements BoardStoreLycler {
    //
    @Autowired
    private BoardPanelStore boardPanelStore;

    @Autowired
    private BoardStore boardStore;

    @Autowired
    private PostingStore postingStore;

    @Autowired
    private CommentStore commentStore;

    @Autowired
    private SurveyResponseStore surveyResponseStore;

    @Autowired
    private NotifyingResponseStore notifyingResponseStore;

    @Autowired
    private PostingTagStore postingTagStore;


    @Override
    public BoardPanelStore requestBoardPanelStore() {
        //
        return boardPanelStore;
    }

    @Override
    public BoardStore requestBoardStore() {
        //
        return boardStore;
    }

    @Override
    public PostingStore requestPostingStore() {
        //
        return postingStore;
    }

    @Override
    public SurveyResponseStore requestSurveyResponseStore() {
        //
        return surveyResponseStore;
    }

    @Override
    public NotifyingResponseStore requestNotifyingResponseStore() {
        //
        return notifyingResponseStore;
    }

    @Override
    public CommentStore requestCommentStore() {
        //
        return commentStore;
    }

    @Override
    public PostingTagStore requestPostingTagStore() {
        //
        return postingTagStore;
    }
}
