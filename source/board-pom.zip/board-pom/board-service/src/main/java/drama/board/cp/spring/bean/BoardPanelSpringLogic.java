package drama.board.cp.spring.bean;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.logic.BoardPanelLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import drama.board.domain.store.BoardStoreLycler;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class BoardPanelSpringLogic extends BoardPanelLogic {
    //
    @Autowired
    public BoardPanelSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        super(proxyLycler, storeLycler);
    }

    @Override
    public BoardPanel buildBoardPanel(BoardPanelCdo boardPanelCdo) {
        return super.buildBoardPanel(boardPanelCdo);
    }

    @Override
    public BoardPanel findBoardPanel(String panelId) {
        return super.findBoardPanel(panelId);
    }

    @Override
    public List<PreSetting> findPreSettings(String panelId) {
        return super.findPreSettings(panelId);
    }

    @Override
    public PreSetting findPreSetting(String panelId, String title) {
        return super.findPreSetting(panelId, title);
    }

    @Override
    public void modifyBoardPanel(String panelId, NameValueList nameValues) {
        super.modifyBoardPanel(panelId, nameValues);
    }

    @Override
    public void removeBoardPanel(String panelId) {
        super.removeBoardPanel(panelId);
    }
}
