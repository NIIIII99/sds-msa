package drama.board.cp.spring.bean;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import drama.board.domain.logic.BoardLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.board.sdo.BoardCdo;
import drama.board.domain.store.BoardStoreLycler;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class BoardSpringLogic extends BoardLogic {
    //
    @Autowired
    public BoardSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        super(proxyLycler, storeLycler);
    }

    @Override
    public String registerBoard(String panelId, BoardCdo boardCdo) {
        return super.registerBoard(panelId, boardCdo);
    }

    @Override
    public Board findBoard(String boardId) {
        return super.findBoard(boardId);
    }

    @Override
    public List<Board> findBoards(String panelId) {
        return super.findBoards(panelId);
    }

    @Override
    public List<Board> findPublicBoards(String panelId) {
        return super.findPublicBoards(panelId);
    }

    @Override
    public PostingRule findPostingRule(String boardId) {
        return super.findPostingRule(boardId);
    }

    @Override
    public void modifyBoard(String boardId, NameValueList nameValues) {
        super.modifyBoard(boardId, nameValues);
    }

    @Override
    public void removeBoard(String boardId) {
        super.removeBoard(boardId);
    }

    @Override
    public void enforceRemoveBoard(String boardId) {
        super.enforceRemoveBoard(boardId);
    }
}
