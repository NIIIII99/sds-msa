package drama.board.sp.spring.web;

import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.logic.SurveyResponseLogic;
import drama.board.domain.spec.survey.SurveyResponseService;
import drama.board.domain.spec.survey.sdo.SurveyResponseCdo;
import nara.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("board-api/s/survey-responses")
public class SurveyResponseServiceResource implements SurveyResponseService {
    //
    @Autowired
    private SurveyResponseLogic responseLogic;

    @Override
    @PostMapping
    public String registerResponse(@RequestBody SurveyResponseCdo responseCdo) {
        //
        return responseLogic.registerResponse(responseCdo);
    }

    @Override
    @PostMapping(params = "postingId")
    public long buildFullResponsesForPosting(@RequestParam String postingId) {
        //
        return responseLogic.buildFullResponsesForPosting(postingId);
    }

    @Override
    @PutMapping(value = "checked")
    public String markResponseAsAnswered(@RequestBody SurveyResponseCdo responseCdo) {
        //
        return responseLogic.markResponseAsAnswered(responseCdo);
    }

    @Override
    @GetMapping("{responseId}")
    public SurveyResponse findResponse(@PathVariable String responseId) {
        //
        return responseLogic.findResponse(responseId);
    }

    @Override
    @GetMapping(params = {"postingId", "offset", "limit"})
    public List<SurveyResponse> findResponsesByPosting(@RequestParam String postingId, @RequestParam int offset, @RequestParam int limit) {
        //
        return responseLogic.findResponsesByPosting(postingId, offset, limit);
    }

    @Override
    @GetMapping(value = "checked", params = {"postingId", "offset", "limit"})
    public List<SurveyResponse> findResponsesByPostingAnswered(@RequestParam String postingId, @RequestParam int offset, @RequestParam int limit) {
        //
        return responseLogic.findResponsesByPostingAnswered(postingId, offset, limit);
    }

    @Override
    public void modifyResponse(String responseId, NameValueList nameValues) {
        //
        responseLogic.modifyResponse(responseId, nameValues);
    }

    @Override
    @DeleteMapping("{responseId}")
    public void removeResponse(@PathVariable String responseId) {
        //
        responseLogic.removeResponse(responseId);
    }

    @Override
    @DeleteMapping(params = "postingId")
    public void removeAllResponsesByPosting(@RequestParam String postingId) {
        //
        responseLogic.removeAllResponsesByPosting(postingId);
    }
}
