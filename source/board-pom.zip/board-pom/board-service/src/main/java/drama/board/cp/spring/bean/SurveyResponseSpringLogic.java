package drama.board.cp.spring.bean;

import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.logic.SurveyResponseLogic;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.survey.sdo.SurveyResponseCdo;
import drama.board.domain.store.BoardStoreLycler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SurveyResponseSpringLogic extends SurveyResponseLogic {
    //
    @Autowired
    public SurveyResponseSpringLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        super(proxyLycler, storeLycler);
    }

    @Override
    public String registerResponse(SurveyResponseCdo responseCdo) {
        return super.registerResponse(responseCdo);
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        return super.buildFullResponsesForPosting(postingId);
    }

    @Override
    public String markResponseAsAnswered(SurveyResponseCdo responseCdo) {
        return super.markResponseAsAnswered(responseCdo);
    }

    @Override
    public SurveyResponse findResponse(String responseId) {
        return super.findResponse(responseId);
    }

    @Override
    public List<SurveyResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        return super.findResponsesByPosting(postingId, offset, limit);
    }

    @Override
    public List<SurveyResponse> findResponsesByPostingAnswered(String postingId, int offset, int limit) {
        return super.findResponsesByPostingAnswered(postingId, offset, limit);
    }

    @Override
    public void removeResponse(String responseId) {
        super.removeResponse(responseId);
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        super.removeAllResponsesByPosting(postingId);
    }
}
