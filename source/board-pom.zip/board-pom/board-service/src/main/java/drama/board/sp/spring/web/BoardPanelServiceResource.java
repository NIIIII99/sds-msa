package drama.board.sp.spring.web;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.logic.BoardPanelLogic;
import drama.board.domain.spec.panel.BoardPanelService;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Screen;
import nara.stage.context.DramaContext;
import nara.stage.context.DramaRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("board-api/s/board-panels")
public class BoardPanelServiceResource implements BoardPanelService {
    //
    @Autowired
    private BoardPanelLogic boardPanelLogic;

    @GetMapping("init")
    public BoardPanel initBoardPanel() {
        //
        final String title = "TeamUser boards panel";
        final List<PreSetting> preSettings = new ArrayList<>();

        Screen screen = Screen.getSample();
        Actor actor = Actor.getSample();
        DramaRequest current = new DramaRequest(screen, actor);
        DramaContext.setCurrentRequest(current);

        BoardPanelCdo cdo = new BoardPanelCdo(title, preSettings);
        return this.buildBoardPanel(cdo);
    }

    @Override
    @PostMapping
    public BoardPanel buildBoardPanel(@RequestBody BoardPanelCdo boardPanelCdo) {
        //
        return boardPanelLogic.buildBoardPanel(boardPanelCdo);
    }

    @Override
    @GetMapping("{panelId}")
    public BoardPanel findBoardPanel(@PathVariable String panelId) {
        //
        return boardPanelLogic.findBoardPanel(panelId);
    }

    @Override
    @GetMapping("{panelId}/pre-settings")
    public List<PreSetting> findPreSettings(@PathVariable String panelId) {
        //
        return boardPanelLogic.findPreSettings(panelId);
    }

    @Override
    @GetMapping(value = "{panelId}/pre-settings", params = "title")
    public PreSetting findPreSetting(@PathVariable String panelId, @RequestParam String title) {
        //
        return boardPanelLogic.findPreSetting(panelId, title);
    }

    @Override
    @PutMapping("{panelId}")
    public void modifyBoardPanel(@PathVariable String panelId, @RequestBody NameValueList nameValues) {
        //
        boardPanelLogic.modifyBoardPanel(panelId, nameValues);
    }

    @Override
    @DeleteMapping("{panelId}")
    public void removeBoardPanel(@PathVariable String panelId) {
        //
        boardPanelLogic.removeBoardPanel(panelId);
    }
}
