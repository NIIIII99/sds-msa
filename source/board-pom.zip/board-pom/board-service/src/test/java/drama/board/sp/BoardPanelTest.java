package drama.board.sp;

import drama.board.AbstractBoardApplicationTests;
import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BoardPanelTest extends AbstractBoardApplicationTests {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Test
    public void test() {
        //
        BoardPanelCdo boardPanelCdo = BoardPanelCdo.getSample();
        BoardPanel boardPanel = getBoardPanelServiceRestAdapter().buildBoardPanel(boardPanelCdo);

        Assert.assertNotNull(boardPanel);
        logger.debug("{}", boardPanel);

        boardPanel = getBoardPanelServiceRestAdapter().findBoardPanel(boardPanel.getId());

        Assert.assertNotNull(boardPanel);
        logger.debug("{}", boardPanel);
    }
}
