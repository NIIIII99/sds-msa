package drama.board.sp;

import drama.board.AbstractBoardApplicationTests;
import org.junit.Test;

public class PostingTest extends AbstractBoardApplicationTests {
    //
    @Test
    public void test() {

    }
}
