package drama.board;

import drama.board.adapter.rest.*;
import drama.board.restclient.SpringWebRestMockClient;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Screen;
import nara.share.restclient.NaraRestClient;
import nara.stage.context.DramaContext;
import nara.stage.context.DramaRequest;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = BoardTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public abstract class AbstractBoardApplicationTests {
    //
    @LocalServerPort
    private int port;

    private NaraRestClient naraRestClient;

    public NaraRestClient getRestClient() {
        //
        if (naraRestClient == null) this.naraRestClient = new SpringWebRestMockClient("http://localhost:" + port);
        return naraRestClient;
    }

    private BoardPanelServiceRestAdapter boardPanelServiceRestAdapter;
    private BoardServiceRestAdapter boardServiceRestAdapter;
    private PostingServiceRestAdapter postingServiceRestAdapter;
    private CommentServiceRestAdapter commentServiceRestAdapter;
    private NotifyingResponseServiceRestAdapter notifyingServiceRestAdapter;


    public BoardServiceRestAdapter getBoardServiceRestAdapter() {
        //
        if (boardServiceRestAdapter == null) this.boardServiceRestAdapter = new BoardServiceRestAdapter(getRestClient());
        return boardServiceRestAdapter;
    }

    public PostingServiceRestAdapter getPostingServiceRestAdapter() {
        //
        if (postingServiceRestAdapter == null) this.postingServiceRestAdapter = new PostingServiceRestAdapter(getRestClient());
        return postingServiceRestAdapter;
    }

    public BoardPanelServiceRestAdapter getBoardPanelServiceRestAdapter() {
        //
        if (boardPanelServiceRestAdapter == null) this.boardPanelServiceRestAdapter = new BoardPanelServiceRestAdapter(getRestClient());
        return boardPanelServiceRestAdapter;
    }

    public CommentServiceRestAdapter getCommentServiceRestAdapter() {
        //
        if (commentServiceRestAdapter == null) this.commentServiceRestAdapter = new CommentServiceRestAdapter(getRestClient());
        return commentServiceRestAdapter;
    }

    public NotifyingResponseServiceRestAdapter getNotifyingServiceRestAdapter() {
        //
        if (notifyingServiceRestAdapter == null) this.notifyingServiceRestAdapter = new NotifyingResponseServiceRestAdapter(getRestClient());
        return notifyingServiceRestAdapter;
    }

    @Before
    public void setUp() throws Exception {
        //
        Screen screen = Screen.getSample();
        Actor actor = Actor.getSample();
        DramaRequest current = new DramaRequest(screen, actor);

        DramaContext.setCurrentRequest(current);
    }
}
