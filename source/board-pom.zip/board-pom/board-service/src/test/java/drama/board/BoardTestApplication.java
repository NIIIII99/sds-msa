package drama.board;

import drama.board.domain.proxy.StageProxy;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BoardTestApplication {
    //
    @Bean
    public StageProxy stageProxy() {
        //
        return Mockito.mock(StageProxy.class);
    }
}

