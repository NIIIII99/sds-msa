package drama.board.restclient;

import nara.share.restclient.RequestBuilder;
import nara.share.restclient.springweb.SpringWebRestClient;
import nara.stage.context.DramaContext;
import nara.stage.context.DramaRequest;

public class SpringWebRestMockClient extends SpringWebRestClient {

    public SpringWebRestMockClient(String serverHost) {
        super(serverHost);
    }

    @Override
    public <T> T sendAndRecieve(RequestBuilder requestBuilder) {
        //
        DramaRequest current = DramaContext.getCurrentRequest();
        return super.sendAndRecieve(
                requestBuilder
                        .addHeader("pavilionId", current.getScreen().getPavilionId())
                        .addHeader("cineroomId", current.getScreen().getCineroomId())
                        .addHeader("audienceId", current.getActor().getAudienceId())
                        .addHeader("playerId", current.getActor().getPlayerId())
        );
    }
}
