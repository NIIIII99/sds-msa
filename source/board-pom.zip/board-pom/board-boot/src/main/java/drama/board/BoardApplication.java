package drama.board;

import drama.board.cp.spring.BoardInitializer;
import drama.board.domain.proxy.StageProxy;
import drama.board.sa.envoy.StageEnvoyProxy;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(value = {BoardInitializer.class})
public class BoardApplication {
    //
    public static void main(String[] args) {
        //
        SpringApplication.run(BoardApplication.class, args);
    }

    @Bean
    public StageProxy stageProxy() {
        //
        return new StageEnvoyProxy();
    }

}
