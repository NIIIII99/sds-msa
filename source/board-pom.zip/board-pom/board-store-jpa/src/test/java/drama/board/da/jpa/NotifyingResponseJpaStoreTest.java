package drama.board.da.jpa;

import drama.board.da.AbstractBoardStoreTest;
import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.reply.notifying.Notifying;
import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class NotifyingResponseJpaStoreTest extends AbstractBoardStoreTest {
    //
    private static Logger logger = LoggerFactory.getLogger(NotifyingResponseJpaStoreTest.class);

    @Autowired
    private BoardJpaStore boardJpaStore;

    @Autowired
    private PostingJpaStore postingJpaStore;

    @Autowired
    private NotifyingResponseJpaStore responseJpaStore;

    @Test
    public void testCrud() {
        //
        Posting posting = Posting.getSample();
        String postingId = posting.getId();

        PostingBody postingBody = PostingBody.getSample(postingId);
        postingBody.setNotifying(Notifying.getSample());

        NotifyingResponse response = NotifyingResponse.getSample(postingId);

        postingJpaStore.create(posting);
        postingJpaStore.createBody(postingBody);
        responseJpaStore.create(response);

        posting = postingJpaStore.retrieve(postingId);
        Assert.assertNotNull(posting);

        postingBody = postingJpaStore.retrieveBody(postingId);
        Assert.assertNotNull(postingBody);

        response = responseJpaStore.retrieve(response.getId());
        Assert.assertNotNull(response);

        System.out.println(posting);
        System.out.println(response);

        long count = responseJpaStore.countByPosting(postingId);
        Assert.assertEquals(1, count);
    }
}
