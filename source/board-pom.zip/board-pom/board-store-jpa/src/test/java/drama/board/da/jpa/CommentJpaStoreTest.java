package drama.board.da.jpa;

import drama.board.da.AbstractBoardStoreTest;
import drama.board.domain.entity.reply.comment.Comment;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class CommentJpaStoreTest extends AbstractBoardStoreTest {
    //
    private static Logger logger = LoggerFactory.getLogger(CommentJpaStoreTest.class);

    @Autowired
    private CommentJpaStore commentJpaStore;

    @Test
    public void test() {
        //
        Comment comment = Comment.getSample();
        commentJpaStore.create(comment);

        comment = commentJpaStore.retrieve(comment.getId());
        Assert.assertNotNull(comment);

        logger.debug("{}", comment);

        String newText = "Hello, I'm new text";
        comment.setText(newText);

        commentJpaStore.update(comment);

        comment = commentJpaStore.retrieve(comment.getId());
        Assert.assertEquals(newText, comment.getText());
        logger.debug("{}", comment);
    }
}
