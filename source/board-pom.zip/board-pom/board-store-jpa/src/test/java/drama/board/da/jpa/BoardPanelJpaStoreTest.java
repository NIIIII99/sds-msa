package drama.board.da.jpa;

import drama.board.da.AbstractBoardStoreTest;
import drama.board.domain.entity.panel.share.BoardCoverage;
import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.share.BoardCategory;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.entity.panel.option.PostingOption;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class BoardPanelJpaStoreTest extends AbstractBoardStoreTest {
    //
    private static Logger logger = LoggerFactory.getLogger(BoardPanelJpaStoreTest.class);

    @Autowired
    private BoardPanelJpaStore boardPanelJpaStore;

    @Test
    public void test() {
        //
        BoardPanel boardPanel = BoardPanel.getSample();
        boardPanelJpaStore.create(boardPanel);

        boardPanel = boardPanelJpaStore.retrieve(boardPanel.getId());
        Assert.assertNotNull(boardPanel);

        logger.debug("{}", boardPanel);

        boardPanel.setTitle("전체 게시판");
        boardPanel.setPrivateFirst(true);

        boardPanel.getPreSettings().add(new PreSetting("전체 인터렉션", BoardCategory.Interaction, BoardCoverage.PublicUser, PostingOption.getNormalBoardSample()));

        boardPanelJpaStore.update(boardPanel);

        boardPanel = boardPanelJpaStore.retrieve(boardPanel.getId());
        Assert.assertEquals("전체 게시판", boardPanel.getTitle());
        Assert.assertEquals(true, boardPanel.isPrivateFirst());

        logger.debug("{}", boardPanel);
    }
}
