package drama.board.da;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardStoreTestApplication {
}
