package drama.board.da.jpa;

import drama.board.da.AbstractBoardStoreTest;
import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.Screen;
import nara.share.domain.drama.Tenant;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

public class BoardJpaStoreTest extends AbstractBoardStoreTest {
    //
    private static Logger logger = LoggerFactory.getLogger(BoardJpaStoreTest.class);

    @Autowired
    private BoardJpaStore boardJpaStore;

    @Test
    public void testCrud() {
        //
        Board board = Board.getSample();
        String boardId = board.getId();

        boardJpaStore.create(board);
        board = boardJpaStore.retrieve(boardId);
        Assert.assertNotNull(board);
        logger.debug("{}", board);

        for (int i = 0; i < 10; i++) {
            logger.debug("{}", boardJpaStore.nextPostingSequence(boardId));
        }

        board.getTags().add("hello");
        board.getTags().add("hi");
        board.getTags().add("world");

        boardJpaStore.update(board);

        board = boardJpaStore.retrieve(boardId);
        Assert.assertEquals(3, board.getTags().size());

        boardJpaStore.delete(board);

        try {
            boardJpaStore.retrieve(boardId);
        } catch (Exception e) {
            Assert.assertTrue(true);
        }
    }

    @Test
    public void testFind() {
        //
        String subscriptionId = UUID.randomUUID().toString();
        String photoProfileId = UUID.randomUUID().toString();
        String panelId = UUID.randomUUID().toString();

        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P1", "P1C1"), new Actor("1@P1", "1@P1C1", "kchuh", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P1", "P1C1"), new Actor("1@P1", "1@P1C1", "kchuh", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P1", "P1C1"), new Actor("1@P1", "1@P1C1", "kchuh", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P1", "P1C2"), new Actor("1@P1", "1@P1C2", "kchuh", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P1", "P1C2"), new Actor("1@P1", "1@P1C2", "kchuh", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P2", "P2C1"), new Actor("1@P2", "1@P2C1", "hkkan", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P2", "P2C1"), new Actor("1@P2", "1@P2C1", "hkkang", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P2", "P2C1"), new Actor("1@P2", "1@P2C1", "hkkang", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P2", "P2C2"), new Actor("1@P2", "1@P2C2", "hkkang", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));
        boardJpaStore.create(new Board(new Tenant(new Screen(subscriptionId, "P2", "P2C2"), new Actor("1@P2", "1@P2C2", "hkkang", "")), DramaAccess.getSample(), "hello", PostingRule.getSample(), photoProfileId, panelId));

        Assert.assertEquals(5, boardJpaStore.retrieveByPavilion("P1").size());
        Assert.assertEquals(3, boardJpaStore.retrieveByCineroom("P1C1").size());
        Assert.assertEquals(5, boardJpaStore.retrieveByAudience("1@P1").size());
        Assert.assertEquals(3, boardJpaStore.retrieveByPlayer("1@P1C1").size());
    }


}
