package drama.board.da.jpa;

import drama.board.da.AbstractBoardStoreTest;
import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.posting.Content;
import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.posting.PostingReadLog;
import drama.board.domain.entity.reply.comment.CommentRule;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.Tenant;
import nara.share.domain.drama.Writer;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class PostingJpaStoreTest extends AbstractBoardStoreTest {
    //
    private static Logger logger = LoggerFactory.getLogger(PostingJpaStoreTest.class);

    @Autowired
    private BoardJpaStore boardJpaStore;

    @Autowired
    private PostingJpaStore postingJpaStore;

    @Test
    public void testCrud() {
        //
        Posting posting = Posting.getSample();
        String boardId = posting.getBoardId();
        String postingId = posting.getId();
        postingJpaStore.create(posting);

        posting = postingJpaStore.retrieve(postingId);
        Assert.assertNotNull(posting);

        logger.debug("{}", posting);

        Assert.assertEquals(1, postingJpaStore.countPostingsOfBoard(boardId));

        PostingBody postingBody = new PostingBody(postingId, Content.getSample());
        postingJpaStore.createBody(postingBody);

        postingBody = postingJpaStore.retrieveBody(postingId);
        Assert.assertNotNull(postingBody);
        logger.debug("{}", postingBody);
    }

    @Test
    public void testPostingReadLog() {
        //
        PostingReadLog readLog = PostingReadLog.getSample();
        String postingId = readLog.getPostingId();
        String audienceId = readLog.getAudienceId();

        postingJpaStore.createReadLog(readLog);
        readLog = postingJpaStore.retrieveReadLog(readLog.getId());
        Assert.assertNotNull(readLog);

        readLog = postingJpaStore.retrieveReadLogByPostingAudience(postingId, audienceId);
        Assert.assertNotNull(readLog);

        List<PostingReadLog> readLogs = postingJpaStore.retrieveReadLogByPosting(postingId, 0, 10);
        Assert.assertEquals(1, readLogs.size());
    }

    @Test
    public void testOffsetRetrieve() {
        //
        Board board = Board.getSample();
        String boardId = board.getId();
        boardJpaStore.create(board);

        for (int i = 0 ; i < 50 ; i++) {
            long nextPostingSequence = boardJpaStore.nextPostingSequence(boardId);
            Posting posting = new Posting(
                Tenant.getSample(),
                DramaAccess.getSample(),
                board.getId(),
                i + " 번째 게시판",
                Writer.getSample(),
                nextPostingSequence,
                CommentRule.getSample()
            );
            postingJpaStore.create(posting);
        }

        Assert.assertEquals(50, postingJpaStore.countPostingsOfBoard(boardId));

        List<Posting> postings = postingJpaStore.retrieveByBoardLatest(boardId, 3, 5);
        Assert.assertEquals(5, postings.size());

        postings.forEach(posting -> logger.debug("{}", posting));
    }
}
