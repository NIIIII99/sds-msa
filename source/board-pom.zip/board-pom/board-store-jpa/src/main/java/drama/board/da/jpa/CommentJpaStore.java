package drama.board.da.jpa;

import drama.board.da.jpa.jpo.reply.CommentJpo;
import drama.board.da.jpa.jpo.reply.CommentVoteJpo;
import drama.board.da.jpa.jpo.reply.SubCommentJpo;
import drama.board.da.jpa.springdata.CommentRepository;
import drama.board.da.jpa.springdata.CommentVoteRepository;
import drama.board.da.jpa.springdata.SubCommentRepository;
import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.entity.reply.comment.vote.CommentVote;
import drama.board.domain.entity.reply.comment.vote.VoteType;
import drama.board.domain.store.CommentStore;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import nara.share.springdata.page.OffsetRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;

@Repository
public class CommentJpaStore implements CommentStore {
    //
    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private SubCommentRepository subCommentRepository;

    @Autowired
    private CommentVoteRepository commentVoteRepository;

    @Override
    public void create(Comment comment) {
        //
        String id = comment.getId();
        if (commentRepository.exists(id)) throw new AlreadyExistsException(String.format("Comment[%s] already exist.", id));
        CommentJpo commentJpo = new CommentJpo(comment);
        commentRepository.save(commentJpo);
    }

    @Override
    public Comment retrieve(String id) throws NoSuchElementException {
        //
        CommentJpo commentJpo = commentRepository.findOne(id);
        if (commentJpo == null) throw new NoSuchElementException(String.format("Comment[%s] not found.", id));
        return commentJpo.toDomain();
    }

    @Override
    public List<Comment> retrieveByPosting(String postingId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time"); // time based order

        List<CommentJpo> commentJpos = commentRepository.findByPostingId(postingId, new OffsetRequest(offset, limit, sort));
        return CommentJpo.toDomain(commentJpos);
    }

    @Override
    public List<Comment> retrieveByPlayer(String playerId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time"); // time based order

        List<CommentJpo> commentJpos = commentRepository.findByWriterPlayerId(playerId, new OffsetRequest(offset, limit, sort));
        return CommentJpo.toDomain(commentJpos);
    }

    @Override
    public Long countByPosting(String postingId) {
        //
        return commentRepository.countByPostingId(postingId);
    }

    @Override
    public Long countByPlayer(String playerId) {
        //
        return commentRepository.countByWriterPlayerId(playerId);
    }

    @Override
    public void update(Comment comment) {
        //
        String id = comment.getId();
        if (!commentRepository.exists(id)) throw new NonExistenceException(String.format("Comment[%s] not found.", id));
        CommentJpo commentJpo = commentRepository.findOne(id);
        commentJpo.update(comment);
        commentRepository.save(commentJpo);
    }

    @Override
    public void delete(Comment comment) {
        //
        commentRepository.delete(comment.getId());
    }

    @Override
    public void deleteAllCommentAndSubCommentByPosting(String postingId) {
        //
        commentRepository.deleteByPostingId(postingId);
        subCommentRepository.deleteByPostingId(postingId);
    }

    @Override
    public void createSubComment(SubComment subComment) {
        //
        String id = subComment.getId();
        if (subCommentRepository.exists(id)) throw new AlreadyExistsException(String.format("SubComment[%s] already exist.", id));
        SubCommentJpo subCommentJpo = new SubCommentJpo(subComment);
        subCommentRepository.save(subCommentJpo);
    }

    @Override
    public SubComment retrieveSubComment(String id) throws NoSuchElementException {
        //
        SubCommentJpo subCommentJpo = subCommentRepository.findOne(id);
        if (subCommentJpo == null) throw new NoSuchElementException(String.format("SubComment[%s] not found.", id));
        return subCommentJpo.toDomain();
    }

    @Override
    public List<SubComment> retrieveSubCommentByComment(String commentId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time"); // time based order

        List<SubCommentJpo> subCommentJpos = subCommentRepository.findByCommentId(commentId, new OffsetRequest(offset, limit, sort));
        return SubCommentJpo.toDomain(subCommentJpos);
    }

    @Override
    public Long countSubCommentByComment(String commentId) {
        //
        return subCommentRepository.countByCommentId(commentId);
    }

    @Override
    public void updateSubComment(SubComment subComment) {
        //
        String id = subComment.getId();
        if (!subCommentRepository.exists(id)) throw new NonExistenceException(String.format("SubComment[%s] not found.", id));
        SubCommentJpo subCommentJpo = subCommentRepository.findOne(id);
        subCommentJpo.update(subComment);
        subCommentRepository.save(subCommentJpo);
    }

    @Override
    public void deleteSubComment(SubComment subComment) {
        //
        subCommentRepository.delete(subComment.getId());
    }

    @Override
    public void deleteAllSubCommentByComment(String commentId) {
        //
        subCommentRepository.deleteByCommentId(commentId);
    }

    @Override
    public void createVote(CommentVote commentVote) {
        //
        String id = commentVote.getId();
        if (commentVoteRepository.exists(id))
            throw new AlreadyExistsException(String.format("CommentVote[%s] already exist.", id));
        CommentVoteJpo commentVoteJpo = new CommentVoteJpo(commentVote);
        commentVoteRepository.save(commentVoteJpo);
    }

    @Override
    public CommentVote retrieveVote(String id) {
        //
        CommentVoteJpo commentVoteJpo = commentVoteRepository.findOne(id);
        if (commentVoteJpo == null)
            throw new NoSuchElementException(String.format("CommentVote[%s] not found.", id));

        return commentVoteJpo.toDomain();
    }

    @Override
    public CommentVote retrieveVoteByCommentPlayer(String commentId, String voterPlayerId) {
        //
        CommentVoteJpo commentVoteJpo = commentVoteRepository.findByCommentIdAndVoterPlayerId(commentId, voterPlayerId);
        if (commentVoteJpo != null) {
            return commentVoteJpo.toDomain();
        } else {
            return null;
        }
    }

    @Override
    public List<CommentVote> retrieveVoteByComment(String commentId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time"); // time based order
        List<CommentVoteJpo> commentVoteJpos = commentVoteRepository.findByCommentId(commentId, new OffsetRequest(offset, limit, sort));

        return CommentVoteJpo.toDomain(commentVoteJpos);
    }

    @Override
    public Long countVoteByComment(String commentId, VoteType voteType) {
        //
        return commentVoteRepository.countByCommentIdAndType(commentId, VoteType.UpVote);
    }

    @Override
    public void updateVote(CommentVote commentVote) {
        //
        String id = commentVote.getId();
        if(!commentVoteRepository.exists(id)) {
            throw new NonExistenceException(String.format("CommentVote[%s] not found.", id));
        }

        CommentVoteJpo commentVoteJpo = commentVoteRepository.findOne(id);
        commentVoteJpo.update(commentVote);
        commentVoteRepository.save(commentVoteJpo);
    }

    @Override
    public void deleteVote(CommentVote commentVote) {
        //
        commentVoteRepository.delete(commentVote.getId());
    }
}
