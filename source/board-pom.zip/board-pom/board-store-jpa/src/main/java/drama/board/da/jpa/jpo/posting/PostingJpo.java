package drama.board.da.jpa.jpo.posting;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingState;
import drama.board.domain.entity.reply.comment.CommentRule;
import nara.share.jpo.drama.DramaAggregateJpo;
import nara.share.jpo.drama.WriterJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_POSTING")
@Table(indexes = {
    @Index(name = "IX_BOARD_POSTING", columnList = "boardId")
})
public class PostingJpo extends DramaAggregateJpo {
    //
    private String title;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="WRITER_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="WRITER_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="WRITER_NAME")),
        @AttributeOverride(name="email", column=@Column(name="WRITER_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="WRITER_ANONYMOUS")),
    })
    private WriterJpo writer;
    private long sequence;          // sequence in board
    private long readCount;         // just read count

    @Lob
    private String stateJson;

    @Lob
    private String commentRuleJson;

    private Long time;
    private Long updateTime;

    private String boardId;

    public PostingJpo() {
        //
    }

    public PostingJpo(Posting posting) {
        //
        super(posting);
        BeanUtils.copyProperties(posting, this, "writer");
        writer = new WriterJpo(posting.getWriter());
        stateJson = posting.getState().toJson();
        commentRuleJson = posting.getCommentRule().toJson();
    }

    public void update(Posting posting) {
        //
        super.update(posting);
        BeanUtils.copyProperties(posting, this, "writer");
        writer.update(posting.getWriter());
        stateJson = posting.getState().toJson();
        commentRuleJson = posting.getCommentRule().toJson();
    }

    public Posting toDomain() {
        //
        Posting posting = new Posting(getId(), getTenantDomain(), getAccessDomain());
        BeanUtils.copyProperties(this, posting);
        posting.setWriter(writer.toDomain());
        posting.setState(PostingState.fromJson(stateJson));
        posting.setCommentRule(CommentRule.fromJson(commentRuleJson));
        return posting;
    }

    public static List<Posting> toDomain(List<PostingJpo> postingJpos) {
        //
        return postingJpos.stream().map(postingJpo -> postingJpo.toDomain()).collect(Collectors.toList());
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public WriterJpo getWriter() {
        return writer;
    }

    public void setWriter(WriterJpo writer) {
        this.writer = writer;
    }

    public long getSequence() {
        return sequence;
    }

    public void setSequence(long sequence) {
        this.sequence = sequence;
    }

    public long getReadCount() {
        return readCount;
    }

    public void setReadCount(long readCount) {
        this.readCount = readCount;
    }

    public String getStateJson() {
        return stateJson;
    }

    public void setStateJson(String stateJson) {
        this.stateJson = stateJson;
    }

    public String getCommentRuleJson() {
        return commentRuleJson;
    }

    public void setCommentRuleJson(String commentRuleJson) {
        this.commentRuleJson = commentRuleJson;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }
}
