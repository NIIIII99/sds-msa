package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.tagsearch.PostingTagJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface PostingTagRepository extends PagingAndSortingRepository<PostingTagJpo, String> {
    //
    void deleteByPostingId(String postingId);
    List<PostingTagJpo> findByBoardIdAndTag(String boardId, String tag, Pageable pageable);
}
