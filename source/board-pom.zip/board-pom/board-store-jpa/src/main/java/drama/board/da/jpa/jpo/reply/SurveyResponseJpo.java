package drama.board.da.jpa.jpo.reply;

import drama.board.domain.entity.reply.survey.SurveyResponse;
import nara.share.jpo.EntityJpo;
import nara.share.jpo.drama.WriterJpo;
import nara.share.util.json.JsonUtil;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_SURVEY_RESPONSE")
@Table(indexes = {
    @Index(name = "IX_BOARD_SURVEY_RESPONSE_POSTING", columnList = "postingId")
})
public class SurveyResponseJpo extends EntityJpo {
    //
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="RESPONDENT_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="RESPONDENT_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="RESPONDENT_NAME")),
        @AttributeOverride(name="email", column=@Column(name="RESPONDENT_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="RESPONDENT_ANONYMOUS")),
    })
    private WriterJpo respondent;
    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> selectedItemNos;

    private boolean answered;
    private Long time;
    private Long updateTime;
    private String postingId;

    public SurveyResponseJpo() {
        //
    }

    public SurveyResponseJpo(SurveyResponse response) {
        //
        super(response);
        BeanUtils.copyProperties(response, this, "respondent");
        respondent = new WriterJpo(response.getRespondent());
    }

    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

    public void update(SurveyResponse response) {
        //
        BeanUtils.copyProperties(response, this, "respondent");
        respondent.update(response.getRespondent());
    }

    public SurveyResponse toDomain() {
        //
        SurveyResponse response = new SurveyResponse(getId());
        BeanUtils.copyProperties(this, response);
        response.setRespondent(respondent.toDomain());

        return response;
    }

    public static List<SurveyResponse> toDomain(List<SurveyResponseJpo> responseJpos) {
        //
        return responseJpos.stream().map(responseJpo -> responseJpo.toDomain()).collect(Collectors.toList());
    }

    public WriterJpo getRespondent() {
        return respondent;
    }

    public void setRespondent(WriterJpo respondent) {
        this.respondent = respondent;
    }

    public List<String> getSelectedItemNos() {
        return selectedItemNos;
    }

    public void setSelectedItemNos(List<String> selectedItemNos) {
        this.selectedItemNos = selectedItemNos;
    }

    public boolean isAnswered() {
        return answered;
    }

    public void setAnswered(boolean answered) {
        this.answered = answered;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public static void main(String[] args) {
        //
        System.out.println(new SurveyResponseJpo(SurveyResponse.getSample()));
    }
}
