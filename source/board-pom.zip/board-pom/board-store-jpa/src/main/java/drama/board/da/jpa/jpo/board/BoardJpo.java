package drama.board.da.jpa.jpo.board;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import nara.share.jpo.drama.ActorJpo;
import nara.share.jpo.drama.DramaAggregateJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD")
@Table(indexes = {
    @Index(name = "IX_BOARD_PANEL", columnList = "panelId")
})
public class BoardJpo extends DramaAggregateJpo {
    //
    private String title;
    private long postingSequence;

    @Lob
    private String postingOptionJson;
    private String photoProfileId;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="ADMIN_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="ADMIN_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="ADMIN_NAME")),
        @AttributeOverride(name="email", column=@Column(name="ADMIN_EMAIL")),
    })
    private ActorJpo admin;

    @ElementCollection(fetch = FetchType.EAGER)
    private List<String> tags;
    private Long time;
    private Long updateTime;

    private String panelId;

    public BoardJpo() {
        //
    }

    public BoardJpo(Board board) {
        //
        super(board);
        BeanUtils.copyProperties(board, this, "tenant", "admin");
        this.postingOptionJson = board.getPostingRule().toJson();
        this.admin = new ActorJpo(board.getAdmin());
    }

    public void update(Board board) {
        //
        BeanUtils.copyProperties(board, this, "tenant", "admin");
        super.update(board);
        this.postingOptionJson = board.getPostingRule().toJson();
        this.admin.update(board.getAdmin());
    }

    public Board toDomain() {
        //
        Board board = new Board(getId(), getTenantDomain(), getAccessDomain());
        BeanUtils.copyProperties(this, board, "tenant", "admin");
        board.setPostingRule(PostingRule.fromJson(postingOptionJson));
        board.setAdmin(admin.toDomain());
        return board;
    }

    public static List<Board> toDomain(List<BoardJpo> boardJpos) {
        //
        return boardJpos.stream().map(boardJpo -> boardJpo.toDomain()).collect(Collectors.toList());
    }

    public void increasePostingSequence(int volume) {
        //
        this.postingSequence += volume;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getPostingSequence() {
        return postingSequence;
    }

    public void setPostingSequence(long postingSequence) {
        this.postingSequence = postingSequence;
    }

    public String getPostingOptionJson() {
        return postingOptionJson;
    }

    public void setPostingOptionJson(String postingOptionJson) {
        this.postingOptionJson = postingOptionJson;
    }

    public String getPhotoProfileId() {
        return photoProfileId;
    }

    public void setPhotoProfileId(String photoProfileId) {
        this.photoProfileId = photoProfileId;
    }

    public ActorJpo getAdmin() {
        return admin;
    }

    public void setAdmin(ActorJpo admin) {
        this.admin = admin;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getPanelId() {
        return panelId;
    }

    public void setPanelId(String panelId) {
        this.panelId = panelId;
    }
}
