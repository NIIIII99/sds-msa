package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.posting.PostingJpo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface PostingRepository extends PagingAndSortingRepository<PostingJpo, String> {
    //
    void deleteByBoardId(String boardId);
    int countByBoardId(String boardId);

    List<PostingJpo> findByIdIn(List<String> ids);
    List<PostingJpo> findByBoardId(String boardId, Pageable pageable);

    Page<PostingJpo> findPageByBoardId(String boardId, Pageable pageable);
}
