package drama.board.da.jpa.jpo.reply;

import drama.board.domain.entity.reply.comment.SubComment;
import nara.share.jpo.EntityJpo;
import nara.share.jpo.drama.WriterJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_SUB_COMMENT")
@Table(indexes = {
    @Index(name = "IX_BOARD_SUB_COMMENT_COMMENT", columnList = "commentId"),
    @Index(name = "IX_BOARD_SUB_COMMENT_COMMENT_POSTING", columnList = "commentId, postingId"),
})
public class SubCommentJpo extends EntityJpo {
    //
    private String text;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="WRITER_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="WRITER_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="WRITER_NAME")),
        @AttributeOverride(name="email", column=@Column(name="WRITER_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="WRITER_ANONYMOUS")),
    })
    private WriterJpo writer;
    private Long time;

    private String commentId;
    private String postingId;

    public SubCommentJpo() {
        //
    }

    public SubCommentJpo(SubComment subComment) {
        //
        super(subComment);
        BeanUtils.copyProperties(subComment, this, "writer");
        this.writer = new WriterJpo(subComment.getWriter());
    }

    public void update(SubComment subComment) {
        //
        BeanUtils.copyProperties(subComment, this, "writer");
        this.writer.update(subComment.getWriter());
    }

    public SubComment toDomain() {
        //
        SubComment subComment = new SubComment(getId());
        BeanUtils.copyProperties(this, subComment);
        subComment.setWriter(writer.toDomain());
        return subComment;
    }

    public static List<SubComment> toDomain(List<SubCommentJpo> subCommentJpos) {
        //
        return subCommentJpos.stream().map(subCommentJpo -> subCommentJpo.toDomain()).collect(Collectors.toList());
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public WriterJpo getWriter() {
        return writer;
    }

    public void setWriter(WriterJpo writer) {
        this.writer = writer;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

}
