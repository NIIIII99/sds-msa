package drama.board.da.jpa.jpo.reply;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import nara.share.jpo.EntityJpo;
import nara.share.jpo.drama.WriterJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_NOTIFYING_RESPONSE")
@Table(indexes = {
    @Index(name = "IX_BOARD_NOTIFYING_RESPONSE_POSTING", columnList = "postingId")
})
public class NotifyingResponseJpo extends EntityJpo {
    //
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="RESPONDENT_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="RESPONDENT_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="RESPONDENT_NAME")),
        @AttributeOverride(name="email", column=@Column(name="RESPONDENT_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="RESPONDENT_ANONYMOUS")),
    })
    private WriterJpo respondent;
    private boolean checked;
    private Long checkTime;
    private String postingId;

    public NotifyingResponseJpo() {
        //
    }

    public NotifyingResponseJpo(NotifyingResponse notifyingResponse) {
        //
        super(notifyingResponse);
        BeanUtils.copyProperties(notifyingResponse, this, "respondent");
        respondent = new WriterJpo(notifyingResponse.getRespondent());
    }

    public void update(NotifyingResponse notifyingResponse) {
        //
        BeanUtils.copyProperties(notifyingResponse, this, "respondent");
        respondent.update(notifyingResponse.getRespondent());
    }

    public NotifyingResponse toDomain() {
        //
        NotifyingResponse notifyingResponse = new NotifyingResponse(getId());
        BeanUtils.copyProperties(this, notifyingResponse);
        notifyingResponse.setRespondent(respondent.toDomain());
        return notifyingResponse;
    }

    public static List<NotifyingResponse> toDomain(List<NotifyingResponseJpo> notifyingResponseJpos) {
        //
        return notifyingResponseJpos.stream().map(notifyingResponseJpo -> notifyingResponseJpo.toDomain()).collect(Collectors.toList());
    }

    public WriterJpo getRespondent() {
        return respondent;
    }

    public void setRespondent(WriterJpo respondent) {
        this.respondent = respondent;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public Long getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Long checkTime) {
        this.checkTime = checkTime;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }
}
