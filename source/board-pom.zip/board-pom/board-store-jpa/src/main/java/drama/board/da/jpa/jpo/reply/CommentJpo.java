package drama.board.da.jpa.jpo.reply;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubCommentRule;
import nara.share.jpo.EntityJpo;
import nara.share.jpo.drama.WriterJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_COMMENT")
@Table(indexes = {
    @Index(name = "IX_BOARD_COMMENT_POSTING", columnList = "postingId")
})
public class CommentJpo extends EntityJpo {
    //
    private String text;
    private String attachmentId;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="WRITER_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="WRITER_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="WRITER_NAME")),
        @AttributeOverride(name="email", column=@Column(name="WRITER_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="WRITER_ANONYMOUS")),
    })
    private WriterJpo writer;
    private int voteCount;

    private Long time;

    @Lob
    private String subCommentRuleJson;

    private String postingId;

    public CommentJpo() {
        //
    }

    public CommentJpo(Comment comment) {
        //
        super(comment);
        BeanUtils.copyProperties(comment, this, "writer");
        this.writer = new WriterJpo(comment.getWriter());
        subCommentRuleJson = comment.getSubCommentRule().toJson();
    }

    public void update(Comment comment) {
        //
        BeanUtils.copyProperties(comment, this, "writer");
        this.writer.update(comment.getWriter());
        subCommentRuleJson = comment.getSubCommentRule().toJson();
    }

    public Comment toDomain() {
        //
        Comment comment = new Comment(getId());
        BeanUtils.copyProperties(this, comment, "writer");
        comment.setWriter(writer.toDomain());
        comment.setSubCommentRule(SubCommentRule.fromJson(subCommentRuleJson));
        return comment;
    }

    public static List<Comment> toDomain(List<CommentJpo> commentJpos) {
        //
        return commentJpos.stream().map(commentJpo -> commentJpo.toDomain()).collect(Collectors.toList());
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public WriterJpo getWriter() {
        return writer;
    }

    public void setWriter(WriterJpo writer) {
        this.writer = writer;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getSubCommentRuleJson() {
        return subCommentRuleJson;
    }

    public void setSubCommentRuleJson(String subCommentRuleJson) {
        this.subCommentRuleJson = subCommentRuleJson;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

}
