package drama.board.da.jpa;

import drama.board.da.jpa.jpo.reply.SurveyResponseJpo;
import drama.board.da.jpa.springdata.SurveyResponseRepository;
import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.store.SurveyResponseStore;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import nara.share.springdata.page.OffsetRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Repository
public class SurveyResponseJpaStore implements SurveyResponseStore {
    //
    @Autowired
    private SurveyResponseRepository responseRepository;

    @Override
    public void create(SurveyResponse response) {
        //
        String id = response.getId();
        if (responseRepository.exists(id)) {
            throw new AlreadyExistsException(String.format("SurveyResponse[%s] already exist.", id));
        }
        SurveyResponseJpo responseJpo = new SurveyResponseJpo(response);
        responseRepository.save(responseJpo);
    }

    @Override
    public void create(List<SurveyResponse> responses) {
        //
        responseRepository.save(
            responses
            .stream()
            .map(response -> new SurveyResponseJpo(response))
            .collect(Collectors.toList())
        );
    }

    @Override
    public SurveyResponse retrieve(String id) throws NoSuchElementException {
        //
        SurveyResponseJpo responseJpo = responseRepository.findOne(id);
        if (responseJpo == null) {
            throw new NoSuchElementException(String.format("SurveyResponse[%s] not found.", id));
        }

        return responseJpo.toDomain();
    }

    @Override
    public SurveyResponse retrieveByPostingPlayer(String postingId, String playerId) {
        //
        SurveyResponseJpo responseJpo = responseRepository.findByPostingIdAndRespondentPlayerId(postingId, playerId);
        if (responseJpo == null) {
            return null;
        }

        return responseJpo.toDomain();
    }

    @Override
    public List<SurveyResponse> retrieveByPosting(String postingId, int offset, int limit) {
        //
        List<SurveyResponseJpo> responseJpos = responseRepository.findByPostingId(postingId, new OffsetRequest(offset, limit));

        return SurveyResponseJpo.toDomain(responseJpos);
    }

    @Override
    public Long countByPosting(String postingId) {
        //
        return responseRepository.countByPostingId(postingId);
    }

    @Override
    public List<SurveyResponse> retrieveByPostingAnswered(String postingId, int offset, int limit) {
        //
        List<SurveyResponseJpo> responseJpos = responseRepository.findByPostingIdAndAnswered(postingId, true, new OffsetRequest(offset, limit));

        return SurveyResponseJpo.toDomain(responseJpos);
    }

    @Override
    public Long countByPostingAnswered(String postingId) {
        //
        return responseRepository.countByPostingIdAndAnswered(postingId, true);
    }

    @Override
    public List<SurveyResponse> retrieveByPostingUnanswered(String postingId, int offset, int limit) {
        //
        List<SurveyResponseJpo> responseJpos = responseRepository.findByPostingIdAndAnswered(postingId, false, new OffsetRequest(offset, limit));

        return SurveyResponseJpo.toDomain(responseJpos);
    }

    @Override
    public Long countByPostingUnanswered(String postingId) {
        //
        return responseRepository.countByPostingIdAndAnswered(postingId, false);
    }

    @Override
    public void update(SurveyResponse response) {
        //
        String id = response.getId();
        if (!responseRepository.exists(id)) {
            throw new NonExistenceException(String.format("SurveyResponse[%s] not found.", id));
        }

        SurveyResponseJpo responseJpo = responseRepository.findOne(id);
        responseJpo.update(response);

        responseRepository.save(responseJpo);
    }

    @Override
    public void delete(SurveyResponse response) {
        //
        responseRepository.delete(response.getId());
    }

    @Override
    public void deleteByPosting(String postingId) {
        //
        responseRepository.deleteByPostingId(postingId);
    }
}
