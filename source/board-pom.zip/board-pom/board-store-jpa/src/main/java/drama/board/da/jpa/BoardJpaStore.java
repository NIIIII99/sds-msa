package drama.board.da.jpa;

import drama.board.da.jpa.jpo.board.BoardJpo;
import drama.board.da.jpa.springdata.BoardRepository;
import drama.board.domain.entity.board.Board;
import drama.board.domain.store.BoardStore;
import nara.share.domain.drama.AccessScope;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;

@Repository
public class BoardJpaStore implements BoardStore {
    //
    @Autowired
    private BoardRepository boardRepository;

    @Override
    public void create(Board board) {
        //
        String id = board.getId();
        if (boardRepository.exists(id)) throw new AlreadyExistsException(String.format("Board[%s] already exist.", id));
        BoardJpo boardJpo = new BoardJpo(board);
        boardRepository.save(boardJpo);
    }

    @Override
    public Board retrieve(String boardId) throws NoSuchElementException {
        //
        BoardJpo boardJpo = boardRepository.findOne(boardId);
        if (boardJpo == null) throw new NoSuchElementException(String.format("Board[%s] not found.", boardId));
        return boardJpo.toDomain();
    }

    @Override
    public List<Board> retrieveByPanel(String panelId) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByPanelId(panelId);
        return BoardJpo.toDomain(boardJpos);
    }

    @Override
    public long countByPanel(String panelId) {
        //
        return boardRepository.countByPanelId(panelId);
    }

    @Override
    public void update(Board board) {
        //
        String id = board.getId();
        if (!boardRepository.exists(id)) throw new NonExistenceException(String.format("Board[%s] not found.", id));
        BoardJpo boardJpo = boardRepository.findOne(id);
        boardJpo.update(board);
        boardRepository.save(boardJpo);
    }

    @Override
    public void delete(Board board) {
        //
        boardRepository.delete(board.getId());
    }

    @Override
    public long nextPostingSequence(String boardId) {
        //
        BoardJpo boardJpo = boardRepository.findOne(boardId);
        if (boardJpo == null) throw new NonExistenceException(String.format("Board[%s] not found.", boardId));
        boardJpo.increasePostingSequence(1);
        boardRepository.save(boardJpo);
        return boardJpo.getPostingSequence();
    }

    @Override
    public List<Board> retrieveByPavilionScope(String pavilionId, AccessScope accessScope) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByTenantScreenPavilionIdAndAccessScope(pavilionId, accessScope);
        return BoardJpo.toDomain(boardJpos);
    }

    @Override
    public List<Board> retrieveByPavilion(String pavilionId) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByTenantScreenPavilionId(pavilionId);
        return BoardJpo.toDomain(boardJpos);
    }

    @Override
    public List<Board> retrieveByCineroom(String cineroomId) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByTenantScreenCineroomId(cineroomId);
        return BoardJpo.toDomain(boardJpos);
    }

    @Override
    public List<Board> retrieveByAudience(String audienceId) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByTenantActorAudienceId(audienceId);
        return BoardJpo.toDomain(boardJpos);
    }

    @Override
    public List<Board> retrieveByPlayer(String playerId) {
        //
        List<BoardJpo> boardJpos = boardRepository.findByTenantActorPlayerId(playerId);
        return BoardJpo.toDomain(boardJpos);
    }
}
