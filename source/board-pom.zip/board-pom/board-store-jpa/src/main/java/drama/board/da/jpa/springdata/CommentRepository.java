package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.reply.CommentJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface CommentRepository extends PagingAndSortingRepository<CommentJpo, String> {
    //
    List<CommentJpo> findByPostingId(String postingId, Pageable pageable);
    List<CommentJpo> findByWriterPlayerId(String playerId, Pageable pageable);

    long countByPostingId(String postingId);
    long countByWriterPlayerId(String playerId);

    void deleteByPostingId(String postingId);
}
