package drama.board.da.jpa;

import drama.board.da.jpa.jpo.posting.PostingBodyJpo;
import drama.board.da.jpa.jpo.posting.PostingJpo;
import drama.board.da.jpa.jpo.posting.PostingReadLogJpo;
import drama.board.da.jpa.springdata.PostingBodyRepository;
import drama.board.da.jpa.springdata.PostingReadLogRepository;
import drama.board.da.jpa.springdata.PostingRepository;
import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.posting.PostingReadLog;
import drama.board.domain.store.PostingStore;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import nara.share.springdata.page.OffsetRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;

@Repository
public class PostingJpaStore implements PostingStore {
    //
    @Autowired
    private PostingRepository postingRepository;

    @Autowired
    private PostingBodyRepository bodyRepository;

    @Autowired
    private PostingReadLogRepository readLogRepository;

    @Override
    public void create(Posting posting) {
        //
        String id = posting.getId();
        if (postingRepository.exists(id)) throw new AlreadyExistsException(String.format("Posting[%s] already exist.", id));
        PostingJpo postingJpo = new PostingJpo(posting);
        postingRepository.save(postingJpo);
    }

    @Override
    public void createBody(PostingBody postingBody) {
        //
        String id = postingBody.getId();
        if (bodyRepository.exists(id)) throw new AlreadyExistsException(String.format("PostingBody[%s] already exist.", id));
        PostingBodyJpo postingBodyJpo = new PostingBodyJpo(postingBody);
        bodyRepository.save(postingBodyJpo);
    }

    @Override
    public Posting retrieve(String id) throws NoSuchElementException {
        //
        PostingJpo postingJpo = postingRepository.findOne(id);
        if (postingJpo == null) throw new NoSuchElementException(String.format("Posting[%s] not found.", id));
        return postingJpo.toDomain();
    }

    @Override
    public PostingBody retrieveBody(String id) throws NoSuchElementException {
        //
        PostingBodyJpo postingBodyJpo = bodyRepository.findOne(id);
        if (postingBodyJpo == null) throw new NoSuchElementException(String.format("PostingBody[%s] not found.", id));
        return postingBodyJpo.toDomain();
    }

    @Override
    public List<Posting> retrieveByIds(List<String> ids) {
        //
        List<PostingJpo> postingJpos = postingRepository.findByIdIn(ids);
        return PostingJpo.toDomain(postingJpos);
    }

    @Override
    public List<Posting> retrieveByBoardLatest(String boardId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time"); // time based order

//        int page = offset / limit; // zero-based page index.
//        Page<PostingJpo> postingJpoPage = postingRepository.findPageByBoardId(boardId, new PageRequest(page, limit, sort));

        List<PostingJpo> postingJpos = postingRepository.findByBoardId(boardId, new OffsetRequest(offset, limit, sort));
        return PostingJpo.toDomain(postingJpos);
    }

    @Override
    public List<Posting> retrieveByBoardOldest(String boardId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.ASC, "time");
        List<PostingJpo> postingJpos = postingRepository.findByBoardId(boardId, new OffsetRequest(offset, limit, sort));
        return PostingJpo.toDomain(postingJpos);
    }

    @Override
    public void update(Posting posting) {
        //
        String id = posting.getId();
        if (!postingRepository.exists(id)) throw new NonExistenceException(String.format("Posting[%s] not found.", id));
        PostingJpo postingJpo = postingRepository.findOne(id);
        postingJpo.update(posting);
        postingRepository.save(postingJpo);
    }

    @Override
    public void updateBody(PostingBody postingBody) {
        //
        String id = postingBody.getId();
        if (!bodyRepository.exists(id)) throw new NonExistenceException(String.format("PostingBody[%s] not found.", id));
        PostingBodyJpo postingJpo = bodyRepository.findOne(id);
        postingJpo.update(postingBody);
        bodyRepository.save(postingJpo);
    }

    @Override
    public void delete(Posting posting) {
        //
        postingRepository.delete(posting.getId());
    }

    @Override
    public void deleteBody(PostingBody postingBody) {
        //
        bodyRepository.delete(postingBody.getId());
    }

    @Override
    public void createReadLog(PostingReadLog readLog) {
        //
        String id = readLog.getId();
        if (readLogRepository.exists(id)) {
            throw new AlreadyExistsException(String.format("PostingReadLog[%s] already exist.", id));
        }
        PostingReadLogJpo readLogJpo = new PostingReadLogJpo(readLog);
        readLogRepository.save(readLogJpo);
    }

    @Override
    public PostingReadLog retrieveReadLog(String id) {
        //
        PostingReadLogJpo readLogJpo = readLogRepository.findOne(id);
        if (readLogJpo == null) {
            throw new NoSuchElementException(String.format("PostingReadLog[%s] not found.", id));
        }

        return readLogJpo.toDomain();
    }

    @Override
    public PostingReadLog retrieveReadLogByPostingAudience(String postingId, String audienceId) {
        //
        PostingReadLogJpo readLogJpo = readLogRepository.findByPostingIdAndAudienceId(postingId, audienceId);
        if (readLogJpo == null) {
            return null;
        }

        return readLogJpo.toDomain();
    }

    @Override
    public List<PostingReadLog> retrieveReadLogByPosting(String postingId, int offset, int limit) {
        //
        Sort sort = new Sort(Sort.Direction.DESC, "time");
        List<PostingReadLogJpo> readLogJpos = readLogRepository.findByPostingId(postingId, new OffsetRequest(offset, limit, sort));

        return PostingReadLogJpo.toDomain(readLogJpos);
    }

    @Override
    public Long countReadLogByPosting(String postingId) {
        //
        return readLogRepository.countByPostingId(postingId);
    }

    @Override
    public void deleteReadLog(PostingReadLog readLog) {
        //
        readLogRepository.delete(readLog.getId());
    }

    @Override
    public void deleteAllReadLogByPosting(String postingId) {
        //
        readLogRepository.deleteByPostingId(postingId);
    }

    @Override
    public void deleteByBoard(String boardId) {
        //
        postingRepository.deleteByBoardId(boardId);
    }

    @Override
    public int countPostingsOfBoard(String boardId) {
        //
        return postingRepository.countByBoardId(boardId);
    }
}
