package drama.board.da.jpa.jpo.reply;

import drama.board.domain.entity.reply.comment.vote.CommentVote;
import drama.board.domain.entity.reply.comment.vote.VoteType;
import nara.share.jpo.EntityJpo;
import nara.share.jpo.drama.WriterJpo;
import nara.share.util.json.JsonUtil;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_COMMENT_VOTE")
@Table(indexes = {
    @Index(name = "IX_BOARD_COMMENT_VOTE_COMMENT", columnList = "commentId")
})
public class CommentVoteJpo extends EntityJpo {
    //
    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name="audienceId", column=@Column(name="VOTER_AUDIENCE_ID")),
        @AttributeOverride(name="playerId", column=@Column(name="VOTER_PLAYER_ID")),
        @AttributeOverride(name="name", column=@Column(name="VOTER_NAME")),
        @AttributeOverride(name="email", column=@Column(name="VOTER_EMAIL")),
        @AttributeOverride(name="anonymous", column=@Column(name="VOTER_ANONYMOUS")),
    })
    private WriterJpo voter;

    @Enumerated(EnumType.STRING)
    private VoteType type;

    private Long time;
    private Long updateTime;

    private String commentId;

    public CommentVoteJpo() {
        //
    }

    public CommentVoteJpo(CommentVote commentVote) {
        //
        super(commentVote);
        BeanUtils.copyProperties(commentVote, this, "voter");
        this.voter = new WriterJpo(commentVote.getVoter());
    }

    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

    public void update(CommentVote commentVote) {
        //
        BeanUtils.copyProperties(commentVote, this, "voter");
        this.voter.update(commentVote.getVoter());
    }

    public CommentVote toDomain() {
        //
        CommentVote commentVote = new CommentVote(getId());
        BeanUtils.copyProperties(this, commentVote, "voter");
        commentVote.setVoter(voter.toDomain());

        return commentVote;
    }

    public static List<CommentVote> toDomain(List<CommentVoteJpo> commentVoteJpos) {
        //
        return commentVoteJpos.stream().map(commentVoteJpo -> commentVoteJpo.toDomain()).collect(Collectors.toList());
    }

    public WriterJpo getVoter() {
        return voter;
    }

    public void setVoter(WriterJpo voter) {
        this.voter = voter;
    }

    public VoteType getType() {
        return type;
    }

    public void setType(VoteType type) {
        this.type = type;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public static void main(String[] args) {
        //
        System.out.println(CommentVote.getSample());
        System.out.println(new CommentVoteJpo(CommentVote.getSample()));
    }
}
