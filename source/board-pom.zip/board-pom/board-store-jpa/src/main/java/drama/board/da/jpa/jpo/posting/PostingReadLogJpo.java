package drama.board.da.jpa.jpo.posting;

import drama.board.domain.entity.posting.PostingReadLog;
import nara.share.jpo.EntityJpo;
import nara.share.util.json.JsonUtil;
import org.springframework.beans.BeanUtils;

import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_POSTING_READ_LOG")
@Table(indexes = {
    @Index(name = "IX_BOARD_POSTING_READ_LOG_POSTING", columnList = "postingId"),
    @Index(name = "IX_BOARD_POSTING_READ_LOG_AUDIENCE", columnList = "audienceId"),
})
public class PostingReadLogJpo extends EntityJpo {
    //
    private String postingId;
    private String audienceId;
    private Long time;

    public PostingReadLogJpo() {
        //
    }

    public PostingReadLogJpo(PostingReadLog postingReadLog) {
        //
        super(postingReadLog);
        BeanUtils.copyProperties(postingReadLog, this);
    }

    public static List<PostingReadLog> toDomain(List<PostingReadLogJpo> readLogJpos) {
        //
        return readLogJpos.stream().map(readLogJpo -> readLogJpo.toDomain()).collect(Collectors.toList());
    }

    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

    public void update(PostingReadLog postingReadLog) {
        //
        BeanUtils.copyProperties(postingReadLog, this);
    }

    public PostingReadLog toDomain() {
        //
        PostingReadLog postingReadLog = new PostingReadLog(getId());
        BeanUtils.copyProperties(this, postingReadLog);

        return postingReadLog;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getAudienceId() {
        return audienceId;
    }

    public void setAudienceId(String audienceId) {
        this.audienceId = audienceId;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public static void main(String[] args) {
        //
        System.out.println(new PostingReadLogJpo(PostingReadLog.getSample()));
    }
}
