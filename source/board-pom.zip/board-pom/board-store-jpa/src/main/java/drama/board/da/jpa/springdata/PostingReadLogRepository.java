package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.posting.PostingReadLogJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface PostingReadLogRepository extends PagingAndSortingRepository<PostingReadLogJpo, String> {
    //
    PostingReadLogJpo findByPostingIdAndAudienceId(String postingId, String audienceId);
    List<PostingReadLogJpo> findByPostingId(String postingId, Pageable pageable);
    Long countByPostingId(String postingId);
    void deleteByPostingId(String postingId);
}
