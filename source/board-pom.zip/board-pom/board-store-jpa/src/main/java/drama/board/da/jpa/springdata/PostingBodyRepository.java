package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.posting.PostingBodyJpo;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface PostingBodyRepository extends PagingAndSortingRepository<PostingBodyJpo, String> {
    //
}
