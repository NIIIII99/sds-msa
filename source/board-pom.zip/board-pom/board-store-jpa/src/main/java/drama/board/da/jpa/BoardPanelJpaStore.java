package drama.board.da.jpa;

import drama.board.da.jpa.jpo.board.BoardPanelJpo;
import drama.board.da.jpa.springdata.BoardPanelRepository;
import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.store.BoardPanelStore;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;

@Repository
public class BoardPanelJpaStore implements BoardPanelStore {
    //
    @Autowired
    private BoardPanelRepository boardPanelRepository;

    @Override
    public void create(BoardPanel boardPanel) {
        //
        String id = boardPanel.getId();
        if (boardPanelRepository.exists(id)) throw new AlreadyExistsException(String.format("BoardPanel[%s] already exist.", id));
        BoardPanelJpo boardPanelJpo = new BoardPanelJpo(boardPanel);
        boardPanelRepository.save(boardPanelJpo);
    }

    @Override
    public BoardPanel retrieve(String id) throws NoSuchElementException {
        //
        BoardPanelJpo boardPanelJpo = boardPanelRepository.findOne(id);
        if (boardPanelJpo == null) throw new NoSuchElementException(String.format("BoardPanel[%s] not found.", id));
        return boardPanelJpo.toDomain();
    }

    @Override
    public void update(BoardPanel boardPanel) {
        //
        String id = boardPanel.getId();
        if (!boardPanelRepository.exists(id)) throw new NonExistenceException(String.format("BoardPanel[%s] not found.", id));
        BoardPanelJpo boardPanelJpo = boardPanelRepository.findOne(id);
        boardPanelJpo.update(boardPanel);
        boardPanelRepository.save(boardPanelJpo);
    }

    @Override
    public void delete(BoardPanel boardPanel) {
        //
        boardPanelRepository.delete(boardPanel.getId());
    }

    @Override
    public List<BoardPanel> retrieveByPavilion(String pavilionId) {
        //
        return boardPanelRepository.findByTenantScreenPavilionId(pavilionId);
    }

    @Override
    public List<BoardPanel> retrieveByCineroom(String cineroomId) {
        //
        return boardPanelRepository.findByTenantScreenCineroomId(cineroomId);
    }
}
