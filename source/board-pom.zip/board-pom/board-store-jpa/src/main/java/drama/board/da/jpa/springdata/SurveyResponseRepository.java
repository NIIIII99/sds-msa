package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.reply.SurveyResponseJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface SurveyResponseRepository extends PagingAndSortingRepository<SurveyResponseJpo, String> {
    //
    SurveyResponseJpo findByPostingIdAndRespondentPlayerId(String postingId, String playerId);
    List<SurveyResponseJpo> findByPostingId(String postingId, Pageable pageable);
    List<SurveyResponseJpo> findByPostingIdAndAnswered(String postingId, boolean answered, Pageable pageable);
    long countByPostingId(String postingId);
    long countByPostingIdAndAnswered(String postingId, boolean answered);

    void deleteByPostingId(String postingId);
}
