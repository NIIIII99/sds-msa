package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.reply.NotifyingResponseJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface NotifyingResponseRepository extends PagingAndSortingRepository<NotifyingResponseJpo, String> {
    //
    NotifyingResponseJpo findByPostingIdAndRespondentPlayerId(String postingId, String playerId);
    List<NotifyingResponseJpo> findByPostingId(String postingId, Pageable pageable);
    List<NotifyingResponseJpo> findByPostingIdAndChecked(String postingId, boolean checked, Pageable pageable);
    long countByPostingId(String postingId);
    long countByPostingIdAndChecked(String postingId, boolean checked);

    void deleteByPostingId(String postingId);


}
