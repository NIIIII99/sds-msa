package drama.board.da.jpa.jpo.tagsearch;

import drama.board.domain.entity.tagsearch.PostingTag;
import nara.share.jpo.EntityJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import java.util.List;
import java.util.stream.Collectors;

@Entity(name = "DR_BOARD_POSTING_TAG")
@Table(indexes = {
    @Index(name = "IX_BOARD_POSTING_TAG_TAG", columnList = "tag"),
    @Index(name = "IX_BOARD_POSTING_TAG_TAG_BOARD", columnList = "tag, boardId"),
    @Index(name = "IX_BOARD_POSTING_TAG_POSTING", columnList = "postingId"),
    @Index(name = "IX_BOARD_POSTING_TAG_POSTING_BOARD", columnList = "postingId, boardId"),
    @Index(name = "IX_BOARD_POSTING_TAG_BOARD", columnList = "boardId"),
})
public class PostingTagJpo extends EntityJpo {
    //
    private String tag;
    private String postingId;
    private String boardId;

    public PostingTagJpo() {
        //
    }

    public PostingTagJpo(PostingTag postingTag) {
        //
        super(postingTag);
        BeanUtils.copyProperties(postingTag, this);
    }

    public PostingTag toDomain() {
        //
        PostingTag postingTag = new PostingTag(getId());
        BeanUtils.copyProperties(this, postingTag);
        return postingTag;
    }

    public static List<PostingTag> toDomain(List<PostingTagJpo> postingTagJpos) {
        //
        return postingTagJpos.stream().map(postingTagJpo -> postingTagJpo.toDomain()).collect(Collectors.toList());
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }
}
