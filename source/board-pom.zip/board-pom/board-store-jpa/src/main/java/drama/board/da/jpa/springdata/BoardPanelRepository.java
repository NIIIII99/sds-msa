package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.board.BoardPanelJpo;
import drama.board.domain.entity.panel.BoardPanel;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface BoardPanelRepository extends PagingAndSortingRepository<BoardPanelJpo, String> {
    //
    List<BoardPanel> findByTenantScreenPavilionId(String pavilionId);
    List<BoardPanel> findByTenantScreenCineroomId(String cineroomId);
}
