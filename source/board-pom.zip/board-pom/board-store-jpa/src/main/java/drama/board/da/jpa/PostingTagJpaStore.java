package drama.board.da.jpa;

import drama.board.da.jpa.jpo.tagsearch.PostingTagJpo;
import drama.board.da.jpa.springdata.PostingTagRepository;
import drama.board.domain.entity.tagsearch.PostingTag;
import drama.board.domain.store.PostingTagStore;
import nara.share.springdata.page.OffsetRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Repository
public class PostingTagJpaStore implements PostingTagStore {
    //
    @Autowired
    private PostingTagRepository postingTagRepository;

    @Override
    public void create(PostingTag postingTag) {
        //
        postingTagRepository.save(new PostingTagJpo(postingTag));
    }

    @Override
    public void create(List<PostingTag> postingTags) {
        //
        postingTagRepository.save(
            postingTags
                .stream()
                .map(postingTag -> new PostingTagJpo(postingTag))
                .collect(Collectors.toList())
        );
    }

    @Override
    public PostingTag retrieve(String id) {
        //
        PostingTagJpo postingTagJpo = postingTagRepository.findOne(id);
        if (postingTagJpo == null) throw new NoSuchElementException(String.format("PostingTag[%s] not found.", id));
        return postingTagJpo.toDomain();
    }

    @Override
    public List<PostingTag> retrieveAllByTag(String boardId, String tag, int offset, int limit) {
        //
        List<PostingTagJpo> postingTagJpos = postingTagRepository.findByBoardIdAndTag(boardId, tag, new OffsetRequest(offset, limit));
        return PostingTagJpo.toDomain(postingTagJpos);
    }

    @Override
    public List<PostingTag> retrieveAll(int offset, int limit) {
        //
        Page<PostingTagJpo> postingTagJpoPage = postingTagRepository.findAll(new OffsetRequest(offset, limit));
        return PostingTagJpo.toDomain(postingTagJpoPage.getContent());
    }

    @Override
    public void delete(String id) {
        //
        postingTagRepository.delete(id);
    }

    @Override
    public void deleteAllByPosting(String postingId) {
        //
        postingTagRepository.deleteByPostingId(postingId);
    }
}
