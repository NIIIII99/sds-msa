package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.reply.CommentVoteJpo;
import drama.board.domain.entity.reply.comment.vote.VoteType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface CommentVoteRepository extends PagingAndSortingRepository<CommentVoteJpo, String> {
    //
    CommentVoteJpo findByCommentIdAndVoterPlayerId(String commentId, String playerId);
    List<CommentVoteJpo> findByCommentId(String commentId, Pageable pageable);

    Long countByCommentIdAndType(String commentId, VoteType voteType);
}
