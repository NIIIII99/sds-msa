package drama.board.da.jpa.jpo.posting;

import drama.board.domain.entity.posting.Content;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.reply.notifying.Notifying;
import drama.board.domain.entity.reply.survey.TinySurvey;
import nara.share.jpo.EntityJpo;
import org.springframework.beans.BeanUtils;

import javax.persistence.Entity;
import javax.persistence.Lob;

@Entity(name = "DR_BOARD_POSTING_BODY")
public class PostingBodyJpo extends EntityJpo {
    //
    @Lob
    private String contentJson;
    private Long updateTime;

    @Lob
    private String notifyingJson;

    @Lob
    private String surveyJson;

    public PostingBodyJpo() {
        //
    }

    public PostingBodyJpo(PostingBody postingBody) {
        //
        super(postingBody);
        BeanUtils.copyProperties(postingBody, this);
        contentJson = postingBody.getContent().toJson();
        if(postingBody.getNotifying() != null) {
            notifyingJson = postingBody.getNotifying().toJson();
        }
        if(postingBody.getSurvey() != null) {
            surveyJson = postingBody.getSurvey().toJson();
        }
    }

    public void update(PostingBody postingBody) {
        //
        BeanUtils.copyProperties(postingBody, this);
        contentJson = postingBody.getContent().toJson();
        if(postingBody.getNotifying() != null) {
            notifyingJson = postingBody.getNotifying().toJson();
        }
        if(postingBody.getSurvey() != null) {
            surveyJson = postingBody.getSurvey().toJson();
        }
    }

    public PostingBody toDomain() {
        //
        PostingBody postingBody = new PostingBody(getId());
        BeanUtils.copyProperties(this, postingBody);
        postingBody.setContent(Content.fromJson(contentJson));
        postingBody.setNotifying(Notifying.fromJson(notifyingJson));
        postingBody.setSurvey(TinySurvey.fromJson(surveyJson));

        return postingBody;
    }

    public String getContentJson() {
        return contentJson;
    }

    public void setContentJson(String contentJson) {
        this.contentJson = contentJson;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getNotifyingJson() {
        return notifyingJson;
    }

    public void setNotifyingJson(String notifyingJson) {
        this.notifyingJson = notifyingJson;
    }

    public String getSurveyJson() {
        return surveyJson;
    }

    public void setSurveyJson(String surveyJson) {
        this.surveyJson = surveyJson;
    }
}
