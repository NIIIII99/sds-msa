package drama.board.da.jpa;

import drama.board.da.jpa.jpo.reply.NotifyingResponseJpo;
import drama.board.da.jpa.springdata.NotifyingResponseRepository;
import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.store.NotifyingResponseStore;
import nara.share.exception.store.AlreadyExistsException;
import nara.share.exception.store.NonExistenceException;
import nara.share.springdata.page.OffsetRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Repository
public class NotifyingResponseJpaStore implements NotifyingResponseStore {
    //
    @Autowired
    private NotifyingResponseRepository notifyingResponseRepository;

    @Override
    public void create(NotifyingResponse notifyingResponse) {
        //
        String id = notifyingResponse.getId();
        if (notifyingResponseRepository.exists(id)) throw new AlreadyExistsException(String.format("NotifyingResponse[%s] already exist.", id));
        NotifyingResponseJpo notifyingResponseJpo = new NotifyingResponseJpo(notifyingResponse);
        notifyingResponseRepository.save(notifyingResponseJpo);
    }

    @Override
    public void create(List<NotifyingResponse> notifyingResponses) {
        //
        notifyingResponseRepository.save(
            notifyingResponses
            .stream()
            .map(notifyingResponse -> new NotifyingResponseJpo(notifyingResponse))
            .collect(Collectors.toList())
        );
    }

    @Override
    public NotifyingResponse retrieve(String id) throws NoSuchElementException {
        //
        NotifyingResponseJpo notifyingResponseJpo = notifyingResponseRepository.findOne(id);
        if (notifyingResponseJpo == null) throw new NoSuchElementException(String.format("NotifyingResponse[%s] not found.", id));
        return notifyingResponseJpo.toDomain();
    }

    @Override
    public NotifyingResponse retrieveByPostingPlayer(String postingId, String playerId) throws NoSuchElementException {
        //
        NotifyingResponseJpo notifyingResponseJpo = notifyingResponseRepository.findByPostingIdAndRespondentPlayerId(postingId, playerId);
        if (notifyingResponseJpo == null) throw new NoSuchElementException(String.format("NotifyingResponse for posting[%] player[%] not found.", postingId, playerId));
        return notifyingResponseJpo.toDomain();
    }

    @Override
    public List<NotifyingResponse> retrieveByPosting(String postingId, int offset, int limit) {
        //
        List<NotifyingResponseJpo> notifyingResponseJpos = notifyingResponseRepository.findByPostingId(postingId, new OffsetRequest(offset, limit));
        return NotifyingResponseJpo.toDomain(notifyingResponseJpos);
    }

    @Override
    public long countByPosting(String postingId) {
        //
        return notifyingResponseRepository.countByPostingId(postingId);
    }

    @Override
    public List<NotifyingResponse> retrieveByCheckedPosting(String postingId, int offset, int limit) {
        //
        List<NotifyingResponseJpo> notifyingResponseJpos = notifyingResponseRepository.findByPostingIdAndChecked(postingId, true, new OffsetRequest(offset, limit));
        return NotifyingResponseJpo.toDomain(notifyingResponseJpos);
    }

    @Override
    public long countByPostingChecked(String postingId) {
        //
        return notifyingResponseRepository.countByPostingIdAndChecked(postingId, true);
    }

    @Override
    public List<NotifyingResponse> retrieveByUncheckedPosting(String postingId, int offset, int limit) {
        //
        List<NotifyingResponseJpo> notifyingResponseJpos = notifyingResponseRepository.findByPostingIdAndChecked(postingId, false, new OffsetRequest(offset, limit));
        return NotifyingResponseJpo.toDomain(notifyingResponseJpos);
    }

    @Override
    public long countByPostingUnchecked(String postingId) {
        //
        return notifyingResponseRepository.countByPostingIdAndChecked(postingId, false);
    }

    @Override
    public long countByReadCheckTime(String postingId) {
        // TODO ??
        return 0;
    }

    @Override
    public long countByUnreadCheckTime(String postingId) {
        // TODO ??
        return 0;
    }

    @Override
    public void update(NotifyingResponse notifyingResponse) {
        //
        String id = notifyingResponse.getId();
        if (!notifyingResponseRepository.exists(id)) throw new NonExistenceException(String.format("NotifyingResponse[%s] not found.", id));
        NotifyingResponseJpo notifyingResponseJpo = notifyingResponseRepository.findOne(id);
        notifyingResponseJpo.update(notifyingResponse);
        notifyingResponseRepository.save(notifyingResponseJpo);
    }

    @Override
    public void delete(NotifyingResponse notifyingResponse) {
        //
        notifyingResponseRepository.delete(notifyingResponse.getId());
    }

    @Override
    public void deleteByPosting(String postingId) {
        //
        notifyingResponseRepository.deleteByPostingId(postingId);
    }
}
