package drama.board.da.jpa.jpo.board;

import drama.board.domain.entity.panel.BoardIntro;
import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import nara.share.jpo.drama.DramaAggregateJpo;
import nara.share.util.json.JsonUtil;
import org.springframework.beans.BeanUtils;

import javax.persistence.Entity;
import javax.persistence.Lob;

@Entity(name = "DR_BOARD_PANEL")
public class BoardPanelJpo extends DramaAggregateJpo {
    //
    private String title;

    @Lob
    private String publicBoardsJson;

    @Lob
    private String privateBoardsJson;

    private boolean privateFirst;

    @Lob
    private String preSettingsJson;

    private Long time;
    private Long updateTime;

    public BoardPanelJpo() {
        //
    }

    public BoardPanelJpo(BoardPanel boardPanel) {
        //
        super(boardPanel);
        BeanUtils.copyProperties(boardPanel, this);

        this.publicBoardsJson = JsonUtil.toJson(boardPanel.getPublicBoards());
        this.privateBoardsJson = JsonUtil.toJson(boardPanel.getPrivateBoards());
        this.preSettingsJson = JsonUtil.toJson(boardPanel.getPreSettings());
    }

    public void update(BoardPanel boardPanel) {
        //
        super.update(boardPanel);
        BeanUtils.copyProperties(boardPanel, this);

        this.publicBoardsJson = JsonUtil.toJson(boardPanel.getPublicBoards());
        this.privateBoardsJson = JsonUtil.toJson(boardPanel.getPrivateBoards());
        this.preSettingsJson = JsonUtil.toJson(boardPanel.getPreSettings());
    }

    public BoardPanel toDomain() {
        //
        BoardPanel boardPanel = new BoardPanel(getId(), getTenantDomain(), getAccessDomain());
        BeanUtils.copyProperties(this, boardPanel);
        boardPanel.setPublicBoards(JsonUtil.fromJsonList(publicBoardsJson, BoardIntro.class));
        boardPanel.setPrivateBoards(JsonUtil.fromJsonList(privateBoardsJson, BoardIntro.class));
        boardPanel.setPreSettings(JsonUtil.fromJsonList(preSettingsJson, PreSetting.class));
        return boardPanel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublicBoardsJson() {
        return publicBoardsJson;
    }

    public void setPublicBoardsJson(String publicBoardsJson) {
        this.publicBoardsJson = publicBoardsJson;
    }

    public String getPrivateBoardsJson() {
        return privateBoardsJson;
    }

    public void setPrivateBoardsJson(String privateBoardsJson) {
        this.privateBoardsJson = privateBoardsJson;
    }

    public boolean isPrivateFirst() {
        return privateFirst;
    }

    public void setPrivateFirst(boolean privateFirst) {
        this.privateFirst = privateFirst;
    }

    public String getPreSettingsJson() {
        return preSettingsJson;
    }

    public void setPreSettingsJson(String preSettingsJson) {
        this.preSettingsJson = preSettingsJson;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }
}
