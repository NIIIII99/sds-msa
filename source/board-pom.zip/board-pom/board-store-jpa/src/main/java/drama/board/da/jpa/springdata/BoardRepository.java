package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.board.BoardJpo;
import nara.share.domain.drama.AccessScope;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface BoardRepository extends PagingAndSortingRepository<BoardJpo, String> {
    //
    List<BoardJpo> findByPanelId(String panelId);

    List<BoardJpo> findByTenantScreenPavilionId(String pavilionId);
    List<BoardJpo> findByTenantScreenCineroomId(String cineroomId);
    List<BoardJpo> findByTenantActorAudienceId(String audienceId);
    List<BoardJpo> findByTenantActorPlayerId(String playerId);

    List<BoardJpo> findByTenantScreenPavilionIdAndAccessScope(String pavilionId, AccessScope accessScope);
    long countByPanelId(String panelId);
}
