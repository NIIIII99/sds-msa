package drama.board.da.jpa.springdata;

import drama.board.da.jpa.jpo.reply.SubCommentJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface SubCommentRepository extends PagingAndSortingRepository<SubCommentJpo, String> {
    //
    List<SubCommentJpo> findByCommentId(String commentId, Pageable pageable);
    long countByCommentId(String commentId);
    void deleteByPostingId(String postingId);
    void deleteByCommentId(String commentId);
}
