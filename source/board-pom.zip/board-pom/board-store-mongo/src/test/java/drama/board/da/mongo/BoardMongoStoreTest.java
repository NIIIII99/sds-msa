package drama.board.da.mongo;

import drama.board.da.BoardStoreTestApplication;
import drama.board.domain.store.BoardStore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = BoardStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class BoardMongoStoreTest {

    @Autowired
    private BoardStore boardStore;

    @Test
    public void testCrud() {
        //
    }


}
