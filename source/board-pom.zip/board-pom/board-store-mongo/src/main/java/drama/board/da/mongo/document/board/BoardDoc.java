package drama.board.da.mongo.document.board;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "DR_BOARD")
public class BoardDoc {

    public long getPostingSequence() {
        return 0;
    }
}
