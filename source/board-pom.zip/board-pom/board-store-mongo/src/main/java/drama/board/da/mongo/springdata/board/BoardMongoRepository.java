package drama.board.da.mongo.springdata.board;

import drama.board.da.mongo.document.board.BoardDoc;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface BoardMongoRepository extends MongoRepository<BoardDoc, String> {
    //
}
