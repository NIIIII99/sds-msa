package drama.board.da.mongo;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.store.PostingStore;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;

@Repository
public class PostingMongoStore implements PostingStore {
    //
    @Override
    public void create(Posting posting) {

    }

    @Override
    public void createBody(PostingBody postingBody) {

    }

    @Override
    public Posting retrieve(String id) throws NoSuchElementException {
        return null;
    }

    @Override
    public PostingBody retrieveBody(String id) throws NoSuchElementException {
        return null;
    }

    @Override
    public List<Posting> retrieveByBoardLatest(String boardId, int offset, int limit) {
        return null;
    }

    @Override
    public List<Posting> retrieveByBoardOldest(String boardId, int offset, int limit) {
        return null;
    }

    @Override
    public void update(Posting posting) {

    }

    @Override
    public void updateBody(PostingBody postingBody) {

    }

    @Override
    public void delete(Posting posting) {

    }

    @Override
    public void deleteBody(PostingBody postingBody) {

    }

    @Override
    public void deleteAll(String boardId) {

    }

    @Override
    public int countPostingsOfBoard(String boardId) {
        return 0;
    }
}
