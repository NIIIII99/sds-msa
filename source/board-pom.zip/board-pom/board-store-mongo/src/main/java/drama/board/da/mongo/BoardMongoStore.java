package drama.board.da.mongo;

import drama.board.da.mongo.document.board.BoardDoc;
import drama.board.da.mongo.springdata.board.BoardMongoRepository;
import drama.board.domain.entity.board.Board;
import drama.board.domain.store.BoardStore;
import nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BoardMongoStore implements BoardStore {
    //

    @Autowired
    private BoardMongoRepository boardRepository;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public void create(Board board) {
        //
    }

    @Override
    public Board retrieve(String boardId) {
        //
        return null;
    }

    @Override
    public List<Board> retrieveByPanel(String panelId) {
        return null;
    }

    @Override
    public long countByPanel(String panelId) {
        return 0;
    }

    @Override
    public long nextPostingSequence(String boardId) {
        //
        if (!boardRepository.exists(boardId)) throw new NonExistenceException(String.format("Board[%s] not found.", boardId));

        Query query = new Query(Criteria.where("id").is(boardId));
        Update update = new Update();
        update.inc("postingSequence", 1);

        FindAndModifyOptions options = new FindAndModifyOptions();
        options.returnNew(true);
        options.upsert(false);

        BoardDoc boardDoc = mongoTemplate.findAndModify(query, update, options, BoardDoc.class);
        return boardDoc.getPostingSequence();
    }


    @Override
    public void update(Board board) {

    }

    @Override
    public void delete(Board board) {

    }


    @Override
    public List<Board> retrieveByPavilion(String pavilionId) {
        return null;
    }

    @Override
    public List<Board> retrieveByCineroom(String cineroomId) {
        return null;
    }

    @Override
    public List<Board> retrieveByAudience(String audienceId) {
        return null;
    }

    @Override
    public List<Board> retrieveByPlayer(String playerId) {
        return null;
    }
}
