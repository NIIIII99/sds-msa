package drama.board.sa.envoy;

import drama.board.domain.proxy.StageProxy;
import nara.cineroom.domain.spec.AudienceProvider;
import nara.cineroom.domain.spec.PlayerProvider;
import nara.stage.context.DramaContext;
import nara.stage.context.StageContext;

public class StageEnvoyProxy implements StageProxy {
    //
    @Override
    public long countPlayers(String cineroomId) {
        //
        StageContext stageContext = DramaContext.getInstance().getStageContext();
        PlayerProvider playerProvider = stageContext.requestCineroomEnvoy().requirePlayerProvider();
        return playerProvider.findPlayerCount(cineroomId);
    }

    @Override
    public long countAudiences(String pavilionId) {
        //
        StageContext stageContext = DramaContext.getInstance().getStageContext();
        AudienceProvider audienceProvider = stageContext.requestCineroomEnvoy().requireAudienceProvider();
        return audienceProvider.findAudienceCount(pavilionId);
    }
}
