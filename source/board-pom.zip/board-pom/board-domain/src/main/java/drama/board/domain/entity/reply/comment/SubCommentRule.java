package drama.board.domain.entity.reply.comment;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class SubCommentRule implements ValueObject {
    //
    private boolean anonymous;

    public SubCommentRule() {
        //
    }

    public SubCommentRule(boolean anonymous) {
        //
        this.anonymous = anonymous;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubCommentRule getSample() {
        //
        boolean anonymous = true;
        return new SubCommentRule(anonymous);
    }

    public static SubCommentRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubCommentRule.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
