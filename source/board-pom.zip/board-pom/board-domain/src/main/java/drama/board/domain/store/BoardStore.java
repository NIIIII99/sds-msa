package drama.board.domain.store;

import drama.board.domain.entity.board.Board;
import nara.share.domain.drama.AccessScope;

import java.util.List;
import java.util.NoSuchElementException;

public interface BoardStore {
    //
    void create(Board board);
    Board retrieve(String boardId) throws NoSuchElementException;
    List<Board> retrieveByPanel(String panelId);
    long countByPanel(String panelId);
    void update(Board board);
    void delete(Board board);

    long nextPostingSequence(String boardId);

    List<Board> retrieveByPavilionScope(String pavilionId, AccessScope accessScope);
    List<Board> retrieveByPavilion(String pavilionId);
    List<Board> retrieveByCineroom(String cineroomId);
    List<Board> retrieveByAudience(String audienceId);
    List<Board> retrieveByPlayer(String playerId);
}
