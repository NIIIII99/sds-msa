package drama.board.domain.spec.posting.sdo;

import drama.board.domain.entity.posting.Content;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.UUID;

public class PostingCdo implements ValueObject {
    //
    private String title;
    private Content content;
    private boolean anonymous;
    private String boardId;

    private NotifyingCdo notifyingCdo;      // can be null
    private TinySurveyCdo tinySurveyCdo;            // can be null


    private PostingCdo() {
        // Only for instantiate by reflection
    }

    public PostingCdo(String title, Content content, boolean anonymous, String boardId) {
        //
        this.title = title;
        this.content = content;
        this.anonymous = anonymous;
        this.boardId = boardId;
    }

    public String toString() {
        //
        return toJson();
    }

    public static PostingCdo getSample() {
        //
        String title = "점심 메뉴를 선택하세요";
        Content content = new Content("오늘 점심 메뉴를 부담없이 골라 보세요");
        boolean anonymous = false;
        String boardId = UUID.randomUUID().toString();

        PostingCdo sample = new PostingCdo(title, content, anonymous, boardId);

        return sample;
    }

    public static PostingCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PostingCdo.class);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }

    public NotifyingCdo getNotifyingCdo() {
        return notifyingCdo;
    }

    public void setNotifyingCdo(NotifyingCdo notifyingCdo) {
        this.notifyingCdo = notifyingCdo;
    }

    public TinySurveyCdo getTinySurveyCdo() {
        return tinySurveyCdo;
    }

    public void setTinySurveyCdo(TinySurveyCdo tinySurveyCdo) {
        this.tinySurveyCdo = tinySurveyCdo;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
