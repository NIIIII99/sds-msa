package drama.board.domain.entity.panel;

import drama.board.domain.entity.panel.option.PostingOption;
import drama.board.domain.entity.panel.share.BoardCoverage;
import drama.board.domain.entity.panel.share.BoardCategory;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class PreSetting implements ValueObject {
    //
    private String title;
    private BoardCategory boardCategory;
    private BoardCoverage boardCoverage;
    private PostingOption postingOption;

    public PreSetting() {
        //
    }

    public PreSetting(String title,
                      BoardCategory category,
                      BoardCoverage coverage,
                      PostingOption settings) {
        //
        super();
        this.title = title;
        this.boardCategory = category;
        this.boardCoverage = coverage;
        this.postingOption = settings;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static PreSetting getNoticeBoardSample() {
        //
        String title = "일반공지";
        BoardCategory type = BoardCategory.Notice;
        BoardCoverage coverage = BoardCoverage.PublicUser;
        PostingOption settings = PostingOption.getNoticeBoardSample();

        PreSetting sample = new PreSetting(title, type, coverage, settings);

        return sample;
    }

    public static PreSetting getNormalBoardSample() {
        //
        String title = "토론게시판";
        BoardCategory type = BoardCategory.BulletinBoard;
        BoardCoverage coverage = BoardCoverage.TeamUser;
        PostingOption settings = PostingOption.getNormalBoardSample();

        PreSetting sample = new PreSetting(title, type, coverage, settings);

        return sample;
    }

    public static PreSetting fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PreSetting.class);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BoardCategory getBoardCategory() {
        return boardCategory;
    }

    public void setBoardCategory(BoardCategory boardCategory) {
        this.boardCategory = boardCategory;
    }

    public BoardCoverage getBoardCoverage() {
        return boardCoverage;
    }

    public void setBoardCoverage(BoardCoverage boardCoverage) {
        this.boardCoverage = boardCoverage;
    }

    public PostingOption getPostingOption() {
        return postingOption;
    }

    public void setPostingOption(PostingOption postingOption) {
        this.postingOption = postingOption;
    }

    public static void main(String[] args) {
        //
        System.out.println(getNoticeBoardSample());
    }
}
