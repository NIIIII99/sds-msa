package drama.board.domain.store;

import drama.board.domain.entity.panel.BoardPanel;

import java.util.List;
import java.util.NoSuchElementException;

public interface BoardPanelStore {
    //
    void create(BoardPanel boardPanel);
    BoardPanel retrieve(String id) throws NoSuchElementException;
    void update(BoardPanel boardPanel);
    void delete(BoardPanel boardPanel);

    List<BoardPanel> retrieveByPavilion(String pavilionId);
    List<BoardPanel> retrieveByCineroom(String cineroomId);
}
