package drama.board.domain.spec.survey;

import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.spec.survey.sdo.SurveyResponseCdo;
import nara.share.domain.NameValueList;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
    name = "SurveyResponse",
    editions = {"Professional", "Enterprise"},
    authorizedRoles = {"Admin", "User"}
)
public interface SurveyResponseService {
    //
    String registerResponse(SurveyResponseCdo responseCdo);
    long buildFullResponsesForPosting(String postingId);
    String markResponseAsAnswered(SurveyResponseCdo responseCdo);
    SurveyResponse findResponse(String responseId);
    List<SurveyResponse> findResponsesByPosting(String postingId, int offset, int limit);
    List<SurveyResponse> findResponsesByPostingAnswered(String postingId, int offset, int limit);
    void modifyResponse(String responseId, NameValueList nameValues);
    void removeResponse(String responseId);
    void removeAllResponsesByPosting(String postingId);
}
