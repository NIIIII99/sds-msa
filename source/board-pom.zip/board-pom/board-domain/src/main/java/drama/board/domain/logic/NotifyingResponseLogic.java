package drama.board.domain.logic;

import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.proxy.StageProxy;
import drama.board.domain.spec.notifying.NotifyingResponseService;
import drama.board.domain.spec.notifying.sdo.NotifyingResponseCdo;
import drama.board.domain.store.BoardStoreLycler;
import drama.board.domain.store.NotifyingResponseStore;
import drama.board.domain.store.PostingStore;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Writer;
import nara.share.exception.store.AlreadyExistsException;
import nara.stage.context.DramaContext;

import java.util.List;

public class NotifyingResponseLogic implements NotifyingResponseService {
    //
    private PostingStore postingStore;
    private NotifyingResponseStore responseStore;
    private StageProxy stageProxy;

    public NotifyingResponseLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.postingStore = storeLycler.requestPostingStore();
        this.responseStore = storeLycler.requestNotifyingResponseStore();
        this.stageProxy = proxyLycler.requestStageProxy();
    }

    @Override
    public String registerResponse(NotifyingResponseCdo responseCdo) {
        //
        String postingId = responseCdo.getPostingId();
        Actor actor = DramaContext.getStage().whoAmI();
        Writer respondent = Writer.newWriter(actor);

        NotifyingResponse response = responseStore.retrieveByPostingPlayer(postingId, actor.getPlayerId());
        if(response != null) {
            throw new AlreadyExistsException("Already exist for: " + actor.getName());
        }

        response = NotifyingResponse.newAsCheckedResponse(postingId, respondent);
        responseStore.create(response);

        PostingBody postingBody = postingStore.retrieveBody(postingId);
        Long responseCount = responseStore.countByPostingChecked(postingId);
        postingBody.getNotifying().setValues(new NameValueList("responseCount", String.valueOf(responseCount)));
        postingStore.updateBody(postingBody);

        return response.getId();
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        //
        return 0;
    }

    @Override
    public String markResponseAsChecked(NotifyingResponseCdo responseCdo) {
        //
        String postingId = responseCdo.getPostingId();
        Actor actor = DramaContext.getStage().whoAmI();
        String playerId = actor.getPlayerId();
        NotifyingResponse response = responseStore.retrieveByPostingPlayer(postingId, playerId);

        response.setChecked(true);
        response.setCheckTime(System.currentTimeMillis());

        responseStore.update(response);

        PostingBody postingBody = postingStore.retrieveBody(postingId);
        postingBody.getNotifying().setValues(new NameValueList("responseCount", "+"));
        postingStore.updateBody(postingBody);

        return response.getId();
    }

    @Override
    public NotifyingResponse findResponse(String responseId) {
        //
        return responseStore.retrieve(responseId);
    }

    @Override
    public List<NotifyingResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        //
        return responseStore.retrieveByPosting(postingId, offset, limit);
    }

    @Override
    public List<NotifyingResponse> findResponsesByCheckedPosting(String postingId, int offset, int limit) {
        //
        return responseStore.retrieveByCheckedPosting(postingId, offset, limit);
    }

    @Override
    public void removeResponse(String responseId) {
        //
        NotifyingResponse response = responseStore.retrieve(responseId);
        responseStore.delete(response);
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        //
        responseStore.deleteByPosting(postingId);
    }
}
