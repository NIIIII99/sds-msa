package drama.board.domain.entity.category;

public class Category {
    //
    private String category;

}
