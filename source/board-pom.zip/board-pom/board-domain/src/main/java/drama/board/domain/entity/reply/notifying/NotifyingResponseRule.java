package drama.board.domain.entity.reply.notifying;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class NotifyingResponseRule implements ValueObject {
    //
    private boolean anonymous;
    private boolean withinTerm;

    public NotifyingResponseRule() {
        //
        this.anonymous = false;
        this.withinTerm = true;
    }

    public NotifyingResponseRule(boolean anonymous, boolean withinTerm) {
        //
        this.anonymous = anonymous;
        this.withinTerm = withinTerm;
    }

    public String toString() {
        //
        return toJson();
    }

    public static NotifyingResponseRule getSample() {
        //
        boolean anonymous = true;
        return new NotifyingResponseRule();
    }

    public static NotifyingResponseRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingResponseRule.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public boolean isWithinTerm() {
        return withinTerm;
    }

    public void setWithinTerm(boolean withinTerm) {
        this.withinTerm = withinTerm;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
