package drama.board.domain.entity.board.rule;

import drama.board.domain.entity.panel.option.NotifyingOption;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class NotifyingRule implements ValueObject {
    //
    private boolean anonymityAllowed;
    private boolean emailAllowed;           // default true
    private boolean smsAllowed;             // default false;
    private boolean responseListAllowed;

    public NotifyingRule(NotifyingOption option) {
        //
        this.emailAllowed = option.isEmailAllowed();
        this.smsAllowed = option.isSmsAllowed();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static NotifyingRule getSample() {
        //
        NotifyingOption notifyingOption = NotifyingOption.getSample();
        NotifyingRule sample = new NotifyingRule(notifyingOption);

        return sample;
    }

    public static NotifyingRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingRule.class);
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public boolean isResponseListAllowed() {
        return responseListAllowed;
    }

    public void setResponseListAllowed(boolean responseListAllowed) {
        this.responseListAllowed = responseListAllowed;
    }

    public boolean isEmailAllowed() {
        return emailAllowed;
    }

    public void setEmailAllowed(boolean emailAllowed) {
        this.emailAllowed = emailAllowed;
    }

    public boolean isSmsAllowed() {
        return smsAllowed;
    }

    public void setSmsAllowed(boolean smsAllowed) {
        this.smsAllowed = smsAllowed;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
