package drama.board.domain.spec.notifying.sdo;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.UUID;

public class NotifyingResponseCdo implements ValueObject {
    //
    private boolean anonymous;
    private String postingId;


    private NotifyingResponseCdo() {
        // Only for instantiate by reflection
    }

    public NotifyingResponseCdo(String postingId) {
        //
        this.anonymous = false;
        this.postingId = postingId;
    }

    public NotifyingResponseCdo(boolean anonymous, String postingId) {
        //
        this.anonymous = anonymous;
        this.postingId = postingId;
    }

    public static NotifyingResponseCdo getSample() {
        //
        String postingId = UUID.randomUUID().toString();

        return new NotifyingResponseCdo(postingId);
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static NotifyingResponseCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingResponseCdo.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
