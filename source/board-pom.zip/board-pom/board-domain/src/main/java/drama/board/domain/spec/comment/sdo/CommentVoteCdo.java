package drama.board.domain.spec.comment.sdo;

import drama.board.domain.entity.reply.comment.vote.VoteType;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class CommentVoteCdo implements ValueObject {
    //
    private boolean anonymous;
    private VoteType voteType;
    private boolean cancelled;

    public CommentVoteCdo() {
        //
    }

    public CommentVoteCdo(VoteType voteType) {
        //
        this.anonymous = false;
        this.voteType = voteType;
        this.cancelled = false;
    }

    public CommentVoteCdo(boolean anonymous,
                          VoteType voteType,
                          boolean cancelled) {
        //
        this.anonymous = anonymous;
        this.voteType = voteType;
        this.cancelled = cancelled;
    }

    public static CommentVoteCdo getSample() {
        //
        return new CommentVoteCdo(VoteType.UpVote);
    }

    public static CommentVoteCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentVoteCdo.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public VoteType getVoteType() {
        return voteType;
    }

    public void setVoteType(VoteType voteType) {
        this.voteType = voteType;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
