package drama.board.domain.entity.panel.share;

public enum BoardCategory {
    //
    Notice,
    BulletinBoard,
    FileSharing,
    Interaction
}
