package drama.board.domain.entity.reply.comment;

import nara.share.domain.Entity;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.annote.Derived;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

import java.util.List;
import java.util.UUID;

public class Comment extends Entity {
    //
    private String text;
    private String attachmentId;
    private Writer writer;      // anonymous is here !!
    private String writerPhotoId;

    @Derived
    private Long upVoteCount;
    @Derived
    private Long downVoteCount;

    private Long subCommentCount;

    private Long time;
    private Long updateTime;

    private SubCommentRule subCommentRule;

    private String postingId;

    transient private List<SubComment> subComments;

    public Comment() {
        //
    }

    public Comment(String id) {
        //
        super(id);
    }

    public Comment(Writer writer, String text, String postingId) {
        //
        super();
        this.writer = writer;
        this.text = text;
        this.upVoteCount = 0L;
        this.downVoteCount = 0L;
        this.subCommentCount = 0L;
        this.attachmentId = null;
        this.time = System.currentTimeMillis();
        this.subCommentRule = new SubCommentRule(false);
        this.postingId = postingId;
    }

    public static Comment getSample() {
        //
        Writer writer = Writer.getSample();
        String text = "It's a great idea. I agree with you.";
        String postingId = UUID.randomUUID().toString();

        Comment sample = new Comment(writer, text, postingId);
        sample.setDownVoteCount(20L);
        sample.setUpVoteCount(30L);
        sample.setValues(new NameValueList("subCommentCount", "+"));

        return sample;
    }

    public static Comment fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Comment.class);
    }

    public boolean setValues(NameValueList nameValues) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            if (value == null) continue;
            switch(nameValue.getName()) {
                case "text":
                    this.text = value;
                    updated = true; break;
                case "attachmentId":
                    this.attachmentId = value;
                    updated = true; break;
                case "subCommentCount":
                    this.subCommentCount = value.equals("+") ? ++subCommentCount : --subCommentCount;
                    updated = true; break;
                case "writerPhotoId":
                    this.writerPhotoId = value;
                    updated = true; break;
            }
        }

        if(updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public Writer getWriter() {
        return writer;
    }

    public void setWriter(Writer writer) {
        this.writer = writer;
    }

    public Long getUpVoteCount() {
        return upVoteCount;
    }

    public void setUpVoteCount(Long upVoteCount) {
        this.upVoteCount = upVoteCount;
    }

    public Long getDownVoteCount() {
        return downVoteCount;
    }

    public void setDownVoteCount(Long downVoteCount) {
        this.downVoteCount = downVoteCount;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public SubCommentRule getSubCommentRule() {
        return subCommentRule;
    }

    public void setSubCommentRule(SubCommentRule subCommentRule) {
        this.subCommentRule = subCommentRule;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getWriterPhotoId() {
        return writerPhotoId;
    }

    public void setWriterPhotoId(String writerPhotoId) {
        this.writerPhotoId = writerPhotoId;
    }

    public Long getSubCommentCount() {
        return subCommentCount;
    }

    public void setSubCommentCount(Long subCommentCount) {
        this.subCommentCount = subCommentCount;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
