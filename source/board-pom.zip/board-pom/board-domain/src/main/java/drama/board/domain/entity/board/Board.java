package drama.board.domain.entity.board;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.option.PostingOption;
import drama.board.domain.entity.posting.Posting;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.DramaAggregate;
import nara.share.domain.drama.Tenant;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Board extends DramaAggregate {
    //
	private String title;
	private long postingSequence;
    private String photoProfileId;
    private Actor admin;
    private List<String> tags;
    private Long time;
    private Long updateTime;
    private Long latestPostingTime;

    private PostingRule postingRule;
    private String panelId;

    transient private List<Posting> postings;   // for reference only

    public Board() {
		//
	}

	public Board(String id, Tenant tenant, DramaAccess access) {
		//
		super(id, tenant, access);
	}

	public Board(Tenant tenant,
                 DramaAccess access,
                 String title,
                 PostingRule postingRule,
                 String photoProfileId,
                 String panelId) {
        //
        super(tenant, access);
        this.title = title;
        this.postingSequence = 0L;
        this.postingRule = postingRule;
        this.photoProfileId = photoProfileId;
        this.admin = tenant.getActor();
        this.tags = new ArrayList<>();
        this.panelId = panelId;
        this.time = System.currentTimeMillis();
        this.latestPostingTime = time;
    }

    public static Board getSample() {
    	//
    	String title = "Java 고급 강좌 게시판";
        Tenant tenant = Tenant.getSample();
        DramaAccess access = DramaAccess.getSample();
        PostingRule option = PostingRule.getSample();
        String photoProfileId = UUID.randomUUID().toString();

        String panelId = BoardPanel.getSample().getId();

    	Board board = new Board(tenant, access, title, option, photoProfileId, panelId);
        board.setAdmin(tenant.getActor());
        board.setPostingRule(new PostingRule(PostingOption.getNormalBoardSample()));

    	return board;
    }

	public static Board fromJson(String json) {
		//
		return JsonUtil.fromJson(json, Board.class);
	}

    public boolean setValues(NameValueList nameValues) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "title":               this.title = value; updated = true; break;
                case "postingSequence":     this.postingSequence = Long.valueOf(value); updated = true; break;
                case "photoProfileId":      this.photoProfileId = value; updated = true; break;
                case "postingRule":         this.postingRule = PostingRule.fromJson(value); updated = true; break;
                case "admin":               this.admin = Actor.fromJson(value); updated = true; break;
                case "tags":                this.tags = JsonUtil.fromJsonList(value, String.class); updated = true; break;
                case "latestPostingTime":   this.latestPostingTime = Long.valueOf(value); updated = true; break;
            }
        }

        if (updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public Long nextPostingSequence() {
        //
        return ++postingSequence;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getPostingSequence() {
        return postingSequence;
    }

    public void setPostingSequence(long postingSequence) {
        this.postingSequence = postingSequence;
    }

    public PostingRule getPostingRule() {
        return postingRule;
    }

    public void setPostingRule(PostingRule postingRule) {
        this.postingRule = postingRule;
    }

    public String getPhotoProfileId() {
        return photoProfileId;
    }

    public void setPhotoProfileId(String photoProfileId) {
        this.photoProfileId = photoProfileId;
    }

    public Actor getAdmin() {
        return admin;
    }

    public void setAdmin(Actor admin) {
        this.admin = admin;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getPanelId() {
        return panelId;
    }

    public void setPanelId(String panelId) {
        this.panelId = panelId;
    }

    public Long getLatestPostingTime() {
        return latestPostingTime;
    }

    public void setLatestPostingTime(Long latestPostingTime) {
        this.latestPostingTime = latestPostingTime;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}
