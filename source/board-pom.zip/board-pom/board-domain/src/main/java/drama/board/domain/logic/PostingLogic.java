package drama.board.domain.logic;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.panel.option.CommentOption;
import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.posting.PostingReadLog;
import drama.board.domain.entity.posting.PostingState;
import drama.board.domain.entity.reply.comment.CommentRule;
import drama.board.domain.entity.reply.notifying.Notifying;
import drama.board.domain.entity.reply.survey.TinySurvey;
import drama.board.domain.entity.tagsearch.PostingTag;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.proxy.StageProxy;
import drama.board.domain.spec.posting.PostingService;
import drama.board.domain.spec.posting.sdo.NotifyingCdo;
import drama.board.domain.spec.posting.sdo.PostingCdo;
import drama.board.domain.spec.posting.sdo.TinySurveyCdo;
import drama.board.domain.store.BoardStore;
import drama.board.domain.store.BoardStoreLycler;
import drama.board.domain.store.PostingStore;
import drama.board.domain.store.PostingTagStore;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Tenant;
import nara.share.domain.drama.Writer;
import nara.stage.context.DramaContext;

import java.util.ArrayList;
import java.util.List;

public class PostingLogic implements PostingService {
    //
    private BoardStore boardStore;
    private PostingStore postingStore;
    private PostingTagStore postingTagStore;
    private StageProxy stageProxy;

    public PostingLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.boardStore = storeLycler.requestBoardStore();
        this.postingStore = storeLycler.requestPostingStore();
        this.postingTagStore = storeLycler.requestPostingTagStore();
        this.stageProxy = proxyLycler.requestStageProxy();
    }

    @Override
    public PostingBody registerPosting(PostingCdo postingCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();
        String boardId = postingCdo.getBoardId();
        Board board = boardStore.retrieve(boardId);
        long sequence = boardStore.nextPostingSequence(boardId);
        CommentOption commentOption = board.getPostingRule().getCommentOption();
        CommentRule commentRule = new CommentRule(commentOption);

        Writer writer = Writer.newWriter(tenant.getActor(), postingCdo.isAnonymous());

        PostingState state = new PostingState();
        state.setAnonymous(postingCdo.isAnonymous());
        if(postingCdo.getContent().getAttachmentId() != null) {
            state.setAttached(true);
        }

        Posting posting = new Posting(
            tenant,
            board.getAccess(),
            boardId,
            postingCdo.getTitle(),
            writer,
            sequence,
            commentRule
        );

        posting.setState(state);

        PostingBody postingBody = new PostingBody(
            posting.getId(),
            postingCdo.getContent()
        );

        NotifyingCdo notifyingCdo = postingCdo.getNotifyingCdo();
        if (notifyingCdo != null) {
            postingBody.setNotifying(new Notifying(
                notifyingCdo.getNotice(),
                notifyingCdo.getTargetCount(),
                notifyingCdo.getResponseRule()
            ));
            posting.getState().setNotified(true);
        } else if (postingCdo.getTinySurveyCdo() != null) {
            TinySurveyCdo surveyCdo = postingCdo.getTinySurveyCdo();
            postingBody.setSurvey(new TinySurvey(
                surveyCdo.getQuestion(),
                surveyCdo.getTargetCount(),
                surveyCdo.getTerm(),
                surveyCdo.getResponseRule()
            ));
            posting.getState().setSurveyed(true);
        }

        postingStore.create(posting);
        postingStore.createBody(postingBody);
        postingTagStore.create(PostingTag.newInstances(posting));

        return postingBody;
    }

    @Override
    public Posting findPosting(String postingId) {
        //
        return postingStore.retrieve(postingId);
    }

    @Override
    public PostingBody findPostingBody(String postingId) {
        //
        String audienceId = DramaContext.getStage().whoAmI().getAudienceId();

        PostingReadLog readLog = postingStore.retrieveReadLogByPostingAudience(postingId, audienceId);
        if (readLog == null) {
            readLog = new PostingReadLog(postingId, audienceId);
            postingStore.createReadLog(readLog);
            Posting posting = postingStore.retrieve(postingId);
            long readLogCount = postingStore.countReadLogByPosting(postingId);
            posting.setReadCount(readLogCount);
        }

        return postingStore.retrieveBody(postingId);
    }

    @Override
    public List<Posting> findPostingsLatest(String boardId, int offset, int limit) {
        //
        return postingStore.retrieveByBoardLatest(boardId, offset, limit);
    }

    @Override
    public List<Posting> findPostingsOldest(String boardId, int offset, int limit) {
        //
        return postingStore.retrieveByBoardOldest(boardId, offset, limit);
    }

    @Override
    public List<Posting> findPostingsByTag(String boardId, String tag, int offset, int limit) {
        //
        List<PostingTag> postingTags = postingTagStore.retrieveAllByTag(boardId, tag, offset, limit);
        List<String> ids = new ArrayList<>();
        for(int i=0; i<limit; i++) {
            ids.add(postingTags.get(i+offset).getPostingId());
        }

        List<Posting> postings = postingStore.retrieveByIds(ids);

        return postings;
    }

    @Override
    public void modifyPosting(String postingId, NameValueList nameValues) {
        //
        Posting posting = postingStore.retrieve(postingId);
        posting.setValues(nameValues);

        postingStore.update(posting);
    }

    @Override
    public void modifyPostingBody(String postingId, NameValueList nameValues) {
        //
        PostingBody postingBody = postingStore.retrieveBody(postingId);
        postingBody.setValues(nameValues);

        postingStore.updateBody(postingBody);
    }

    @Override
    public void removePosting(String postingId) {
        //
        Posting posting = postingStore.retrieve(postingId);
        PostingBody postingBody = postingStore.retrieveBody(postingId);

        // TODO notifying, survey도 지워야 함
        postingStore.deleteBody(postingBody);
        postingStore.delete(posting);
    }

    @Override
    public void removeAllPosting(String boardId) {
        //
        int limit = 100;
        int offset = 0;
        while(true) {
            List<Posting> postings = postingStore.retrieveByBoardOldest(boardId, offset, limit);
            if (postings.size() == 0) {
                break;
            }

            for(Posting posting : postings) {
                PostingBody postingBody = postingStore.retrieveBody(posting.getId());
                // TODO notifying, survey도 지워야 함
                postingStore.deleteBody(postingBody);
                postingStore.delete(posting);
            }
            offset += limit;
        }
    }
}
