package drama.board.domain.spec.comment.sdo;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class CommentCdo implements ValueObject {
    //
    private boolean anonymous;
    private String text;
    private String attachmentId;

    private CommentCdo() {
        // Only for instantiate by reflection
    }

    public CommentCdo(String text,
                      String attachmentId) {
        //
        this.anonymous = false;
        this.text = text;
        this.attachmentId = attachmentId;
    }

    public CommentCdo(boolean anonymous,
                      String text,
                      String attachmentId) {
        //
        this.anonymous = anonymous;
        this.text = text;
        this.attachmentId = attachmentId;
    }

    public CommentCdo(String text) {
        //
        this.anonymous = false;
        this.text = text;
        this.attachmentId = null;
    }

    public static CommentCdo getSample() {
        //
        String text = "I agree with you.";
        return new CommentCdo(text);
    }

    public static CommentCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentCdo.class);
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
