package drama.board.domain.entity.panel.option;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class SurveyOption implements ValueObject {
    //
    private boolean anonymityAllowed;
    private boolean openAllowed;


    public SurveyOption() {
        //
        this.anonymityAllowed = true;
        this.openAllowed = true;
    }

    public SurveyOption(boolean anonymityAllowed, boolean openAllowed) {
        //
        this.anonymityAllowed = anonymityAllowed;
        this.openAllowed = openAllowed;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static SurveyOption getSample() {
        //
        return new SurveyOption();
    }

    public static SurveyOption fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SurveyOption.class);
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public boolean isOpenAllowed() {
        return openAllowed;
    }

    public void setOpenAllowed(boolean openAllowed) {
        this.openAllowed = openAllowed;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
