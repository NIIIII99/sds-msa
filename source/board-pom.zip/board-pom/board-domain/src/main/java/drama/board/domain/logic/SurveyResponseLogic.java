package drama.board.domain.logic;

import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.reply.survey.SurveyResponse;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.proxy.StageProxy;
import drama.board.domain.spec.survey.SurveyResponseService;
import drama.board.domain.spec.survey.sdo.SurveyResponseCdo;
import drama.board.domain.store.BoardStoreLycler;
import drama.board.domain.store.PostingStore;
import drama.board.domain.store.SurveyResponseStore;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Actor;
import nara.share.domain.drama.Screen;
import nara.share.domain.drama.Writer;
import nara.share.exception.store.AlreadyExistsException;
import nara.stage.context.DramaContext;

import java.util.List;

public class SurveyResponseLogic implements SurveyResponseService {
    //
    private PostingStore postingStore;
    private SurveyResponseStore responseStore;
    private StageProxy stageProxy;

    public SurveyResponseLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.postingStore = storeLycler.requestPostingStore();
        this.responseStore = storeLycler.requestSurveyResponseStore();
        this.stageProxy = proxyLycler.requestStageProxy();
    }

    @Override
    public String registerResponse(SurveyResponseCdo responseCdo) {
        //
        String postingId = responseCdo.getPostingId();
        Actor actor = DramaContext.getStage().whoAmI();
        Screen screen = DramaContext.getStage().whereAmI();

        Writer respondent = Writer.newWriter(actor);

        SurveyResponse response = responseStore.retrieveByPostingPlayer(postingId, actor.getPlayerId());
        if(response != null) {
            throw new AlreadyExistsException("Already exist for: " + actor.getName());
        }

        response = SurveyResponse.newAsAnsweredResponse(postingId, respondent, responseCdo.getSelectedItemNos());
        responseStore.create(response);

        PostingBody postingBody = postingStore.retrieveBody(postingId);
        Long responseCount = responseStore.countByPostingAnswered(postingId);
        postingBody.getSurvey().setValues(new NameValueList("responseCount", String.valueOf(responseCount)));
        postingStore.updateBody(postingBody);

        return response.getId();
    }

    @Override
    public long buildFullResponsesForPosting(String postingId) {
        //
        return 0;
    }

    @Override
    public String markResponseAsAnswered(SurveyResponseCdo responseCdo) {
        //
        String postingId = responseCdo.getPostingId();
        Actor actor = DramaContext.getStage().whoAmI();

        SurveyResponse response = responseStore.retrieveByPostingPlayer(postingId, actor.getPlayerId());
        response.setSelectedItemNos(responseCdo.getSelectedItemNos());
        response.setUpdateTime(System.currentTimeMillis());

        responseStore.update(response);

        PostingBody postingBody = postingStore.retrieveBody(postingId);
        Long responseCount = responseStore.countByPostingAnswered(postingId);
        postingBody.getSurvey().setValues(new NameValueList("responseCount", String.valueOf(responseCount)));
        postingStore.updateBody(postingBody);

        return response.getId();
    }

    @Override
    public SurveyResponse findResponse(String responseId) {
        //
        return responseStore.retrieve(responseId);
    }

    @Override
    public List<SurveyResponse> findResponsesByPosting(String postingId, int offset, int limit) {
        //
        return responseStore.retrieveByPosting(postingId, offset, limit);
    }

    @Override
    public List<SurveyResponse> findResponsesByPostingAnswered(String postingId, int offset, int limit) {
        //
        return responseStore.retrieveByPostingAnswered(postingId, offset, limit);
    }

    @Override
    public void modifyResponse(String responseId, NameValueList nameValues) {
        //
        SurveyResponse response = responseStore.retrieve(responseId);
        response.setValues(nameValues);

        responseStore.update(response);
    }

    @Override
    public void removeResponse(String responseId) {
        //
        SurveyResponse response = responseStore.retrieve(responseId);
        responseStore.delete(response);
    }

    @Override
    public void removeAllResponsesByPosting(String postingId) {
        //
        responseStore.deleteByPosting(postingId);
    }
}
