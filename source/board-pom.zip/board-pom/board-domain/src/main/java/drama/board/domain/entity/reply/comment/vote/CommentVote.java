package drama.board.domain.entity.reply.comment.vote;

import drama.board.domain.entity.reply.comment.Comment;
import nara.share.domain.Entity;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

public class CommentVote extends Entity {
    //
    private Writer voter;
    private VoteType type;
    private Long time;
    private Long updateTime;

    private String commentId;

    public CommentVote() {
        //
    }

    public CommentVote(String id) {
        //
        super(id);
    }

    public CommentVote(Writer voter, String commentId, VoteType type) {
        //
        super();
        this.voter = voter;
        this.commentId = commentId;
        this.type = type;
        this.time = System.currentTimeMillis();
        this.updateTime = time;
    }

    public static CommentVote getSample() {
        //
        Writer voter = Writer.getSample();
        String commentId = Comment.getSample().getId();

        CommentVote sample = new CommentVote(voter, commentId, VoteType.UpVote);

        return sample;
    }

    public static CommentVote fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentVote.class);
    }

    public boolean setValues(NameValueList nameValues) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            if(value == null) continue;
            switch(nameValue.getName()) {
                case "type":
                    this.type = VoteType.valueOf(value);
                    updated = true; break;
            }
        }

        if(updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public Writer getVoter() {
        return voter;
    }

    public void setVoter(Writer voter) {
        this.voter = voter;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public VoteType getType() {
        return type;
    }

    public void setType(VoteType type) {
        this.type = type;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
