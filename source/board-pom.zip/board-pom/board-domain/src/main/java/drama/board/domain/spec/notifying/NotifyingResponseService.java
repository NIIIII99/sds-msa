package drama.board.domain.spec.notifying;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;
import drama.board.domain.spec.notifying.sdo.NotifyingResponseCdo;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
    name = "NotifyingResponse",
    editions = {"Professional", "Enterprise"},
    authorizedRoles = {"Admin", "User"}
)
public interface NotifyingResponseService {
    //
    String registerResponse(NotifyingResponseCdo responseCdo);
    long buildFullResponsesForPosting(String postingId);
    String markResponseAsChecked(NotifyingResponseCdo responseCdo);
    NotifyingResponse findResponse(String responseId);
    List<NotifyingResponse> findResponsesByPosting(String postingId, int offset, int limit);
    List<NotifyingResponse> findResponsesByCheckedPosting(String postingId, int offset, int limit);
    void removeResponse(String responseId);
    void removeAllResponsesByPosting(String postingId);
}
