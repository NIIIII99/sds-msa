package drama.board.domain.entity.panel.share;

public enum SizeUnit {
   KB,
   MB,
   GB
}
