package drama.board.domain.entity.reply.comment.vote;

public enum VoteType {
    //
    UpVote,             // Like, 공감
    DownVote            // Dislike, 비공감
}
