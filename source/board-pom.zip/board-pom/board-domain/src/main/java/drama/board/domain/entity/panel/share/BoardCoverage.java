package drama.board.domain.entity.panel.share;

public enum BoardCoverage {
    //
    PublicUser,
    TeamUser
}
