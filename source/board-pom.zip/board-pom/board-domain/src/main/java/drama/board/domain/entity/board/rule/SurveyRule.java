package drama.board.domain.entity.board.rule;

import drama.board.domain.entity.panel.option.SurveyOption;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class SurveyRule implements ValueObject {
    //
    private boolean anonymityAllowed;
    private boolean openAllowed;

    public SurveyRule() {
        //
    }

    public SurveyRule(SurveyOption option) {
        //
        this.anonymityAllowed = option.isAnonymityAllowed();
        this.openAllowed = option.isOpenAllowed();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static SurveyRule getSample() {
        //
        SurveyOption surveyOption = SurveyOption.getSample();
        return new SurveyRule(surveyOption);
    }

    public static SurveyRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SurveyRule.class);
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public boolean isOpenAllowed() {
        return openAllowed;
    }

    public void setOpenAllowed(boolean openAllowed) {
        this.openAllowed = openAllowed;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
