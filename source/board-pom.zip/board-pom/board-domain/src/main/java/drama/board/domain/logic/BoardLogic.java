package drama.board.domain.logic;

import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import drama.board.domain.entity.panel.BoardIntro;
import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.board.BoardService;
import drama.board.domain.spec.board.sdo.BoardCdo;
import drama.board.domain.store.BoardPanelStore;
import drama.board.domain.store.BoardStore;
import drama.board.domain.store.BoardStoreLycler;
import drama.board.domain.store.PostingStore;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.AccessScope;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.Tenant;
import nara.share.exception.IllegalRequestException;
import nara.stage.context.DramaContext;

import java.util.ArrayList;
import java.util.List;

public class BoardLogic implements BoardService {
    //
    private BoardPanelStore boardPanelStore;
    private BoardStore boardStore;
    private PostingStore postingStore;

    public BoardLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.boardPanelStore = storeLycler.requestBoardPanelStore();
        this.boardStore = storeLycler.requestBoardStore();
        this.postingStore = storeLycler.requestPostingStore();
    }

    @Override
    public String registerBoard(String panelId, BoardCdo boardCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();
        DramaAccess access = new DramaAccess(boardCdo.getScope());
        BoardPanel boardPanel = boardPanelStore.retrieve(panelId);
        PreSetting preSetting = boardPanel.requestPreSetting(boardCdo.getPreSettingTitle());
        if (preSetting == null) {
            throw new IllegalRequestException("No such a PreSetting: " + boardCdo.getPreSettingTitle());
        }
        PostingRule postingRule = new PostingRule(preSetting.getPostingOption());

        Board board = new Board(
            tenant,
            access,
            boardCdo.getTitle(),
            postingRule,
            boardCdo.getPhotoProfileId(),
            panelId);

        boardStore.create(board);

        BoardIntro boardIntro = new BoardIntro(board);
        if (access.getScope().isCineroomScope()) {
            boardPanel.getPrivateBoards().add(boardIntro);
        } else {
            boardPanel.getPublicBoards().add(boardIntro);
        }
        boardPanelStore.update(boardPanel);

        return board.getId();
    }

    @Override
    public Board findBoard(String boardId) {
        //
        return boardStore.retrieve(boardId);
    }

    @Override
    public List<Board> findBoards(String panelId) {
        //
        return boardStore.retrieveByPanel(panelId);
    }

    @Override
    public List<Board> findPublicBoards(String panelId) {
        //
        BoardPanel panel = boardPanelStore.retrieve(panelId);
        String pavilionId = panel.getTenant().getScreen().getPavilionId();
        String cineroomId = panel.getTenant().getScreen().getCineroomId();

        List<Board> boards = boardStore.retrieveByPavilionScope(pavilionId, AccessScope.Pavilion);
        List<Board> myPublicBoards = new ArrayList<>();

        for(Board board : boards) {
            DramaAccess access = board.getAccess();
            if(access.isAllowed(cineroomId)) {
                myPublicBoards.add(board);
            }
        }

        return myPublicBoards;
    }

    @Override
    public PostingRule findPostingRule(String boardId) {
        //
        Board board = boardStore.retrieve(boardId);
        return board.getPostingRule();
    }

    @Override
    public void modifyBoard(String boardId, NameValueList nameValues) {
        //
        Board board = boardStore.retrieve(boardId);
        board.setValues(nameValues);

        boardStore.update(board);

        BoardPanel boardPanel = boardPanelStore.retrieve(board.getPanelId());
//        bo
        // TODO Update intro
    }

    @Override
    public void removeBoard(String boardId) {
        //
        Board board = boardStore.retrieve(boardId);
        int postingCount = postingStore.countPostingsOfBoard(boardId);
        if (postingCount > 0) {
            throw new IllegalRequestException("Can't remove a board which has any postings. Remove all postings first.");
        }

        boardStore.delete(board);

        BoardPanel boardPanel = boardPanelStore.retrieve(board.getPanelId());
        boardPanel.getPrivateBoards().removeIf(boardIntro -> boardIntro.getId().equals(boardId));
        boardPanel.getPublicBoards().removeIf(boardIntro -> boardIntro.getId().equals(boardId));
        boardPanelStore.update(boardPanel);
    }

    @Override
    public void enforceRemoveBoard(String boardId) {
        //
        Board board = boardStore.retrieve(boardId);
        postingStore.deleteByBoard(boardId);

        boardStore.delete(board);
    }
}
