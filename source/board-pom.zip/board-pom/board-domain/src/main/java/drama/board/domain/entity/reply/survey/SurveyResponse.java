package drama.board.domain.entity.reply.survey;

import nara.share.domain.Entity;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class SurveyResponse extends Entity {
    //
    private List<String> selectedItemNos;
    private boolean answered;
    private Writer respondent;      // anonymous 가능
    private Long time;
    private Long updateTime;

    private String postingId;

    public SurveyResponse() {
        //
    }

    public SurveyResponse(String id) {
        //
        super(id);
    }

    private SurveyResponse(String postingId, Writer respondent, List<String> selectedItemNos) {
        //
        super();
        if(this.selectedItemNos == null) {
            this.selectedItemNos = new ArrayList<>();
        }
        this.selectedItemNos.addAll(selectedItemNos);
        if (selectedItemNos.size() > 0) {
            this.answered = true;
        } else {
            this.answered = false;
        }
        this.postingId = postingId;
        this.respondent = respondent;
        this.time = System.currentTimeMillis();
        this.updateTime = this.time;
    }

    private SurveyResponse(String postingId, Writer respondent) {
        //
        this(postingId, respondent, new ArrayList<String>());
    }

    public static SurveyResponse newAsAnsweredResponse(String postingId, Writer respondent, List<String> selectedItemNos) {
        //
        SurveyResponse response = new SurveyResponse(postingId, respondent, selectedItemNos);
        response.setTime(System.currentTimeMillis());
        response.setUpdateTime(System.currentTimeMillis());

        return response;
    }

    public static SurveyResponse newAsUnansweredResponse(String postingId, Writer respondent) {
        //
        SurveyResponse response = new SurveyResponse(postingId, respondent);

        return response;
    }

    public static SurveyResponse getSample() {
        //
        String postingId = UUID.randomUUID().toString();
        return getSample(postingId);
    }

    public static SurveyResponse getSample(String postingId) {
        //
        List<String> selectedItemNos = Arrays.asList("Yes");
        Writer respondent = Writer.getSample();

        SurveyResponse sample = new SurveyResponse(postingId, respondent, selectedItemNos);

        return sample;
    }

    public static SurveyResponse fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SurveyResponse.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            if (value == null) continue;
            switch(nameValue.getName()) {
                case "selectedItemNos":
                    this.selectedItemNos = JsonUtil.fromJsonList(value, String.class);
                    if(selectedItemNos != null && selectedItemNos.size() > 0) {
                        this.answered = true;
                        this.updateTime = System.currentTimeMillis();
                    }
                    break;
            }
        }
    }

    public Writer getRespondent() {
        return respondent;
    }

    public void setRespondent(Writer respondent) {
        this.respondent = respondent;
    }

    public List<String> getSelectedItemNos() {
        return selectedItemNos;
    }

    public void setSelectedItemNos(List<String> selectedItemNos) {
        this.selectedItemNos = selectedItemNos;
    }

    public boolean isAnswered() {
        return answered;
    }

    public void setAnswered(boolean answered) {
        this.answered = answered;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
