package drama.board.domain.spec.board;


import drama.board.domain.entity.board.Board;
import drama.board.domain.entity.board.PostingRule;
import drama.board.domain.spec.board.sdo.BoardCdo;
import nara.share.domain.NameValueList;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.AuthorizedRole;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
        name = "Board",
        editions = {"Community", "Professional", "Enterprise"},
        authorizedRoles = {"Admin", "User"}
        )
public interface BoardService {
    //
    @AuthorizedRole(roleNames = "Admin")
    String registerBoard(String panelId, BoardCdo boardCdo);

    Board findBoard(String boardId);
    List<Board> findBoards(String panelId);
    List<Board> findPublicBoards(String panelId);

    PostingRule findPostingRule(String boardId);

    @AuthorizedRole(roleNames = "Admin")
    void modifyBoard(String boardId, NameValueList nameValus);

    @AuthorizedRole(roleNames = "Admin")
    void removeBoard(String boardId);

    @AuthorizedRole(roleNames = "Admin")
    void enforceRemoveBoard(String boardId);
}
