package drama.board.domain.entity.reply.survey;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class QuestionItem implements ValueObject {
    //
    private String itemNo;          // "1", "A", 등 아무것이나, default "1"
    private String text;


    private QuestionItem() {
        // Only for instantiate by reflection
    }

    public QuestionItem(String itemNo, String text) {
        //
        this.itemNo = itemNo;
        this.text = text;
    }

    public String toString() {
        //
        return toJson();
    }

    public static List<QuestionItem> getSamples() {
        //
        List<QuestionItem> samples = new ArrayList<>();

        samples.add(new QuestionItem("1", "Facebook"));
        samples.add(new QuestionItem("2", "Google"));
        samples.add(new QuestionItem("3", "Apple"));

        return samples;
    }

    public static QuestionItem fromJson(String json) {
        //
        return JsonUtil.fromJson(json, QuestionItem.class);
    }

    public String getItemNo() {
        return itemNo;
    }

    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSamples());
    }
}
