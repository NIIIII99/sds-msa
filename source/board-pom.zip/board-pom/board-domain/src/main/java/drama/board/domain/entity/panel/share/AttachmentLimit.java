package drama.board.domain.entity.panel.share;


import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class AttachmentLimit implements ValueObject {
    //
    private int allowedSize;
    private SizeUnit unit;          // default MB

    public AttachmentLimit() {
        //
    }

    public AttachmentLimit(int allowedSize) {
        //
        this.allowedSize = allowedSize;
        this.unit = SizeUnit.MB;
    }

    public AttachmentLimit(int allowedSize, SizeUnit unit) {
        //
        this.allowedSize = allowedSize;
        this.unit = unit;
    }

    public AttachmentLimit(AttachmentLimit attachmentLimit) {
        //
        this.allowedSize = attachmentLimit.getAllowedSize();
        this.unit = attachmentLimit.getUnit();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static AttachmentLimit getSample() {
        //
        return new AttachmentLimit(10);
    }

    public static AttachmentLimit fromJson(String json) {
        //
        return JsonUtil.fromJson(json, AttachmentLimit.class);
    }

    public int getAllowedSize() {
        return allowedSize;
    }

    public void setAllowedSize(int allowedSize) {
        this.allowedSize = allowedSize;
    }

    public SizeUnit getUnit() {
        return unit;
    }

    public void setUnit(SizeUnit unit) {
        this.unit = unit;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
