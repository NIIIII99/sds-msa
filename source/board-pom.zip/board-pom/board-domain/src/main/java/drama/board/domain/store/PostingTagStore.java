package drama.board.domain.store;

import drama.board.domain.entity.tagsearch.PostingTag;

import java.util.List;

public interface PostingTagStore {
    //
    void create(PostingTag postingTag);
    void create(List<PostingTag> postingTags);
    PostingTag retrieve(String id);
    List<PostingTag> retrieveAllByTag(String boardId, String tag, int offset, int limit);
    List<PostingTag> retrieveAll(int offset, int limit);
    void delete(String id);
    void deleteAllByPosting(String postingId);
}
