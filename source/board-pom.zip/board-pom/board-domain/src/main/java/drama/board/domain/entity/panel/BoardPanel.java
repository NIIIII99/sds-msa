package drama.board.domain.entity.panel;

import drama.board.domain.entity.board.Board;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.DramaAggregate;
import nara.share.domain.drama.Tenant;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class BoardPanel extends DramaAggregate {
    //
    private String title;
    private List<BoardIntro> publicBoards;
    private List<BoardIntro> privateBoards;
    private boolean privateFirst;
    private List<PreSetting> preSettings;
    private Long time;
    private Long updateTime;

    transient private List<Board> boards;

    public BoardPanel() {
        //
    }

    public BoardPanel(String id, Tenant tenant, DramaAccess access) {
        //
        super(id, tenant, access);
    }

    public BoardPanel(Tenant tenant, String title, List<PreSetting> preSettings) {
        //
        super(tenant);              // always Cineroom scope
        this.title = title;
        this.publicBoards = new ArrayList<>();
        this.privateBoards = new ArrayList<>();
        this.privateFirst = false;
        this.preSettings = new ArrayList<>();
        if (preSettings != null && preSettings.size() > 0) {
            this.preSettings.addAll(preSettings);
        }
        this.time = System.currentTimeMillis();
        this.updateTime = time;
    }

    public String toString() {
        //
        return toJson();
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static BoardPanel getSample() {
        //
        Tenant tenant = Tenant.getSample();
        String title = "종합 게시판";
        List<PreSetting> preSettings = new ArrayList<>();
        preSettings.add(PreSetting.getNoticeBoardSample());

        BoardPanel sample = new BoardPanel(tenant, title, preSettings);

        return sample;
    }

    public boolean setValues(NameValueList nameValus) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValus.getList()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "title":
                    this.title = value;
                    updated = true;
                    break;
                case "publicBoards":
                    this.publicBoards = JsonUtil.fromJsonList(value, BoardIntro.class);
                    updated = true;
                    break;
                case "privateBoards":
                    this.privateBoards = JsonUtil.fromJsonList(value, BoardIntro.class);
                    updated = true;
                    break;
                case "privateFirst":
                    this.privateFirst = Boolean.valueOf(value);
                    updated = true;
                    break;
                case "preSettings":
                    this.preSettings = JsonUtil.fromJsonList(value, PreSetting.class);
                    updated = true;
                    break;
            }
        }

        if (updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public PreSetting requestPreSetting(String title) {
        //
        if (this.preSettings == null) {
            return null;
        }

        PreSetting foundSetting = null;
        for(PreSetting preSetting : this.preSettings) {
            if (preSetting.getTitle().equals(title)) {
                foundSetting = preSetting;
                break;
            }
        }

        return foundSetting;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<BoardIntro> getPublicBoards() {
        return publicBoards;
    }

    public void setPublicBoards(List<BoardIntro> publicBoards) {
        this.publicBoards = publicBoards;
    }

    public List<BoardIntro> getPrivateBoards() {
        return privateBoards;
    }

    public void setPrivateBoards(List<BoardIntro> privateBoards) {
        this.privateBoards = privateBoards;
    }

    public boolean isPrivateFirst() {
        return privateFirst;
    }

    public void setPrivateFirst(boolean privateFirst) {
        this.privateFirst = privateFirst;
    }

    public List<PreSetting> getPreSettings() {
        return preSettings;
    }

    public void setPreSettings(List<PreSetting> preSettings) {
        this.preSettings = preSettings;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
