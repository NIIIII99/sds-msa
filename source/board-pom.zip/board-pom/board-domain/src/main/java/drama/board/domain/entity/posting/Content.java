package drama.board.domain.entity.posting;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class Content implements ValueObject {
    //
    private String text;
    private ContentType type;
    private String attachmentId;        // 첨부파일도 컨텐트로 봐야 합니다.

    public Content() {
        //
    }

    public Content(String text) {
        //
        this(text, ContentType.PlainText, null);
    }

    public Content(String text, ContentType type) {
        //
        this(text, type, null);
    }

    public Content(String text, ContentType type, String attachmentId) {
        //
        this.text = text;
        this.type = type;
        this.attachmentId = attachmentId;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Content getSample() {
        //
        String text = "즐거운 하루를 체조로 시작합시다.";

        return new Content(text);
    }

    public static Content fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Content.class);
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public ContentType getType() {
        return type;
    }

    public void setType(ContentType type) {
        this.type = type;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
