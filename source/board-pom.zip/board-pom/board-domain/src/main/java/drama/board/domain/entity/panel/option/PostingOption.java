package drama.board.domain.entity.panel.option;

import drama.board.domain.entity.panel.share.AttachmentLimit;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class PostingOption implements ValueObject {
	//
    private boolean attachAllowed;          // 첨부 허용
    private boolean commentAllowed;         // 댓글 허용
    private boolean notifyingAllowed;       // 알림 허용
    private boolean surveyAllowed;          // 설문 허용
    private boolean anonymityAllowed;       // 익명 허용
    private AttachmentLimit attachmentLimit;

    private CommentOption commentOption;
    private NotifyingOption notifyingOption;
    private SurveyOption surveyOption;

    public PostingOption() {
		//
		this.attachAllowed = false;
		this.notifyingAllowed = false;
		this.surveyAllowed = false;
		this.anonymityAllowed = false;
		this.commentAllowed = false;
		this.attachmentLimit = null;

		this.commentOption = null;
		this.notifyingOption = null;
		this.surveyOption = null;
	}

    public static PostingOption newSettingsForNoticeBoard() {
        //
        return new PostingOption();
    }

    private static PostingOption newSettingsForNormalBoard() {
        //
        PostingOption postingOption = new PostingOption();
        postingOption.setAttachAllowed(true);
        postingOption.setAttachmentLimit(new AttachmentLimit(100));
        postingOption.setNotifyingAllowed(true);
        postingOption.setNotifyingOption(new NotifyingOption()); // email:default
        postingOption.setCommentAllowed(true);
        postingOption.setCommentOption(new CommentOption());
        postingOption.setSurveyAllowed(false);

        return postingOption;
    }

	@Override
	public String toString() {
		//
		return toJson();
	}

	public static PostingOption getNoticeBoardSample() {
        //
        return newSettingsForNoticeBoard();
    }

	public static PostingOption getNormalBoardSample() {
		//
		return newSettingsForNormalBoard();
	}

	public static PostingOption fromJson(String json) {
		//
		return JsonUtil.fromJson(json, PostingOption.class);
	}

    public boolean isAttachAllowed() {
        return attachAllowed;
    }

    public void setAttachAllowed(boolean attachAllowed) {
        this.attachAllowed = attachAllowed;
    }

    public boolean isNotifyingAllowed() {
        return notifyingAllowed;
    }

    public void setNotifyingAllowed(boolean notifyingAllowed) {
        this.notifyingAllowed = notifyingAllowed;
    }

    public boolean isSurveyAllowed() {
        return surveyAllowed;
    }

    public void setSurveyAllowed(boolean surveyAllowed) {
        this.surveyAllowed = surveyAllowed;
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public boolean isCommentAllowed() {
        return commentAllowed;
    }

    public void setCommentAllowed(boolean commentAllowed) {
        this.commentAllowed = commentAllowed;
    }

    public AttachmentLimit getAttachmentLimit() {
        return attachmentLimit;
    }

    public void setAttachmentLimit(AttachmentLimit attachmentLimit) {
        //
        if(attachmentLimit != null) {
            this.attachAllowed = true;
        }
        this.attachmentLimit = attachmentLimit;
    }

    public CommentOption getCommentOption() {
        return commentOption;
    }

    public void setCommentOption(CommentOption commentOption) {
        //
        if(commentOption != null) {
            this.commentAllowed = true;
        }
        this.commentOption = commentOption;
    }

    public NotifyingOption getNotifyingOption() {
        return notifyingOption;
    }

    public void setNotifyingOption(NotifyingOption notifyingOption) {
        //
        if(notifyingOption != null) {
            this.notifyingAllowed = true;
        }
        this.notifyingOption = notifyingOption;
    }

    public SurveyOption getSurveyOption() {
        return surveyOption;
    }

    public void setSurveyOption(SurveyOption surveyOption) {
        //
        if (surveyOption != null) {
            this.surveyAllowed = true;
        }
        this.surveyOption = surveyOption;
    }

    public static void main(String[] args) {
		//
		System.out.println(getNormalBoardSample());
	}
}
