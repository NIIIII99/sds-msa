package drama.board.domain.entity.posting;

import drama.board.domain.entity.reply.comment.CommentRule;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.annote.Derived;
import nara.share.domain.drama.DramaAccess;
import nara.share.domain.drama.DramaAggregate;
import nara.share.domain.drama.Tenant;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class Posting extends DramaAggregate {
    //
    private String title;
    private Writer writer;
    private long sequence;          // sequence in board

    @Derived
    private long readCount;         // just read count
	private Long time;
	private Long updateTime;

    private PostingState state;
    private CommentRule commentRule;
    private List<String> tags;

    private String boardId;

    transient private PostingBody body;

    public Posting() {
		//
	}

	public Posting(String id, Tenant tenant, DramaAccess access) {
		//
		super(id, tenant, access);
	}

	public Posting(Tenant tenant,
                   DramaAccess access,
                   String boardId,
                   String title,
                   Writer writer,
                   long sequence,
                   CommentRule commentRule) {
    	//
    	super(tenant, access);
    	this.boardId = boardId;
    	this.title = title;
    	this.writer = writer;
    	this.sequence = sequence;
    	this.readCount = 0L;
    	this.time = System.currentTimeMillis();
    	this.updateTime = System.currentTimeMillis();
    	this.commentRule = commentRule;
    	this.state = new PostingState();
    	this.tags = new ArrayList<>();
    }

    public static Posting getSample() {
    	//
        Tenant tenant = Tenant.getSample();
        DramaAccess access = DramaAccess.getSample();

        String boardId = UUID.randomUUID().toString();
        String title = "게시글 작성 안내";
        Writer writer = Writer.getSample();
    	long sequence = 12L;
    	CommentRule commentRule = CommentRule.getSample();

    	Posting sample = new Posting(tenant, access, boardId, title, writer, sequence, commentRule);
    	List<String> tags = Arrays.asList("global", "healthcare");
    	sample.getTags().addAll(tags);

    	return sample;
    }

	public void increaseReadCount() {
		//
		this.readCount++;
	}

    public static Posting fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Posting.class);
    }

    public boolean setValues(NameValueList nameValus) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValus.getList()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "title":
                    this.title = value;
                    updated = true;
                    break;
                case "sequence":
                    this.sequence = Long.valueOf(value);
                    updated = true;
                    break;
                case "state":
                    this.state = PostingState.fromJson(value);
                    updated = true;
                    break;
                case "commentRule":
                    this.commentRule = CommentRule.fromJson(value);
                    updated = true;
                    break;
                case "tags":
                    this.tags = JsonUtil.fromJsonList(value, String.class);
                    updated = true;
                    break;
            }
        }

        if(updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Writer getWriter() {
        return writer;
    }

    public void setWriter(Writer writer) {
        this.writer = writer;
    }

    public long getSequence() {
        return sequence;
    }

    public void setSequence(long sequence) {
        this.sequence = sequence;
    }

    public long getReadCount() {
        return readCount;
    }

    public void setReadCount(long readCount) {
        this.readCount = readCount;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }

    public PostingState getState() {
        return state;
    }

    public void setState(PostingState state) {
        this.state = state;
    }

    public PostingBody getBody() {
        return body;
    }

    public void setBody(PostingBody body) {
        this.body = body;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public CommentRule getCommentRule() {
        return commentRule;
    }

    public void setCommentRule(CommentRule commentRule) {
        this.commentRule = commentRule;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}
