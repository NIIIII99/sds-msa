package drama.board.domain.store;

import drama.board.domain.entity.reply.survey.SurveyResponse;

import java.util.List;
import java.util.NoSuchElementException;

public interface SurveyResponseStore {
    //
    void create(SurveyResponse notifyingResponse);
    void create(List<SurveyResponse> notifyingResponses);
    SurveyResponse retrieve(String id) throws NoSuchElementException;
    SurveyResponse retrieveByPostingPlayer(String postingId, String playerId);
    List<SurveyResponse> retrieveByPosting(String postingId, int offset, int limit);
    Long countByPosting(String postingId);
    List<SurveyResponse> retrieveByPostingAnswered(String postingId, int offset, int limit);
    Long countByPostingAnswered(String postingId);
    List<SurveyResponse> retrieveByPostingUnanswered(String postingId, int offset, int limit);
    Long countByPostingUnanswered(String postingId);

    // TODO ??
    // long countByReadCheckTime(String postingId);

    // TODO ??
    // long countByUnreadCheckTime(String postingId);
    void update(SurveyResponse notifyingResponse);
    void delete(SurveyResponse notifyingResponse);
    void deleteByPosting(String postingId);
}
