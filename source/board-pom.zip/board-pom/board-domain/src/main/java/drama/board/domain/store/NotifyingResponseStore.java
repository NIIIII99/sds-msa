package drama.board.domain.store;

import drama.board.domain.entity.reply.notifying.NotifyingResponse;

import java.util.List;
import java.util.NoSuchElementException;

public interface NotifyingResponseStore {
    //
    void create(NotifyingResponse notifyingResponse);
    void create(List<NotifyingResponse> notifyingResponses);
    NotifyingResponse retrieve(String id) throws NoSuchElementException;
    NotifyingResponse retrieveByPostingPlayer(String postingId, String playerId) throws NoSuchElementException;
    List<NotifyingResponse> retrieveByPosting(String postingId, int offset, int limit);
    long countByPosting(String postingId);
    List<NotifyingResponse> retrieveByCheckedPosting(String postingId, int offset, int limit);
    long countByPostingChecked(String postingId);
    List<NotifyingResponse> retrieveByUncheckedPosting(String postingId, int offset, int limit);
    long countByPostingUnchecked(String postingId);

    // TODO ??
    long countByReadCheckTime(String postingId);

    // TODO ??
    long countByUnreadCheckTime(String postingId);
    void update(NotifyingResponse notifyingResponse);
    void delete(NotifyingResponse notifyingResponse);
    void deleteByPosting(String postingId);
}
