package drama.board.domain.proxy;

public interface BoardProxyLycler {
    //
    StageProxy requestStageProxy();
}
