package drama.board.domain.spec.posting;


import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.spec.posting.sdo.PostingCdo;
import nara.share.domain.NameValueList;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.AuthorizedRole;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
        name = "Posting",
        editions = {"Community", "Professional", "Enterprise"},
        authorizedRoles = {"Admin", "User"}
        )
public interface PostingService {
    //
    PostingBody registerPosting(PostingCdo postingCdo);
    Posting findPosting(String postingId);
    PostingBody findPostingBody(String postingId);
    List<Posting> findPostingsLatest(String boardId, int offset, int limit);
    List<Posting> findPostingsOldest(String boardId, int offset, int limit);
    List<Posting> findPostingsByTag(String boardId, String tag, int offset, int limit);
    void modifyPosting(String postingId, NameValueList nameValues);
    void modifyPostingBody(String postingId, NameValueList nameValues);
    void removePosting(String postingId);

    @AuthorizedRole(roleNames = "Admin")
    void removeAllPosting(String boardId);
}
