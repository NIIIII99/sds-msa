package drama.board.domain.entity.reply.survey;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class SurveyResponseRule implements ValueObject {
    //
    private boolean anonymous;
    private boolean open;
    private boolean withinTerm;

    public SurveyResponseRule() {
        //
        this.anonymous = false;
        this.open = false;
        this.withinTerm = true;
    }

    public SurveyResponseRule(boolean anonymous, boolean open, boolean withinTerm) {
        //
        this.anonymous = anonymous;
        this.open = open;
        this.withinTerm = withinTerm;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SurveyResponseRule getSample() {
        //
        boolean anonymous = true;
        boolean open = false;
        boolean withinTerm = true;

        return new SurveyResponseRule(anonymous, open, withinTerm);
    }

    public static SurveyResponseRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SurveyResponseRule.class);
    }

    public boolean isWithinTerm() {
        return withinTerm;
    }

    public void setWithinTerm(boolean withinTerm) {
        this.withinTerm = withinTerm;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
