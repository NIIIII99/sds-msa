package drama.board.domain.entity.reply.comment;

import drama.board.domain.entity.panel.option.CommentOption;
import drama.board.domain.entity.panel.share.AttachmentLimit;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class CommentRule implements ValueObject {
    //
    private boolean anonymous;
    private boolean photoRequired;
    private boolean voteRequired;
    private boolean attachAllowed;
    private AttachmentLimit attachmentLimit;

    public CommentRule() {
        //
    }

    public CommentRule(CommentOption option) {
        //
        this.anonymous = option.isAnonymityAllowed();
        this.photoRequired = option.isPhotoAllowed();
        this.voteRequired = option.isVoteAllowed();
        this.attachAllowed = option.isAttachAllowed();
        this.attachmentLimit = option.getAttachmentLimit();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static CommentRule getSample() {
        //
        return new CommentRule();
    }

    public static CommentRule fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentRule.class);
    }

    public boolean isPhotoRequired() {
        return photoRequired;
    }

    public void setPhotoRequired(boolean photoRequired) {
        this.photoRequired = photoRequired;
    }

    public boolean isVoteRequired() {
        return voteRequired;
    }

    public void setVoteRequired(boolean voteRequired) {
        this.voteRequired = voteRequired;
    }

    public boolean isAttachAllowed() {
        return attachAllowed;
    }

    public void setAttachAllowed(boolean attachAllowed) {
        this.attachAllowed = attachAllowed;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public AttachmentLimit getAttachmentLimit() {
        return attachmentLimit;
    }

    public void setAttachmentLimit(AttachmentLimit attachmentLimit) {
        this.attachmentLimit = attachmentLimit;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
