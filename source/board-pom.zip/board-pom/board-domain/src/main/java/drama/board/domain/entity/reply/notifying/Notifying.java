package drama.board.domain.entity.reply.notifying;

import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.ValueObject;
import nara.share.domain.annote.Derived;
import nara.share.util.json.JsonUtil;

import java.util.List;

public class Notifying implements ValueObject {
    //
    private Notice notice;
    private Long targetCount;
    @Derived
    private Long responseCount;         // count by query
    private NotifyingResponseRule responseRule;

    transient private List<NotifyingResponse> responses;

    public Notifying() {
        //
    }

    public Notifying(long targetCount) {
        //
        this.targetCount = targetCount;
        this.responseCount = 0L;
        this.notice = new Notice();
        this.responseRule = new NotifyingResponseRule();
    }

    public Notifying(Notice notice, long targetCount, NotifyingResponseRule responseRule) {
        //
        this.notice = notice;
        this.targetCount = targetCount;
        this.responseCount = 0L;
        this.responseRule = responseRule;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Notifying getSample() {
        //
        int targetCount = 120;
        Notice notice = new Notice();
        NotifyingResponseRule responseRule = new NotifyingResponseRule();

        Notifying sample = new Notifying(notice, targetCount, responseRule);

        return sample;
    }

    public static Notifying fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Notifying.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            if (value == null) continue;
            switch(nameValue.getName()) {
                case "responseCount":
                    this.responseCount = Long.valueOf(value);
                    break;
                case "notice":      // term 조정가능
                    this.notice = Notice.fromJson(value);
                    break;
                case "responseRule":
                    this.responseRule = NotifyingResponseRule.fromJson(value);
                    break;
            }
        }
    }

    public Notice getNotice() {
        return notice;
    }

    public void setNotice(Notice notice) {
        this.notice = notice;
    }

    public Long getTargetCount() {
        return targetCount;
    }

    public void setTargetCount(Long targetCount) {
        this.targetCount = targetCount;
    }

    public Long getResponseCount() {
        return responseCount;
    }

    public void setResponseCount(Long responseCount) {
        this.responseCount = responseCount;
    }

    public NotifyingResponseRule getResponseRule() {
        return responseRule;
    }

    public void setResponseRule(NotifyingResponseRule responseRule) {
        this.responseRule = responseRule;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
