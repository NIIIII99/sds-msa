package drama.board.domain.store;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.entity.reply.comment.vote.CommentVote;
import drama.board.domain.entity.reply.comment.vote.VoteType;

import java.util.List;
import java.util.NoSuchElementException;

public interface CommentStore {
    //
    void create(Comment comment);
    Comment retrieve(String id) throws NoSuchElementException;
    List<Comment> retrieveByPosting(String postingId, int offset, int limit);
    List<Comment> retrieveByPlayer(String playerId, int offset, int limit);
    Long countByPosting(String postingId);
    Long countByPlayer(String playerId);
    void update(Comment comment);
    void delete(Comment comment);
    void deleteAllCommentAndSubCommentByPosting(String postingId);

    void createSubComment(SubComment subComment);
    SubComment retrieveSubComment(String id) throws NoSuchElementException;
    List<SubComment> retrieveSubCommentByComment(String commentId, int offset, int limit);
    Long countSubCommentByComment(String commentId);
    void updateSubComment(SubComment subComment);
    void deleteSubComment(SubComment subComment);
    void deleteAllSubCommentByComment(String commentId);

    void createVote(CommentVote commentVote);
    CommentVote retrieveVote(String id) throws NoSuchElementException;
    CommentVote retrieveVoteByCommentPlayer(String commentId, String voterPlayerId);
    List<CommentVote> retrieveVoteByComment(String commentId, int offset, int limit);
    Long countVoteByComment(String commentId, VoteType voteType);
    void updateVote(CommentVote commentVote);
    void deleteVote(CommentVote commentVote);
}
