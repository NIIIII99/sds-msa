package drama.board.domain.spec.comment;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.spec.comment.sdo.CommentCdo;
import drama.board.domain.spec.comment.sdo.CommentVoteCdo;
import drama.board.domain.spec.comment.sdo.SubCommentCdo;
import nara.share.domain.NameValueList;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
    name = "Comment",
    editions = {"Community", "Professional", "Enterprise"},
    authorizedRoles = {"Admin", "User"}
)
public interface CommentService {
    //
    String registerComment(String postingId, CommentCdo commentCdo);
    Comment findComment(String commentId);
    List<Comment> findCommentsByPosting(String postingId, int offset, int limit);
    List<Comment> findCommentsByPlayer(String playerId, int offset, int limit);
    long countCommentsByPlayer(String playerId);
    void modifyComment(String commentId, NameValueList nameValues);
    void removeComment(String commentId);
    void removeCommentsByPosting(String postingId);
    long countCommentsByPosting(String postingId);
    long addCommentVote(String commentId, CommentVoteCdo commentVoteCdo);

    String registerSubComment(String commentId, SubCommentCdo subCommentCdo);
    List<SubComment> findSubCommentsByComment(String commentId, int offset, int limit);
    long countSubCommentsByComment(String commentId);
    void updateSubComment(String subCommentId, NameValueList nameValues);
    void removeSubComment(String subCommentId);
    void removeSubCommentsByComment(String commentId);
}
