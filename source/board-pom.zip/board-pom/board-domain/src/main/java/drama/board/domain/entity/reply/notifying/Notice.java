package drama.board.domain.entity.reply.notifying;

import nara.share.domain.DatePair;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.time.LocalDate;

public class Notice implements ValueObject {
    //
    private Notiway notiway;
    private DatePair term;
    private String message;

    public Notice() {
        //
        this.notiway = Notiway.Email;
        this.term = new DatePair(LocalDate.now(), 10);
        this.message = "No message.";
    }

    public Notice(Notiway notiway, DatePair term, String message) {
        //
        this.notiway = notiway;
        this.term = term;
        this.message = message;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Notice getSample() {
        //
        Notiway notiway = Notiway.Email;
        DatePair term = DatePair.getSample();
        String message = "Check your board.";

        Notice sample = new Notice(notiway, term, message);

        return sample;
    }

    public static Notice fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Notice.class);
    }

    public Notiway getNotiway() {
        return notiway;
    }

    public void setNotiway(Notiway notiway) {
        this.notiway = notiway;
    }

    public DatePair getTerm() {
        return term;
    }

    public void setTerm(DatePair term) {
        this.term = term;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
