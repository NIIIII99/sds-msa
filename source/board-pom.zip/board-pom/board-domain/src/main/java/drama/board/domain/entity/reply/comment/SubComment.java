package drama.board.domain.entity.reply.comment;

import nara.share.domain.Entity;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

import java.util.UUID;

public class SubComment extends Entity {
    //
    private String text;
    private Writer writer;          // anonymous is here !!
    private Long time;

    private String commentId;
    private String postingId;

    public SubComment() {
        //
    }

    public SubComment(String id) {
        //
        super(id);
    }

    public SubComment(Writer writer, String text, Comment comment) {
        //
        super();
        this.writer = writer;
        this.text = text;
        this.time = System.currentTimeMillis();
        this.commentId = comment.getId();
        this.postingId = comment.getPostingId();
    }

    public static SubComment getSample() {
        //
        Writer writer = Writer.getSample();
        String text = "It's a great idea. I agree with you.";
        String replyId = UUID.randomUUID().toString();
        Comment comment = Comment.getSample();

        SubComment sample = new SubComment(writer, text, comment);

        return sample;
    }

    public static SubComment fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubComment.class);
    }

    public void setValues(NameValueList nameValuus) {
        //
        for(NameValue nameValue : nameValuus.getList()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "text":            this.text = value; break;
            }
        }
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Writer getWriter() {
        return writer;
    }

    public void setWriter(Writer writer) {
        this.writer = writer;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
