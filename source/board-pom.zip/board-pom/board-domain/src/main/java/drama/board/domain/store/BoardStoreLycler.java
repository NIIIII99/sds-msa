package drama.board.domain.store;

public interface BoardStoreLycler {
    //
    BoardPanelStore requestBoardPanelStore();
    BoardStore requestBoardStore();
    PostingStore requestPostingStore();
    NotifyingResponseStore requestNotifyingResponseStore();
    SurveyResponseStore requestSurveyResponseStore();
    CommentStore requestCommentStore();
    PostingTagStore requestPostingTagStore();
}
