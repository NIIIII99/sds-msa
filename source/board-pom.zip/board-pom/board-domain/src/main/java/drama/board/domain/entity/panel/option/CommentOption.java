package drama.board.domain.entity.panel.option;

import drama.board.domain.entity.panel.share.AttachmentLimit;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class CommentOption implements ValueObject {
    //
    private boolean anonymityAllowed;
    private boolean photoAllowed;
    private boolean voteAllowed;            // 공감
    private boolean attachAllowed;
    private AttachmentLimit attachmentLimit;

    public CommentOption() {
        //
        this.anonymityAllowed = false;
        this.photoAllowed = true;
        this.voteAllowed = true;
        this.attachAllowed = false;
        this.attachmentLimit = new AttachmentLimit(10);
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static CommentOption getSample() {
        //
        return new CommentOption();
    }

    public static CommentOption fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentOption.class);
    }

    public boolean isPhotoAllowed() {
        return photoAllowed;
    }

    public void setPhotoAllowed(boolean photoAllowed) {
        this.photoAllowed = photoAllowed;
    }

    public boolean isVoteAllowed() {
        return voteAllowed;
    }

    public void setVoteAllowed(boolean voteAllowed) {
        this.voteAllowed = voteAllowed;
    }

    public boolean isAttachAllowed() {
        return attachAllowed;
    }

    public void setAttachAllowed(boolean attachAllowed) {
        this.attachAllowed = attachAllowed;
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public AttachmentLimit getAttachmentLimit() {
        return attachmentLimit;
    }

    public void setAttachmentLimit(AttachmentLimit attachmentLimit) {
        this.attachmentLimit = attachmentLimit;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
