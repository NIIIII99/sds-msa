package drama.board.domain.entity.tagsearch;

import drama.board.domain.entity.posting.Posting;
import nara.share.domain.Entity;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class PostingTag extends Entity {
    //
    private String tag;
    private String postingId;
    private String boardId;

    public PostingTag() {
        //
    }

    public PostingTag(String id) {
        //
        super(id);
    }

    private PostingTag(String tag, String postingId, String boardId) {
        //
        super();
        this.tag = tag;
        this.postingId = postingId;
        this.boardId = boardId;
    }

    public static List<PostingTag> newInstances(Posting posting) {
        //
        List<PostingTag> postingTags = new ArrayList<>();
        List<String> tags = posting.getTags();
        for(String tag : tags) {
            postingTags.add(new PostingTag(tag, posting.getId(), posting.getBoardId()));
        }

        return postingTags;
    }

    public static List<PostingTag> getSample() {
        //
        Posting posting = Posting.getSample();
        return newInstances(posting);
    }

    public static PostingTag fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PostingTag.class);
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
