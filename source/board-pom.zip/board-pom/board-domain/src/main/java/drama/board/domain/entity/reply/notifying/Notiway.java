package drama.board.domain.entity.reply.notifying;

public enum Notiway {
    //
    Email,
    SMS,
    NaraTalk
}
