package drama.board.domain.entity.board;

import drama.board.domain.entity.panel.share.AttachmentLimit;
import drama.board.domain.entity.panel.option.CommentOption;
import drama.board.domain.entity.board.rule.NotifyingRule;
import drama.board.domain.entity.board.rule.SurveyRule;
import drama.board.domain.entity.panel.option.PostingOption;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class PostingRule implements ValueObject {
	//
    private boolean attachAllowed;          // 첨부 허용
    private boolean commentAllowed;         // 댓글 허용
    private boolean notifyingAllowed;       // 알림 허용
    private boolean surveyAllowed;          // 설문 허용
    private boolean anonymityAllowed;       // 익명 허용
    private AttachmentLimit attachmentLimit;

    private CommentOption commentOption;    // It's just option
    private NotifyingRule notifyingRule;
    private SurveyRule surveyRule;

 	public PostingRule(PostingOption option) {
        //
        this.attachAllowed = option.isAttachAllowed();
        this.notifyingAllowed = option.isNotifyingAllowed();
        this.surveyAllowed = option.isSurveyAllowed();
        this.anonymityAllowed = option.isAnonymityAllowed();
        this.commentAllowed = option.isCommentAllowed();
        this.attachmentLimit = option.getAttachmentLimit();

        this.commentOption = option.getCommentOption();
        if (option.getNotifyingOption() != null) {
            this.notifyingRule = new NotifyingRule(option.getNotifyingOption());
        }
        if (option.getSurveyOption() != null) {
            this.surveyRule = new SurveyRule(option.getSurveyOption());
        }
    }

    public static PostingRule newNoticeOptionSample() {
        //
        PostingOption postingOption = PostingOption.getNoticeBoardSample();
        return new PostingRule(postingOption);
    }

    private static PostingRule newBoardOptionSample() {
        //
        PostingOption postingOption = PostingOption.getNormalBoardSample();
        PostingRule postingRule = new PostingRule(postingOption);

        return postingRule;
    }

	@Override
	public String toString() {
		//
		return toJson();
	}

	public static PostingRule getSample() {
		//
		return newBoardOptionSample();
	}

	public static PostingRule fromJson(String json) {
		//
		return JsonUtil.fromJson(json, PostingRule.class);
	}

    public boolean isAttachAllowed() {
        return attachAllowed;
    }

    public void setAttachAllowed(boolean attachAllowed) {
        this.attachAllowed = attachAllowed;
    }

    public boolean isCommentAllowed() {
        return commentAllowed;
    }

    public void setCommentAllowed(boolean commentAllowed) {
        this.commentAllowed = commentAllowed;
    }

    public boolean isNotifyingAllowed() {
        return notifyingAllowed;
    }

    public void setNotifyingAllowed(boolean notifyingAllowed) {
        this.notifyingAllowed = notifyingAllowed;
    }

    public boolean isSurveyAllowed() {
        return surveyAllowed;
    }

    public void setSurveyAllowed(boolean surveyAllowed) {
        this.surveyAllowed = surveyAllowed;
    }

    public boolean isAnonymityAllowed() {
        return anonymityAllowed;
    }

    public void setAnonymityAllowed(boolean anonymityAllowed) {
        this.anonymityAllowed = anonymityAllowed;
    }

    public AttachmentLimit getAttachmentLimit() {
        return attachmentLimit;
    }

    public void setAttachmentLimit(AttachmentLimit attachmentLimit) {
        this.attachmentLimit = attachmentLimit;
    }

    public CommentOption getCommentOption() {
        return commentOption;
    }

    public void setCommentOption(CommentOption commentOption) {
        this.commentOption = commentOption;
    }

    public NotifyingRule getNotifyingRule() {
        return notifyingRule;
    }

    public void setNotifyingRule(NotifyingRule notifyingRule) {
        this.notifyingRule = notifyingRule;
    }

    public SurveyRule getSurveyRule() {
        return surveyRule;
    }

    public void setSurveyRule(SurveyRule surveyRule) {
        this.surveyRule = surveyRule;
    }

    public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}
