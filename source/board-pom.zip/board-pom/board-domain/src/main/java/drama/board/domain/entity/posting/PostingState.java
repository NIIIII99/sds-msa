package drama.board.domain.entity.posting;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class PostingState implements ValueObject {
    //
    private boolean anonymous;      // 익명임
    private boolean attached;       // 첨부있음
    private boolean notified;       // 통지했음
    private boolean surveyed;       // 설문포함

    public PostingState() {
        //
        this.anonymous = false;
        this.attached = false;
        this.surveyed = false;
        this.notified = false;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static PostingState getSample() {
        //
        PostingState sample = new PostingState();
        sample.setAttached(true);

        return sample;
    }

    public static PostingState fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PostingState.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public boolean isAttached() {
        return attached;
    }

    public void setAttached(boolean attached) {
        this.attached = attached;
    }

    public boolean isSurveyed() {
        return surveyed;
    }

    public void setSurveyed(boolean surveyed) {
        this.surveyed = surveyed;
    }

    public boolean isNotified() {
        return notified;
    }

    public void setNotified(boolean notified) {
        this.notified = notified;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
