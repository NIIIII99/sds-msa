package drama.board.domain.logic;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.comment.CommentRule;
import drama.board.domain.entity.reply.comment.SubComment;
import drama.board.domain.entity.reply.comment.vote.CommentVote;
import drama.board.domain.entity.reply.comment.vote.VoteType;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.proxy.StageProxy;
import drama.board.domain.spec.comment.CommentService;
import drama.board.domain.spec.comment.sdo.CommentCdo;
import drama.board.domain.spec.comment.sdo.CommentVoteCdo;
import drama.board.domain.spec.comment.sdo.SubCommentCdo;
import drama.board.domain.store.BoardStore;
import drama.board.domain.store.BoardStoreLycler;
import drama.board.domain.store.CommentStore;
import drama.board.domain.store.PostingStore;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Tenant;
import nara.share.domain.drama.Writer;
import nara.stage.context.DramaContext;

import java.util.List;

public class CommentLogic implements CommentService {
    //
    private BoardStore boardStore;
    private PostingStore postingStore;
    private CommentStore commentStore;
    private StageProxy stageProxy;

    public CommentLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.boardStore = storeLycler.requestBoardStore();
        this.postingStore = storeLycler.requestPostingStore();
        this.commentStore = storeLycler.requestCommentStore();
        this.stageProxy = proxyLycler.requestStageProxy();
    }

    @Override
    public String registerComment(String postingId, CommentCdo commentCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();
        Posting posting = postingStore.retrieve(postingId);
        CommentRule commentRule = posting.getCommentRule();
        Writer writer = Writer.newWriter(tenant.getActor(), commentCdo.isAnonymous());

        Comment comment = new Comment(writer, commentCdo.getText(), postingId);

        if(commentCdo.getAttachmentId() != null) {
            comment.setAttachmentId(commentCdo.getAttachmentId());
        }

        commentStore.create(comment);

        return comment.getId();
    }

    @Override
    public Comment findComment(String commentId) {
        //
        return commentStore.retrieve(commentId);
    }

    @Override
    public List<Comment> findCommentsByPosting(String postingId, int offset, int limit) {
        //
        return commentStore.retrieveByPosting(postingId, offset, limit);
    }

    @Override
    public List<Comment> findCommentsByPlayer(String playerId, int offset, int limit) {
        //
        return commentStore.retrieveByPlayer(playerId, offset, limit);
    }

    @Override
    public long countCommentsByPlayer(String playerId) {
        //
        return commentStore.countByPlayer(playerId);
    }

    @Override
    public void modifyComment(String commentId, NameValueList nameValues) {
        //
        Comment comment = commentStore.retrieve(commentId);
        if(comment.setValues(nameValues)) {
            commentStore.update(comment);
        }
    }

    @Override
    public void removeComment(String commentId) {
        //
        Comment comment = commentStore.retrieve(commentId);
        commentStore.deleteAllSubCommentByComment(commentId);
        commentStore.delete(comment);
    }

    @Override
    public void removeCommentsByPosting(String postingId) {
        //
        commentStore.deleteAllCommentAndSubCommentByPosting(postingId);
    }

    @Override
    public long countCommentsByPosting(String postingId) {
        //
        return commentStore.countByPosting(postingId);
    }

    @Override
    public long addCommentVote(String commentId, CommentVoteCdo commentVoteCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();
        Comment comment = commentStore.retrieve(commentId);
        Writer voter = Writer.newWriter(tenant.getActor(), commentVoteCdo.isAnonymous());
        CommentVote commentVote = commentStore.retrieveVoteByCommentPlayer(commentId, voter.getPlayerId());

        VoteType newVoteType = commentVoteCdo.getVoteType();
        if (commentVote == null) {
            // new vote
            if(commentVoteCdo.isCancelled()) {
                // do nothing
                return newVoteType.equals(VoteType.UpVote) ? comment.getUpVoteCount() : comment.getDownVoteCount();
            } else {
                commentVote = new CommentVote(voter, commentId, newVoteType);
                commentStore.createVote(commentVote);
            }
        } else {
            if(commentVoteCdo.isCancelled()) {
                commentStore.deleteVote(commentVote);
            } else {
                if(!commentVote.getType().equals(newVoteType)) {
                    commentVote.setValues(new NameValueList("type", newVoteType.name()));
                    commentStore.updateVote(commentVote);
                } else {
                    // do nothing
                    return newVoteType.equals(VoteType.UpVote) ? comment.getUpVoteCount() : comment.getDownVoteCount();
                }
            }
        }

        Long upVoteCount = commentStore.countVoteByComment(commentId, VoteType.UpVote);
        Long downVoteCount = commentStore.countVoteByComment(commentId, VoteType.DownVote);
        comment.setUpVoteCount(upVoteCount);
        comment.setDownVoteCount(downVoteCount);
        commentStore.update(comment);

        return newVoteType.equals(VoteType.UpVote) ? comment.getUpVoteCount() : comment.getDownVoteCount();
    }

    @Override
    public String registerSubComment(String commentId, SubCommentCdo subCommentCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();
        Comment comment = commentStore.retrieve(commentId);
        Writer writer = Writer.newWriter(tenant.getActor(), comment.getSubCommentRule().isAnonymous());

        SubComment subComment = new SubComment(writer, subCommentCdo.getText(), comment);
        commentStore.createSubComment(subComment);
        comment.setValues(new NameValueList("subCommentCount", "+"));
        commentStore.update(comment);

        return subComment.getId();
    }

    @Override
    public List<SubComment> findSubCommentsByComment(String commentId, int offset, int limit) {
        //
        return commentStore.retrieveSubCommentByComment(commentId, offset, limit);
    }

    @Override
    public long countSubCommentsByComment(String commentId) {
        //
        return commentStore.countSubCommentByComment(commentId);
    }

    @Override
    public void updateSubComment(String subCommentId, NameValueList nameValues) {
        //
        SubComment subComment = commentStore.retrieveSubComment(subCommentId);
        subComment.setValues(nameValues);

        commentStore.updateSubComment(subComment);
    }

    @Override
    public void removeSubComment(String subCommentId) {
        //
        SubComment subComment = commentStore.retrieveSubComment(subCommentId);
        Comment comment = commentStore.retrieve(subComment.getCommentId());
        comment.setValues(new NameValueList("subCommentCount", "-"));
        commentStore.update(comment);

        commentStore.deleteSubComment(subComment);
    }

    @Override
    public void removeSubCommentsByComment(String commentId) {
        //
        commentStore.deleteAllSubCommentByComment(commentId);
        Comment comment = commentStore.retrieve(commentId);
        comment.setSubCommentCount(0L);
        commentStore.update(comment);
    }
}
