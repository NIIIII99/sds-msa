package drama.board.domain.spec.panel.sdo;

import drama.board.domain.entity.panel.PreSetting;
import nara.share.domain.ValueObject;
import nara.share.domain.drama.AccessScope;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class BoardPanelCdo implements ValueObject {
    //
    private AccessScope accessScope;
    private String title;
    private List<PreSetting> preSettings;

    public BoardPanelCdo() {
        //
    }

    public BoardPanelCdo(String title, List<PreSetting> preSettings) {
        //
        this.title = title;
        this.preSettings = preSettings;
    }

    public static BoardPanelCdo getSample() {
        //
        String title = "TeamUser boards panel";
        List<PreSetting> preSettings = new ArrayList<>();
        preSettings.add(PreSetting.getNoticeBoardSample());

        BoardPanelCdo sample = new BoardPanelCdo(title, preSettings);

        return sample;
    }

    public static BoardPanelCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, BoardPanelCdo.class);
    }

    public boolean hasPreSettings() {
        //
        if (this.preSettings != null && this.preSettings.size() > 0) {
            return true;
        }

        return false;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<PreSetting> getPreSettings() {
        return preSettings;
    }

    public void setPreSettings(List<PreSetting> preSettings) {
        this.preSettings = preSettings;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
