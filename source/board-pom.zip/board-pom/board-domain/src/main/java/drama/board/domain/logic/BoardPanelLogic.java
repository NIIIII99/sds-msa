package drama.board.domain.logic;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.proxy.BoardProxyLycler;
import drama.board.domain.spec.panel.BoardPanelService;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import drama.board.domain.store.BoardPanelStore;
import drama.board.domain.store.BoardStore;
import drama.board.domain.store.BoardStoreLycler;
import nara.share.domain.NameValueList;
import nara.share.domain.drama.Tenant;
import nara.share.exception.IllegalRequestException;
import nara.stage.context.DramaContext;

import java.util.ArrayList;
import java.util.List;

public class BoardPanelLogic implements BoardPanelService {
    //
    private BoardPanelStore boardPanelStore;
    private BoardStore boardStore;

    public BoardPanelLogic(BoardProxyLycler proxyLycler, BoardStoreLycler storeLycler) {
        //
        this.boardStore = storeLycler.requestBoardStore();
        this.boardPanelStore = storeLycler.requestBoardPanelStore();
    }

    @Override
    public BoardPanel buildBoardPanel(BoardPanelCdo boardPanelCdo) {
        //
        Tenant tenant = DramaContext.getStage().requestTenant();

        if (!boardPanelCdo.hasPreSettings()) {
            List<PreSetting> preSettings = new ArrayList<>();
            preSettings.add(PreSetting.getNoticeBoardSample());
            preSettings.add(PreSetting.getNormalBoardSample());
            boardPanelCdo.setPreSettings(preSettings);
        }

        BoardPanel boardPanel = new BoardPanel(
            tenant,
            boardPanelCdo.getTitle(),
            boardPanelCdo.getPreSettings()
        );

        boardPanelStore.create(boardPanel);

        return boardPanel;
    }

    @Override
    public BoardPanel findBoardPanel(String panelId) {
        //
        return boardPanelStore.retrieve(panelId);
    }

    @Override
    public List<PreSetting> findPreSettings(String panelId) {
        //
        BoardPanel boardPanel = boardPanelStore.retrieve(panelId);

        return boardPanel.getPreSettings();
    }

    @Override
    public PreSetting findPreSetting(String panelId, String title) {
        //
        BoardPanel boardPanel = boardPanelStore.retrieve(panelId);

        PreSetting foundPreSetting = null;
        for(PreSetting preSetting : boardPanel.getPreSettings()) {
            if (preSetting.getTitle().equals(title)) {
                foundPreSetting = preSetting;
                break;
            }
        }

        return foundPreSetting;
    }

    @Override
    public void modifyBoardPanel(String panelId, NameValueList nameValues) {
        //
        BoardPanel boardPanel = boardPanelStore.retrieve(panelId);
        boardPanel.setValues(nameValues);

        boardPanelStore.update(boardPanel);
    }

    @Override
    public void removeBoardPanel(String panelId) {
        //
        BoardPanel boardPanel = boardPanelStore.retrieve(panelId);
        long boardCount = boardStore.countByPanel(panelId);
        if (boardCount != 0) {
            throw new IllegalRequestException("Remove all the boards first.");
        }

        boardPanelStore.delete(boardPanel);
    }
}
