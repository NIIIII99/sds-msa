package drama.board.domain.spec.survey.sdo;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class SurveyResponseCdo implements ValueObject {
    //
    private List<String> selectedItemNos;
    private boolean anonymous;
    private String postingId;


    private SurveyResponseCdo() {
        // Only for instantiate by reflection
    }

    public SurveyResponseCdo(String postingId, List<String> selectedItemNos) {
        //
        this.selectedItemNos = selectedItemNos;
        this.anonymous = false;
        this.postingId = postingId;
    }

    public SurveyResponseCdo(boolean anonymous, String postingId, List<String> selectedItemNos) {
        //
        this.selectedItemNos = selectedItemNos;
        this.anonymous = anonymous;
        this.postingId = postingId;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SurveyResponseCdo getSample() {
        //
        String postingId = UUID.randomUUID().toString();
        List<String> selectedItemNos = Arrays.asList("Yes");

        return new SurveyResponseCdo(postingId, selectedItemNos);
    }

    public static SurveyResponseCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SurveyResponseCdo.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public List<String> getSelectedItemNos() {
        return selectedItemNos;
    }

    public void setSelectedItemNos(List<String> selectedItemNos) {
        this.selectedItemNos = selectedItemNos;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
