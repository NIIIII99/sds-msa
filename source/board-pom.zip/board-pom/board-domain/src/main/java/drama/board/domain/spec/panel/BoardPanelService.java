package drama.board.domain.spec.panel;

import drama.board.domain.entity.panel.BoardPanel;
import drama.board.domain.entity.panel.PreSetting;
import drama.board.domain.spec.panel.sdo.BoardPanelCdo;
import nara.share.domain.NameValueList;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.AuthorizedRole;
import nara.stage.domain.entity.dramarepo.dramaspec.annotation.ServiceFeature;

import java.util.List;

@ServiceFeature(
    name = "BoardPanel",
    editions = {"Community", "Professional", "Enterprise"},
    authorizedRoles = {"Admin", "User"}
)
public interface BoardPanelService {
    //
    @AuthorizedRole(roleNames = "Admin")
    BoardPanel buildBoardPanel(BoardPanelCdo boardPanelCdo);

    BoardPanel findBoardPanel(String panelId);

    @AuthorizedRole(roleNames = "Admin")
    List<PreSetting> findPreSettings(String panelId);

    PreSetting findPreSetting(String panelId, String title);

    @AuthorizedRole(roleNames = "Admin")
    void modifyBoardPanel(String panelId, NameValueList nameValues);

    @AuthorizedRole(roleNames = "Admin")
    void removeBoardPanel(String panelId);
}
