package drama.board.domain.proxy;

public interface StageProxy {
    //
    long countPlayers(String cineroomId);
    long countAudiences(String pavilionId);
}
