package drama.board.domain.spec.board.sdo;

import drama.board.domain.entity.panel.PreSetting;
import nara.share.domain.ValueObject;
import nara.share.domain.drama.AccessScope;
import nara.share.util.json.JsonUtil;

import java.util.UUID;

public class BoardCdo implements ValueObject {
    //
    private AccessScope scope;          // default cineroom
    private String title;
    private String preSettingTitle;
    private String photoProfileId;

    private BoardCdo() {
        // Only for instantiate by reflection
    }

    public BoardCdo(AccessScope scope,
                    String title,
                    String preSettingTitle,
                    String photoProfileId) {
        //
        this.scope = scope;
        this.title = title;
        this.preSettingTitle = preSettingTitle;
        this.photoProfileId = photoProfileId;
    }

    public String toString() {
        //
        return toJson();
    }

    public static BoardCdo getSample() {
        //
        AccessScope scope = AccessScope.Pavilion;
        String title = "Project A TeamUser Baord";
        String preSettingTitle = PreSetting.getNoticeBoardSample().getTitle();
        String photoProfileId = UUID.randomUUID().toString();

        BoardCdo sample = new BoardCdo(scope, title, preSettingTitle, photoProfileId);

        return sample;
    }

    public static BoardCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, BoardCdo.class);
    }

    public AccessScope getScope() {
        return scope;
    }

    public void setScope(AccessScope scope) {
        this.scope = scope;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPreSettingTitle() {
        return preSettingTitle;
    }

    public void setPreSettingTitle(String preSettingTitle) {
        this.preSettingTitle = preSettingTitle;
    }

    public String getPhotoProfileId() {
        return photoProfileId;
    }

    public void setPhotoProfileId(String photoProfileId) {
        this.photoProfileId = photoProfileId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
