package drama.board.domain.entity.posting;

import drama.board.domain.entity.reply.comment.Comment;
import drama.board.domain.entity.reply.notifying.Notifying;
import drama.board.domain.entity.reply.survey.TinySurvey;
import nara.share.domain.Entity;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.util.json.JsonUtil;

import java.util.List;

public class PostingBody extends Entity {
    //
    private Content content;
    private Long updateTime;

    private Notifying notifying;
    private TinySurvey survey;

    transient private List<Comment> comments;

    public PostingBody() {
        //
    }

    public PostingBody(String id) {
        //
        super(id);
    }

    public PostingBody(String postingId, Content content) {
        //
        super(postingId);
        this.content = content;
        this.updateTime = System.currentTimeMillis();
    }

    public static PostingBody getSample() {
        //
        String postingId = Posting.getSample().getId();
        Content content = Content.getSample();
        PostingBody sample = new PostingBody(postingId, content);

        return sample;
    }

    public static PostingBody getSample(String postingId) {
        //
        Content content = Content.getSample();
        PostingBody sample = new PostingBody(postingId, content);

        return sample;
    }

    public static PostingBody fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PostingBody.class);
    }

    public boolean setValues(NameValueList nameValues) {
        //
        boolean updated = false;
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "content":
                    this.content = Content.fromJson(value);
                    updated = true;
                    break;
            }
        }

        if(updated) {
            this.updateTime = System.currentTimeMillis();
        }

        return updated;
    }

    public Notifying getNotifying() {
        return notifying;
    }

    public void setNotifying(Notifying notifying) {
        this.notifying = notifying;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public TinySurvey getSurvey() {
        return survey;
    }

    public void setSurvey(TinySurvey survey) {
        this.survey = survey;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
