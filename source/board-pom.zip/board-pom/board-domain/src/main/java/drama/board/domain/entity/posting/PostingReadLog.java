package drama.board.domain.entity.posting;

import nara.share.domain.Entity;
import nara.share.domain.drama.Actor;
import nara.share.util.json.JsonUtil;

import java.util.UUID;

public class PostingReadLog extends Entity {
    //
    private String postingId;
    private String audienceId;
    private Long time;

    public PostingReadLog() {
        //
    }

    public PostingReadLog(String id) {
        //
        super(id);
    }

    public PostingReadLog(String postingId,String audienceId) {
        //
        this.postingId = postingId;
        this.audienceId = audienceId;
        this.time = System.currentTimeMillis();
    }

    public static PostingReadLog getSample() {
        //
        String postingId = UUID.randomUUID().toString();
        String audienceId = Actor.getSample().getAudienceId();

        PostingReadLog sample = new PostingReadLog(postingId, audienceId);

        return sample;
    }

    public static PostingReadLog fromJson(String json) {
        //
        return JsonUtil.fromJson(json, PostingReadLog.class);
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getAudienceId() {
        return audienceId;
    }

    public void setAudienceId(String audienceId) {
        this.audienceId = audienceId;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
