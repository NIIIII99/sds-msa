package drama.board.domain.spec.posting.sdo;

import drama.board.domain.entity.reply.survey.Question;
import drama.board.domain.entity.reply.survey.SurveyResponseRule;
import nara.share.domain.DatePair;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class TinySurveyCdo implements ValueObject {
    //
    private Question question;
    private Long targetCount;
    private DatePair term;
    private SurveyResponseRule responseRule;

    public TinySurveyCdo() {
        //
    }

    public TinySurveyCdo(Question question, Long targetCount, DatePair term, SurveyResponseRule responseRule) {
        //
        this.question = question;
        this.term = term;
        this.targetCount = targetCount;
        this.responseRule = responseRule;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TinySurveyCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TinySurveyCdo.class);
    }

    public static TinySurveyCdo getSample() {
        //
        Question question = Question.getSample();
        Long targetCount = 40L;
        DatePair term = DatePair.getSample();
        SurveyResponseRule responseRule = SurveyResponseRule.getSample();

        TinySurveyCdo sample = new TinySurveyCdo(question, targetCount, term, responseRule);

        return sample;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public Long getTargetCount() {
        return targetCount;
    }

    public void setTargetCount(Long targetCount) {
        this.targetCount = targetCount;
    }

    public DatePair getTerm() {
        return term;
    }

    public void setTerm(DatePair term) {
        this.term = term;
    }

    public SurveyResponseRule getResponseRule() {
        return responseRule;
    }

    public void setResponseRule(SurveyResponseRule responseRule) {
        this.responseRule = responseRule;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
