package drama.board.domain.entity.panel;

import drama.board.domain.entity.board.Board;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BoardIntro implements ValueObject {
    //
    private String id;
    private String title;
    private String profilePhotoId;
    private List<String> latestPostings;
    private Long latestUpdateTime;

    public BoardIntro() {
        //
    }

    public BoardIntro(Board board) {
        //
        this.id = board.getId();
        this.title = board.getTitle();
        this.profilePhotoId = board.getPhotoProfileId();
        this.latestPostings = new ArrayList<>();            // FixMe
        this.latestUpdateTime = board.getLatestPostingTime();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static BoardIntro getSample() {
        //
        Board board = Board.getSample();
        BoardIntro sample = new BoardIntro(board);

        return sample;
    }

    public static BoardIntro fromJson(String json) {
        //
        return JsonUtil.fromJson(json, BoardIntro.class);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProfilePhotoId() {
        return profilePhotoId;
    }

    public void setProfilePhotoId(String profilePhotoId) {
        this.profilePhotoId = profilePhotoId;
    }

    public List<String> getLatestPostings() {
        return latestPostings;
    }

    public void setLatestPostings(List<String> latestPostings) {
        this.latestPostings = latestPostings;
    }

    public Long getLatestUpdateTime() {
        return latestUpdateTime;
    }

    public void setLatestUpdateTime(Long latestUpdateTime) {
        this.latestUpdateTime = latestUpdateTime;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
