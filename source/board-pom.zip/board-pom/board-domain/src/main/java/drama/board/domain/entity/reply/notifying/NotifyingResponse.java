package drama.board.domain.entity.reply.notifying;

import drama.board.domain.entity.posting.Posting;
import nara.share.domain.Entity;
import nara.share.domain.drama.Writer;
import nara.share.util.json.JsonUtil;

public class NotifyingResponse extends Entity {
    // "확인" 버튼을 클릭해야 생성함
    //
    private Writer respondent;
    private boolean checked;
    private Long checkTime;
    private String postingId;

    public NotifyingResponse() {
        //
    }

    public NotifyingResponse(String id) {
        //
        super(id);
    }

    private NotifyingResponse(String postingId, Writer respondent) {
        //
        super();
        this.postingId = postingId;
        this.respondent = respondent;
        this.checked = false;
        this.checkTime = 0L;
    }

    public static NotifyingResponse newAsCheckedResponse(String postingId, Writer respondent) {
        //
        NotifyingResponse response = new NotifyingResponse(postingId, respondent);
        response.setChecked(true);
        response.setCheckTime(System.currentTimeMillis());

        return response;
    }

    public static NotifyingResponse newAsUncheckedResponse(String postingId, Writer respondent) {
        //
        NotifyingResponse response = new NotifyingResponse(postingId, respondent);
        response.setChecked(false);
        response.setCheckTime(0L);

        return response;
    }

    public static NotifyingResponse getSample() {
        //
        String postingId = Posting.getSample().getId();
        return getSample(postingId);
    }

    public static NotifyingResponse getSample(String postingId) {
        //
        Writer respondent = Writer.getSample();
        NotifyingResponse sample = newAsCheckedResponse(postingId, respondent);
        sample.markAsRead();

        return sample;
    }

    public static NotifyingResponse fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingResponse.class);
    }

    public void markAsRead() {
        //
        this.checked = true;
        this.checkTime = System.currentTimeMillis();
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public Writer getRespondent() {
        return respondent;
    }

    public void setRespondent(Writer respondent) {
        this.respondent = respondent;
    }

    public Long getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Long checkTime) {
        this.checkTime = checkTime;
    }

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
