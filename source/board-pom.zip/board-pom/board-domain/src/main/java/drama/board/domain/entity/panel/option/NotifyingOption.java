package drama.board.domain.entity.panel.option;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class NotifyingOption implements ValueObject {
    //
    private boolean emailAllowed;       // default true
    private boolean smsAllowed;         // default false;

    public NotifyingOption() {
        //
        this.emailAllowed = true;
        this.smsAllowed = false;
    }

    public NotifyingOption(boolean emailAllowed, boolean smsAllowed) {
        //
        this.emailAllowed = emailAllowed;
        this.smsAllowed = smsAllowed;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static NotifyingOption getSample() {
        //
        return new NotifyingOption();
    }

    public static NotifyingOption fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingOption.class);
    }

    public boolean isEmailAllowed() {
        return emailAllowed;
    }

    public void setEmailAllowed(boolean emailAllowed) {
        this.emailAllowed = emailAllowed;
    }

    public boolean isSmsAllowed() {
        return smsAllowed;
    }

    public void setSmsAllowed(boolean smsAllowed) {
        this.smsAllowed = smsAllowed;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
