package drama.board.domain.store;

import drama.board.domain.entity.posting.Posting;
import drama.board.domain.entity.posting.PostingBody;
import drama.board.domain.entity.posting.PostingReadLog;

import java.util.List;
import java.util.NoSuchElementException;

public interface PostingStore {
    //
    void create(Posting posting);
    Posting retrieve(String id) throws NoSuchElementException;
    List<Posting> retrieveByIds(List<String> ids);
    List<Posting> retrieveByBoardLatest(String boardId, int offset, int limit);
    List<Posting> retrieveByBoardOldest(String boardId, int offset, int limit);
    void update(Posting posting);
    void delete(Posting posting);
    void deleteByBoard(String boardId);

    int countPostingsOfBoard(String boardId);

    void createBody(PostingBody postingBody);
    PostingBody retrieveBody(String id) throws NoSuchElementException;
    void updateBody(PostingBody postingBody);
    void deleteBody(PostingBody postingBody);

    void createReadLog(PostingReadLog readLog);
    PostingReadLog retrieveReadLog(String id);
    PostingReadLog retrieveReadLogByPostingAudience(String postingId, String audienceId);
    List<PostingReadLog> retrieveReadLogByPosting(String postingId, int offset, int limit);
    Long countReadLogByPosting(String postingId);
    void deleteReadLog(PostingReadLog readLog);
    void deleteAllReadLogByPosting(String postingId);
}
