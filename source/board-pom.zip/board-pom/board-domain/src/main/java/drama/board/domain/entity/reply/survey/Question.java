package drama.board.domain.entity.reply.survey;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class Question implements ValueObject {
    //
    private String title;
    private boolean simple;
    private boolean multiSelectable;
    private List<QuestionItem> items;


    private Question() {
        // Only for instantiate by reflection
    }

    public Question(String title, List<String> itemStrs) {
        //
        this.title = title;
        this.simple = true;
        this.multiSelectable = false;
        this.items = new ArrayList<>();

        for(int itemNo=1, index = 0; index<itemStrs.size(); itemNo++, index++) {
             items.add(new QuestionItem(String.valueOf(itemNo), itemStrs.get(index)));
        }
    }

    public Question(String title, boolean simple, boolean multiSelectable, List<QuestionItem> items) {
        //
        this.title = title;
        this.simple = simple;
        this.multiSelectable = multiSelectable;
        this.items = new ArrayList<>();
        this.items.addAll(items);
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Question getSample() {
        //
        String title = "Choice the best company";
        boolean simple = true;
        boolean multiSelectable = false;
        List<QuestionItem> items = QuestionItem.getSamples();

        Question sample = new Question(title, simple, multiSelectable, items);

        return sample;
    }

    public static Question fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Question.class);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isSimple() {
        return simple;
    }

    public void setSimple(boolean simple) {
        this.simple = simple;
    }

    public boolean isMultiSelectable() {
        return multiSelectable;
    }

    public void setMultiSelectable(boolean multiSelectable) {
        this.multiSelectable = multiSelectable;
    }

    public List<QuestionItem> getItems() {
        return items;
    }

    public void setItems(List<QuestionItem> items) {
        this.items = items;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
