package drama.board.domain.spec.posting.sdo;

import drama.board.domain.entity.reply.notifying.Notice;
import drama.board.domain.entity.reply.notifying.NotifyingResponseRule;
import drama.board.domain.entity.reply.notifying.Notiway;
import nara.share.domain.DatePair;
import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class NotifyingCdo implements ValueObject {
    //
    private Notice notice;
    private Long targetCount;
    private NotifyingResponseRule responseRule;

    public NotifyingCdo() {
        //
    }

    public NotifyingCdo (Notice notice, Long targetCount, NotifyingResponseRule responseRule) {
        //
        this.notice = notice;
        this.targetCount = targetCount;
        this.responseRule = responseRule;
    }

    public String toString() {
        //
        return toJson();
    }

    public static NotifyingCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NotifyingCdo.class);
    }

    public static NotifyingCdo getSample() {
        //
        Notice notice = new Notice(Notiway.Email, DatePair.getSample(), "Hello everyone.");
        NotifyingResponseRule responseRule = NotifyingResponseRule.getSample();

        NotifyingCdo sample = new NotifyingCdo(notice, 25L, responseRule);

        return sample;
    }

    public Notice getNotice() {
        return notice;
    }

    public void setNotice(Notice notice) {
        this.notice = notice;
    }

    public Long getTargetCount() {
        return targetCount;
    }

    public void setTargetCount(Long targetCount) {
        this.targetCount = targetCount;
    }

    public NotifyingResponseRule getResponseRule() {
        return responseRule;
    }

    public void setResponseRule(NotifyingResponseRule responseRule) {
        this.responseRule = responseRule;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
