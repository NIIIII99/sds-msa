package drama.board.domain.spec.comment.sdo;

import nara.share.domain.ValueObject;
import nara.share.util.json.JsonUtil;

public class SubCommentCdo implements ValueObject {
    //
    private String text;

    private SubCommentCdo() {
        // Only for instantiate by reflection
    }

    public SubCommentCdo(String text) {
        //
        this.text = text;
    }

    public SubCommentCdo(boolean anonymous, String text) {
        //
        this.text = text;
    }

    public String toString() {
        //
        return toJson();
    }

    public static SubCommentCdo getSample() {
        //
        String text = "I agree with you.";
        return new SubCommentCdo(text);
    }

    public static SubCommentCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, SubCommentCdo.class);
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
