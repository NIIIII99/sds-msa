package drama.board.domain.entity.reply.survey;

import nara.share.domain.DatePair;
import nara.share.domain.NameValue;
import nara.share.domain.NameValueList;
import nara.share.domain.ValueObject;
import nara.share.domain.annote.Derived;
import nara.share.util.json.JsonUtil;

import java.util.List;

public class TinySurvey implements ValueObject {
    //
    private Long targetCount;
    @Derived
    private Long responseCount;
    private Question question;
    private NameValueList itemCounts;
    private DatePair term;
    private SurveyResponseRule responseRule;

    transient private List<SurveyResponse> responses;

    public TinySurvey() {
        //
    }

    public TinySurvey(Question question, Long targetCount, DatePair term, SurveyResponseRule responseRule) {
        //
        this.targetCount = targetCount;
        this.question = question;
        this.responseCount = 0L;
        this.itemCounts = new NameValueList();
        this.term = term;
        this.responseRule = responseRule;
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static TinySurvey getSample() {
        //
        TinySurvey sample = new TinySurvey(
            Question.getSample(),
            25L,
            DatePair.getSample(),
            SurveyResponseRule.getSample());

        return sample;
    }

    public static TinySurvey fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TinySurvey.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.getList()) {
            String value = nameValue.getValue();
            if (value == null) continue;
            switch(nameValue.getName()) {
                case "responseCount":
                    this.responseCount = Long.valueOf(value);
                    break;
                case "question":      // term 조정가능
                    this.question = Question.fromJson(value);
                    break;
                case "responseRule":
                    this.responseRule = SurveyResponseRule.fromJson(value);
                    break;
                case "itemCounts":
                    this.itemCounts = NameValueList.fromJson(value);
                    break;
            }
        }
    }

    public Long getTargetCount() {
        return targetCount;
    }

    public void setTargetCount(Long targetCount) {
        this.targetCount = targetCount;
    }

    public void setResponseCount(Long responseCount) {
        this.responseCount = responseCount;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public long getResponseCount() {
        return responseCount;
    }

    public void setResponseCount(long responseCount) {
        this.responseCount = responseCount;
    }

    public NameValueList getItemCounts() {
        return itemCounts;
    }

    public void setItemCounts(NameValueList itemCounts) {
        this.itemCounts = itemCounts;
    }

    public DatePair getTerm() {
        return term;
    }

    public void setTerm(DatePair term) {
        this.term = term;
    }

    public SurveyResponseRule getResponseRule() {
        return responseRule;
    }

    public void setResponseRule(SurveyResponseRule responseRule) {
        this.responseRule = responseRule;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
