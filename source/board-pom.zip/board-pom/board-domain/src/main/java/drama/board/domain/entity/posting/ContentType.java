package drama.board.domain.entity.posting;

public enum ContentType {
    //
    PlainText,
    HTML,
    Markdown,
    XML,
    JSON
}
