package io.naraplatform.tenant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

//@EnableDiscoveryClient
@SpringBootApplication
public class TenantApp {

    public static void main(String[] args) {
        SpringApplication.run(TenantApp.class, args);
    }

}
