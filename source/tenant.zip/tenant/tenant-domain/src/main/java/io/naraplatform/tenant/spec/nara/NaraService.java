package io.naraplatform.tenant.spec.nara;

import io.naraplatform.tenant.entity.nara.Nara;

import java.util.List;

public interface NaraService {
    //
    String registerNara(Nara nara);
     Nara findNara(String naraId);
    Nara findNaraByUsid(String usid);
    List<Nara> findAllNaras();
    void modifyNaraName(String usid, String name);
    void removeNara(String usid, String name);
}
