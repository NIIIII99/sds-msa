package io.naraplatform.tenant.logic.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.spec.metro.CitizenService;
import io.naraplatform.tenant.spec.metro.sdo.CitizenCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.metro.MetroStore;

import java.util.List;
import java.util.NoSuchElementException;

public class CitizenLogic implements CitizenService {
    //
    private MetroStore metroStore;
    private CitizenStore citizenStore;

    public CitizenLogic(TenantStoreLycler storeLycler) {
        //
        this.metroStore = storeLycler.requestMetroStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public String registerCitizen(CitizenCdo citizenCdo) {
        //
        String usid = citizenCdo.getUsid();
        if(usid != null) {
            if(citizenStore.existsByMetroIdAndUsid(citizenCdo.getMetroId(), usid)) {
                throw new AlreadyExistsException("Citizen usid: " + usid);
            }
        }

        String email = citizenCdo.getContact().getEmail();
        if(email != null) {
            if(citizenStore.existsByEmail(email)) {
                throw new AlreadyExistsException("Citizen email: " + email);
            }
        }

        Citizen citizen = new Citizen(
            citizenCdo.getMetroId(),
            citizenCdo.getUsid(),
            citizenCdo.getNames(),
            citizenCdo.getContact(),
            citizenCdo.getLoginInfo()
        );

        citizenStore.create(citizen);

        return citizen.getId();
    }

    @Override
    public Citizen findCitizen(String citizenId) {
        //
        Citizen citizen = citizenStore.retrieve(citizenId);
        if(citizen ==  null) {
            throw new NoSuchElementException("CitizenId: " + citizenId);
        }

        return citizen;
    }

    @Override
    public Citizen findCitizenByUsidInMetro(String metroId, String usid) {
        //
        Citizen citizen = citizenStore.retrieveByMetroIdAndUsid(metroId, usid);
        if(citizen == null) {
            throw new NoSuchElementException(String.format("MetroId:%s, Usid:%s", metroId, usid));
        }

        return citizen;
    }

    @Override
    public List<Citizen> findCitizensByNameLikeInMetro(String metroId, String nameLike) {
        //
        return citizenStore.retrieveByMetroIdAndNameLike(metroId, nameLike);
    }

    @Override
    public List<Citizen> findCitizensInMetro(String metroId, int offset, int limit) {
        //
        return citizenStore.retrieveByMetroId(metroId, offset, limit);
    }

    @Override
    public void modifyCitizen(String citizenId, NameValueList nameValues) {
        //
        Citizen citizen = findCitizen(citizenId);
        citizen.setValues(nameValues);

        citizenStore.update(citizen);
    }

    @Override
    public void removeCitizen(String citizenId) {
        //
        Citizen citizen = findCitizen(citizenId);
        citizenStore.delete(citizen);
    }

    @Override
    public void removeCitizensInMetro(String metroId) {
        //
        citizenStore.deleteByMetroId(metroId);
    }

    @Override
    public void removeCitizensByCitizenIds(List<String> citizenIds) {
        //
        citizenStore.deleteByCitizenIds(citizenIds);
    }
}
