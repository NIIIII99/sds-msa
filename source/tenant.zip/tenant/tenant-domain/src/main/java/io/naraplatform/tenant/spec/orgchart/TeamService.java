package io.naraplatform.tenant.spec.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;

import java.util.List;

public interface TeamService {
    //
    String buildTeam(String teamNodeId);
    Team findTeam(String teamId);
    List<Team> findChildTeams(String parentId);
    void modifyTeam(String teamId, NameValueList nameValues);
    void removeTeam(String teamId);
    int countTeamsInOrgChart(String orgChartId);

    String addTeamMember(String teamId, String citizenId);
    void addTeamMembers(String teamId, List<String> citizenIds);
    TeamMember findTeamMember(String memberId);
    List<TeamMember> findTeamMembersInTeam(String teamId, int offset, int limit);
    void modifyTeamMember(String memberId, NameValueList nameValues);
    void removeTeamMember(String memberId);
    void removeTeamMembers(List<String> memberIds);
    void removeTeamMembersInTeam(String teamId);
    int countTeamMembersInTeam(String teamId);
}
