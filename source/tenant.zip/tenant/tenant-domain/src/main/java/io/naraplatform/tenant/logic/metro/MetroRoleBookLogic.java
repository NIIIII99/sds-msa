package io.naraplatform.tenant.logic.metro;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import io.naraplatform.tenant.spec.metro.MetroRoleBookService;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.MetroRoleBookStore;

import java.util.List;
import java.util.NoSuchElementException;

public class MetroRoleBookLogic implements MetroRoleBookService {
    //
    private MetroRoleBookStore roleBookStore;

    public MetroRoleBookLogic(TenantStoreLycler storeLycler) {
        //
        this.roleBookStore = storeLycler.requestMetroRoleBookStore();
    }

    @Override
    public String registerMetroRoleBook(MetroRoleBookCdo metroRoleBookCdo) {
        //
        MetroRoleCdo adminRoleCdo = metroRoleBookCdo.getAdminRoleCdo();
        MetroRoleCdo baseUserRoleCdo = metroRoleBookCdo.getBaseUserRoleCdo();
        IdName metro = metroRoleBookCdo.getMetro();
        MetroRole adminRole = new MetroRole(
            metro.getId(),
            adminRoleCdo.getSequence(),
            adminRoleCdo.getName(),
            adminRoleCdo.getDisplayName()
        );

        MetroRole baseUserRole = new MetroRole(
            metro.getId(),
            adminRoleCdo.getSequence(),
            adminRoleCdo.getName(),
            adminRoleCdo.getDisplayName()
        );

        MetroRoleBook roleBook = new MetroRoleBook(metro, adminRole, baseUserRole);

        roleBookStore.create(roleBook);
        roleBookStore.createMetroRole(adminRole);
        roleBookStore.createMetroRole(baseUserRole);

        return roleBook.getId();        // metroId;
    }

    @Override
    public MetroRoleBook findMetroRoleBook(String metroId) {
        //
        MetroRoleBook roleBook = roleBookStore.retrieve(metroId);
        if(roleBook == null) {
            throw new NoSuchElementException("MetroId: " + metroId);
        }

        return roleBook;
    }

    @Override
    public void removeMetroRoleBook(String metroId) {
        //
        MetroRoleBook roleBook = findMetroRoleBook(metroId);

        roleBookStore.deleteMetroRolesByMetroId(metroId);
        roleBookStore.delete(roleBook);
    }

    @Override
    public String addMetroRole(String metroId, MetroRoleCdo metroRoleCdo) {
        //
        if(roleBookStore.existsMetroRoleByMetroIdAndRoleName(metroId, metroRoleCdo.getName())) {
            throw new AlreadyExistsException("Metro name: " + metroRoleCdo.getDisplayName());
        }

        MetroRole metroRole = new MetroRole(
            metroId,
            metroRoleCdo.getSequence(),
            metroRoleCdo.getName(),
            metroRoleCdo.getDisplayName()
        );

        roleBookStore.createMetroRole(metroRole);

        return metroRole.getId();
    }

    @Override
    public List<MetroRole> findMetroRolesByMetroId(String metroId) {
        //
        return roleBookStore.retrieveMetroRolesByMetroId(metroId);
    }

    @Override
    public MetroRole findMetroRole(String roleId) {
        //
        MetroRole metroRole = roleBookStore.retrieveMetroRole(roleId);
        if (metroRole == null) {
            throw new NoSuchElementException("RoleId: " + roleId);
        }

        return metroRole;
    }

    @Override
    public void modifyMetroRole(String roleId, NameValueList nameValues) {
        //
        MetroRole role = findMetroRole(roleId);
        role.setValues(nameValues);

        roleBookStore.updateMetroRole(role);
    }

    @Override
    public void removeMetroRoles(List<String> roleIds) {
        //
        for(String roleId : roleIds) {
            roleBookStore.deleteMetroRole(roleId);
        }
    }

    @Override
    public void removeMetroRole(String metroId, String roleName) {
        //
        List<MetroRole> metroRoles = findMetroRolesByMetroId(metroId);
        for(MetroRole metroRole : metroRoles) {
            if (metroRole.getName().equals(roleName)) {
                roleBookStore.deleteMetroRole(metroRole.getId());
                break;
            }
        }
    }
}
