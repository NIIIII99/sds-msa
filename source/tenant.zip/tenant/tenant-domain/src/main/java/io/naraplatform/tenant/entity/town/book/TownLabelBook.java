package io.naraplatform.tenant.entity.town.book;

import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.town.Town;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Label book for a specific Town
 **/

@Getter
@Setter
@NoArgsConstructor
public class TownLabelBook extends NaraEntity {
    //
    private LangStrings townLabels;
    private LangStrings townerLabels;

    public TownLabelBook(String id) {
        //
        super(id);
    }

    public TownLabelBook(String townId,
                         LangStrings townLabels,
                         LangStrings townerLabels) {
        //
        super(townId);
        this.townLabels = townLabels;
        this.townerLabels = townerLabels;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TownLabelBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownLabelBook.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "townLabels":
                    this.townLabels = LangStrings.fromJson(value);
                    break;
                case "townerLabels":
                    this.townerLabels = LangStrings.fromJson(value);
                    break;
            }
        }
    }

    public static TownLabelBook defaultBook(String townId) {
        //
        LangStrings townLabels = LangStrings.newString("en", "Team").addString("ko", "팀");
        LangStrings townerLabels = LangStrings.newString("en", "Team Member").addString("ko", "팀원");

        return new TownLabelBook(townId, townLabels, townerLabels);
    }

    public static TownLabelBook sample() {
        //
        Town town = Town.sample();
        return defaultBook(town.getId());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
