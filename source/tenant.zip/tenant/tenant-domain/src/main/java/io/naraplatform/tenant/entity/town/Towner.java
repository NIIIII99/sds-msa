package io.naraplatform.tenant.entity.town;

public interface Towner {
    //
    TownerIdentity getIdentity();
}
