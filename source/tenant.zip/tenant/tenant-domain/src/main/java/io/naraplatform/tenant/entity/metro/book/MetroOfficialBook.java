package io.naraplatform.tenant.entity.metro.book;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.type.OfficialPolicy;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialBook extends NaraEntity implements NaraAggregate {
    //
    private String metroName;
    private IdName primaryOfficial;
    private OfficialPolicy policy;

    transient private List<MetroOfficial> officials;

    public MetroOfficialBook(String id) {
        //
        super(id);
    }

    public MetroOfficialBook(IdName metro, MetroOfficial primanyOfficial) {
        //
        super(metro.getId());                           // Metro has only one MetroOfficialBook
        this.metroName = metro.getName();
        this.primaryOfficial = primanyOfficial.getIdName();
        this.policy = new OfficialPolicy();             // multiAdmin is default setting.
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroOfficialBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroOfficialBook.class);
    }

    public static MetroOfficialBook sample() {
        //
        Metro metro = Metro.sample();
        MetroOfficial primaryOfficial = MetroOfficial.samplePrimary();

        return new MetroOfficialBook(metro.getIdName(), primaryOfficial);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "metroName":
                    this.metroName = value;
                    break;
                case "primaryOfficial":
                    this.primaryOfficial = IdName.fromJson(value);
                    break;
                case "policy":
                    this.policy = OfficialPolicy.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid attribute: " + nameValue);
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
