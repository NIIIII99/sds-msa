package io.naraplatform.tenant.logic.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.spec.town.TownAdminBookService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.town.TownAdminBookStore;
import io.naraplatform.tenant.store.town.TownStore;

import java.util.List;
import java.util.NoSuchElementException;

public class TownAdminBookLogic implements TownAdminBookService {
    //
    private TownAdminBookStore adminBookStore;
    private TownStore townStore;
    private CitizenStore citizenStore;

    public TownAdminBookLogic(TenantStoreLycler storeLycler) {
        //
        this.adminBookStore = storeLycler.requestTownAdminBookStore();
        this.townStore = storeLycler.requestTownStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public TownAdminBook findTownAdminBook(String townId) {
        //
        TownAdminBook adminBook = adminBookStore.retrieve(townId);
        if (adminBook == null) {
            Town town = townStore.retrieve(townId);
            adminBook = new TownAdminBook(town.getIdName());
            adminBookStore.create(adminBook);
        }

        return adminBook;
    }

    @Override
    public String addTownAdmin(String townId, String citizenId, Tier tier) {
        //
        Citizen citizen = citizenStore.retrieve(citizenId);
        TownAdmin admin = new TownAdmin(townId, tier, citizen);

        adminBookStore.createTownAdmin(admin);
        return admin.getId();
    }

    @Override
    public List<TownAdmin> findTownAdminsInTown(String townId) {
        //
        return adminBookStore.retrieveTownAdminsByTownId(townId);
    }

    @Override
    public TownAdmin findTownAdmin(String adminId) {
        //
        TownAdmin admin = adminBookStore.retrieveTownAdmin(adminId);
        if (admin == null) {
            throw new NoSuchElementException("AdminId: " + adminId);
        }

        return admin;
    }

    @Override
    public void modifyTownAdmin(String adminId, NameValueList nameValues) {
        //
        TownAdmin admin = findTownAdmin(adminId);
        admin.setValues(nameValues);

        adminBookStore.updateTownAdmin(admin);
    }

    @Override
    public void removeTownAdmins(List<String> adminIds) {
        //
        adminBookStore.deleteTownAdmins(adminIds);
    }
}
