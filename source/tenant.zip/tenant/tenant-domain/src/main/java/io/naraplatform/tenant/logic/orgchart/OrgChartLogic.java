package io.naraplatform.tenant.logic.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.exception.IllegalRequestException;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.spec.orgchart.OrgChartService;
import io.naraplatform.tenant.spec.orgchart.sdo.OrgChartCdo;
import io.naraplatform.tenant.spec.orgchart.sdo.TeamNodeCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.orgchart.OrgChartStore;

import java.util.List;
import java.util.NoSuchElementException;

public class OrgChartLogic implements OrgChartService {
    //
    private OrgChartStore orgChartStore;

    public OrgChartLogic(TenantStoreLycler storeLycler) {
        //
        this.orgChartStore = storeLycler.requestOrgChartStore();
    }

    @Override
    public String registerOrgChart(OrgChartCdo orgChartCdo) {
        //
        String metroId = orgChartCdo.getMetroId();
        List<OrgChart> existOrgCharts = orgChartStore.retrieveByMetroId(metroId);
        if (existOrgCharts.size() > 0) {
            if (hasPrimary(existOrgCharts)) {
                if(orgChartCdo.getTier().equals(Tier.Primary)) {
                    throw new IllegalArgumentException("One primary chart available.");
                }
            }
        } else {
            if(!orgChartCdo.getTier().equals(Tier.Primary)) {
                throw new IllegalArgumentException("First chart should be Primary.");
            }
        }

        OrgChart orgChart = new OrgChart(
            metroId,
            orgChartCdo.getTitles(),
            orgChartCdo.getTier()
        );

        TeamNode rootNode = new TeamNode(orgChart);

        orgChartStore.create(orgChart);
        orgChartStore.createTeamNode(rootNode);

        return orgChart.getId();
    }

    private boolean hasPrimary(List<OrgChart> orgCharts) {
        //
        for(OrgChart orgChart : orgCharts) {
            if (orgChart.getTier().equals(Tier.Primary)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public OrgChart findOrgChart(String orgChartId) {
        //
        OrgChart orgChart = orgChartStore.retrieve(orgChartId);
        if(orgChart == null) {
            throw new NoSuchElementException("OrgChartId: " + orgChartId);
        }

        return orgChart;
    }

    @Override
    public OrgChart findPrimaryOrgChartInMetro(String metroId) {
        //
        List<OrgChart> existOrgCharts = orgChartStore.retrieveByMetroId(metroId);
        for(OrgChart orgChart : existOrgCharts) {
            if(orgChart.getTier().equals(Tier.Primary)) {
                return orgChart;
            }
        }

        return null;
    }

    @Override
    public List<OrgChart> findOrgChartsInMetro(String metroId) {
        //
        return orgChartStore.retrieveByMetroId(metroId);
    }

    @Override
    public void modifyOrgChart(String orgChartId, NameValueList nameValues) {
        //
        OrgChart orgChart = orgChartStore.retrieve(orgChartId);
        orgChart.setValues(nameValues);

        orgChartStore.update(orgChart);
    }

    @Override
    public void removeOrgChart(String orgChartId) {
        //
        OrgChart orgChart = orgChartStore.retrieve(orgChartId);
        if (orgChartStore.countTeamNodesByOrgChartId(orgChartId) > 0) {
            throw new IllegalRequestException("Remove the teamNode first in orgChart: " + orgChartId);
        }

        orgChartStore.delete(orgChart);
    }

    @Override
    public void forceRemoveOrgChart(String orgChartId) {
        //
        orgChartStore.deleteTeamNodesByOrgChartId(orgChartId);
        orgChartStore.delete(orgChartId);
    }

    @Override
    public void removeOrgChartInMetro(String metroId) {
        //
        List<OrgChart> orgCharts = orgChartStore.retrieveByMetroId(metroId);
        for(OrgChart orgChart : orgCharts) {
            forceRemoveOrgChart(orgChart.getId());
        }
    }

    @Override
    public String addTeamNode(String orgChartId, TeamNodeCdo teamNodeCdo) {
        //
        String parentId = teamNodeCdo.getParentId();
        TeamNode parentNode = findTeamNode(parentId);

        int levelSequence = parentNode.nextChildSequence();
        orgChartStore.updateTeamNode(parentNode);

        TeamNode teamNode = new TeamNode(
            orgChartId,
            parentId,
            levelSequence,
            teamNodeCdo.getTitles()
        );
        orgChartStore.createTeamNode(teamNode);

        return teamNode.getId();
    }

    @Override
    public TeamNode findRootNodeInOrgChart(String orgChartId) {
        //
        // rootNode's parentId equals orgChartId
        //
        List<TeamNode> rootNodes = orgChartStore.retrieveTeamNodesByParentId(orgChartId);
        if(rootNodes.size() != 1) {
            throw new IllegalStateException("Root node should be one entity.");
        }

        return rootNodes.get(0);
    }

    @Override
    public TeamNode findTeamNode(String nodeId) {
        //
        TeamNode teamNode = orgChartStore.retrieveTeamNode(nodeId);
        if (teamNode == null) {
            throw new NoSuchElementException("TeamNodeId: " + nodeId);
        }

        return teamNode;
    }

    @Override
    public List<TeamNode> findTeamNodesInOrgChart(String orgChartId) {
        //
        return orgChartStore.retrieveTeamNodesByOrgChartId(orgChartId);
    }

    @Override
    public void modifyTeamNode(String nodeId, NameValueList nameValues) {
        //
        TeamNode teamNode = findTeamNode(nodeId);
        teamNode.setValues(nameValues);

        orgChartStore.updateTeamNode(teamNode);
    }

    @Override
    public void removeTeamNode(String nodeId) {
        // remove node and children
        TeamNode teamNode = findTeamNode(nodeId);
        orgChartStore.deleteTeamNode(teamNode);
    }

    @Override
    public void removeTeamNodesInParent(String parentId) {
        // remove all children
        orgChartStore.deleteTeamNodesByParentId(parentId);
    }

    @Override
    public void removeTeamNodes(List<String> nodeIds) {
        //
        for(String nodeId : nodeIds) {
            orgChartStore.deleteTeamNode(nodeId);
        }
    }
}
