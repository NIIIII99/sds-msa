package io.naraplatform.tenant.store.town;

import io.naraplatform.tenant.entity.town.ActiveTowner;
import io.naraplatform.tenant.entity.town.DormantTowner;
import io.naraplatform.tenant.entity.town.TownerIdentity;

import java.util.List;

public interface TownerStore {
    //
    void create(ActiveTowner towner);
    ActiveTowner retrieveActiveTowner(String id);
    ActiveTowner retrieveActiveTownerByTownIdAndUsid(String townId, String usid);
    List<ActiveTowner> retrieveActiveTownerByTownIdAndNameLike(String townId, String nameLike);
    List<ActiveTowner> retrieveActiveTownerByTownId(String townId, int offset, int limit);
    void updateActiveTowner(ActiveTowner towner);
    void deleteActiveTowner(ActiveTowner towner);
    void deleteActiveTownersByTownerIds(List<String> townerIds);
    void deleteActiveTownersByTownId(String townId);
    long countActiveTownerByTownId(String townId);

    void create(DormantTowner towner);
    DormantTowner retrieveDormantTowner(String id);
    List<DormantTowner> retrieveDormantTownerByTownId(String townId, int offset, int limit);
    void deleteDormantTowner(DormantTowner towner);
    void deleteDormantTownersByTownerIds(List<String> townerIds);
    List<String> deleteDormantTownersByTownId(String townId);

    void create(TownerIdentity identity);
    TownerIdentity retrieveIdentity(String townerId);
    TownerIdentity retrieveIdentityByTownIdAndCitizenId(String townId, String citizenId);
    List<TownerIdentity> retrieveIdentitiesByTownId(String townId, int offset, int limit);
    boolean existsIdentityByTownIdAndCitizenId(String townId, String citizenId);
    void updateIdentity(TownerIdentity identity);
    void deleteIdentity(String identity);
    void deleteIdentitiesByTownId(String townId);
    void deleteIdentitiesByTownerIds(List<String> townerIds);
}
