package io.naraplatform.tenant.spec.nara;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import io.naraplatform.tenant.spec.nara.sdo.NaraLabelBookCdo;

import java.util.List;

public interface NaraLabelBookService {
    //
    String registerNaraLabelBook(NaraLabelBookCdo labelBookCdo);
    NaraLabelBook findNaraLabelBook(String labelBookId);
    List<NaraLabelBook> findNaraLabelBooksByNaraId(String naraId, int offset, int limit);
    List<NaraLabelBook> findNaraLabelBooksByMetroType(MetroType metroType, int offset, int limit);
    List<NaraLabelBook> findNaraLabelBooksByTitleLike(String titleLike, int offset, int limit);
    void modifyNaraLabelBook(String labelBookId, NameValueList nameValues);
    void removeNaraLabelBook(String labelBookId);
}
