package io.naraplatform.tenant.entity.town;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import io.naraplatform.tenant.entity.town.policy.TownPolicy;
import io.naraplatform.tenant.entity.town.policy.TownType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * 1. You can build a town from an OrgChart and a team
 * 2. You can build a town from the Metro
 **/

@Getter
@Setter
@NoArgsConstructor
public class Town extends NaraEntity implements NaraAggregate {
    //
    private String usid;                    // team code, if exists
    private List<String> supportLangs;
    private LangStrings titles;
    private LangStrings pathNames;          // NextreeConsulting/R&DCenter/TeamA
    private TownType type;
    private TownPolicy policy;
    private String baseRoleName;            // User
    private long time;

    private String tinyAlbumId;             // from depot service
    private String profileId;               // from profile service
    private String townDiskId;              // from town service

    private String metroId;

    transient private TownLabelBook labelBook;
    transient private TownRoleBook roleBook;
    transient private TownAdminBook adminBook;
    transient private List<ActiveTowner> towners;

    public Town(String id) {
        //
        super(id);
    }

    public Town(Metro metro, Team team, TownType townType) {
        //
        this(team.getId());
        this.supportLangs = metro.getSupportLangs();
        this.titles = team.getTitles();
        this.type = townType;
        this.policy = TownPolicy.defaultPolicy();
        this.time = System.currentTimeMillis();
        this.metroId = metro.getId();
    }

    public static Town sample() {
        //
        Metro metro = Metro.sample();
        Team team = Team.sample();

        Town sample = new Town(metro, team, TownType.Project);
        sample.setType(TownType.Project);
        sample.setPathNames(LangStrings.newString("ko", "namoosori"));
        sample.setTitles(LangStrings.newString("ko", "나무소리").addString("en", "namoosori"));

        return sample;
    }

    public static Town fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Town.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "usid":
                    this.usid = value;
                    break;
                case "supportLangs":
                    this.supportLangs = JsonUtil.fromJsonList(value, String.class);
                    break;
                case "titles":
                    this.titles = LangStrings.fromJson(value);
                    break;
                case "policy":
                    this.policy = TownPolicy.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());

            }
        }
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), titles.getString());
    }

    public static void main(String[] args) {
        //
        System.out.println(Town.sample());
    }
}
