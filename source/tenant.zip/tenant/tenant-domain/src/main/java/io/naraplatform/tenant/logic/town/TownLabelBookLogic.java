package io.naraplatform.tenant.logic.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import io.naraplatform.tenant.spec.town.TownLabelBookService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.town.TownLabelBookStore;

public class TownLabelBookLogic implements TownLabelBookService {
    //
    private TownLabelBookStore labelBookStore;

    public TownLabelBookLogic(TenantStoreLycler storeLycler) {
        //
        this.labelBookStore = storeLycler.requestTownLabelBookStore();
    }

    @Override
    public TownLabelBook findTownLabelBook(String townId) {
        //
        TownLabelBook labelBook = labelBookStore.retrieve(townId);
        if(labelBook == null) {
            labelBook = TownLabelBook.defaultBook(townId);        // include adminRole and defaultUserRole
            labelBookStore.create(labelBook);
        }

        return labelBook;
    }

    @Override
    public void modifyTownLabelBook(String townId, NameValueList nameValues) {
        //
        TownLabelBook labelBook = labelBookStore.retrieve(townId);
        labelBook.setValues(nameValues);

        labelBookStore.update(labelBook);
    }
}
