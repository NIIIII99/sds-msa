package io.naraplatform.tenant.entity.orgchart;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.share.util.string.StringUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Team extends NaraEntity implements NaraAggregate {
    //
    private LangStrings titles;
    private String parentId;
    private IdName leader;
    private LangStrings memos;

    private String orgChartId;
    transient private List<TeamMember> members;

    public Team(String id) {
        //
        super(id);
    }

    public Team(TeamNode teamNode) {
        //
        super(teamNode.getId());
        this.titles = teamNode.getTitles();
        this.parentId = teamNode.getParentId();
        this.leader = null;
    }

    public boolean hasLeader() {
        //
        return leader != null;
    }

    public boolean hasOrgChartId() {
        //
        return !StringUtil.isEmpty(orgChartId);
    }

    public String toString() {
        //
        return toJson();
    }

    public static Team fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Team.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "titles":
                    this.titles = LangStrings.fromJson(value);
                    break;
                case "leader":
                    this.leader = IdName.fromJson(value);
                    break;
                case "memos":
                    this.memos = LangStrings.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
    }

    public static Team sample() {
        //
        return new Team(TeamNode.sampleRoot());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
