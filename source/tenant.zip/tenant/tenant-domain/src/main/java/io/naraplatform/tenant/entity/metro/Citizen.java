package io.naraplatform.tenant.entity.metro;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.lang.LangNames;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.LoginUserInfo;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.type.CitizenType;
import io.naraplatform.tenant.entity.town.Towner;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Citizen extends NaraEntity implements NaraAggregate {
    //
    private String usid;                // employee id, member id, etc. Unique in metro only.
    private LangNames names;
    private String nickname;            // optional
    private CitizenType type;
    private Contact contact;
    private LangStrings titles;         // multi-lingual, 직급
    private LangStrings teams;          // multi-lingual, 부서
    private String tinyAlbumId;         // 프로필 사진을 위한
    private String profileId;           // employee, student, member, etc
    private String personalDiskId;      // personal drive
    private long time;
    private String homeTownId;
    private String metroId;

    private LoginUserInfo loginInfo;
    transient private List<Towner> towners;

    public Citizen(String id) {
        //
        super(id);
    }

    public Citizen(String metroId,
                   String usid,
                   LangNames names,
                   Contact contact,
                   LoginUserInfo loginInfo) {
        //
        super();
        this.usid = usid;
        this.names = names;
        this.contact = contact;
        this.loginInfo = loginInfo;
        this.type = CitizenType.Resident;
        this.time = System.currentTimeMillis();
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "usid":
                    this.usid = value;
                    break;
                case "contact":
                    this.contact = Contact.fromJson(value);
                    break;
                case "titles":
                    this.titles = LangStrings.fromJson(value);
                    break;
                case "teams":
                    this.teams = LangStrings.fromJson(value);
                    break;
                case "tinyAlbumId":
                    this.tinyAlbumId = value;
                    break;
                case "profileId":
                    this.profileId = value;
                    break;
                case "type":
                    this.type = CitizenType.valueOf(value);
                    break;
                case "nickname":
                    this.nickname = value;
                    break;
                case "loginInfo":
                    this.loginInfo = LoginUserInfo.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
   }

    public static Citizen sampleWithId(String metroId) {
        //
        String usid = "19-102993";
        Contact contact = Contact.sample();
        LoginUserInfo loginUserInfo = LoginUserInfo.sample();
        LangNames names = LangNames.sample();

        Citizen sample = new Citizen(metroId, usid, names, contact, loginUserInfo);
        sample.setTitles(LangStrings.newString("ko", "부장").addString("en", "Manager"));

        return sample;
    }

    public static Citizen sample() {
        //
        return sampleWithId(Metro.sample().getId());
    }

    public static Citizen fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Citizen.class);
    }

    public boolean hasContact() {
        //
        if(contact != null) {
            return true;
        }

        return false;
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), names.getNames().get(0).getName().getDisplayName());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
