package io.naraplatform.tenant.entity.orgchart;

import io.naraplatform.share.domain.lang.LangStrings;

public interface TreeNode {
    //
    LangStrings getTitles();
    boolean isLeaf();
    boolean isRoot();
}
