package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroRoleBookCdo implements JsonSerializable {
    //
    private IdName metro;
    private MetroRoleCdo adminRoleCdo;
    private MetroRoleCdo baseUserRoleCdo;

    public MetroRoleBookCdo(IdName metro,
                            MetroRoleCdo adminRoleCdo,
                            MetroRoleCdo baseUserRoleCdo) {
        //
        this.metro = metro;
        this.adminRoleCdo = adminRoleCdo;
        this.baseUserRoleCdo = baseUserRoleCdo;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroRoleBookCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroRoleBookCdo.class);
    }

    public static MetroRoleBookCdo sample() {
        //
        Metro metro = Metro.sample();
        MetroRoleCdo adminRoleCdo = MetroRoleCdo.sampleAdmin();
        MetroRoleCdo baseUserRoleCdo = MetroRoleCdo.sampleBaseUser();

        return new MetroRoleBookCdo(metro.getIdName(), adminRoleCdo, baseUserRoleCdo);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
