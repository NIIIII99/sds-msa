package io.naraplatform.tenant.entity.town;


import io.naraplatform.share.domain.Expiration;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DormantTowner extends NaraEntity implements NaraAggregate, Towner {
    //
    private String usid;            // Unique in Metro
    private String name;
    private String title;
    private String nickname;
    private List<String> roleNames;
    private Expiration expiration;

    private String citizenId;
    private String townId;

    public DormantTowner(String id) {
        //
        super(id);
    }

    public DormantTowner(ActiveTowner towner, String dormantReason) {
        //
        super(towner.getId());
        this.usid = towner.getUsid();
        this.name = towner.getName();
        this.title = towner.getTitle();
        this.nickname = towner.getNickname();
        this.roleNames = towner.getRoleNames();
        this.expiration = Expiration.newExpired(dormantReason);
        this.citizenId = towner.getCitizenId();
        this.townId = towner.getTownId();
    }

    public ActiveTowner activate() {
        //
        ActiveTowner towner = new ActiveTowner(getId());
        towner.setUsid(usid);
        towner.setName(name);
        towner.setTitle(title);
        towner.setNickname(nickname);
        towner.setRoleNames(roleNames);
        towner.setCitizenId(citizenId);
        towner.setTownId(townId);

        return towner;
    }

    public static DormantTowner sample() {
        //
        ActiveTowner towner = ActiveTowner.sample();
        String dormantReason = "회원탈퇴";
        return new DormantTowner(towner, dormantReason);
    }

    public static DormantTowner fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DormantTowner.class);
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), getName());
    }

    @Override
    public TownerIdentity getIdentity() {
        //
        TownerIdentity townerIdentity = new TownerIdentity(
            getId(),
            usid,
            name,
            title,
            nickname
        );

        townerIdentity.setState(TownerState.Dormanted);

        return townerIdentity;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
