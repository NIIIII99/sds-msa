package io.naraplatform.tenant.spec.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.spec.metro.sdo.MetroCdo;

import java.util.List;

public interface MetroService {
    //
    String buildMetro(MetroCdo metroCdo);
    Metro findMetro(String metroId);
    List<Metro> finaMetrosInNara(String naraId, int offset, int limit);
    void modifyMetro(String metroId, NameValueList nameValues);
    void removeMetro(String metroId);
    void forceRemoveMetro(String metroId);
    boolean existsMetroByNames(LangStrings names);
}
