package io.naraplatform.tenant.spec.town.sdo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.policy.TownType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TownCdo implements JsonSerializable {
    //
    private String metroId;
    private String teamId;
    private TownType type;
    private String adminCitizenId;

    public TownCdo(String metroId,
                   String teamId,
                   TownType type,
                   String adminCitizenId) {
        //
        this.metroId = metroId;
        this.teamId = teamId;
        this.type = type;
        this.adminCitizenId = adminCitizenId;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TownCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownCdo.class);
    }

    public static TownCdo sample() {
        //
        Town town = Town.sample();
        Citizen admin = Citizen.sample();

        return new TownCdo(
            town.getMetroId(),
            town.getId(),
            town.getType(),
            admin.getIdName().getId());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
