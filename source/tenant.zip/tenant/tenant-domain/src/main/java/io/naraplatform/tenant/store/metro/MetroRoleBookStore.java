package io.naraplatform.tenant.store.metro;

import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;

import java.util.List;

public interface MetroRoleBookStore {
    //
    void create(MetroRoleBook metroRoleBook);
    MetroRoleBook retrieve(String metroId);
    void update(MetroRoleBook metroRoleBook);
    void delete(MetroRoleBook metroRoleBook);
    boolean exists(String metroId);

    void createMetroRole(MetroRole metroRole);
    MetroRole retrieveMetroRole(String roleId);
    List<MetroRole> retrieveMetroRolesByMetroId(String metroId);
    void updateMetroRole(MetroRole metroRole);
    void deleteMetroRole(MetroRole metroRole);
    void deleteMetroRole(String roleId);
    void deleteMetroRolesByMetroId(String metroId);
    boolean existsMetroRoleByMetroIdAndRoleName(String metroId, String roleName);
}
