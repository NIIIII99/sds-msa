package io.naraplatform.tenant.spec.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.spec.metro.sdo.CitizenCdo;

import java.util.List;

public interface CitizenService {
    // for metro
    String registerCitizen(CitizenCdo citizenCdo);
    Citizen findCitizen(String citizenId);
    Citizen findCitizenByUsidInMetro(String metroId, String usid);
    List<Citizen> findCitizensByNameLikeInMetro(String metroId, String nameLike);
    List<Citizen> findCitizensInMetro(String metroId, int offset, int limit);
    void modifyCitizen(String citizenId, NameValueList nameValues);
    void removeCitizen(String citizenId);
    void removeCitizensInMetro(String metroId);
    void removeCitizensByCitizenIds(List<String> citizenIds);
}
