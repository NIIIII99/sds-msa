package io.naraplatform.tenant.store.metro;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Metro;

import java.util.List;

public interface MetroStore {
    //
    void create(Metro metro);
    Metro retrieve(String id);
    List<Metro> retrieveByNaraId(String naraId, int offset, int limit);
    void update(Metro metro);
    void delete(Metro metro);
    boolean existsByNames(LangStrings names);
}
