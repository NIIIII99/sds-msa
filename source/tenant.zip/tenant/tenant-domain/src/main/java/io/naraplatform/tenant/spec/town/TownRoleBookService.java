package io.naraplatform.tenant.spec.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;

public interface TownRoleBookService {
    //
    TownRoleBook findTownRoleBook(String townId);
    void modifyTownRoleBook(String townId, NameValueList nameValues);
}
