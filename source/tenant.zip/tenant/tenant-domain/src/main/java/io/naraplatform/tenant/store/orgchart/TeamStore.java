package io.naraplatform.tenant.store.orgchart;

import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;

import java.util.List;

public interface TeamStore {
    //
    void create(Team team);
    Team retrieve(String id);
    List<Team> retrieveByOrgChartId(String orgChartId);
    List<Team> retrieveByParentId(String parentId);
    void update(Team team);
    void delete(Team team);
    int count(String orgChartId);

    void createTeamMember(TeamMember member);
    TeamMember retrieveTeamMember(String memberId);
    List<TeamMember> retrieveTeamMembersByTeamId(String teamId, int offset, int limit);
    List<TeamMember> retrieveTeamMembersByCitizenId(String citizenId);
    void updateTeamMember(TeamMember member);
    void deleteTeamMember(TeamMember member);
    void deleteTeamMembersByTeamId(String teamId);
    void deleteTeamMembersByMemberIds(List<String> memberIds);
    boolean existsTeamMemberByTeamIdAndCitizenId(String teamId, String citizenId);
    int countTeamMembersByTeamId(String teamId);
}
