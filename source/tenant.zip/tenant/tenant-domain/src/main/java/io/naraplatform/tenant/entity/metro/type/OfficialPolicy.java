package io.naraplatform.tenant.entity.metro.type;

import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OfficialPolicy implements ValueObject {
    //
    private boolean singleAdmin;

    public OfficialPolicy(boolean singleAdmin) {
        //
        this.singleAdmin = singleAdmin;
    }

    public String toString() {
        //
        return toJson();
    }

    public static OfficialPolicy fromJson(String json) {
        //
        return JsonUtil.fromJson(json, OfficialPolicy.class);
    }

    public static OfficialPolicy sample() {
        //
        return new OfficialPolicy();
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
