package io.naraplatform.tenant.spec.orgchart.sdo;

import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OrgChartCdo implements JsonSerializable {
    //
    private String metroId;
    private LangStrings titles;
    private Tier tier;

    public OrgChartCdo(String metroId,
                       LangStrings titles,
                       Tier tier) {
        //
        this.metroId = metroId;
        this.titles = titles;
        this.tier = tier;
    }

    public String toString() {
        //
        return toJson();
    }

    public static OrgChartCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, OrgChartCdo.class);
    }

    public static OrgChartCdo sample() {
        //
        OrgChart orgChart = OrgChart.sample();
        return new OrgChartCdo(
            orgChart.getMetroId(),
            orgChart.getTitles(),
            orgChart.getTier()
        );
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
