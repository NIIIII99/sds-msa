package io.naraplatform.tenant.logic.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.exception.IllegalRequestException;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.spec.metro.MetroService;
import io.naraplatform.tenant.spec.metro.sdo.MetroCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.metro.MetroStore;

import java.util.List;
import java.util.NoSuchElementException;

public class MetroLogic implements MetroService {
    //
    private MetroStore metroStore;
    private CitizenStore citizenStore;

    public MetroLogic(TenantStoreLycler storeLycler) {
        //
        this.metroStore = storeLycler.requestMetroStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public String buildMetro(MetroCdo metroCdo) {
        //
        if(metroStore.existsByNames(metroCdo.getNames())) {
            throw new AlreadyExistsException("Metro name: " + metroCdo.getNames());
        }

        Metro metro = new Metro(
            metroCdo.getSupportLangs(),
            metroCdo.getNara(),
            metroCdo.getNames(),
            metroCdo.getType()
        );

        metroStore.create(metro);

        return metro.getId();
    }

    @Override
    public Metro findMetro(String metroId) {
        //
        Metro metro = metroStore.retrieve(metroId);
        if(metro == null) {
            throw new NoSuchElementException("MetroId: " + metroId);
        }

        return metro;
    }

    @Override
    public List<Metro> finaMetrosInNara(String naraId, int offset, int limit) {
        //
        return metroStore.retrieveByNaraId(naraId, offset, limit);
    }

    @Override
    public void modifyMetro(String metroId, NameValueList nameValues) {
        //
        Metro metro = findMetro(metroId);
        metro.setValues(nameValues);

        metroStore.update(metro);
    }

    @Override
    public void removeMetro(String metroId) {
        //
        Metro metro = findMetro(metroId);
        if (citizenStore.countByMetroId(metroId) > 0) {
            throw new IllegalRequestException("Remove the citizens first in metro: " + metroId);
        }

        metroStore.delete(metro);
    }

    @Override
    public void forceRemoveMetro(String metroId) {
        //
        Metro metro = findMetro(metroId);
        citizenStore.deleteByMetroId(metroId);
        metroStore.delete(metro);
    }

    @Override
    public boolean existsMetroByNames(LangStrings names) {
        //
        return metroStore.existsByNames(names);
    }
}
