package io.naraplatform.tenant.spec.nara.sdo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NaraLabelBookCdo implements JsonSerializable {
    //
    private IdName nara;
    private MetroType metroType;
    private String title;
    private NameValueList labels;   // metroLabels, citizenLabels, TownLabels, TownerLabels

    public NaraLabelBookCdo(IdName nara,
                            MetroType metroType,
                            String title,
                            NameValueList labels) {
        //
        this.nara = nara;
        this.metroType = metroType;
        this.title = title;
        this.labels = labels;
    }

    public String toString() {
        //
        return toJson();
    }

    public static NaraLabelBookCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NaraLabelBookCdo.class);
    }

    public static NaraLabelBookCdo sample() {
        //
        NaraLabelBook labelBook = NaraLabelBook.naraSample();
        IdName nara = labelBook.getNara();
        MetroType metroType = labelBook.getMetroType();
        String title = labelBook.getTitle();

        NameValueList labels = new NameValueList();
        labels.add("metroLabels", labelBook.getMetroLabels().toJson());
        labels.add("citizenLabels", labelBook.getCitizenLabels().toJson());
        labels.add("townLabels", labelBook.getTownLabels().toJson());
        labels.add("townerLabels", labelBook.getTownerLabels().toJson());

        return new NaraLabelBookCdo(nara, metroType, title, labels);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
