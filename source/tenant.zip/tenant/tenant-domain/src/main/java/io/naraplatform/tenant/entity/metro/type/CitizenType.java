package io.naraplatform.tenant.entity.metro.type;

public enum CitizenType {
    //
    Resident,
    Visitant
}
