package io.naraplatform.tenant.spec.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownLabelBook;

public interface TownLabelBookService {
    //
    TownLabelBook findTownLabelBook(String townId);
    void modifyTownLabelBook(String townId, NameValueList nameValues);
}
