package io.naraplatform.tenant.entity.town;


import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TownerIdentity extends NaraEntity implements NaraAggregate {
    //
    private String usid;            // Unique in Metro
    private String name;
    private String title;
    private String nickname;
    private TownerState state;

    public TownerIdentity(String id,
                          String usid,
                          String name,
                          String title,
                          String nickname) {
        //
        super(id);
        this.usid = usid;
        this.name = name;
        this.title = title;
        this.nickname = nickname;
    }

    public static TownerIdentity sample() {
        //
        Towner towner = ActiveTowner.sample();
        return towner.getIdentity();
    }

    public static TownerIdentity fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownerIdentity.class);
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), getName());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
