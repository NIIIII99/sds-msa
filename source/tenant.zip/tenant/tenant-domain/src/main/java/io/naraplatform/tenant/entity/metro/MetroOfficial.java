package io.naraplatform.tenant.entity.metro;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/*
 * MetroOfficial should be a citizen
 *
 */

@Getter
@Setter
@NoArgsConstructor
public class MetroOfficial extends NaraEntity {
    //
    private String name;
    private Tier tier;
    private Contact contact;
    private long time;

    private String metroId;         // ==  Official book id

    public MetroOfficial(String id) {
        //
        super(id);
    }

    public MetroOfficial(Tier tier, Citizen citizen) {
        //
        super(citizen.getId());
        this.name = citizen.getIdName().getName();
        this.tier = tier;
        if(!citizen.hasContact()) {
            throw new IllegalArgumentException("Citizens who want to be a MetroOfficial need a contact.");
        }
        this.contact = citizen.getContact();
        this.time = System.currentTimeMillis();
    }

    public static MetroOfficial samplePrimary() {
        //
        Citizen citizen = Citizen.sample();
        return new MetroOfficial(Tier.Primary, citizen);
    }

    public static MetroOfficial sampleSecondary() {
        //
        Citizen citizen = Citizen.sample();
        return new MetroOfficial(Tier.Secondary, citizen);
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroOfficial fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroOfficial.class);
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), getName());
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "name":    // uniqueness check
                    this.name = value;
                    break;
                case "tier":    // uniqueness check
                    this.tier = Tier.valueOf(value);
                    break;
                case "contact":
                    this.contact = Contact.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not supported: " + nameValue);
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(samplePrimary());
    }
}
