package io.naraplatform.tenant.store.metro;

import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;

import java.util.List;

public interface MetroOfficialBookStore {
    //
    void create(MetroOfficialBook officialBook);
    MetroOfficialBook retrieve(String metroId);       // metroId == bookId
    void update(MetroOfficialBook officialBook);
    void delete(MetroOfficialBook officialBook);
    boolean exists(String metroId);

    void createMetroOfficial(MetroOfficial metroOfficial);
    MetroOfficial retrieveMetroOfficial(String officialId);
    List<MetroOfficial> retrieveMetroOfficialsByMetroId(String metroId);
    void updateMetroOfficial(MetroOfficial metroOfficial);
    void deleteMetroOfficial(MetroOfficial metroOfficial);
    void deleteMetroOfficials(List<String> officialIds);
    void deleteMetroOfficialsInMetro(String metroId);
    boolean existsMetroOfficialByCitizenId(String citizenId);
}
