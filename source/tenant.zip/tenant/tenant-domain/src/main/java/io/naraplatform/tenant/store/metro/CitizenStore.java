package io.naraplatform.tenant.store.metro;

import io.naraplatform.tenant.entity.metro.Citizen;

import java.util.List;

public interface CitizenStore {
    //
    void create(Citizen citizen);
    Citizen retrieve(String id);
    Citizen retrieveByMetroIdAndUsid(String metroId, String usid);
    List<Citizen> retrieveByMetroIdAndNameLike(String metroId, String nameLike);
    List<Citizen> retrieveByMetroId(String metroId, int offset, int limit);
    void update(Citizen citizen);
    void delete(Citizen citizen);
    void deleteByMetroId(String metroId);
    void deleteByCitizenIds(List<String> citizenIds);
    boolean existsByMetroIdAndUsid(String metroId, String usid);
    boolean existsByEmail(String email);
    long countByMetroId(String metroId);
}
