package io.naraplatform.tenant.entity.nara;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Nara extends NaraEntity implements NaraAggregate {
    //
    private String usid;                // Certified id when it certified as global
    private String name;
    private boolean certified;          // certified as a global Nara
    private long time;

    public Nara(String id) {
        //
        super(id);
    }

    public Nara(String usid, String name) {
        //
        super();
        this.usid = usid;
        this.name = name;
        this.certified = false;
        this.time = System.currentTimeMillis();
    }

    public String toString() {
        //
        return toJson();
    }

    public static Nara fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Nara.class);
    }

    public static Nara sample() {
        //
        return new Nara("AAA", "NaraPlatform");
    }

    public IdName getIdName() {
        //
        return new IdName(getUsid(), getName());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
