package io.naraplatform.tenant.entity.town.policy;

import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.domain.drama.NamingRule;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TownPolicy implements ValueObject {
    //
    private boolean townerInviteable;
    private NamingRule namingRule;

    public TownPolicy() {
        // default
        this.townerInviteable = false;
        this.namingRule = NamingRule.DisplayName;
    }

    public TownPolicy(boolean townerInviteable, NamingRule namingRule) {
        //
        this.townerInviteable = townerInviteable;
        this.namingRule = namingRule;
    }

    public static TownPolicy defaultPolicy() {
        //
        return new TownPolicy();
    }

    public static TownPolicy sample() {
        //
        boolean townerInviteable = true;
        return new TownPolicy(townerInviteable, NamingRule.Nickname);
    }

    public static TownPolicy fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownPolicy.class);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
