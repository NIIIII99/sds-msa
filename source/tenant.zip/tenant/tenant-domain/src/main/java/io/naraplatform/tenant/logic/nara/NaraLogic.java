package io.naraplatform.tenant.logic.nara;

import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.nara.Nara;
import io.naraplatform.tenant.spec.nara.NaraService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.nara.NaraStore;

import java.util.List;
import java.util.NoSuchElementException;

public class NaraLogic implements NaraService {
    //
    private NaraStore naraStore;

    public NaraLogic(TenantStoreLycler storeLycler) {
        //
        this.naraStore = storeLycler.requestNaraStore();
    }

    @Override
    public String registerNara(Nara nara) {
        //
        if (naraStore.existsByUsidOrName(nara.getUsid(), nara.getName())) {
            throw new AlreadyExistsException("Usid: " + nara.getUsid() + ", Name: " + nara.getName());
        }

        naraStore.create(nara);
        return nara.getId();
    }

    @Override
    public Nara findNara(String naraId) {
        //
        Nara nara = naraStore.retrieve(naraId);
        if (nara == null) {
            throw new NoSuchElementException("Nara id: " + naraId);
        }

        return nara;
    }

    @Override
    public Nara findNaraByUsid(String usid) {
        //
        Nara nara = naraStore.retrieveByUsid(usid);
        if(nara == null) {
            throw new NoSuchElementException("Nara usid: " + usid);
        }

        return nara;
    }

    @Override
    public List<Nara> findAllNaras() {
        //
        return naraStore.retrieveAll();
    }

    @Override
    public void modifyNaraName(String usid, String name) {
        //
        Nara nara = findNaraByUsid(usid);
        if (nara.getName().equals(name)) {
            return;
        }

        nara.setName(name);
        naraStore.update(nara);
    }

    @Override
    public void removeNara(String usid, String name) {
        //
        Nara nara = findNaraByUsid(usid);
        naraStore.delete(nara);
    }
}
