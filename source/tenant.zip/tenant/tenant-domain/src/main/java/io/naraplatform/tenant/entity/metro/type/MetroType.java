package io.naraplatform.tenant.entity.metro.type;

public enum MetroType {
    //
    Nara,
    Company,
    Government,
    School,
    Institute,
    Community,
    eCommerce
}
