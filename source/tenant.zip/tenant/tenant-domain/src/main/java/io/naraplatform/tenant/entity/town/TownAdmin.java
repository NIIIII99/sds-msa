package io.naraplatform.tenant.entity.town;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/*
 * TownAdmin does not have to be a towner, just a citizen
 */

@Getter
@Setter
@NoArgsConstructor
public class TownAdmin extends NaraEntity {
    //
    private IdName citizen;
    private Tier tier;
    private Contact contact;
    private String townId;          // town id == TownAdminBook id

    public TownAdmin(String id) {
        //
        super(id);
    }

    public TownAdmin(String townId, Tier tier, Citizen citizen) {
        //
        super();
        this.townId = townId;
        this.citizen = citizen.getIdName();
        this.tier = tier;
        if(citizen.getContact() == null) {
            //
            throw new IllegalArgumentException("Citizen's contact required.");
        }

        this.contact = citizen.getContact();
    }

    public static TownAdmin primary(String townId, Citizen citizen) {
        //
        return new TownAdmin(townId, Tier.Primary, citizen);
    }

    public static TownAdmin secondary(String townId, Citizen citizen) {
        //
        return new TownAdmin(townId, Tier.Secondary, citizen);
    }

    public String toString() {
        //
        return toJson();
    }

    public static TownAdmin fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownAdmin.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "tier":
                    this.tier = Tier.valueOf(value);
                    break;
                case "citizen":
                    this.citizen = IdName.fromJson(value);
                    break;
                case "contact":
                    this.contact = Contact.fromJson(value);
                    break;
            }
        }
    }

    public static TownAdmin sample() {
        //
        Town town = Town.sample();
        return TownAdmin.primary(town.getId(), Citizen.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
