package io.naraplatform.tenant.entity.metro;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.Nara;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.town.Town;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Metro extends NaraEntity implements NaraAggregate {
    //
    private List<String> supportLangs;      // index(0) is default language
    private IdName nara;                    // english name
    private MetroType type;
    private LangStrings names;
    private LangStrings memos;

    private String labelBookId;
    private String tinyAlbumId;             // depot's id
    private String profileId;               // company profile, institute profile, etc.
    private long time;

    transient private List<MetroRole> metroRoles;
    transient private MetroOfficialBook officialBook;

    transient private List<Town> towns;
    transient private List<Citizen> citizens;
    transient private List<OrgChart> orgCharts;

    public Metro(String id) {
        //
        super(id);
    }

    public Metro(List<String> supportLangs,
                 IdName nara,
                 LangStrings names,
                 MetroType type) {
        //
        super();
        this.supportLangs = names.getLangs();
        this.names = names;
        this.nara = nara;
        this.type = type;
        this.time = System.currentTimeMillis();
    }

    public static Metro sample() {
        //
        List<String> supprtLangs = Arrays.asList("ko", "en");
        IdName naraIdName = Nara.sample().getIdName();
        LangStrings names = LangStrings.newString("en", "Namoosori").addString("ko", "나무소리");

        Metro sample = new Metro(supprtLangs, naraIdName, names, MetroType.Company);

        return sample;
    }

    public static Metro fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Metro.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "names":
                    this.names = LangStrings.fromJson(value);
                    this.supportLangs = names.getLangs();
                    break;
                case "memo":
                    this.memos = LangStrings.fromJson(value);
                    break;
                case "tinyAlbumId":
                    this.tinyAlbumId = value;
                    break;
                case "profileId":
                    this.profileId = value;
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), getNames().getString());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
