package io.naraplatform.tenant.logic.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import io.naraplatform.tenant.spec.town.TownRoleBookService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.town.TownRoleBookStore;

public class TownRoleBookLogic implements TownRoleBookService {
    //
    private TownRoleBookStore roleBookStore;

    public TownRoleBookLogic(TenantStoreLycler storeLycler) {
        //
        this.roleBookStore = storeLycler.requestTownRoleBookStore();
    }

    @Override
    public TownRoleBook findTownRoleBook(String townId) {
        //
        TownRoleBook roleBook = roleBookStore.retrieve(townId);
        if(roleBook == null) {
            roleBook = TownRoleBook.defaultBook(townId);        // include adminRole and defaultUserRole
            roleBookStore.create(roleBook);
        }

        return roleBook;
    }

    @Override
    public void modifyTownRoleBook(String townId, NameValueList nameValues) {
        //
        TownRoleBook roleBook = roleBookStore.retrieve(townId);
        roleBook.setValues(nameValues);

        roleBookStore.update(roleBook);
    }
}
