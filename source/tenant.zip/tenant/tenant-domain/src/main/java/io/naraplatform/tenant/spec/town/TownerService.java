package io.naraplatform.tenant.spec.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.ActiveTowner;
import io.naraplatform.tenant.entity.town.DormantTowner;
import io.naraplatform.tenant.entity.town.TownerIdentity;

import java.util.List;

public interface TownerService {
    //
    String registerActiveTownerWithMember(String townId, String teamMemberId);
    String registerActiveTownerWithCitizen(String townId, String citizenId);
    ActiveTowner findActiveTowner(String townerId);
    ActiveTowner findActiveTownersByUsidInTown(String townId, String usid);
    List<ActiveTowner> findActiveTownersByNameLikeInTown(String townId, String nameLike);
    List<ActiveTowner> findActiveTownersInTown(String townId, int offset, int limit);
    void modifyActiveTowner(String townerId, NameValueList nameValues);
    void removeActiveTowner(String townerId);
    void removeActiveTownersInTown(String townId);
    void removeActiveTonwersByTonwerIds(List<String> townerIds);

    String makeDormantTowner(String activeTownerId, String reason);
    String makeActiveTowner(String townerId);
    DormantTowner findDormantTowner(String townerId);
    List<DormantTowner> findDormantTownersInTown(String townId, int offset, int limit);
    void removeDormantTowner(String townerId);
    void removeDormantTownersInTown(String townId);

    TownerIdentity findTownerIdentity(String townerId);
    List<TownerIdentity> findTownerIdentitiesInTown(String townId, int offset, int limit);
    void enforceRemoveTownerIdentity(String townerId);
}
