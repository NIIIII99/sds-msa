package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.domain.lang.LangNames;
import io.naraplatform.share.domain.nara.LoginUserInfo;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CitizenCdo implements JsonSerializable {
    //
    private String metroId;
    private String usid;
    private LangNames names;
    private Contact contact;
    private LoginUserInfo loginInfo;

    public CitizenCdo(String metroId,
                      String usid,
                      LangNames names,
                      Contact contact,
                      LoginUserInfo loginInfo) {
        //
        this.metroId = metroId;
        this.usid = usid;
        this.names = names;
        this.contact = contact;
        this.loginInfo = loginInfo;
    }

    public String toString() {
        //
        return toJson();
    }

    public static CitizenCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CitizenCdo.class);
    }

    public static CitizenCdo sample() {
        //
        Citizen citizen = Citizen.sample();
        return new CitizenCdo(
            citizen.getMetroId(),
            citizen.getUsid(),
            citizen.getNames(),
            citizen.getContact(),
            citizen.getLoginInfo()
        );
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
