package io.naraplatform.tenant.store.nara;

import io.naraplatform.tenant.entity.nara.Nara;

import java.util.List;

public interface NaraStore {
    //
    void create(Nara nara);
    Nara retrieve(String id);
    Nara retrieveByUsid(String usid);
    List<Nara> retrieveAll();
    void update(Nara nara);
    void delete(Nara nara);

    boolean existsByUsidOrName(String usid, String name);
}
