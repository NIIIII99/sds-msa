package io.naraplatform.tenant.store.town;

import io.naraplatform.tenant.entity.town.book.TownRoleBook;

public interface TownRoleBookStore {
    //
    void create(TownRoleBook roleBook);
    TownRoleBook retrieve(String townId);
    void update(TownRoleBook roleBook);
    void delete(TownRoleBook roleBook);
    boolean exists(String townId);
}
