package io.naraplatform.tenant.spec.orgchart.sdo;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TeamNodeCdo implements JsonSerializable {
    //
    private String parentId;            // if null, it's root node
    private LangStrings titles;

    public TeamNodeCdo(String parentId,
                       LangStrings titles) {
        //
        this.parentId = parentId;
        this.titles = titles;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TeamNodeCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TeamNodeCdo.class);
    }

    public static TeamNodeCdo sample() {
        //
        TeamNode node = TeamNode.sampleNode();

        return new TeamNodeCdo(
            node.getParentId(),
            node.getTitles()
        );
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
