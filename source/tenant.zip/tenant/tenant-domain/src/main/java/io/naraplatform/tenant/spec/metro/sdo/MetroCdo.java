package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class MetroCdo implements JsonSerializable {
    //
    private List<String> supportLangs;      // index(0) is default language
    private IdName nara;                    // english name
    private MetroType type;
    private LangStrings names;

    public MetroCdo(List<String> supportLangs,
                    IdName nara,
                    MetroType type,
                    LangStrings names) {
        //
        this.supportLangs = supportLangs;
        this.nara = nara;
        this.type = type;
        this.names = names;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroCdo.class);
    }

    public static MetroCdo sample() {
        //
        Metro metro = Metro.sample();

        return new MetroCdo(
            metro.getSupportLangs(),
            metro.getNara(),
            metro.getType(),
            metro.getNames());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
