package io.naraplatform.tenant.spec.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.spec.orgchart.sdo.OrgChartCdo;
import io.naraplatform.tenant.spec.orgchart.sdo.TeamNodeCdo;

import java.util.List;

public interface OrgChartService {
    //
    String registerOrgChart(OrgChartCdo orgChartCdo);
    OrgChart findOrgChart(String orgChartId);
    OrgChart findPrimaryOrgChartInMetro(String metroId);
    List<OrgChart> findOrgChartsInMetro(String metroId);
    void modifyOrgChart(String orgChartId, NameValueList nameValues);
    void removeOrgChart(String orgChartId);
    void forceRemoveOrgChart(String orgChartId);
    void removeOrgChartInMetro(String metroId);

    String addTeamNode(String orgChartId, TeamNodeCdo teamNodeCdo);
    TeamNode findRootNodeInOrgChart(String orgChartId);
    TeamNode findTeamNode(String nodeId);
    List<TeamNode> findTeamNodesInOrgChart(String orgChartId);
    void modifyTeamNode(String nodeId, NameValueList nameValues);
    void removeTeamNode(String nodeId);
    void removeTeamNodesInParent(String parentId);
    void removeTeamNodes(List<String> nodeIds);
}
