package io.naraplatform.tenant.entity.town.policy;

public enum TownType {
    //
    Project,
    Organization,
    Individual,
    Community,
    Shop,
    Family
}
