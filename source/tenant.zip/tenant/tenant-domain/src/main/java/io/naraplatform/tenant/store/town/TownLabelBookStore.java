package io.naraplatform.tenant.store.town;

import io.naraplatform.tenant.entity.town.book.TownLabelBook;

public interface TownLabelBookStore {
    //
    void create(TownLabelBook labelBook);
    TownLabelBook retrieve(String townId);
    void update(TownLabelBook labelBook);
    void delete(TownLabelBook labelBook);
    boolean exists(String townId);
}
