package io.naraplatform.tenant.store;

import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.metro.MetroOfficialBookStore;
import io.naraplatform.tenant.store.metro.MetroRoleBookStore;
import io.naraplatform.tenant.store.metro.MetroStore;
import io.naraplatform.tenant.store.nara.NaraLabelBookStore;
import io.naraplatform.tenant.store.nara.NaraStore;
import io.naraplatform.tenant.store.orgchart.OrgChartStore;
import io.naraplatform.tenant.store.orgchart.TeamStore;
import io.naraplatform.tenant.store.town.*;

public interface TenantStoreLycler {
    //
    NaraStore requestNaraStore();
    NaraLabelBookStore requestNaraLabelBookStore();
    MetroRoleBookStore requestMetroRoleBookStore();
    MetroOfficialBookStore requestMetroOfficialBookStore();
    MetroStore requestMetroStore();
    CitizenStore requestCitizenStore();
    OrgChartStore requestOrgChartStore();
    TeamStore requestTeamStore();
    TownStore requestTownStore();
    TownerStore requestTownerStore();
    TownAdminBookStore requestTownAdminBookStore();
    TownRoleBookStore requestTownRoleBookStore();
    TownLabelBookStore requestTownLabelBookStore();
}
