package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.MetroRole;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroRoleCdo implements JsonSerializable {
    //
    private int sequence;
    private String name;
    private String displayName;
    private String memo;

    public MetroRoleCdo(int sequence,
                        String name,
                        String displayName,
                        String memo) {
        //
        this.sequence = sequence;
        this.name = name;
        this.displayName = displayName;
        this.memo = memo;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroRoleCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroRoleCdo.class);
    }

    public static MetroRoleCdo sampleAdmin() {
        //
        MetroRole metroRole = MetroRole.sampleAdmin();
        return new MetroRoleCdo(
            metroRole.getSequence(),
            metroRole.getName(),
            metroRole.getDisplayName(),
            metroRole.getMemo());
    }

    public static MetroRoleCdo sampleBaseUser() {
        //
        MetroRole metroRole = MetroRole.sampleUser();
        return new MetroRoleCdo(
            metroRole.getSequence(),
            metroRole.getName(),
            metroRole.getDisplayName(),
            metroRole.getMemo());
    }

    public static void main(String[] args) {
        //
        System.out.println(sampleAdmin());
    }
}
