package io.naraplatform.tenant.entity.metro.book;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.entity.metro.MetroRole;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroRoleBook extends NaraEntity implements NaraAggregate {
    //
    private String metroName;
    private String adminRoleName;
    private String baseUserRoleName;

    public MetroRoleBook(String id) {
        //
        super(id);
    }

    public MetroRoleBook(IdName metro, MetroRole admin, MetroRole baseUserRole) {
        //
        super(metro.getId());
        this.metroName = metro.getName();
        this.adminRoleName = admin.getName();
        this.baseUserRoleName = baseUserRole.getName();
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroRoleBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroRoleBook.class);
    }

    public static MetroRoleBook sample() {
        //
        Metro metro = Metro.sample();
        MetroRole admin = MetroRole.sampleAdmin();
        MetroRole user = MetroRole.sampleUser();

        return new MetroRoleBook(metro.getIdName(), admin, user);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
