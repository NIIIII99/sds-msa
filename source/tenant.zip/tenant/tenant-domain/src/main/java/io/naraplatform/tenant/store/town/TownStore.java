package io.naraplatform.tenant.store.town;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;

import java.util.List;

public interface TownStore {
    //
    void create(Town town);
    Town retrieve(String id);
    List<Town> retrieveByMetroId(String metroId, int offset, int limit);
    void update(Town town);
    void delete(Town town);
    boolean existsByTitles(LangStrings titles);
}
