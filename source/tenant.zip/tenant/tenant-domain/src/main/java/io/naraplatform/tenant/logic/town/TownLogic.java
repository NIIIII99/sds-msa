package io.naraplatform.tenant.logic.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.spec.town.TownService;
import io.naraplatform.tenant.spec.town.sdo.TownCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.metro.MetroStore;
import io.naraplatform.tenant.store.orgchart.TeamStore;
import io.naraplatform.tenant.store.town.TownAdminBookStore;
import io.naraplatform.tenant.store.town.TownStore;
import io.naraplatform.tenant.store.town.TownerStore;

import java.util.List;
import java.util.NoSuchElementException;

public class TownLogic implements TownService {
    //
    private TownStore townStore;
    private TownerStore townerStore;
    private TeamStore teamStore;
    private CitizenStore citizenStore;
    private MetroStore metroStore;
    private TownAdminBookStore adminBookStore;

    public TownLogic(TenantStoreLycler storeLycler) {
        //
        this.townStore = storeLycler.requestTownStore();
        this.townerStore = storeLycler.requestTownerStore();
        this.teamStore = storeLycler.requestTeamStore();
        this.metroStore = storeLycler.requestMetroStore();
        this.citizenStore = storeLycler.requestCitizenStore();
        this.adminBookStore = storeLycler.requestTownAdminBookStore();
    }

    @Override
    public String buildTown(TownCdo townCdo) {
        //
        Metro metro = metroStore.retrieve(townCdo.getMetroId());
        Team team = teamStore.retrieve(townCdo.getTeamId());
        Citizen citizen = citizenStore.retrieve(townCdo.getAdminCitizenId());

        Town town = new Town(metro, team, townCdo.getType());
        TownAdminBook adminBook = new TownAdminBook(town.getIdName());
        TownAdmin admin = TownAdmin.primary(town.getId(), citizen);

        townStore.create(town);
        adminBookStore.create(adminBook);
        adminBookStore.createTownAdmin(admin);

        return town.getId();
    }

    @Override
    public Town findTown(String townId) {
        //
        Town town = townStore.retrieve(townId);
        if(town == null) {
            throw new NoSuchElementException("TownId: " + townId);
        }

        return town;
    }

    @Override
    public List<Town> finaTownsInMetro(String metroId, int offset, int limit) {
        //
        return townStore.retrieveByMetroId(metroId, offset, limit);
    }

    @Override
    public void modifyTown(String townId, NameValueList nameValues) {
        //
        Town town = findTown(townId);
        town.setValues(nameValues);

        townStore.update(town);
    }

    @Override
    public void removeTown(String townId) {
        //
        Town town = findTown(townId);
        townerStore.deleteActiveTownersByTownId(townId);
        townerStore.deleteDormantTownersByTownId(townId);
        townStore.delete(town);
    }

    @Override
    public boolean existsTownByTitles(LangStrings titles) {
        //
        return townStore.existsByTitles(titles);
    }
}
