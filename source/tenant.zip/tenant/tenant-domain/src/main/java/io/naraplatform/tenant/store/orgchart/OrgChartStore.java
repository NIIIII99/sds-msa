package io.naraplatform.tenant.store.orgchart;

import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;

import java.util.List;

public interface OrgChartStore {
    //
    void create(OrgChart orgChart);
    OrgChart retrieve(String id);
    List<OrgChart> retrieveByMetroId(String metroId);
    void update(OrgChart orgChart);
    void delete(OrgChart orgChart);
    void delete(String id);

    void createTeamNode(TeamNode node);
    TeamNode retrieveTeamNode(String nodeId);
    List<TeamNode> retrieveTeamNodesByParentId(String parentId);
    List<TeamNode> retrieveTeamNodesByOrgChartId(String orgChartId);
    void updateTeamNode(TeamNode teamNode);
    void updateTeamNodes(List<TeamNode> teamNodes);
    void deleteTeamNode(TeamNode teamNode);             // delete all children
    void deleteTeamNode(String nodeId);                 // delete all children
    void deleteTeamNodesByOrgChartId(String orgChartId);
    void deleteTeamNodesByParentId(String parentId);
    void deleteTeamNodeByOrgChartIdAndParentId(String orgChartId, String parentId);
    int countTeamNodesByOrgChartId(String orgChartId);
    int countTeamNodesByParentId(String parentId);
}
