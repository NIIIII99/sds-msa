package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialCdo implements JsonSerializable {
    //
    private String citizenId;            // citizen usid
    private Tier tier;

    public MetroOfficialCdo(String citizenId,
                            Tier tier) {
        //
        this.citizenId = citizenId;
        this.tier = tier;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroOfficialCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroOfficialCdo.class);
    }

    public static MetroOfficialCdo samplePrimaryOfficial() {
        //
        Citizen citizen = Citizen.sample();
        return new MetroOfficialCdo(citizen.getId(), Tier.Primary);
    }

    public static MetroOfficialCdo sampleSecondaryOfficial() {
        //
        Citizen citizen = Citizen.sample();
        return new MetroOfficialCdo(citizen.getId(), Tier.Secondary);
    }

    public static void main(String[] args) {
        //
        System.out.println(samplePrimaryOfficial());
    }
}
