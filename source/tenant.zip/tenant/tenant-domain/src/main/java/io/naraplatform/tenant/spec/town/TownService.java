package io.naraplatform.tenant.spec.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.spec.town.sdo.TownCdo;

import java.util.List;

public interface TownService {
    //
    String buildTown(TownCdo townCdo);
    Town findTown(String townId);
    List<Town> finaTownsInMetro(String metroId, int offset, int limit);
    void modifyTown(String townId, NameValueList nameValues);
    void removeTown(String townId);
    boolean existsTownByTitles(LangStrings titles);
}
