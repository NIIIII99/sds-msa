package io.naraplatform.tenant.logic.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.spec.orgchart.TeamService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.orgchart.OrgChartStore;
import io.naraplatform.tenant.store.orgchart.TeamStore;

import java.util.List;
import java.util.NoSuchElementException;

public class TeamLogic implements TeamService {
    //
    private TeamStore teamStore;
    private OrgChartStore orgChartStore;
    private CitizenStore citizenStore;

    public TeamLogic(TenantStoreLycler storeLycler) {
        //
        this.teamStore = storeLycler.requestTeamStore();
        this.orgChartStore = storeLycler.requestOrgChartStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public String buildTeam(String teamNodeId) {
        //
        TeamNode teamNode = orgChartStore.retrieveTeamNode(teamNodeId);
        if (teamNode == null) {
            throw new NoSuchElementException("TeamNodeId: " + teamNodeId);
        }

        Team team = new Team(teamNode);
        teamStore.create(team);

        return team.getId();
    }

    @Override
    public Team findTeam(String teamId) {
        //
        Team team = teamStore.retrieve(teamId);
        if(team == null) {
            throw new NoSuchElementException("TeamId: " + teamId);
        }

        return team;
    }

    @Override
    public List<Team> findChildTeams(String parentId) {
        //
        return teamStore.retrieveByParentId(parentId);
    }

    @Override
    public void modifyTeam(String teamId, NameValueList nameValues) {
        //
        Team team = findTeam(teamId);
        team.setValues(nameValues);

        teamStore.update(team);
    }

    @Override
    public void removeTeam(String teamId) {
        //
        Team team = findTeam(teamId);
        teamStore.deleteTeamMembersByTeamId(teamId);
        teamStore.delete(team);
    }

    @Override
    public int countTeamsInOrgChart(String orgChartId) {
        //
        return teamStore.count(orgChartId);
    }

    @Override
    public String addTeamMember(String teamId, String citizenId) {
        //
        Team team = findTeam(teamId);
        Citizen citizen = citizenStore.retrieve(citizenId);

        TeamMember member = new TeamMember(team, citizen);
        teamStore.createTeamMember(member);

        return member.getId();
    }

    @Override
    public void addTeamMembers(String teamId, List<String> citizenIds) {
        //
        Team team = findTeam(teamId);
        for(String citizenId : citizenIds) {
            if(teamStore.existsTeamMemberByTeamIdAndCitizenId(teamId, citizenId)) {
                continue;
            }
            Citizen citizen = citizenStore.retrieve(citizenId);
            TeamMember member = new TeamMember(team, citizen);
            teamStore.createTeamMember(member);
        }
    }

    @Override
    public TeamMember findTeamMember(String memberId) {
        //
        TeamMember member = teamStore.retrieveTeamMember(memberId);
        if(member == null) {
            throw new NoSuchElementException("MemberId: " + memberId);
        }

        return member;
    }

    @Override
    public List<TeamMember> findTeamMembersInTeam(String teamId, int offset, int limit) {
        //
        return teamStore.retrieveTeamMembersByTeamId(teamId, offset, limit);
    }

    @Override
    public void modifyTeamMember(String memberId, NameValueList nameValues) {
        //
        TeamMember member = findTeamMember(memberId);
        member.setValues(nameValues);

        teamStore.updateTeamMember(member);
    }

    @Override
    public void removeTeamMember(String memberId) {
        //
        TeamMember member = findTeamMember(memberId);
        teamStore.deleteTeamMember(member);
    }

    @Override
    public void removeTeamMembers(List<String> memberIds) {
        //
        for(String memberId : memberIds) {
            removeTeamMember(memberId);
        }
    }

    @Override
    public void removeTeamMembersInTeam(String teamId) {
        //
        teamStore.deleteTeamMembersByTeamId(teamId);
    }

    @Override
    public int countTeamMembersInTeam(String teamId) {
        //
        return teamStore.countTeamMembersByTeamId(teamId);
    }
}
