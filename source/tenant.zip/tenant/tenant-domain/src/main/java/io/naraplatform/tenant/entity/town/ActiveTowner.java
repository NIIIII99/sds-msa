package io.naraplatform.tenant.entity.town;


import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.drama.TownRole;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class ActiveTowner extends NaraEntity implements Towner, NaraAggregate {
    //
    private String usid;            // Unique in Metro
    private String name;
    private String title;
    private String nickname;
    private List<String> roleNames;
    private long time;

    private String citizenId;
    private String townId;

    public ActiveTowner(String id) {
        //
        super(id);
    }

    public ActiveTowner(Town town, Citizen citizen) {
        //
        this(town, citizen, Arrays.asList(TownRole.defaultUserRole().getKey()));
    }

    public ActiveTowner(Town town, Citizen citizen, List<String> roleNames) {
        //
        super();
        this.usid = citizen.getUsid();
        this.name = citizen.getNames().getFirstName(); //null; // citizen.getNames().getString(citizen.getNames().firstLang());
        this.title = citizen.getTitles().getString();
        this.nickname = citizen.getNickname();
        this.roleNames = roleNames;
        this.time = System.currentTimeMillis();
        this.citizenId = citizen.getId();
        this.townId = town.getId();
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "usid":
                    this.usid = value;
                    break;
                case "name":
                    this.name = value;
                    break;
                case "title":
                    this.title = value;
                    break;
                case "nickname":
                    this.nickname = value;
                    break;
                case "roleNames":
                    this.roleNames = JsonUtil.fromJsonList(value, String.class);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());

            }
        }
    }

    public static ActiveTowner sample() {
        //
        Town town = Town.sample();
        Citizen citizen = Citizen.sampleWithId(town.getMetroId());
        List<String> roles = Arrays.asList(TownRole.sample().getNames().getString());

        return new ActiveTowner(town, citizen, roles);
    }

    public static ActiveTowner fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ActiveTowner.class);
    }

    public IdName getIdName() {
        //
        return new IdName(getId(), getName());
    }

    @Override
    public TownerIdentity getIdentity() {
        //
        TownerIdentity townerIdentity = new TownerIdentity(
            getId(),
            usid,
            name,
            title,
            nickname
        );

        townerIdentity.setState(TownerState.Active);

        return townerIdentity;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
