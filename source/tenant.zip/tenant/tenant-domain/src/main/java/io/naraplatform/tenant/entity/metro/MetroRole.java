package io.naraplatform.tenant.entity.metro;

import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/*
 * This is for reference when you building TownRole
 */

@Getter
@Setter
@NoArgsConstructor
public class MetroRole extends NaraEntity {
    //
    private int sequence;
    private String name;            // unique in metro, English only (Admin)
    private String displayName;     // Local lang, 관리자
    private String memo;

    private String metroId;

    public MetroRole(String id) {
        //
        super(id);
    }

    public MetroRole(String metroId, int sequence, String name) {
        //
        this(metroId, sequence, name, name);
    }

    public MetroRole(String metroId, int sequence, String name, String displayName) {
        //
        super();
        this.metroId = metroId;
        this.sequence = sequence;
        this.name = name;
        this.displayName = displayName;
    }

    public static MetroRole sampleAdmin() {
        //
        String metroId = Metro.sample().getId();
        String adminRoleName = "Admin";
        String displayName = "관리자";
        return new MetroRole(metroId, 1, adminRoleName, displayName);
    }

    public static MetroRole sampleUser() {
        //
        String metroId = Metro.sample().getId();
        String baseUserRoleName = "User";
        String displayName = "사용자";
        MetroRole userRole = new MetroRole(metroId, 0, baseUserRoleName, displayName);

        return userRole;
    }

    public static MetroRole newRole(String metroId, int sequence, String roleName, String displayName) {
        //
        MetroRole role = new MetroRole(metroId, sequence, roleName, displayName);
        return role;
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "sequence":
                    this.sequence = Integer.parseInt(value);
                    break;
                case "name":    // uniqueness check
                    this.name = value;
                    break;
                case "displayName":    // uniqueness check
                    this.displayName = value;
                    break;
                case "memo":
                    this.memo = value;
                    break;
                default:
                    throw new IllegalArgumentException("Not supported: " + nameValue);
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sampleAdmin());
    }
}
