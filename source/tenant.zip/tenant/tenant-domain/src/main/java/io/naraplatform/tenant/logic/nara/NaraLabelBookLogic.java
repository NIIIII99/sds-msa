package io.naraplatform.tenant.logic.nara;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import io.naraplatform.tenant.spec.nara.NaraLabelBookService;
import io.naraplatform.tenant.spec.nara.sdo.NaraLabelBookCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.nara.NaraLabelBookStore;

import java.util.List;
import java.util.NoSuchElementException;

public class NaraLabelBookLogic implements NaraLabelBookService {
    //
    private NaraLabelBookStore labelBookStore;

    public NaraLabelBookLogic(TenantStoreLycler storeLycler) {
        //
        this.labelBookStore = storeLycler.requestNaraLabelBookStore();
    }

    @Override
    public String registerNaraLabelBook(NaraLabelBookCdo labelBookCdo) {
        //
        String title = labelBookCdo.getTitle();
        if(labelBookStore.existsByTitle(title)) {
            throw new IllegalArgumentException("Title duplication not allowed: " + title);
        }

        NaraLabelBook labelBook = new NaraLabelBook(
            labelBookCdo.getNara(),
            labelBookCdo.getMetroType(),
            title
        );

        labelBook.setValues(labelBookCdo.getLabels());

        labelBookStore.create(labelBook);
        return labelBook.getId();
    }

    @Override
    public NaraLabelBook findNaraLabelBook(String labelBookId) {
        //
        NaraLabelBook labelBook = labelBookStore.retrieve(labelBookId);
        if (labelBook == null) {
            throw new NoSuchElementException("NaraLabelBook id: " + labelBookId);
        }

        return labelBook;
    }

    @Override
    public List<NaraLabelBook> findNaraLabelBooksByNaraId(String naraId, int offset, int limit) {
        //
        return labelBookStore.retrieveByNaraId(naraId);
    }

    @Override
    public List<NaraLabelBook> findNaraLabelBooksByMetroType(MetroType metroType, int offset, int limit) {
        //
        return labelBookStore.retrieveByMetroType(metroType, offset, limit);
    }

    @Override
    public List<NaraLabelBook> findNaraLabelBooksByTitleLike(String titleLike, int offset, int limit) {
        //
        return labelBookStore.retrieveByTitleLike(titleLike, offset, limit);
    }

    @Override
    public void modifyNaraLabelBook(String labelBookId, NameValueList nameValues) {
        //
        NaraLabelBook labelBook = findNaraLabelBook(labelBookId);
        String title = nameValues.getValueOf("title");
        if(title != null) {
            NaraLabelBook naraLabelBook = labelBookStore.retrieveByTitle(title);
            if (naraLabelBook != null && naraLabelBook.getNara().getId() != labelBookId) {
                throw new AlreadyExistsException("The title is used by other: " +  title);
            }
        }

        labelBook.setValues(nameValues);
        labelBookStore.update(labelBook);
    }

    @Override
    public void removeNaraLabelBook(String labelBookId) {
        //
        NaraLabelBook labelBook = findNaraLabelBook(labelBookId);
        labelBookStore.delete(labelBook);
    }
}
