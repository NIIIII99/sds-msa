package io.naraplatform.tenant.store.nara;

import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;

import java.util.List;

public interface NaraLabelBookStore {
    //
    void create(NaraLabelBook naraLabelBook);
    NaraLabelBook retrieve(String id);
    NaraLabelBook retrieveByTitle(String title);
    List<NaraLabelBook> retrieveByNaraId(String naraId);
    List<NaraLabelBook> retrieveByMetroType(MetroType metroType, int offset, int limit);
    List<NaraLabelBook> retrieveByTitleLike(String titleLike, int offset, int limit);
    void update(NaraLabelBook naraLabelBook);
    void delete(NaraLabelBook naraLabelBook);
    boolean existsByTitle(String title);
}
