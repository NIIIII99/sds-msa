package io.naraplatform.tenant.entity.orgchart;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TeamMember extends NaraEntity {
    //
    private IdName citizen;
    private String title;               // optional

    private String teamId;
    private String orgChartId;

    public TeamMember(String id) {
        //
        super(id);
    }

    public TeamMember(Team team, Citizen citizen) {
        //
        super();
        this.citizen = citizen.getIdName();
        this.title = citizen.getTitles().getString();
        this.teamId = team.getId();
        this.orgChartId = team.getOrgChartId();
    }

    public static TeamMember sample() {
        //
        Team team = Team.sample();
        Citizen citizen = Citizen.sample();
        TeamMember sample = new TeamMember(team, citizen);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static TeamMember fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TeamMember.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "citizen":
                    this.citizen = IdName.fromJson(value);
                    break;
                case "title":
                    this.title = value;
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());

            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
