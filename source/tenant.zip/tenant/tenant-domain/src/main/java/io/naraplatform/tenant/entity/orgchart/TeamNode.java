package io.naraplatform.tenant.entity.orgchart;

import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TeamNode extends NaraEntity implements TreeNode {
    //
    private LangStrings titles;
    private String parentId;            // equals with orgChartId, it's root node
    private int levelSequence;
    private int childSequence;
    private String orgChartId;
    private long time;

    public TeamNode(String id) {
        //
        super(id);
    }

    public TeamNode(OrgChart orgChart) {
        // for root node
        this(orgChart.getId(), orgChart.getId(), 0, orgChart.getTitles());
    }

    public TeamNode(String orgChartId,
                    String parentId,
                    int levelSequence,
                    LangStrings titles) {
        //
        super();
        this.childSequence = 0;
        this.orgChartId = orgChartId;
        this.parentId = parentId;
        this.levelSequence = levelSequence;
        this.titles = titles;
        this.time = System.currentTimeMillis();
    }

    public String toString() {
        //
        return toJson();
    }

    public static TeamNode fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TeamNode.class);
    }

    public static TeamNode sampleRoot() {
        //
        return new TeamNode(OrgChart.sample());
    }

    public static TeamNode sampleNode() {
        //
        TeamNode rootNode = sampleRoot();
        return new TeamNode(
            rootNode.getOrgChartId(),
            rootNode.getId(),
            rootNode.getChildSequence(),
            LangStrings.newString("en", "RnD Lab").addString("ko", "연구소")
        );
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "titles":
                    titles = LangStrings.fromJson(value);
                    break;
                case "levelSequence":
                    this.levelSequence = Integer.valueOf(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
    }

    public int nextChildSequence() {
        //
        return childSequence++;
    }

    @Override
    public boolean isLeaf() {
        if (childSequence == 0) {
            return true;
        }

        return false;
    }

    @Override
    public boolean isRoot() {
        //
        if(parentId == null) {
            return true;
        }

        return false;
    }

    public static void main(String[] args) {
        //
        System.out.println(sampleRoot());
        System.out.println(sampleNode());
    }
}
