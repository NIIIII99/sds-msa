package io.naraplatform.tenant.spec.metro.sdo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialBookCdo implements JsonSerializable {
    //
    private IdName metro;
    private MetroOfficialCdo primaryOfficialCdo;

    public MetroOfficialBookCdo(IdName metro,
                                MetroOfficialCdo primaryOfficialCdo) {
        //
        this.metro = metro;
        this.primaryOfficialCdo = primaryOfficialCdo;
    }

    public String toString() {
        //
        return toJson();
    }

    public static MetroOfficialBookCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, MetroOfficialBookCdo.class);
    }

    public static MetroOfficialBookCdo sample() {
        //
        Metro metro = Metro.sample();
        MetroOfficialCdo primaryOfficialCdo = MetroOfficialCdo.samplePrimaryOfficial();

        return new MetroOfficialBookCdo(metro.getIdName(), primaryOfficialCdo);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
