package io.naraplatform.tenant.logic.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import io.naraplatform.tenant.entity.town.*;
import io.naraplatform.tenant.spec.town.TownerService;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.orgchart.TeamStore;
import io.naraplatform.tenant.store.town.TownStore;
import io.naraplatform.tenant.store.town.TownerStore;

import java.util.List;
import java.util.NoSuchElementException;

public class TownerLogic implements TownerService {
    //
    private TownStore townStore;
    private TownerStore townerStore;
    private TeamStore teamStore;
    private CitizenStore citizenStore;

    public TownerLogic(TenantStoreLycler storeLycler) {
        //
        this.townStore = storeLycler.requestTownStore();
        this.townerStore = storeLycler.requestTownerStore();
        this.teamStore = storeLycler.requestTeamStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public String registerActiveTownerWithMember(String townId, String memberId) {
        //
        Town town = townStore.retrieve(townId);
        TeamMember member = teamStore.retrieveTeamMember(memberId);
        Citizen citizen = citizenStore.retrieve(member.getCitizen().getId());

        ActiveTowner towner = new ActiveTowner(town, citizen);
        townerStore.create(towner);
        townerStore.create(towner.getIdentity());

        return towner.getId();
    }

    @Override
    public String registerActiveTownerWithCitizen(String townId, String citizenId) {
        //
        Town town = townStore.retrieve(townId);
        Citizen citizen = citizenStore.retrieve(citizenId);

        ActiveTowner towner = new ActiveTowner(town, citizen);
        townerStore.create(towner);
        townerStore.create(towner.getIdentity());

        return towner.getId();
    }

    @Override
    public ActiveTowner findActiveTowner(String townerId) {
        //
        return townerStore.retrieveActiveTowner(townerId);
    }

    @Override
    public ActiveTowner findActiveTownersByUsidInTown(String townId, String usid) {
        //
        return townerStore.retrieveActiveTownerByTownIdAndUsid(townId, usid);
    }

    @Override
    public List<ActiveTowner> findActiveTownersByNameLikeInTown(String townId, String nameLike) {
        //
        return townerStore.retrieveActiveTownerByTownIdAndNameLike(townId, nameLike);
    }

    @Override
    public List<ActiveTowner> findActiveTownersInTown(String townId, int offset, int limit) {
        //
        return townerStore.retrieveActiveTownerByTownId(townId, offset, limit);
    }

    @Override
    public void modifyActiveTowner(String townerId, NameValueList nameValues) {
        //
        ActiveTowner towner = findActiveTowner(townerId);
        towner.setValues(nameValues);
        townerStore.updateActiveTowner(towner);
    }

    @Override
    public void removeActiveTowner(String townerId) {
        //
        ActiveTowner towner = findActiveTowner(townerId);
        this.removeActiveTowner(towner);
    }

    private void removeActiveTowner(ActiveTowner towner) {
        //
        TownerIdentity identity = townerStore.retrieveIdentity(towner.getId());
        identity.setState(TownerState.Removed);
        townerStore.updateIdentity(identity);
        townerStore.deleteActiveTowner(towner);
    }

    @Override
    public void removeActiveTownersInTown(String townId) {
        //
        int offset = 0;
        int limit = 1000;
        while(true) {
            List<ActiveTowner> towners = townerStore.retrieveActiveTownerByTownId(townId, offset, limit);
            if(towners.size() == 0) {
                break;
            }
            for(ActiveTowner towner : towners) {
                this.removeActiveTowner(towner);
            }

            offset += limit;
        }
    }

    @Override
    public void removeActiveTonwersByTonwerIds(List<String> townerIds) {
        //
        for(String townerId : townerIds) {
            removeActiveTowner(townerId);
        }
    }

    @Override
    public String makeDormantTowner(String activeTownerId, String reason) {
        //
        ActiveTowner activeTowner = townerStore.retrieveActiveTowner(activeTownerId);
        DormantTowner dormantTowner = new DormantTowner(activeTowner, reason);
        TownerIdentity identity = townerStore.retrieveIdentity(activeTownerId);
        identity.setState(TownerState.Dormanted);
        townerStore.create(dormantTowner);
        townerStore.updateIdentity(identity);
        townerStore.deleteActiveTowner(activeTowner);

        return dormantTowner.getId();
    }

    @Override
    public String makeActiveTowner(String dormantTownerId) {
        //
        DormantTowner dormantTowner = townerStore.retrieveDormantTowner(dormantTownerId);
        ActiveTowner activeTowner = dormantTowner.activate();
        TownerIdentity identity = townerStore.retrieveIdentity(dormantTownerId);
        identity.setState(TownerState.Active);

        townerStore.create(activeTowner);
        townerStore.updateIdentity(identity);
        townerStore.deleteDormantTowner(dormantTowner);

        return activeTowner.getId();
    }

    @Override
    public DormantTowner findDormantTowner(String townerId) {
        //
        DormantTowner towner = townerStore.retrieveDormantTowner(townerId);
        if (towner == null) {
            throw new NoSuchElementException("DormantTownerId: " + townerId);
        }

        return towner;
    }

    @Override
    public List<DormantTowner> findDormantTownersInTown(String townId, int offset, int limit) {
        //
        return townerStore.retrieveDormantTownerByTownId(townId, offset, limit);
    }

    @Override
    public void removeDormantTowner(String dormantTownerId) {
        //
        DormantTowner dormantTowner = findDormantTowner(dormantTownerId);
        this.removeDormantTowner(dormantTowner);
    }

    private void removeDormantTowner(DormantTowner dormantTowner) {
        //
        TownerIdentity identity = townerStore.retrieveIdentity(dormantTowner.getId());
        identity.setState(TownerState.Removed);

        townerStore.updateIdentity(identity);
        townerStore.deleteDormantTowner(dormantTowner);
    }

    @Override
    public void removeDormantTownersInTown(String townId) {
        //
        int offset = 0;
        int limit = 1000;
        while(true) {
            List<DormantTowner> towners = townerStore.retrieveDormantTownerByTownId(townId, offset, limit);
            if(towners.size() == 0) {
                break;
            }
            for(DormantTowner towner : towners) {
                this.removeDormantTowner(towner);
            }

            offset += limit;
        }
    }

    @Override
    public TownerIdentity findTownerIdentity(String townerId) {
        //
        TownerIdentity identity = townerStore.retrieveIdentity(townerId);
        if(identity == null) {
            throw new NoSuchElementException("TownerId: " + townerId);
        }

        return identity;
    }

    @Override
    public List<TownerIdentity> findTownerIdentitiesInTown(String townId, int offset, int limit) {
        //
        return townerStore.retrieveIdentitiesByTownId(townId, offset, limit);
    }

    @Override
    public void enforceRemoveTownerIdentity(String townerId) {
        //
        townerStore.deleteIdentity(townerId);
    }
}
