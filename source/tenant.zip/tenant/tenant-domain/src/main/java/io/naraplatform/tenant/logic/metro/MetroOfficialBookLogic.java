package io.naraplatform.tenant.logic.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.spec.metro.MetroOfficialBookService;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialCdo;
import io.naraplatform.tenant.store.TenantStoreLycler;
import io.naraplatform.tenant.store.metro.CitizenStore;
import io.naraplatform.tenant.store.metro.MetroOfficialBookStore;

import java.util.List;
import java.util.NoSuchElementException;

public class MetroOfficialBookLogic implements MetroOfficialBookService {
    //
    private MetroOfficialBookStore officialBookStore;
    private CitizenStore citizenStore;

    public MetroOfficialBookLogic(TenantStoreLycler storeLycler) {
        //
        this.officialBookStore = storeLycler.requestMetroOfficialBookStore();
        this.citizenStore = storeLycler.requestCitizenStore();
    }

    @Override
    public String registerMetroOfficialBook(MetroOfficialBookCdo metroOfficialBookCdo) {
        //
        String metroId = metroOfficialBookCdo.getMetro().getId();
        MetroOfficialBook officialBook = officialBookStore.retrieve(metroId);
        if (officialBook != null) {
            throw new AlreadyExistsException("MetroOfficialBook for metro: " + metroId);
        }

        MetroOfficialCdo primaryOfficialCdo = metroOfficialBookCdo.getPrimaryOfficialCdo();
        Citizen citizen = citizenStore.retrieve(primaryOfficialCdo.getCitizenId());
        if(citizen == null) {
            throw new NoSuchElementException("CitizenId: " + primaryOfficialCdo.getCitizenId());
        }

        MetroOfficial primaryOfficial = new MetroOfficial(primaryOfficialCdo.getTier(), citizen);

        officialBook = new MetroOfficialBook(
            metroOfficialBookCdo.getMetro(),
            primaryOfficial
        );

        officialBookStore.create(officialBook);
        officialBookStore.createMetroOfficial(primaryOfficial);

        return officialBook.getId();
    }

    @Override
    public MetroOfficialBook findMetroOfficialBook(String metroId) {
        //
        MetroOfficialBook officialBook = officialBookStore.retrieve(metroId);
        if (officialBook == null) {
            throw new NoSuchElementException("MetroOfficialBook for metro: " + metroId);
        }

        return officialBook;
    }

    @Override
    public void removeMetroOfficialBook(String metroId) {
        //
        MetroOfficialBook officialBook = officialBookStore.retrieve(metroId);
        officialBookStore.deleteMetroOfficialsInMetro(metroId);
        officialBookStore.delete(officialBook);
    }

    @Override
    public String addMetroOfficial(String metroId, MetroOfficialCdo metroOfficialCdo) {
        //
        String citizenId = metroOfficialCdo.getCitizenId();
        if (officialBookStore.existsMetroOfficialByCitizenId(citizenId)) {
            throw new AlreadyExistsException("The citizen already exists as MetroOfficial: " + citizenId);
        }

        Citizen citizen = citizenStore.retrieve(citizenId);
        MetroOfficial metroOfficial = new MetroOfficial(
            metroOfficialCdo.getTier(),
            citizen
        );

        officialBookStore.createMetroOfficial(metroOfficial);

        return metroOfficial.getId();
    }

    @Override
    public List<MetroOfficial> findMetroOfficialsInMetro(String metroId) {
        //
        return officialBookStore.retrieveMetroOfficialsByMetroId(metroId);
    }

    @Override
    public MetroOfficial findMetroOfficial(String officialId) {
        //
        MetroOfficial official = officialBookStore.retrieveMetroOfficial(officialId);
        if(official == null) {
            throw new NoSuchElementException("No such a official: " + officialId);
        }

        return official;
    }

    @Override
    public void modifyMetroOfficial(String officialId, NameValueList nameValues) {
        //
        MetroOfficial official = findMetroOfficial(officialId);
        official.setValues(nameValues);

        officialBookStore.updateMetroOfficial(official);
    }

    @Override
    public void removeMetroOfficials(List<String> officialIds) {
        //
        officialBookStore.deleteMetroOfficials(officialIds);
    }
}
