package io.naraplatform.tenant.entity.nara;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Shared label among metros, you can create any number of label books as you wish.
 **/
@Getter
@Setter
@NoArgsConstructor
public class NaraLabelBook extends NaraEntity implements NaraAggregate {
    //
    private IdName nara;
    private MetroType metroType;
    private String title;                   // unique
    private LangStrings metroLabels;
    private LangStrings citizenLabels;
    private LangStrings townLabels;
    private LangStrings townerLabels;

    public NaraLabelBook(String id) {
        //
        super(id);
    }

    public NaraLabelBook(IdName nara, MetroType metroType, String title) {
        //
        super();
        this.nara = nara;
        this.metroType = metroType;
        this.title = title;
    }

    public String toString() {
        //
        return toJson();
    }

    public static NaraLabelBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, NaraLabelBook.class);
    }

    public static NaraLabelBook companySample() {
        //
        IdName nara = Nara.sample().getIdName();
        String title = "CompanyLabel";
        NaraLabelBook companySample = new NaraLabelBook(nara, MetroType.Company, title);

        companySample.setMetroLabels(LangStrings.newString("en", "Company").addString("ko", "회사"));
        companySample.setCitizenLabels(LangStrings.newString("en", "Employee").addString("ko", "임직원"));
        companySample.setTownLabels(LangStrings.newString("en", "TeamNode").addString("ko", "팀"));
        companySample.setTownerLabels(LangStrings.newString("en", "TeamMember").addString("ko", "팀원"));

        return companySample;
    }

    public static NaraLabelBook naraSample() {
        //
        IdName nara = Nara.sample().getIdName();
        String title = "NaraLabel";

        NaraLabelBook naraSample = new NaraLabelBook(nara, MetroType.Nara, title);

        naraSample.setMetroLabels(LangStrings.newString("en", "Metro").addString("ko", "메트로"));
        naraSample.setCitizenLabels(LangStrings.newString("en", "Citizen").addString("ko", "시민"));
        naraSample.setTownLabels(LangStrings.newString("en", "Town").addString("ko", "타운"));
        naraSample.setTownerLabels(LangStrings.newString("en", "ActiveTowner").addString("ko", "타우너"));

        return naraSample;
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            if(value == null) continue;
            switch(nameValue.getName()) {
                case "metroType":
                    this.metroType = MetroType.valueOf(value);
                    break;
                case "title":
                    // need to do uniqueness check
                    this.title = value;
                    break;
                case "metroLabels":
                    this.metroLabels = LangStrings.fromJson(value);
                    break;
                case "citizenLabels":
                    this.citizenLabels = LangStrings.fromJson(value);
                    break;
                case "townLabels":
                    this.townLabels = LangStrings.fromJson(value);
                    break;
                case "townerLabels":
                    this.townerLabels = LangStrings.fromJson(value);
                    break;

                default:
                    throw new IllegalArgumentException("Invalid field name: " + nameValue.getName());

            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(naraSample());
        System.out.println(companySample());
    }
}
