package io.naraplatform.tenant.entity.town.book;

import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.drama.TownRole;
import io.naraplatform.share.domain.drama.TownRoleList;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TownRoleBook extends NaraEntity implements NaraAggregate {
    //
    private TownRole adminRole;
    private TownRole defaultUserRole;
    private TownRoleList additionalRoles;           //

    public TownRoleBook(String id) {
        //
        super(id);
    }

    private TownRoleBook(String townId, TownRole adminRole, TownRole defaultUserRole) {
        //
        super(townId);
        this.adminRole = adminRole;
        this.defaultUserRole = defaultUserRole;
        this.additionalRoles = new TownRoleList();
    }

    public static TownRoleBook defaultBook(String townId) {
        //
        TownRole adminRole = TownRole.adminRole();
        TownRole defaultUserRole = TownRole.defaultUserRole();

        TownRoleBook roleBook = new TownRoleBook(townId, adminRole, defaultUserRole);

        return roleBook;
    }

    public String toString() {
        //
        return toJson();
    }

    public static TownRoleBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownRoleBook.class);
    }

    public static TownRoleBook sample() {
        //
        return defaultBook(Metro.sample().getId());
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "adminRole":
                    this.adminRole = TownRole.fromJson(value);
                    break;
                case "defaultUserRole":
                    this.defaultUserRole = TownRole.fromJson(value);
                    break;
                case "additionalRoles":
                    this.additionalRoles = TownRoleList.fromJson(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
