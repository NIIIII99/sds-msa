package io.naraplatform.tenant.spec.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleCdo;

import java.util.List;

public interface MetroRoleBookService {
    //
    String registerMetroRoleBook(MetroRoleBookCdo metroRoleBookCdo);
    MetroRoleBook findMetroRoleBook(String metroId);
    void removeMetroRoleBook(String metroId);

    String addMetroRole(String metroId, MetroRoleCdo metroRoleCdo);
    List<MetroRole> findMetroRolesByMetroId(String metroId);
    MetroRole findMetroRole(String roleId);
    void modifyMetroRole(String roleId, NameValueList nameValues);
    void removeMetroRoles(List<String> roleIds);
    void removeMetroRole(String metroId, String roleName);
}
