package io.naraplatform.tenant.spec.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;

import java.util.List;

public interface TownAdminBookService {
    //
    TownAdminBook findTownAdminBook(String townId);

    String addTownAdmin(String townId, String citizenId, Tier tier);
    List<TownAdmin> findTownAdminsInTown(String townId);
    TownAdmin findTownAdmin(String adminId);
    void modifyTownAdmin(String adminId, NameValueList nameValues);
    void removeTownAdmins(List<String> adminIds);
}
