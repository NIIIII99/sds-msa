package io.naraplatform.tenant.store.town;

import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;

import java.util.List;

public interface TownAdminBookStore {
    //
    void create(TownAdminBook adminBook);
    TownAdminBook retrieve(String townId);       // townId == bookId
    void update(TownAdminBook adminBook);
    void delete(TownAdminBook adminBook);
    boolean exists(String townId);

    void createTownAdmin(TownAdmin admin);
    TownAdmin retrieveTownAdmin(String adminId);
    List<TownAdmin> retrieveTownAdminsByTownId(String townId);
    void updateTownAdmin(TownAdmin admin);
    void deleteTownAdmin(TownAdmin admin);
    void deleteTownAdmins(List<String> adminIds);
    void deleteTownAdminsByTownId(String townId);
    boolean existsTownAdminByCitizenId(String citizenId);
}
