package io.naraplatform.tenant.entity.orgchart;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class OrgChart extends NaraEntity implements NaraAggregate {
    //
    private LangStrings titles;
    private String baseLang;        // "ko", "en", etc
    private Tier tier;
    private long time;
    private String metroId;

    transient private TeamNode rootNode;

    public OrgChart(String id) {
        //
        super(id);
    }

    public OrgChart(String metroId, LangStrings titles, Tier tier) {
        //
        super();
        this.titles = titles;
        this.metroId = metroId;
        this.tier = tier;
        this.baseLang = titles.getLangs().get(0);
        this.time = System.currentTimeMillis();
    }

    public static OrgChart sample() {
        //
        String companyId = UUID.randomUUID().toString();
        LangStrings titles = LangStrings.newString("en","OrgChart for NEXTREE").addString("ko", "넥스트리조직도");

        OrgChart sample = new OrgChart(companyId, titles, Tier.Primary);

        return sample;
    }

    public static OrgChart fromJson(String json) {
        //
        return JsonUtil.fromJson(json, OrgChart.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "titles":
                    this.titles = LangStrings.fromJson(value);
                    break;
                case "tier":
                    this.tier = Tier.valueOf(value);
                    break;
                default:
                    throw new IllegalArgumentException("Not updateable: " + nameValue.getName());
            }
        }
    }

    public IdName getIdName() {
        //
        return  new IdName(getId(), titles.getString());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
