package io.naraplatform.tenant.entity.town.book;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.TownAdmin;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class TownAdminBook extends NaraEntity implements NaraAggregate {
    //
    private String townName;
    private boolean singleAdmin;        //

    transient private List<TownAdmin> admins;

    public TownAdminBook(String id) {
        //
        super(id);
    }

    public TownAdminBook(IdName town) {
        //
        super(town.getId());         // same id with metro
        this.townName = town.getName();
    }

    public String toString() {
        //
        return toJson();
    }

    public static TownAdminBook fromJson(String json) {
        //
        return JsonUtil.fromJson(json, TownAdminBook.class);
    }

    public static TownAdminBook sample() {
        //
        Town town = Town.sample();
        return new TownAdminBook(town.getIdName());
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            if (value == null) {
                continue;
            }
            switch(nameValue.getName()) {
                case "townName":
                    this.townName = value;
                    break;
                case "singleAdmin":
                    this.singleAdmin = Boolean.parseBoolean(value);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid attribute: " + nameValue);
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
