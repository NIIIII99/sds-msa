package io.naraplatform.tenant.entity.town;

public enum TownerState {
    //
    Active,
    Dormanted,
    Removed
}
