package io.naraplatform.tenant.spec.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialCdo;

import java.util.List;

public interface MetroOfficialBookService {
    //
    String registerMetroOfficialBook(MetroOfficialBookCdo metroOfficialBookCdo);
    MetroOfficialBook findMetroOfficialBook(String metroId);
    void removeMetroOfficialBook(String metroId);

    String addMetroOfficial(String metroId, MetroOfficialCdo metroOfficialCdo);
    List<MetroOfficial> findMetroOfficialsInMetro(String metroId);
    MetroOfficial findMetroOfficial(String officialId);
    void modifyMetroOfficial(String officialId, NameValueList nameValues);
    void removeMetroOfficials(List<String> officialIds);
}
