package io.naraplatform.tenant.rest.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.ActiveTowner;
import io.naraplatform.tenant.entity.town.DormantTowner;
import io.naraplatform.tenant.entity.town.TownerIdentity;
import io.naraplatform.tenant.spec.town.TownerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TownerResource implements TownerService {
    //
    @Autowired
    TownerService townerService;

    @Override
    @PostMapping(value = "/town/{townId}/member/{memberId}")
    public String registerActiveTownerWithMember(@PathVariable(name = "townId") String townId, @PathVariable(name = "memberId") String teamMemberId) {
        //
        return townerService.registerActiveTownerWithMember(townId, teamMemberId);
    }

    @Override
    @PostMapping(value = "/town/{townId}/citizen/{citizenId}")
    public String registerActiveTownerWithCitizen(@PathVariable(name = "townId") String townId, @PathVariable(name = "citizenId") String citizenId) {
        //
        return townerService.registerActiveTownerWithCitizen(townId, citizenId);
    }

    @Override
    @GetMapping(value = "/town/towner/{townerId}")
    public ActiveTowner findActiveTowner(@PathVariable(name = "townerId") String townerId) {
        //
        return townerService.findActiveTowner(townerId);
    }

    @Override
    @GetMapping(value = "/town/{townId}/usis/{usid}")
    public ActiveTowner findActiveTownersByUsidInTown(@PathVariable(name = "townId") String townId, @PathVariable(name = "usid") String usid) {
        //
        return townerService.findActiveTownersByUsidInTown(townId, usid);
    }

    @Override
    @GetMapping(value = "/town/{townId}/name/{nameLike}")
    public List<ActiveTowner> findActiveTownersByNameLikeInTown(@PathVariable(name = "townId") String townId, @PathVariable(name = "nameLike") String nameLike) {
        //
        return townerService.findActiveTownersByNameLikeInTown(townId, nameLike);
    }

    @Override
    @GetMapping(value = "/town/{townId}/towner")
    public List<ActiveTowner> findActiveTownersInTown(@PathVariable(name = "townId") String townId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return townerService.findActiveTownersInTown(townId, offset, limit);
    }

    @Override
    @PutMapping(value = "/town/towner/{townerId}/active")
    public void modifyActiveTowner(@PathVariable(name = "townerId") String townerId, @RequestBody NameValueList nameValues) {
        //
        townerService.modifyActiveTowner(townerId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/town/towner/{townerId}/active")
    public void removeActiveTowner(@PathVariable(name = "townerId") String townerId) {
        //
        townerService.removeActiveTowner(townerId);
    }

    @Override
    @DeleteMapping(value = "/town/{townId}/towner/active")
    public void removeActiveTownersInTown(@PathVariable(name = "townId") String townId) {
        //
        townerService.removeActiveTownersInTown(townId);
    }

    @Override
    public void removeActiveTonwersByTonwerIds(List<String> townerIds) {
        //
    }

    @Override
    @PutMapping(value = "/town/towner/{townerId}/dormant/reason")
    public String makeDormantTowner(@PathVariable(name = "townerId") String activeTownerId, @RequestParam(name = "reason") String reason) {
        //
        return townerService.makeDormantTowner(activeTownerId, reason);
    }

    @Override
    @PutMapping(value = "/town/towner/{townerId}/activate")
    public String makeActiveTowner(@PathVariable(name = "townerId") String townerId) {
        //
        return townerService.makeActiveTowner(townerId);
    }

    @Override
    @GetMapping(value = "/town/towner/{townerId}/dormant")
    public DormantTowner findDormantTowner(@PathVariable(name = "townerId") String townerId) {
        //
        return townerService.findDormantTowner(townerId);
    }

    @Override
    @GetMapping(value = "/town/{townId}/towner/dormant")
    public List<DormantTowner> findDormantTownersInTown(@PathVariable(name = "townId") String townId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return townerService.findDormantTownersInTown(townId, offset, limit);
    }

    @Override
    @DeleteMapping(value = "/town/towner/{townerId}/dormant")
    public void removeDormantTowner(@PathVariable(name = "townerId") String townerId) {
        //
        townerService.removeDormantTowner(townerId);
    }

    @Override
    @DeleteMapping(value = "/town/{townId}/dormant")
    public void removeDormantTownersInTown(@PathVariable(name = "townId") String townId) {
        //
        townerService.removeDormantTownersInTown(townId);
    }

    @Override
    @GetMapping(value = "/town/towner/identity/{townerId}")
    public TownerIdentity findTownerIdentity(@PathVariable(name = "townerId") String townerId) {
        //
        return townerService.findTownerIdentity(townerId);
    }

    @Override
    @GetMapping(value = "/town/{townId}/identity")
    public List<TownerIdentity> findTownerIdentitiesInTown(@PathVariable(name = "townId") String townId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return townerService.findTownerIdentitiesInTown(townId, offset, limit);
    }

    @Override
    @DeleteMapping(value = "/town/towner/{townerId}/force")
    public void enforceRemoveTownerIdentity(@PathVariable(name = "townerId") String townerId) {
        //
        townerService.enforceRemoveTownerIdentity(townerId);
    }
}
