package io.naraplatform.tenant.rest.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import io.naraplatform.tenant.spec.town.TownRoleBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class TownRoleBookResource implements TownRoleBookService {
    //
    @Autowired
    TownRoleBookService townRoleBookService;

    @Override
    @GetMapping(value = "/town/{townId}/book/role")
    public TownRoleBook findTownRoleBook(@PathVariable(name = "townId") String townId) {
        //
        return townRoleBookService.findTownRoleBook(townId);
    }

    @Override
    @PutMapping(value = "/town/{townId}/book/role")
    public void modifyTownRoleBook(@PathVariable(name = "townId") String townId, @RequestBody NameValueList nameValues) {
        //
        townRoleBookService.modifyTownRoleBook(townId, nameValues);
    }
}
