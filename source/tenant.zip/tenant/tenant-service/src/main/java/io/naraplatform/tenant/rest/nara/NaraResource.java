package io.naraplatform.tenant.rest.nara;

import io.naraplatform.tenant.entity.nara.Nara;
import io.naraplatform.tenant.spec.nara.NaraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/nara")
public class NaraResource implements NaraService {
    //
    @Autowired
    NaraService naraService;

    @Override
    @PostMapping(value = {"", "/"})
    public String registerNara(@RequestBody Nara nara) {
        //
        return naraService.registerNara(nara);
    }

    @Override
    @GetMapping(value = "/{naraId}")
    public Nara findNara(@PathVariable(name = "naraId") String naraId) {
        //
        return naraService.findNara(naraId);
    }

    @Override
    @GetMapping(value = "/")
    public Nara findNaraByUsid(@RequestParam(name = "usid") String usid) {
        //
        return naraService.findNaraByUsid(usid);
    }

    @Override
    @GetMapping(value = {"", "/"})
    public List<Nara> findAllNaras() {
        //
        return naraService.findAllNaras();
    }

    @Override
    @PutMapping(value = "/{usid}/{name}")
    public void modifyNaraName(@PathVariable(name="usid") String usid, @PathVariable(name="name") String name) {
        //
        naraService.modifyNaraName(usid, name);
    }

    @Override
    @DeleteMapping(value = "/{usid}/{name}")
    public void removeNara(@PathVariable(name="usid") String usid, @PathVariable(name="name") String name) {
        //
        naraService.removeNara(usid, name);
    }
}
