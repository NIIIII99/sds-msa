package io.naraplatform.tenant.rest.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.spec.metro.MetroService;
import io.naraplatform.tenant.spec.metro.sdo.MetroCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/metro")
public class MetroResource implements MetroService {
    //
    @Autowired
    MetroService metroService;

    @Override
    @PostMapping(value = {"", "/"})
    public String buildMetro(@RequestBody MetroCdo metroCdo) {
        //
        return metroService.buildMetro(metroCdo);
    }

    @Override
    @GetMapping(value = "/{metroId}")
    public Metro findMetro(@PathVariable(name = "metroId") String metroId) {
        //
        return metroService.findMetro(metroId);
    }

    @Override
    @GetMapping(value = "/nara/{naraId}")
    public List<Metro> finaMetrosInNara(@PathVariable(name = "naraId") String naraId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return metroService.finaMetrosInNara(naraId, offset, limit);
    }

    @Override
    @PutMapping(value = "/{metroId}")
    public void modifyMetro(@PathVariable(name = "metroId") String metroId, @RequestBody NameValueList nameValues) {
        //
        metroService.modifyMetro(metroId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/{metroId}")
    public void removeMetro(@PathVariable(name = "metroId") String metroId) {
        //
        metroService.removeMetro(metroId);
    }

    @Override
    @DeleteMapping(value = "/{metroId}/force")
    public void forceRemoveMetro(@PathVariable(name = "metroId") String metroId) {
        //
        metroService.forceRemoveMetro(metroId);
    }

    @Override
    @PostMapping(value = "/exists/name")
    public boolean existsMetroByNames(@RequestBody LangStrings names) {
        //
        return metroService.existsMetroByNames(names);
    }
}
