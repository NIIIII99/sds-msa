package io.naraplatform.tenant.rest.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.spec.metro.MetroOfficialBookService;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroOfficialCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/official")
public class MetroOfficialBookResource implements MetroOfficialBookService {
    //
    @Autowired
    MetroOfficialBookService metroOfficialBookService;

    @Override
    @PostMapping(value = {"/book", "/book/"})
    public String registerMetroOfficialBook(@RequestBody MetroOfficialBookCdo metroOfficialBookCdo) {
        //
        return metroOfficialBookService.registerMetroOfficialBook(metroOfficialBookCdo);
    }

    @Override
    @GetMapping(value = "/book/metro/{metroId}")
    public MetroOfficialBook findMetroOfficialBook(@PathVariable(name = "metroId") String metroId) {
        //
        return metroOfficialBookService.findMetroOfficialBook(metroId);
    }

    @Override
    @DeleteMapping(value = "/book/metro/{metroId}")
    public void removeMetroOfficialBook(@PathVariable(name = "metroId") String metroId) {
        //
        metroOfficialBookService.removeMetroOfficialBook(metroId);
    }

    @Override
    @PostMapping(value = "/metro/{metroId}")
    public String addMetroOfficial(@PathVariable(name = "metroId") String metroId, @RequestBody MetroOfficialCdo metroOfficialCdo) {
        //
        return metroOfficialBookService.addMetroOfficial(metroId, metroOfficialCdo);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}/officials")
    public List<MetroOfficial> findMetroOfficialsInMetro(@PathVariable(name = "metroId") String metroId) {
        //
        return metroOfficialBookService.findMetroOfficialsInMetro(metroId);
    }

    @Override
    @GetMapping(value = "/{officialId}")
    public MetroOfficial findMetroOfficial(@PathVariable(name = "officialId") String officialId) {
        //
        return metroOfficialBookService.findMetroOfficial(officialId);
    }

    @Override
    @PutMapping(value = "/{officialId}")
    public void modifyMetroOfficial(@PathVariable(name = "officialId") String officialId, @RequestBody NameValueList nameValues) {
        //
        metroOfficialBookService.modifyMetroOfficial(officialId, nameValues);
    }

    @Override
    public void removeMetroOfficials(List<String> officialIds) {
        //
    }
}
