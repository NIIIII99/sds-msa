package io.naraplatform.tenant.rest.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import io.naraplatform.tenant.spec.metro.MetroRoleBookService;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleBookCdo;
import io.naraplatform.tenant.spec.metro.sdo.MetroRoleCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping()
public class MetroRoleBookResource implements MetroRoleBookService {
    //
    @Autowired
    MetroRoleBookService metroRoleBookService;

    @Override
    @PostMapping(value = "/rolebook")
    public String registerMetroRoleBook(@RequestBody MetroRoleBookCdo metroRoleBookCdo) {
        //
        return metroRoleBookService.registerMetroRoleBook(metroRoleBookCdo);
    }

    @Override
    @GetMapping(value = {"/rolebook/metro/{metroId}"})
    public MetroRoleBook findMetroRoleBook(@PathVariable(name = "metroId") String metroId) {
        //
        return metroRoleBookService.findMetroRoleBook(metroId);
    }

    @Override
    @DeleteMapping(value = {"/rolebook/metro/{metroId}"})
    public void removeMetroRoleBook(@PathVariable(name = "metroId") String metroId) {
        //
        metroRoleBookService.removeMetroRoleBook(metroId);
    }

    @Override
    @PostMapping(value = "/role/metro/{metroId}")
    public String addMetroRole(@PathVariable(name = "metroId") String metroId, @RequestBody MetroRoleCdo metroRoleCdo) {
        //
        return metroRoleBookService.addMetroRole(metroId, metroRoleCdo);
    }

    @Override
    @GetMapping(value = "/role/metro/{metroId}")
    public List<MetroRole> findMetroRolesByMetroId(@PathVariable(name = "metroId") String metroId) {
        //
        return metroRoleBookService.findMetroRolesByMetroId(metroId);
    }

    @Override
    @GetMapping(value = "/role/{roleId}")
    public MetroRole findMetroRole(@PathVariable(name = "roleId") String roleId) {
        //
        return metroRoleBookService.findMetroRole(roleId);
    }

    @Override
    @PutMapping(value = "/role/{roleId}")
    public void modifyMetroRole(@PathVariable(name = "roleId") String roleId, @RequestBody NameValueList nameValues) {
        //
        metroRoleBookService.modifyMetroRole(roleId, nameValues);
    }

    @Override
    public void removeMetroRoles(List<String> roleIds) {
        //
    }

    @Override
    @DeleteMapping(value = "/role/metro/{metroId}/name/{roleName}")
    public void removeMetroRole(@PathVariable(name = "metroId") String metroId, @PathVariable(name = "roleName") String roleName) {
        //
        metroRoleBookService.removeMetroRole(metroId, roleName);
    }
}
