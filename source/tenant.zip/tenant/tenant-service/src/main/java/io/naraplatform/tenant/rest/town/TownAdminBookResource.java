package io.naraplatform.tenant.rest.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.spec.town.TownAdminBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TownAdminBookResource implements TownAdminBookService {
    //
    @Autowired
    TownAdminBookService townAdminBookService;

    @Override
    @GetMapping(value = "/town/{townId}/book")
    public TownAdminBook findTownAdminBook(@PathVariable(name = "townId") String townId) {
        //
        return townAdminBookService.findTownAdminBook(townId);
    }

    @Override
    @PostMapping(value = "/town/{townId}/admin")
    public String addTownAdmin(@PathVariable(name = "townId") String townId, @RequestParam(name = "citizenId") String citizenId, @RequestParam(name = "tier") Tier tier) {
        //
        return townAdminBookService.addTownAdmin(townId, citizenId, tier);
    }

    @Override
    @GetMapping(value = "/town/{townId}/admin")
    public List<TownAdmin> findTownAdminsInTown(@PathVariable(name = "townId") String townId) {
        //
        return townAdminBookService.findTownAdminsInTown(townId);
    }

    @Override
    @GetMapping(value = "/town/admin/{adminId}")
    public TownAdmin findTownAdmin(@PathVariable(name = "adminId") String adminId) {
        //
        return townAdminBookService.findTownAdmin(adminId);
    }

    @Override
    @PutMapping(value = "/town/admin/{adminId}")
    public void modifyTownAdmin(@PathVariable(name = "adminId") String adminId, @RequestBody NameValueList nameValues) {
        //
        townAdminBookService.modifyTownAdmin(adminId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/town/admin")
    public void removeTownAdmins(@RequestBody List<String> adminIds) {
        //
        townAdminBookService.removeTownAdmins(adminIds);
    }
}
