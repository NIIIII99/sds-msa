package io.naraplatform.tenant.rest.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import io.naraplatform.tenant.spec.town.TownLabelBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class TownLabelBookResource implements TownLabelBookService {
    //
    @Autowired
    TownLabelBookService townLabelBookService;

    @Override
    @GetMapping(value = "/town/{townId}/book/label")
    public TownLabelBook findTownLabelBook(@PathVariable(name = "townId") String townId) {
        //
        return townLabelBookService.findTownLabelBook(townId);
    }

    @Override
    @PutMapping(value = "/town/{townId}/book/label")
    public void modifyTownLabelBook(@PathVariable(name = "townId") String townId, @RequestBody NameValueList nameValues) {
        //
        townLabelBookService.modifyTownLabelBook(townId, nameValues);
    }
}
