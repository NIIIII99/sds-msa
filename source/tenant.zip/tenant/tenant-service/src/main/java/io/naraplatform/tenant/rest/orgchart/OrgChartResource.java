package io.naraplatform.tenant.rest.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.spec.orgchart.OrgChartService;
import io.naraplatform.tenant.spec.orgchart.sdo.OrgChartCdo;
import io.naraplatform.tenant.spec.orgchart.sdo.TeamNodeCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/orgchart")
public class OrgChartResource implements OrgChartService {
    //
    @Autowired
    OrgChartService orgChartService;

    @Override
    @PostMapping(value = {"", "/"})
    public String registerOrgChart(OrgChartCdo orgChartCdo) {
        //
        return orgChartService.registerOrgChart(orgChartCdo);
    }

    @Override
    @GetMapping(value = "/{orgChartId}")
    public OrgChart findOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        return orgChartService.findOrgChart(orgChartId);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}/primary")
    public OrgChart findPrimaryOrgChartInMetro(@PathVariable(name = "metroId") String metroId) {
        //
        return orgChartService.findPrimaryOrgChartInMetro(metroId);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}")
    public List<OrgChart> findOrgChartsInMetro(@PathVariable(name = "metroId") String metroId) {
        //
        return orgChartService.findOrgChartsInMetro(metroId);
    }

    @Override
    @PutMapping(value = "/{orgChartId}")
    public void modifyOrgChart(@PathVariable(name = "orgChartId") String orgChartId, @RequestBody NameValueList nameValues) {
        //
        orgChartService.modifyOrgChart(orgChartId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/{orgChartId}")
    public void removeOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        orgChartService.removeOrgChart(orgChartId);
    }

    @Override
    @DeleteMapping(value = "/{orgChartId}/force")
    public void forceRemoveOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        orgChartService.forceRemoveOrgChart(orgChartId);
    }

    @Override
    @DeleteMapping(value = "/metro/{metroId}")
    public void removeOrgChartInMetro(@PathVariable(name = "metroId") String metroId) {
        //
        orgChartService.removeOrgChartInMetro(metroId);
    }

    @Override
    @PostMapping(value = "/{orgChartId}/node")
    public String addTeamNode(@PathVariable(name = "orgChartId") String orgChartId, @RequestBody TeamNodeCdo teamNodeCdo) {
        //
        return orgChartService.addTeamNode(orgChartId, teamNodeCdo);
    }

    @Override
    @GetMapping(value = "/{orgChartId}/node/root")
    public TeamNode findRootNodeInOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        return orgChartService.findRootNodeInOrgChart(orgChartId);
    }

    @Override
    @GetMapping(value = "/node/{nodeId}")
    public TeamNode findTeamNode(@PathVariable(name = "nodeId") String nodeId) {
        //
        return orgChartService.findTeamNode(nodeId);
    }

    @Override
    @GetMapping(value = "/{orgChartId}/node")
    public List<TeamNode> findTeamNodesInOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        return orgChartService.findTeamNodesInOrgChart(orgChartId);
    }

    @Override
    @PutMapping(value = "/node/{nodeId}")
    public void modifyTeamNode(@PathVariable(name = "nodeId") String nodeId, @RequestBody NameValueList nameValues) {
        //
        orgChartService.modifyTeamNode(nodeId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/node/{nodeId}")
    public void removeTeamNode(@PathVariable(name = "nodeId") String nodeId) {
        //
        orgChartService.removeTeamNode(nodeId);
    }

    @Override
    @DeleteMapping(value = "/node/parent/{parentId}")
    public void removeTeamNodesInParent(@PathVariable(name = "parentId") String parentId) {
        //
        orgChartService.removeTeamNodesInParent(parentId);
    }

    @Override
    public void removeTeamNodes(List<String> nodeIds) {
        //
    }
}
