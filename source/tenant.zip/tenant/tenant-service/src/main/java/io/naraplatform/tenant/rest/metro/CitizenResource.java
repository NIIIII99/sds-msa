package io.naraplatform.tenant.rest.metro;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.spec.metro.CitizenService;
import io.naraplatform.tenant.spec.metro.sdo.CitizenCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/citizen")
public class CitizenResource implements CitizenService {
    //
    @Autowired
    CitizenService citizenService;

    @Override
    @PostMapping(value = {"", "/"})
    public String registerCitizen(@RequestBody CitizenCdo citizenCdo) {
        //
        return citizenService.registerCitizen(citizenCdo);
    }

    @Override
    @GetMapping(value = "/{citizenId}")
    public Citizen findCitizen(@PathVariable(name = "citizenId") String citizenId) {
        //
        return citizenService.findCitizen(citizenId);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}/{usid}")
    public Citizen findCitizenByUsidInMetro(@PathVariable(name = "metroId") String metroId, @PathVariable(name = "usid") String usid) {
        //
        return citizenService.findCitizenByUsidInMetro(metroId, usid);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}/name/{nameLike}")
    public List<Citizen> findCitizensByNameLikeInMetro(@PathVariable(name = "metroId") String metroId, @PathVariable(name = "nameLike") String nameLike) {
        //
        return citizenService.findCitizensByNameLikeInMetro(metroId, nameLike);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}")
    public List<Citizen> findCitizensInMetro(@PathVariable(name = "metroId") String metroId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return citizenService.findCitizensInMetro(metroId, offset, limit);
    }

    @Override
    @PutMapping(value = "/{citizenId}")
    public void modifyCitizen(@PathVariable(name = "citizenId") String citizenId, @RequestBody NameValueList nameValues) {
        //
        citizenService.modifyCitizen(citizenId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/{citizenId}")
    public void removeCitizen(@PathVariable(name = "citizenId") String citizenId) {
        //
        citizenService.removeCitizen(citizenId);
    }

    @Override
    @DeleteMapping(value = "/metro/{metroId}")
    public void removeCitizensInMetro(String metroId) {
        //
        citizenService.removeCitizensInMetro(metroId);
    }

    @Override
    public void removeCitizensByCitizenIds(List<String> citizenIds) {
        //
    }
}
