package io.naraplatform.tenant.rest.nara;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import io.naraplatform.tenant.spec.nara.NaraLabelBookService;
import io.naraplatform.tenant.spec.nara.sdo.NaraLabelBookCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/labelbook")
public class NaraLabelBookResoure implements NaraLabelBookService {
    //
    @Autowired
    NaraLabelBookService naraLabelBookService;

    @Override
    @PostMapping(value = {"", "/"})
    public String registerNaraLabelBook(@RequestBody NaraLabelBookCdo labelBookCdo) {
        //
        return naraLabelBookService.registerNaraLabelBook(labelBookCdo);
    }

    @Override
    @GetMapping(value = {"/{labelBookId}"})
    public NaraLabelBook findNaraLabelBook(@PathVariable(name = "labelBookId") String labelBookId) {
        //
        return naraLabelBookService.findNaraLabelBook(labelBookId);
    }

    @Override
    @GetMapping(value = "/nara/{naraId}")
    public List<NaraLabelBook> findNaraLabelBooksByNaraId(@PathVariable(name = "naraId") String naraId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return naraLabelBookService.findNaraLabelBooksByNaraId(naraId, offset, limit);
    }

    @Override
    @GetMapping(value = "/nara/type/{metroType}")
    public List<NaraLabelBook> findNaraLabelBooksByMetroType(@PathVariable(name = "metroType") MetroType metroType, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return naraLabelBookService.findNaraLabelBooksByMetroType(metroType, offset, limit);
    }

    @Override
    @GetMapping(value = "/nara/title/{titleLike}")
    public List<NaraLabelBook> findNaraLabelBooksByTitleLike(@PathVariable(name = "titleLike") String titleLike, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return naraLabelBookService.findNaraLabelBooksByTitleLike(titleLike, offset, limit);
    }

    @Override
    @PutMapping(value = "/{labelBookId}")
    public void modifyNaraLabelBook(@PathVariable(name = "labelBookId") String labelBookId, @RequestBody NameValueList nameValues) {
        //
        naraLabelBookService.modifyNaraLabelBook(labelBookId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/{labelBookId}")
    public void removeNaraLabelBook(String labelBookId) {
        //
        naraLabelBookService.removeNaraLabelBook(labelBookId);
    }
}
