package io.naraplatform.tenant.rest.town;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.spec.town.TownService;
import io.naraplatform.tenant.spec.town.sdo.TownCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TownResource implements TownService {
    //
    @Autowired
    TownService townService;

    @Override
    @PostMapping(value = {"/town"})
    public String buildTown(@RequestBody TownCdo townCdo) {
        //
        return townService.buildTown(townCdo);
    }

    @Override
    @GetMapping(value = "/town/{townId}")
    public Town findTown(@PathVariable(name = "townId") String townId) {
        //
        return townService.findTown(townId);
    }

    @Override
    @GetMapping(value = "/metro/{metroId}/town")
    public List<Town> finaTownsInMetro(@PathVariable(name = "metroId") String metroId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return townService.finaTownsInMetro(metroId, offset, limit);
    }

    @Override
    @PutMapping(value = "/town/{townId}")
    public void modifyTown(@PathVariable(name = "townId") String townId, @RequestBody NameValueList nameValues) {
        //
        townService.modifyTown(townId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/town/{townId}")
    public void removeTown(@PathVariable(name = "townId") String townId) {
        //
        townService.removeTown(townId);
    }

    @Override
    @PostMapping(value = "/town/exists")
    public boolean existsTownByTitles(@RequestBody LangStrings titles) {
        //
        return townService.existsTownByTitles(titles);
    }
}
