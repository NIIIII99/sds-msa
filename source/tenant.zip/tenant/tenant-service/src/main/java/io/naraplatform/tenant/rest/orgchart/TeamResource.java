package io.naraplatform.tenant.rest.orgchart;

import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import io.naraplatform.tenant.spec.orgchart.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(name = "team")
public class TeamResource implements TeamService {
    //
    @Autowired
    TeamService teamService;

    @Override
    @PostMapping(value = {"", "/"})
    public String buildTeam(@RequestBody String teamNodeId) {
        //
        return teamService.buildTeam(teamNodeId);
    }

    @Override
    @GetMapping(value = "/{teamId}")
    public Team findTeam(@PathVariable(name = "teamId") String teamId) {
        //
        return teamService.findTeam(teamId);
    }

    @Override
    @GetMapping(value = "/parent/{parentId}")
    public List<Team> findChildTeams(@PathVariable(name = "parentId") String parentId) {
        //
        return teamService.findChildTeams(parentId);
    }

    @Override
    @PutMapping(value = "/{teamId}")
    public void modifyTeam(@PathVariable(name = "teamId") String teamId, @RequestBody NameValueList nameValues) {
        //
        teamService.modifyTeam(teamId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/{teamId}")
    public void removeTeam(@PathVariable(name = "teamId") String teamId) {
        //
        teamService.removeTeam(teamId);
    }

    @Override
    @GetMapping(value = "/orgChart/{orgChartId}/count")
    public int countTeamsInOrgChart(@PathVariable(name = "orgChartId") String orgChartId) {
        //
        return teamService.countTeamsInOrgChart(orgChartId);
    }

    @Override
    @PostMapping(value = "/{teamId}/{citizenId}")
    public String addTeamMember(@PathVariable(name = "teamId") String teamId, @PathVariable(name = "citizenId") String citizenId) {
        //
        return teamService.addTeamMember(teamId, citizenId);
    }

    @Override
    public void addTeamMembers(String teamId, List<String> citizenIds) {
        //
    }

    @Override
    @GetMapping(value = "/member/{memberId}")
    public TeamMember findTeamMember(@PathVariable(name = "memberId") String memberId) {
        //
        return teamService.findTeamMember(memberId);
    }

    @Override
    @GetMapping(value = "/member/team/{teamId}")
    public List<TeamMember> findTeamMembersInTeam(@PathVariable(name = "teamId") String teamId, @RequestParam(name = "offset") int offset, @RequestParam(name = "limit") int limit) {
        //
        return teamService.findTeamMembersInTeam(teamId, offset, limit);
    }

    @Override
    @PutMapping(value = "/member/{memberId}")
    public void modifyTeamMember(@PathVariable(name = "memberId") String memberId, @RequestBody NameValueList nameValues) {
        //
        teamService.modifyTeamMember(memberId, nameValues);
    }

    @Override
    @DeleteMapping(value = "/member/{memberId}")
    public void removeTeamMember(@PathVariable(name = "memberId") String memberId) {
        //
        teamService.removeTeamMember(memberId);
    }

    @Override
    public void removeTeamMembers(List<String> memberIds) {
        //
    }

    @Override
    @DeleteMapping(value = "/member/team/{teamId}")
    public void removeTeamMembersInTeam(@PathVariable(name = "teamId") String teamId) {
        //
        teamService.removeTeamMembersInTeam(teamId);
    }

    @Override
    @GetMapping(value = "/member/team/{teamId}/count")
    public int countTeamMembersInTeam(@PathVariable(name = "teamId") String teamId) {
        //
        return teamService.countTeamMembersInTeam(teamId);
    }
}
