package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("citizen_by_email")
@Getter
@Setter
@NoArgsConstructor
public class CitizenByEmailCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "email", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String email;
    @PrimaryKeyColumn(name = "citizenId", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String citizenId;
    private String json;

    public CitizenByEmailCmo(Citizen citizen) {
        //
        this.email = citizen.getContact().getEmail();
        this.citizenId = citizen.getId();
        this.json = citizen.toJson();
    }

    public Citizen toDomain() {
        //
        return Citizen.fromJson(json);
    }
}
