package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.Town;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_by_metroId")
@Getter
@Setter
@NoArgsConstructor
public class TownByMetroIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "metroId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String metroId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;


    public TownByMetroIdCmo(Town town) {
        //
        this.metroId = town.getMetroId();
        this.id = town.getId();
        this.json = town.toJson();

    }

    public Town toDomain() {
        //
        return Town.fromJson(json);
    }
}
