package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("org_chart")
@Getter
@Setter
@NoArgsConstructor
public class OrgChartCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String json;

    public OrgChartCmo(OrgChart orgChart) {
        //
        this.id = orgChart.getId();
        this.json = orgChart.toJson();
    }

    public OrgChart toDomain() {
        //
        return OrgChart.fromJson(this.json);
    }
}
