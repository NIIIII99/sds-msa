package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroByLangNameCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.Collection;
import java.util.List;

public interface MetroByLangNameRepository extends CassandraRepository<MetroByLangNameCmo, String> {
    //
    List<MetroByLangNameCmo> findAllByNameIn(Collection<String> names, Pageable pageable);
}
