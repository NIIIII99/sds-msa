package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleByMetroIdAndNameCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;
import java.util.Optional;

public interface MetroRoleByMetroIdAndNameRepository extends CassandraRepository<MetroRoleByMetroIdAndNameCmo, String> {
    //
    void deleteAllByMetroId(String metroId);
    List<MetroRoleByMetroIdAndNameCmo> findAllByMetroId(String metroId);
    Optional<MetroRoleByMetroIdAndNameCmo> findByMetroIdAndName(String metroId, String name);
}
