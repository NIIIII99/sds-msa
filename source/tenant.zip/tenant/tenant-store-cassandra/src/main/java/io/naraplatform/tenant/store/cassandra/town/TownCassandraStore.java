package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.share.domain.lang.LangString;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownByLangTitleCmo;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownByMetroIdCmo;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownCmo;
import io.naraplatform.tenant.store.cassandra.town.repository.TownByLangTitleRepository;
import io.naraplatform.tenant.store.cassandra.town.repository.TownByMetroIdRepository;
import io.naraplatform.tenant.store.cassandra.town.repository.TownRepository;
import io.naraplatform.tenant.store.town.TownStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class TownCassandraStore implements TownStore {
    //
    @Autowired
    TownRepository townRepository;
    @Autowired
    TownByMetroIdRepository townByMetroIdRepository;
    @Autowired
    TownByLangTitleRepository townByLangTitleRepository;

    @Override
    public void create(Town town) {
        //
        townRepository.save(new TownCmo(town));
        townByMetroIdRepository.save(new TownByMetroIdCmo(town));
        town.getTitles().getList().stream()
            .forEach((title) -> {
                townByLangTitleRepository.save(new TownByLangTitleCmo(title.getLang(), town));
            });
    }

    @Override
    public Town retrieve(String id) {
        //
        Optional<TownCmo> townCmo = townRepository.findById(id);
        if (!townCmo.isPresent()) {
            throw new NoSuchElementException(String.format("Town(%s) is not found.", id));
        }

        return townCmo.get().toDomain();
    }

    @Override
    public List<Town> retrieveByMetroId(String metroId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<TownByMetroIdCmo> townByMetroIdCmos = townByMetroIdRepository.findAllByMetroId(metroId, pageable);
        return townByMetroIdCmos.stream()
            .map(TownByMetroIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(Town town) {
        //
        townRepository.save(new TownCmo(town));
        townByMetroIdRepository.save(new TownByMetroIdCmo(town));
        town.getTitles().getList().stream()
            .forEach((title) -> {
                townByLangTitleRepository.save(new TownByLangTitleCmo(title.getLang(), town));
            });
    }

    @Override
    public void delete(Town town) {
        //
        townRepository.delete(new TownCmo(town));
        townByMetroIdRepository.delete(new TownByMetroIdCmo(town));
        town.getTitles().getList().stream()
            .forEach((title) -> {
                townByLangTitleRepository.delete(new TownByLangTitleCmo(title.getLang(), town));
            });
    }

    @Override
    public boolean existsByTitles(LangStrings titles) {
        //
        for (LangString title: titles.list()) {
            int count = townByLangTitleRepository.findAllByTitleAndLangCode(title.getString(), title.getLang()).size();
            if (count > 0) {
                return true;
            }
        }

        return false;
    }
}
