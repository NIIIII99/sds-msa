package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroByLangNameCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroByNaraCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroCmo;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroByLangNameRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroByNaraRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroRepository;
import io.naraplatform.tenant.store.metro.MetroStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class MetroCassandraStore implements MetroStore {
    //
    @Autowired
    MetroRepository metroRepository;
    @Autowired
    MetroByNaraRepository metroByNaraRepository;
    @Autowired
    MetroByLangNameRepository metroByLangNameRepository;

    @Override
    public void create(Metro metro) {
        //
        metroRepository.save(new MetroCmo(metro));

        metroByNaraRepository.save(new MetroByNaraCmo(metro));
        metro.getNames().list().stream()
            .map(name -> new MetroByLangNameCmo(name.getLang(), metro))
            .forEach(rom -> metroByLangNameRepository.save(rom));
    }

    @Override
    public Metro retrieve(String id) {
        //
        Optional<MetroCmo> metroCmo = metroRepository.findById(id);
        if (!metroCmo.isPresent()) {
            throw new NoSuchElementException(String.format("Metro(%s) is not found.", id));
        }

        return metroCmo.get().toDomain();
    }

    @Override
    public List<Metro> retrieveByNaraId(String naraId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<MetroByNaraCmo> metroByNaraCmos = metroByNaraRepository.findAllByNaraId(naraId, pageable);
        return metroByNaraCmos.stream()
            .map(MetroByNaraCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(Metro metro) {
        //
        metroRepository.save(new MetroCmo(metro));

        metroByNaraRepository.save(new MetroByNaraCmo(metro));
        metro.getNames().list().stream()
            .map(name -> new MetroByLangNameCmo(name.getLang(), metro))
            .forEach(rom -> metroByLangNameRepository.save(rom));
    }

    @Override
    public void delete(Metro metro) {
        //
        metroRepository.delete(new MetroCmo(metro));

        metroByNaraRepository.delete(new MetroByNaraCmo(metro));
        metro.getNames().list().stream()
            .map(name -> new MetroByLangNameCmo(name.getLang(), metro))
            .forEach(rom -> metroByLangNameRepository.delete(rom));
    }

    @Override
    public boolean existsByNames(LangStrings names) {
        //
        Pageable pageable = PageRequest.of(1, 1);
        List<MetroByLangNameCmo> metroByLangNameCmos = metroByLangNameRepository.findAllByNameIn(names.getStrings(), pageable);

        return metroByLangNameCmos.size() > 0;
    }
}
