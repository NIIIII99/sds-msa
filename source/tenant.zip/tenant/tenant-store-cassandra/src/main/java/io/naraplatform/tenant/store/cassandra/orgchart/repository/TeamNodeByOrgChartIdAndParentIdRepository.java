package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamNodeByOrgChartIdAndParentIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TeamNodeByOrgChartIdAndParentIdRepository extends CassandraRepository<TeamNodeByOrgChartIdAndParentIdCmo, String> {
    //
    List<TeamNodeByOrgChartIdAndParentIdCmo> findAllByOrgChartId(String orgChartId);
    List<TeamNodeByOrgChartIdAndParentIdCmo> findAllByOrgChartIdAndParentId(String orgChartId, String parentId);
}
