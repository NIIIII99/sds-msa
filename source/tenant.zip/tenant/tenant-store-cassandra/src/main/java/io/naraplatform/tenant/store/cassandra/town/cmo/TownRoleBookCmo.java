package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.domain.drama.TownRole;
import io.naraplatform.share.domain.drama.TownRoleList;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_rolebook")
@Getter
@Setter
@NoArgsConstructor
public class TownRoleBookCmo {
    //
    @PrimaryKey
    private String id;
    private String adminRoleJson;
    private String defaultUserRoleJson;
    private String additionalRolesJson;

    public TownRoleBookCmo(TownRoleBook townRoleBook) {
        //
        this.id = townRoleBook.getId();
        this.adminRoleJson = townRoleBook.getAdminRole().toJson();
        this.defaultUserRoleJson = townRoleBook.getDefaultUserRole().toJson();
        this.additionalRolesJson = townRoleBook.getAdditionalRoles().toJson();
    }

    public TownRoleBook toDomain() {
        //
        TownRoleBook townRoleBook = new TownRoleBook(this.id);
        townRoleBook.setAdminRole(TownRole.fromJson(adminRoleJson));
        townRoleBook.setDefaultUserRole(TownRole.fromJson(defaultUserRoleJson));
        townRoleBook.setAdditionalRoles(TownRoleList.fromJson(additionalRolesJson));
        return townRoleBook;
    }

}
