package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.DormantTownerByTownIdAndCitizenIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DormantTownerByTownIdAndCitizenIdRepository extends CassandraRepository<DormantTownerByTownIdAndCitizenIdCmo, String> {
    //
    List<DormantTownerByTownIdAndCitizenIdCmo> findAllByTownId(String townId);
    List<DormantTownerByTownIdAndCitizenIdCmo> findAllByTownId(String townId, Pageable pageable);
}
