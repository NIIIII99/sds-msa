package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_member_by_citizenId")
@Getter
@Setter
@NoArgsConstructor
public class TeamMemberByCitizenIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "citizenId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String citizenId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public TeamMemberByCitizenIdCmo(TeamMember teamMember) {
        //
        this.id = teamMember.getId();
        this.citizenId = teamMember.getCitizen().getId();
        this.json = teamMember.toJson();
    }

    public TeamMember toDomain() {
        //
        return TeamMember.fromJson(this.json);
    }
}
