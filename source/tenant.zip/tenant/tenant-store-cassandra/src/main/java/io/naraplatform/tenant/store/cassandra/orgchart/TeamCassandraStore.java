package io.naraplatform.tenant.store.cassandra.orgchart;

import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import io.naraplatform.tenant.store.cassandra.orgchart.cmo.*;
import io.naraplatform.tenant.store.cassandra.orgchart.repository.*;
import io.naraplatform.tenant.store.orgchart.TeamStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class TeamCassandraStore implements TeamStore {
    //
    @Autowired
    TeamRepository teamRepository;
    @Autowired
    TeamByOrgChartIdRepository teamByOrgChartIdRepository;
    @Autowired
    TeamByParentIdRepository teamByParentIdRepository;

    @Autowired
    TeamMemberRepository teamMemberRepository;
    @Autowired
    TeamMemberByTeamIdAndCitizenIdRepository teamMemberByTeamIdAndCitizenIdRepository;
    @Autowired
    TeamMemberByCitizenIdRepository teamMemberByCitizenIdRepository;

    @Override
    public void create(Team team) {
        //
        teamRepository.save(new TeamCmo(team));
        if (team.hasOrgChartId()) {
            teamByOrgChartIdRepository.save(new TeamByOrgChartIdCmo(team));
        }
        teamByParentIdRepository.save(new TeamByParentIdCmo(team));
    }

    @Override
    public Team retrieve(String id) {
        //
        Optional<TeamCmo> teamCmo = teamRepository.findById(id);
        if (!teamCmo.isPresent()) {
            throw new NoSuchElementException(String.format("Team(%s) is not found.", id));
        }

        return teamCmo.get().toDomain();
    }

    @Override
    public List<Team> retrieveByOrgChartId(String orgChartId) {
        //
        List<TeamByOrgChartIdCmo> teamByOrgChartIdCmos = teamByOrgChartIdRepository.findAllByOrgChartId(orgChartId);
        return teamByOrgChartIdCmos.stream()
            .map(TeamByOrgChartIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<Team> retrieveByParentId(String parentId) {
        //
        List<TeamByParentIdCmo> teamByParentIdCmos = teamByParentIdRepository.findAllByParentId(parentId);
        return teamByParentIdCmos.stream()
            .map(TeamByParentIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(Team team) {
        //
        teamRepository.save(new TeamCmo(team));
        teamByOrgChartIdRepository.save(new TeamByOrgChartIdCmo(team));
        teamByParentIdRepository.save(new TeamByParentIdCmo(team));
    }

    @Override
    public void delete(Team team) {
        //
        teamRepository.delete(new TeamCmo(team));
        if (team.hasOrgChartId()) {
            teamByOrgChartIdRepository.delete(new TeamByOrgChartIdCmo(team));
        }
        teamByParentIdRepository.delete(new TeamByParentIdCmo(team));
    }

    @Override
    public int count(String orgChartId) {
        //
        return this.retrieveByOrgChartId(orgChartId).size();
    }

    @Override
    public void createTeamMember(TeamMember member) {
        //
        teamMemberRepository.save(new TeamMemberCmo(member));
        teamMemberByTeamIdAndCitizenIdRepository.save(new TeamMemberByTeamIdAndCitizenIdCmo(member));
        teamMemberByCitizenIdRepository.save(new TeamMemberByCitizenIdCmo(member));
    }

    @Override
    public TeamMember retrieveTeamMember(String memberId) {
        //
        Optional<TeamMemberCmo> teamMemberCmo = teamMemberRepository.findById(memberId);
        if (!teamMemberCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TeamMember(%s) is not found", memberId));
        }

        return teamMemberCmo.get().toDomain();
    }

    @Override
    public List<TeamMember> retrieveTeamMembersByTeamId(String teamId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<TeamMemberByTeamIdAndCitizenIdCmo> teamMemberByTeamIdCmos = teamMemberByTeamIdAndCitizenIdRepository.findAllByTeamId(teamId, pageable);
        return teamMemberByTeamIdCmos.stream()
            .map(TeamMemberByTeamIdAndCitizenIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<TeamMember> retrieveTeamMembersByCitizenId(String citizenId) {
        //
        List<TeamMemberByCitizenIdCmo> teamMemberByCitizenIdCmos = teamMemberByCitizenIdRepository.findAllByCitizenId(citizenId);
        return teamMemberByCitizenIdCmos.stream()
            .map(TeamMemberByCitizenIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateTeamMember(TeamMember member) {
        //
        teamMemberRepository.save(new TeamMemberCmo(member));
        teamMemberByTeamIdAndCitizenIdRepository.save(new TeamMemberByTeamIdAndCitizenIdCmo(member));
        teamMemberByCitizenIdRepository.save(new TeamMemberByCitizenIdCmo(member));
    }

    @Override
    public void deleteTeamMember(TeamMember member) {
        //
        teamMemberRepository.delete(new TeamMemberCmo(member));
        teamMemberByTeamIdAndCitizenIdRepository.delete(new TeamMemberByTeamIdAndCitizenIdCmo(member));
        teamMemberByCitizenIdRepository.delete(new TeamMemberByCitizenIdCmo(member));
    }

    @Override
    public void deleteTeamMembersByTeamId(String teamId) {
        //
        List<TeamMemberByTeamIdAndCitizenIdCmo> teamMemberByTeamIdCmos = teamMemberByTeamIdAndCitizenIdRepository.findAllByTeamId(teamId);
        teamMemberByTeamIdCmos.stream()
            .map(TeamMemberByTeamIdAndCitizenIdCmo::toDomain)
            .forEach((teamMember) -> {
                teamMemberRepository.delete(new TeamMemberCmo(teamMember));
                teamMemberByTeamIdAndCitizenIdRepository.delete(new TeamMemberByTeamIdAndCitizenIdCmo(teamMember));
                teamMemberByCitizenIdRepository.delete(new TeamMemberByCitizenIdCmo(teamMember));
            });
    }

    @Override
    public void deleteTeamMembersByMemberIds(List<String> memberIds) {
        //
        List<TeamMemberCmo> teamMemberCmos = teamMemberRepository.findAllById(memberIds);
        teamMemberCmos.stream()
            .map(TeamMemberCmo::toDomain)
            .forEach((teamMember) -> {
                teamMemberRepository.delete(new TeamMemberCmo(teamMember));
                teamMemberByTeamIdAndCitizenIdRepository.delete(new TeamMemberByTeamIdAndCitizenIdCmo(teamMember));
                teamMemberByCitizenIdRepository.delete(new TeamMemberByCitizenIdCmo(teamMember));
            });
    }

    @Override
    public boolean existsTeamMemberByTeamIdAndCitizenId(String teamId, String citizenId) {
        //
        Optional<TeamMemberByTeamIdAndCitizenIdCmo> teamMemberByTeamIdAndCitizenIdCmo = teamMemberByTeamIdAndCitizenIdRepository.findByTeamIdAndCitizenId(teamId, citizenId);
        return teamMemberByTeamIdAndCitizenIdCmo.isPresent();
    }

    @Override
    public int countTeamMembersByTeamId(String teamId) {
        //
        return teamMemberByTeamIdAndCitizenIdRepository.findAllByTeamId(teamId).size();
    }
}
