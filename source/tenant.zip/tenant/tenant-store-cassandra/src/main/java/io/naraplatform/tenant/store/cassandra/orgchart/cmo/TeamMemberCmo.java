package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_member")
@Getter
@Setter
@NoArgsConstructor
public class TeamMemberCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String citizenJson;
    private String title;
    private String teamId;
    private String orgChartId;

    public TeamMemberCmo(TeamMember teamMember) {
        //
        this.id = teamMember.getId();
        this.citizenJson = teamMember.getCitizen().toJson();
        this.title = teamMember.getTitle();
        this.teamId = teamMember.getTeamId();
        this.orgChartId = teamMember.getOrgChartId();
    }

    public TeamMember toDomain() {
        //
        TeamMember teamMember = new TeamMember(id);
        teamMember.setCitizen(IdName.fromJson(citizenJson));
        teamMember.setTitle(title);
        teamMember.setTeamId(teamId);
        teamMember.setOrgChartId(orgChartId);
        return teamMember;
    }
}
