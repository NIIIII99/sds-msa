package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminBookCmo;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminByCitizenIdCmo;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminByTownIdCmo;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminCmo;
import io.naraplatform.tenant.store.cassandra.town.repository.TownAdminBookRepository;
import io.naraplatform.tenant.store.cassandra.town.repository.TownAdminByCitizenIdRepository;
import io.naraplatform.tenant.store.cassandra.town.repository.TownAdminByTownIdRepository;
import io.naraplatform.tenant.store.cassandra.town.repository.TownAdminRepository;
import io.naraplatform.tenant.store.town.TownAdminBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class TownAdminBookCassandraStore implements TownAdminBookStore {
    //
    @Autowired
    TownAdminBookRepository townAdminBookRepository;

    @Autowired
    TownAdminRepository townAdminRepository;
    @Autowired
    TownAdminByTownIdRepository townAdminByTownIdRepository;
    @Autowired
    TownAdminByCitizenIdRepository townAdminByCitizenIdRepository;

    @Override
    public void create(TownAdminBook adminBook) {
        //
        townAdminBookRepository.save(new TownAdminBookCmo(adminBook));
    }

    @Override
    public TownAdminBook retrieve(String townId) {
        //
        Optional<TownAdminBookCmo> townAdminBookCmo = townAdminBookRepository.findById(townId);
        if (!townAdminBookCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TownAdminBook(%s) is not found.", townId));
        }

        return townAdminBookCmo.get().toDomain();
    }

    @Override
    public void update(TownAdminBook adminBook) {
        //
        townAdminBookRepository.save(new TownAdminBookCmo(adminBook));
    }

    @Override
    public void delete(TownAdminBook adminBook) {
        //
        townAdminBookRepository.delete(new TownAdminBookCmo(adminBook));
    }

    @Override
    public boolean exists(String townId) {
        //
        return townAdminBookRepository.existsById(townId);
    }

    @Override
    public void createTownAdmin(TownAdmin admin) {
        //
        townAdminRepository.save(new TownAdminCmo(admin));
        townAdminByTownIdRepository.save(new TownAdminByTownIdCmo(admin));
        townAdminByCitizenIdRepository.save(new TownAdminByCitizenIdCmo(admin));
    }

    @Override
    public TownAdmin retrieveTownAdmin(String adminId) {
        //
        Optional<TownAdminCmo> townAdminCmo = townAdminRepository.findById(adminId);
        if (!townAdminCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TownAdmin(%s) is not found.", adminId));
        }

        return townAdminCmo.get().toDomain();
    }

    @Override
    public List<TownAdmin> retrieveTownAdminsByTownId(String townId) {
        //
        List<TownAdminByTownIdCmo> townAdminByTownIdCmos = townAdminByTownIdRepository.findAllByTownId(townId);
        return townAdminByTownIdCmos.stream()
            .map(TownAdminByTownIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateTownAdmin(TownAdmin admin) {
        //
        townAdminRepository.save(new TownAdminCmo(admin));
        townAdminByTownIdRepository.save(new TownAdminByTownIdCmo(admin));
        townAdminByCitizenIdRepository.save(new TownAdminByCitizenIdCmo(admin));
    }

    @Override
    public void deleteTownAdmin(TownAdmin admin) {
        //
        townAdminRepository.delete(new TownAdminCmo(admin));
        townAdminByTownIdRepository.delete(new TownAdminByTownIdCmo(admin));
        townAdminByCitizenIdRepository.delete(new TownAdminByCitizenIdCmo(admin));
    }

    @Override
    public void deleteTownAdmins(List<String> adminIds) {
        //
        List<TownAdminCmo> townAdminCmos = townAdminRepository.findAllById(adminIds);
        townAdminCmos.stream()
            .map(TownAdminCmo::toDomain)
            .forEach((townAdmin) -> {
                deleteTownAdmin(townAdmin);
            });
    }

    @Override
    public void deleteTownAdminsByTownId(String townId) {
        //
        List<TownAdminByTownIdCmo> townAdminByTownIdCmos = townAdminByTownIdRepository.findAllByTownId(townId);
        townAdminByTownIdCmos.stream()
            .map(TownAdminByTownIdCmo::toDomain)
            .forEach((townAdmin) -> {
                deleteTownAdmin(townAdmin);
            });
    }

    @Override
    public boolean existsTownAdminByCitizenId(String citizenId) {
        //
        Optional<TownAdminByCitizenIdCmo> townAdminByCitizenIdCmo = townAdminByCitizenIdRepository.findByCitizenId(citizenId);
        return townAdminByCitizenIdCmo.isPresent();
    }
}
