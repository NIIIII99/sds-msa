package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.town.ActiveTowner;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("towner_active")
@Getter
@Setter
@NoArgsConstructor
public class ActiveTownerCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String usid;
    private String name;
    private String title;
    private String nickname;
    private String roleNamesJson;
    private long time;
    private String citizenId;
    private String townId;

    public ActiveTownerCmo(ActiveTowner activeTowner) {
        //
        this.id = activeTowner.getId();
        BeanUtils.copyProperties(activeTowner, this);
        this.roleNamesJson = JsonUtil.toJson(activeTowner.getRoleNames());
    }

    public ActiveTowner toDomain() {
        //
        ActiveTowner activeTowner = new ActiveTowner(this.id);
        BeanUtils.copyProperties(this, activeTowner);
        activeTowner.setRoleNames(JsonUtil.fromJsonList(roleNamesJson, String.class));
        return activeTowner;
    }
}
