package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByMetroIdAndNameAndLangCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface CitizenByMetroIdAndNameAndLangRepository extends CassandraRepository<CitizenByMetroIdAndNameAndLangCmo, String> {
    //
    List<CitizenByMetroIdAndNameAndLangCmo> findAllByMetroIdAndNameLike(String metroId, String nameLike);
}
