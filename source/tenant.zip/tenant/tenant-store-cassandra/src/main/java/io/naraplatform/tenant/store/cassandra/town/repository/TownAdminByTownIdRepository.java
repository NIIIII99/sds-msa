package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminByTownIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TownAdminByTownIdRepository extends CassandraRepository<TownAdminByTownIdCmo, String> {
    //
    List<TownAdminByTownIdCmo> findAllByTownId(String townId);
}
