package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamNodeCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface TeamNodeRepository extends CassandraRepository<TeamNodeCmo, String> {
    //
    Optional<TeamNodeCmo> findById(String id);
}
