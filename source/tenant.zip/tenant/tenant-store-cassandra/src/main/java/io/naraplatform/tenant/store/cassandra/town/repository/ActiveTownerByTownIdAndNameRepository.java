package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.ActiveTownerByTownIdAndNameCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface ActiveTownerByTownIdAndNameRepository extends CassandraRepository<ActiveTownerByTownIdAndNameCmo, String> {
    //
    List<ActiveTownerByTownIdAndNameCmo> findAllByTownIdAndNameLike(String townId, String nameLike);
}
