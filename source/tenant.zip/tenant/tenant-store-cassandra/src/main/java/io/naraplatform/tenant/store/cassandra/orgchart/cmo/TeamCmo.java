package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.string.StringUtil;
import io.naraplatform.tenant.entity.orgchart.Team;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team")
@Getter
@Setter
@NoArgsConstructor
public class TeamCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;              // teamNode's id
    private String titlesJson;
    private String parentId;
    private String leaderJson;
    private String orgChartId;

    public TeamCmo(Team team) {
        //
        this.id = team.getId();
        this.titlesJson = team.getTitles().toJson();
        this.parentId = team.getParentId();
        if (team.hasLeader()) {
            this.leaderJson = team.getLeader().toJson();
        }
        this.orgChartId = team.getOrgChartId();
    }

    public Team toDomain() {
        //
        Team team = new Team(id);
        team.setTitles(LangStrings.fromJson(titlesJson));
        team.setParentId(parentId);
        if (!StringUtil.isEmpty(leaderJson)) {
            team.setLeader(IdName.fromJson(leaderJson));
        }
        team.setOrgChartId(orgChartId);
        return team;
    }
}
