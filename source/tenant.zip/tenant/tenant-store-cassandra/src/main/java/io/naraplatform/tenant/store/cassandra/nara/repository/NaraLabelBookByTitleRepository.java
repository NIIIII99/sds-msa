package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByTitleCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface NaraLabelBookByTitleRepository extends CassandraRepository<NaraLabelBookByTitleCmo, String> {
    //
    Optional<NaraLabelBookByTitleCmo> findByTitle(String title);
    List<NaraLabelBookByTitleCmo> findAllByTitlesLike(String title, Pageable pageable);
}
