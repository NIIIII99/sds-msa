package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface MetroRoleBookRepository extends CassandraRepository<MetroRoleBookCmo, String> {
}
