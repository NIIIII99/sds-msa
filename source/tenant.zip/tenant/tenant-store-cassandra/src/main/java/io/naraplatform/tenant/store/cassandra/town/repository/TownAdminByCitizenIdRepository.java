package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminByCitizenIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface TownAdminByCitizenIdRepository extends CassandraRepository<TownAdminByCitizenIdCmo, String> {
    //
    Optional<TownAdminByCitizenIdCmo> findByCitizenId(String citizenId);
}
