package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface NaraLabelBookRepository extends CassandraRepository<NaraLabelBookCmo, String> {
}
