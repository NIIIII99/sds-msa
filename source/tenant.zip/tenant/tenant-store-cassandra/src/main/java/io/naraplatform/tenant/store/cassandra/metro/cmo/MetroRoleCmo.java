package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.MetroRole;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_role")
@Getter
@Setter
@NoArgsConstructor
public class MetroRoleCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private int sequence;
    private String name;
    private String displayName;
    private String memo;
    private String metroId;

    public MetroRoleCmo(MetroRole metroRole) {
        //
        this.id = metroRole.getId();
        this.sequence = metroRole.getSequence();
        this.name = metroRole.getName();
        this.displayName = metroRole.getDisplayName();
        this.memo = metroRole.getMemo();
        this.metroId = metroRole.getMetroId();
    }

    public MetroRole toDomain() {
        //
        MetroRole metroRole = new MetroRole(this.id);
        metroRole.setSequence(this.sequence);
        metroRole.setName(this.name);
        metroRole.setDisplayName(this.displayName);
        metroRole.setMemo(this.memo);
        metroRole.setMetroId(this.metroId);

        return metroRole;
    }

}
