package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface NaraRepository extends CassandraRepository<NaraCmo, String> {
}
