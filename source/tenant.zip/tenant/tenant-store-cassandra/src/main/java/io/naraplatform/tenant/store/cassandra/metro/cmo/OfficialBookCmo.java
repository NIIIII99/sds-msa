package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.Table;

//@Table("official_book")
//@Getter
//@Setter
//@NoArgsConstructor
public class OfficialBookCmo implements JsonSerializable {
    //
//    @PrimaryKey
//    private String id;              // metroId
//    private String metroName;
//    private String policyJson;
//
//    public OfficialBookCmo(OfficialBook officialBook) {
//        //
//        this.id = officialBook.getId();
//        this.metroName = officialBook.getMetroName();
//        this.policyJson = JsonUtil.toJson(officialBook.getPolicy());
//    }
//
//    public OfficialBook toDomain() {
//        //
//        OfficialBook officialBook = new OfficialBook(this.id);
//        officialBook.setMetroName(this.metroName);
//        officialBook.setPolicy(JsonUtil.fromJson(policyJson, OfficialPolicy.class));
//        return officialBook;
//    }

}
