package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialBookCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialByMetroIdCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialCmo;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroOfficialBookRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroOfficialByMetroIdRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroOfficialRepository;
import io.naraplatform.tenant.store.metro.MetroOfficialBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class MetroOfficialBookCassandraStore implements MetroOfficialBookStore {
    //
    @Autowired
    MetroOfficialBookRepository metroOfficialBookRepository;
    @Autowired
    MetroOfficialRepository metroOfficialRepository;
    @Autowired
    MetroOfficialByMetroIdRepository metroOfficialByMetroIdRepository;

    @Override
    public void create(MetroOfficialBook officialBook) {
        //
        metroOfficialBookRepository.save(new MetroOfficialBookCmo(officialBook));
    }

    @Override
    public MetroOfficialBook retrieve(String metroId) {
        //
        Optional<MetroOfficialBookCmo> metroOfficialBookCmo = metroOfficialBookRepository.findById(metroId);
        if (!metroOfficialBookCmo.isPresent()) {
            throw new NoSuchElementException(String.format("MetroOfficialBook(%s) is not found.", metroId));
        }

        return metroOfficialBookCmo.get().toDomain();
    }

    @Override
    public void update(MetroOfficialBook officialBook) {
        //
        metroOfficialBookRepository.save(new MetroOfficialBookCmo(officialBook));
    }

    @Override
    public void delete(MetroOfficialBook officialBook) {
        //
        metroOfficialBookRepository.delete(new MetroOfficialBookCmo(officialBook));
    }

    @Override
    public boolean exists(String metroId) {
        //
        Optional<MetroOfficialBookCmo> metroOfficialBookCmo = metroOfficialBookRepository.findById(metroId);
        return metroOfficialBookCmo.isPresent();
    }

    @Override
    public void createMetroOfficial(MetroOfficial metroOfficial) {
        //
        metroOfficialRepository.save(new MetroOfficialCmo(metroOfficial));
        metroOfficialByMetroIdRepository.save(new MetroOfficialByMetroIdCmo((metroOfficial)));
    }

    @Override
    public MetroOfficial retrieveMetroOfficial(String officialId) {
        //
        Optional<MetroOfficialCmo> metroOfficialCmo = metroOfficialRepository.findById(officialId);
        if (!metroOfficialCmo.isPresent()) {
            throw new NoSuchElementException(String.format("MetroOfficial(%s) is not found.", officialId));
        }

        return metroOfficialCmo.get().toDomain();
    }

    @Override
    public List<MetroOfficial> retrieveMetroOfficialsByMetroId(String metroId) {
        //
        List<MetroOfficialByMetroIdCmo> metroOfficialByMetroIdCmos = metroOfficialByMetroIdRepository.findAllByMetroId(metroId);
        return metroOfficialByMetroIdCmos.stream()
            .map(MetroOfficialByMetroIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateMetroOfficial(MetroOfficial metroOfficial) {
        //
        metroOfficialRepository.save(new MetroOfficialCmo(metroOfficial));
        metroOfficialByMetroIdRepository.save(new MetroOfficialByMetroIdCmo((metroOfficial)));
    }

    @Override
    public void deleteMetroOfficial(MetroOfficial metroOfficial) {
        //
        metroOfficialRepository.delete(new MetroOfficialCmo(metroOfficial));
        metroOfficialByMetroIdRepository.delete(new MetroOfficialByMetroIdCmo((metroOfficial)));
    }

    @Override
    public void deleteMetroOfficials(List<String> officialIds) {
        //
        List<MetroOfficialCmo> metroOfficialByCmos = metroOfficialRepository.findAllById(officialIds);
        metroOfficialByCmos.stream()
            .map(MetroOfficialCmo::toDomain)
            .forEach((metroOfficial) -> {
                metroOfficialRepository.delete(new MetroOfficialCmo(metroOfficial));
                metroOfficialByMetroIdRepository.delete(new MetroOfficialByMetroIdCmo((metroOfficial)));
            });
    }

    @Override
    public void deleteMetroOfficialsInMetro(String metroId) {
        //
        List<MetroOfficialByMetroIdCmo> metroOfficialByMetroIdCmos = metroOfficialByMetroIdRepository.findAllByMetroId(metroId);
        metroOfficialByMetroIdCmos.stream()
            .map(MetroOfficialByMetroIdCmo::toDomain)
            .forEach((metroOfficial -> {
                metroOfficialRepository.delete(new MetroOfficialCmo(metroOfficial));
                metroOfficialByMetroIdRepository.delete(new MetroOfficialByMetroIdCmo((metroOfficial)));
            }));
    }

    @Override
    public boolean existsMetroOfficialByCitizenId(String citizenId) {
        //
        Optional<MetroOfficialCmo> metroOfficialCmo = metroOfficialRepository.findById(citizenId);
        return metroOfficialCmo.isPresent();
    }

//    OfficialBookRepository officialBookRepository;
//    MetroOfficialRepository metroOfficialRepository;
//    MetroOfficialByBookRepository metroOfficialByBookRepository;
}
