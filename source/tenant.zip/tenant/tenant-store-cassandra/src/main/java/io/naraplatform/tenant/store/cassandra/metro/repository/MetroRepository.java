package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface MetroRepository extends CassandraRepository<MetroCmo, String> {
}
