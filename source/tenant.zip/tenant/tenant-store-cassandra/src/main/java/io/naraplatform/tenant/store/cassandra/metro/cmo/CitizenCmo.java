package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("citizen")
@Getter
@Setter
@NoArgsConstructor
public class CitizenCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String json;

    public CitizenCmo(Citizen citizen) {
        //
        this.id = citizen.getId();
        this.json = citizen.toJson();
    }

    public Citizen toDomain() {
        //
        return Citizen.fromJson(json);
    }
}
