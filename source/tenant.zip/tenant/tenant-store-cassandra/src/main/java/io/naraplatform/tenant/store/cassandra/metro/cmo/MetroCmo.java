package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro")
@Getter
@Setter
@NoArgsConstructor
public class MetroCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String json;

    public MetroCmo(Metro metro) {
        //
        this.id = metro.getId();
        this.json = metro.toJson();
    }

    public Metro toDomain() {
        //
        return Metro.fromJson(json);
    }
}
