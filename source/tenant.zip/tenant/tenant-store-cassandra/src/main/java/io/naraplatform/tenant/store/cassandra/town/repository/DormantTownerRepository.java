package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.DormantTownerCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DormantTownerRepository extends CassandraRepository<DormantTownerCmo, String> {
}
