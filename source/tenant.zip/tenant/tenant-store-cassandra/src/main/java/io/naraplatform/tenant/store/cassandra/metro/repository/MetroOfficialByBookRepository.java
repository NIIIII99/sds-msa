package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialByBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface MetroOfficialByBookRepository extends CassandraRepository<MetroOfficialByBookCmo, String> {
    //
    List<MetroOfficialByBookCmo> findAllByBookId(String bookId);
}
