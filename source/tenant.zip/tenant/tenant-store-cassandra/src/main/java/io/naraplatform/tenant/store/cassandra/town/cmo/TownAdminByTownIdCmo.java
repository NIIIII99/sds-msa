package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.TownAdmin;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_admin_by_townId")
@Getter
@Setter
@NoArgsConstructor
public class TownAdminByTownIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "townId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String townId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public TownAdminByTownIdCmo(TownAdmin townAdmin) {
        //
        this.townId = townAdmin.getTownId();
        this.id = townAdmin.getId();
        this.json = townAdmin.toJson();
    }

    public TownAdmin toDomain() {
        //
        return TownAdmin.fromJson(json);
    }
}

