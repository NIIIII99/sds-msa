package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_by_lang_name")
@Getter
@Setter
@NoArgsConstructor
public class MetroByLangNameCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "name", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String name;
    @PrimaryKeyColumn(name = "langCode", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "metroId", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String metroId;
    private String json;

    public MetroByLangNameCmo(String langCode, Metro metro) {
        //
        this.name = metro.getNames().getString(langCode);
        this.langCode = langCode;
        this.metroId = metro.getId();

        this.json = metro.toJson();
    }

    public Metro toDomain() {
        //
        return Metro.fromJson(json);
    }
}
