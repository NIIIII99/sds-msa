package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.OrgChartByMetroIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface OrgChartByMetroIdRepository extends CassandraRepository<OrgChartByMetroIdCmo, String> {
    //
    List<OrgChartByMetroIdCmo> findAllByMetroId(String metroId);
}
