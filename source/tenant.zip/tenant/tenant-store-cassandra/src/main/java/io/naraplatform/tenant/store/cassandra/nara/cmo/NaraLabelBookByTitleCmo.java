package io.naraplatform.tenant.store.cassandra.nara.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nara_label_book_by_title")
@Getter
@Setter
@NoArgsConstructor
public class NaraLabelBookByTitleCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "title", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String title;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    @Indexed
    private String titles;
    private String json;

    public NaraLabelBookByTitleCmo(NaraLabelBook naraLabelBook) {
        //
        this.title = naraLabelBook.getTitle();
        this.id = naraLabelBook.getId();
        this.titles = naraLabelBook.getTitle();
        this.json = naraLabelBook.toJson();
    }

    public NaraLabelBook toDomain() {
        //
        return NaraLabelBook.fromJson(json);
    }
}
