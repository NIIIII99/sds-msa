package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_official_by_metroId")
@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialByMetroIdCmo implements JsonSerializable {

    @PrimaryKeyColumn(name = "metroId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String metroId;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;              // citizenId
    private String json;

    public MetroOfficialByMetroIdCmo(MetroOfficial metroOfficial) {
        //
        this.metroId = metroOfficial.getMetroId();
        this.id = metroOfficial.getId();
        this.json = metroOfficial.toJson();
    }

    public MetroOfficial toDomain() {
        //
        return MetroOfficial.fromJson(json);
    }
}
