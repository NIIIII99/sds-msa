package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_official_by_book")
@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialByBookCmo implements JsonSerializable {

    @PrimaryKeyColumn(name = "bookId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String bookId;              // bookId(=metroId)
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public MetroOfficialByBookCmo(MetroOfficial metroOfficial) {
        //
        this.bookId = metroOfficial.getMetroId();
        this.id = metroOfficial.getId();
        this.json = metroOfficial.toJson();
    }

    public MetroOfficial toDomain() {
        //
        return MetroOfficial.fromJson(json);
    }
}
