package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface CitizenRepository extends CassandraRepository<CitizenCmo, String> {
    //
}
