package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_adminbook")
@Getter
@Setter
@NoArgsConstructor
public class TownAdminBookCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String townName;
    private boolean singleAdmin;

    public TownAdminBookCmo(TownAdminBook townAdminBook) {
        //
        this.id = townAdminBook.getId();
        this.townName = townAdminBook.getTownName();
        this.singleAdmin = townAdminBook.isSingleAdmin();
    }

    public TownAdminBook toDomain() {
        //
        TownAdminBook townAdminBook = new TownAdminBook(id);
        townAdminBook.setTownName(townName);
        townAdminBook.setSingleAdmin(singleAdmin);
        return townAdminBook;
    }
}
