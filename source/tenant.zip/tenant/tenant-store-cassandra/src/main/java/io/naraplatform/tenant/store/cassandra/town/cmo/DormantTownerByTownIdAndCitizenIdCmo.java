package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.DormantTowner;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("towner_dormant_by_townId_and_citizenId")
@Getter
@Setter
@NoArgsConstructor
public class DormantTownerByTownIdAndCitizenIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "townId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String townId;
    @PrimaryKeyColumn(name = "citizenId", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String citizenId;
    @PrimaryKeyColumn(name = "id", ordinal = 3, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public DormantTownerByTownIdAndCitizenIdCmo(DormantTowner dormantTowner) {
        //
        this.townId = dormantTowner.getTownId();
        this.citizenId = dormantTowner.getCitizenId();
        this.id = dormantTowner.getId();
        this.json = dormantTowner.toJson();
    }

    public DormantTowner toDomain() {
        //
        return DormantTowner.fromJson(this.json);
    }
}
