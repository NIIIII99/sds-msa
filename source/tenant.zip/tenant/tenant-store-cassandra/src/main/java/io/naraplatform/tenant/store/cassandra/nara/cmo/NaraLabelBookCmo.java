package io.naraplatform.tenant.store.cassandra.nara.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nara_label_book")
@Getter
@Setter
@NoArgsConstructor
public class NaraLabelBookCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String json;

    public NaraLabelBookCmo(NaraLabelBook naraLabelBook) {
        //
        this.id = naraLabelBook.getId();
        this.json = naraLabelBook.toJson();
    }

    public NaraLabelBook toDomain() {
        //
        return NaraLabelBook.fromJson(json);
    }
}
