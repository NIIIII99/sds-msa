package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialByMetroIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface MetroOfficialByMetroIdRepository extends CassandraRepository<MetroOfficialByMetroIdCmo, String> {
    //
    List<MetroOfficialByMetroIdCmo> findAllByMetroId(String metroId);
}
