package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface MetroRoleRepository extends CassandraRepository<MetroRoleCmo, String> {
}
