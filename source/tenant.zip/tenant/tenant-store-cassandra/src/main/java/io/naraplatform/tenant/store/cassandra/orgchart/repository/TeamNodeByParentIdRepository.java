package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamNodeByParentIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TeamNodeByParentIdRepository extends CassandraRepository<TeamNodeByParentIdCmo, String> {
    //
    List<TeamNodeByParentIdCmo> findAllByParentId(String parentId);
}
