package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.Team;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_by_orgChartId")
@Getter
@Setter
@NoArgsConstructor
public class TeamByOrgChartIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "orgChartId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String orgChartId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;              // teamNode's id
    private String json;

    public TeamByOrgChartIdCmo(Team team) {
        //
        this.orgChartId = team.getOrgChartId();
        this.id = team.getId();
        this.json = team.toJson();
    }

    public Team toDomain() {
        //
        return Team.fromJson(json);
    }
}
