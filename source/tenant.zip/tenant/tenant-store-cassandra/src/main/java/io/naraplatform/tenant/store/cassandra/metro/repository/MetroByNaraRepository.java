package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroByNaraCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface MetroByNaraRepository extends CassandraRepository<MetroByNaraCmo, String> {
    //
    List<MetroByNaraCmo> findAllByNaraId(String naraId, Pageable pageable);
}
