package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface MetroOfficialBookRepository extends CassandraRepository<MetroOfficialBookCmo, String> {
}
