package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByNaraCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface NaraLabelBookByNaraRepository extends CassandraRepository<NaraLabelBookByNaraCmo, String> {
    //
    List<NaraLabelBookByNaraCmo> findAllByNaraId(String naraId);
}
