package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownByLangTitleCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TownByLangTitleRepository extends CassandraRepository<TownByLangTitleCmo, String> {
    //
    List<TownByLangTitleCmo> findAllByTitleAndLangCode(String title, String langCode);
}
