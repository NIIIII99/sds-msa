package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("org_chart_by_metro")
@Getter
@Setter
@NoArgsConstructor
public class OrgChartByMetroIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "metroId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String metroId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public OrgChartByMetroIdCmo(OrgChart orgChart) {
        //
        this.metroId = orgChart.getMetroId();
        this.id = orgChart.getId();
        this.json = orgChart.toJson();
    }

    public OrgChart toDomain() {
        //
        return OrgChart.fromJson(json);
    }
}
