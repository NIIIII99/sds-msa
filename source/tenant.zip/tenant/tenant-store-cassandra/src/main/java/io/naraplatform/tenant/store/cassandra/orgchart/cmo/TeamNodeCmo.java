package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.context.annotation.Primary;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_node")
@Getter
@Setter
@NoArgsConstructor
public class TeamNodeCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String titlesJson;
    private String parentId;
    private int levelSequence;
    private int childSequence;
    private String orgChartId;
    private long time;

    public TeamNodeCmo(TeamNode teamNode) {
        //
        this.id = teamNode.getId();
        this.titlesJson = teamNode.getTitles().toJson();
        this.parentId = teamNode.getParentId();
        this.levelSequence = teamNode.getLevelSequence();
        this.childSequence = teamNode.getChildSequence();
        this.orgChartId = teamNode.getOrgChartId();
        this.time = teamNode.getTime();
    }

    public TeamNode toDomain() {
        //
        TeamNode teamNode = new TeamNode(this.id);
        teamNode.setTitles(LangStrings.fromJson(this.titlesJson));
        teamNode.setParentId(this.parentId);
        teamNode.setLevelSequence(this.levelSequence);
        teamNode.setChildSequence(this.childSequence);
        teamNode.setOrgChartId(this.orgChartId);
        teamNode.setTime(this.time);

        return teamNode;
    }

//    id
//    parentId
//    orgChartId, parentId
}
