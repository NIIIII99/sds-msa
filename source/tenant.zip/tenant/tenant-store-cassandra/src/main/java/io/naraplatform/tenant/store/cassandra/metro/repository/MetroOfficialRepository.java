package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroOfficialCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface MetroOfficialRepository extends CassandraRepository<MetroOfficialCmo, String> {
}
