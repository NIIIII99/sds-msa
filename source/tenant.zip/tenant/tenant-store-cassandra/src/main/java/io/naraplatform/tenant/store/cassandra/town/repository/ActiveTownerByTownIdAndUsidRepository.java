package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.ActiveTownerByTownIdAndUsidCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ActiveTownerByTownIdAndUsidRepository extends CassandraRepository<ActiveTownerByTownIdAndUsidCmo, String> {
    //
    Optional<ActiveTownerByTownIdAndUsidCmo> findByTownIdAndUsid(String townId, String usid);
    List<ActiveTownerByTownIdAndUsidCmo> findAllByTownId(String townId, Pageable pageable);
    List<ActiveTownerByTownIdAndUsidCmo> findAllByTownId(String townId);
}
