package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.entity.metro.type.OfficialPolicy;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_official_book")
@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialBookCmo {
    //
    @PrimaryKey
    private String id;                      // == metroId
    private String metroName;
    private String primaryOfficialJson;
    private String policyJson;

    public MetroOfficialBookCmo(MetroOfficialBook metroOfficialBook) {
        //
        this.id = metroOfficialBook.getId();
        this.metroName = metroOfficialBook.getMetroName();
        this.primaryOfficialJson = metroOfficialBook.getPrimaryOfficial().toJson();
        this.policyJson = metroOfficialBook.getPolicy().toJson();
    }

    public MetroOfficialBook toDomain() {
        //
        MetroOfficialBook metroOfficialBook = new MetroOfficialBook(this.id);
        metroOfficialBook.setMetroName(this.metroName);
        metroOfficialBook.setPrimaryOfficial(IdName.fromJson(this.primaryOfficialJson));
        metroOfficialBook.setPolicy(OfficialPolicy.fromJson(this.policyJson));

        return metroOfficialBook;
    }
}
