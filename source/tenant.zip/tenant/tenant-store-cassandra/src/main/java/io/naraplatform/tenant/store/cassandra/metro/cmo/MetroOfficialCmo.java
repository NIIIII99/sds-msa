package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.MetroOfficial;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_official")
@Getter
@Setter
@NoArgsConstructor
public class MetroOfficialCmo implements JsonSerializable {

    @PrimaryKey
    private String id;              // citizenId
    private String json;

    public MetroOfficialCmo(MetroOfficial metroOfficial) {
        //
        this.id = metroOfficial.getId();
        this.json = metroOfficial.toJson();
    }

    public MetroOfficial toDomain() {
        //
        return MetroOfficial.fromJson(json);
    }
}
