package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownLabelBookCmo;
import io.naraplatform.tenant.store.cassandra.town.repository.TownLabelBookRepository;
import io.naraplatform.tenant.store.town.TownLabelBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.NoSuchElementException;
import java.util.Optional;

@Repository
public class TownLabelBookCassandraStore implements TownLabelBookStore {
    //
    @Autowired
    TownLabelBookRepository townLabelBookRepository;

    @Override
    public void create(TownLabelBook labelBook) {
        //
        townLabelBookRepository.save(new TownLabelBookCmo(labelBook));
    }

    @Override
    public TownLabelBook retrieve(String townId) {
        //
        Optional<TownLabelBookCmo> townLabelBookCmo = townLabelBookRepository.findById(townId);
        if (!townLabelBookCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TownLabelBook(%s) is not found.", townId));
        }

        return townLabelBookCmo.get().toDomain();
    }

    @Override
    public void update(TownLabelBook labelBook) {
        //
        townLabelBookRepository.save(new TownLabelBookCmo(labelBook));
    }

    @Override
    public void delete(TownLabelBook labelBook) {
        //
        townLabelBookRepository.delete(new TownLabelBookCmo(labelBook));
    }

    @Override
    public boolean exists(String townId) {
        //
        return townLabelBookRepository.existsById(townId);
    }
}
