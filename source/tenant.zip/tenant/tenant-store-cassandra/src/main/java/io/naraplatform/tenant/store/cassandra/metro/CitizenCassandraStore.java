package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByEmailCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByMetroIdAndNameAndLangCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByMetroIdAndUsidCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenCmo;
import io.naraplatform.tenant.store.cassandra.metro.repository.CitizenByEmailRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.CitizenByMetroIdAndNameAndLangRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.CitizenByMetroIdAndUsidRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.CitizenRepository;
import io.naraplatform.tenant.store.metro.CitizenStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class CitizenCassandraStore implements CitizenStore {
    //
    @Autowired
    CitizenRepository citizenRepository;
    @Autowired
    CitizenByEmailRepository citizenByEmailRepository;
    @Autowired
    CitizenByMetroIdAndUsidRepository citizenByMetroIdAndUsidRepository;
    @Autowired
    CitizenByMetroIdAndNameAndLangRepository citizenByMetroIdAndNameAndLangRepository;

    @Override
    public void create(Citizen citizen) {
        citizenRepository.save(new CitizenCmo(citizen));
        citizenByEmailRepository.save(new CitizenByEmailCmo(citizen));
        citizenByMetroIdAndUsidRepository.save(new CitizenByMetroIdAndUsidCmo(citizen));
        //
        citizen.getNames().names().stream()
            .map((name) -> new CitizenByMetroIdAndNameAndLangCmo(citizen, name.getLang()))
            .forEach(citizenByMetroIdAndNameAndLangRepository::save);
    }

    @Override
    public Citizen retrieve(String id) {
        //
        Optional<CitizenCmo> citizenCmo = citizenRepository.findById(id);
        if (!citizenCmo.isPresent()) {
            throw new NoSuchElementException(String.format("Citizen(%s) is not found.", id));
        }

        return citizenCmo.get().toDomain();
    }

    @Override
    public Citizen retrieveByMetroIdAndUsid(String metroId, String usid) {
        //
        Optional<CitizenByMetroIdAndUsidCmo> citizenByMetroIdAndUsidCmo = citizenByMetroIdAndUsidRepository.findByMetroIdAndUsid(metroId, usid);
        if (!citizenByMetroIdAndUsidCmo.isPresent()) {
            throw new NoSuchElementException(String.format("Citizen(%s, %s) is not found.", metroId, usid));
        }

        return citizenByMetroIdAndUsidCmo.get().toDomain();
    }

    @Override
    public List<Citizen> retrieveByMetroIdAndNameLike(String metroId, String nameLike) {
        //
        List<CitizenByMetroIdAndNameAndLangCmo> citizenByMetroIdAndNameAndLangCmos = citizenByMetroIdAndNameAndLangRepository.findAllByMetroIdAndNameLike(metroId, nameLike);
        return citizenByMetroIdAndNameAndLangCmos.stream()
            .map(CitizenByMetroIdAndNameAndLangCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<Citizen> retrieveByMetroId(String metroId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<CitizenByMetroIdAndUsidCmo> citizenByMetroIdAndUsidCmos = citizenByMetroIdAndUsidRepository.findAllByMetroId(metroId, pageable);
        return citizenByMetroIdAndUsidCmos.stream().map(CitizenByMetroIdAndUsidCmo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(Citizen citizen) {
        //
        citizenRepository.save(new CitizenCmo(citizen));
        citizenByEmailRepository.save(new CitizenByEmailCmo(citizen));
        citizenByMetroIdAndUsidRepository.save(new CitizenByMetroIdAndUsidCmo(citizen));
        //
        citizen.getNames().names().stream()
            .map((name) -> new CitizenByMetroIdAndNameAndLangCmo(citizen, name.getLang()))
            .forEach(citizenByMetroIdAndNameAndLangRepository::save);
    }

    @Override
    public void delete(Citizen citizen) {
        //
        citizenRepository.delete(new CitizenCmo(citizen));
        citizenByEmailRepository.delete(new CitizenByEmailCmo(citizen));
        citizenByMetroIdAndUsidRepository.delete(new CitizenByMetroIdAndUsidCmo(citizen));
        //
        citizen.getNames().names().stream()
            .map((name) -> new CitizenByMetroIdAndNameAndLangCmo(citizen, name.getLang()))
            .forEach(citizenByMetroIdAndNameAndLangRepository::delete);
    }

    @Override
    public void deleteByMetroId(String metroId) {
        //
        List<CitizenByMetroIdAndUsidCmo> citizenByMetroIdAndUsidCmos = citizenByMetroIdAndUsidRepository.findAllByMetroId(metroId);
        citizenByMetroIdAndUsidCmos.stream()
            .map(CitizenByMetroIdAndUsidCmo::toDomain)
            .forEach((citizen) -> {
                citizenRepository.delete(new CitizenCmo(citizen));
                citizenByEmailRepository.delete(new CitizenByEmailCmo(citizen));
                citizenByMetroIdAndUsidRepository.delete(new CitizenByMetroIdAndUsidCmo(citizen));
                //
                citizen.getNames().names().stream()
                    .map((name) -> new CitizenByMetroIdAndNameAndLangCmo(citizen, name.getLang()))
                    .forEach(citizenByMetroIdAndNameAndLangRepository::delete);
            });
    }

    @Override
    public void deleteByCitizenIds(List<String> citizenIds) {
        //
        List<CitizenCmo> citizenCmos = citizenRepository.findAllById(citizenIds);
        citizenCmos.stream()
            .map(CitizenCmo::toDomain)
            .forEach((citizen) -> {
                citizenRepository.delete(new CitizenCmo(citizen));
                citizenByEmailRepository.delete(new CitizenByEmailCmo(citizen));
                citizenByMetroIdAndUsidRepository.delete(new CitizenByMetroIdAndUsidCmo(citizen));
                //
                citizen.getNames().names().stream()
                    .map((name) -> new CitizenByMetroIdAndNameAndLangCmo(citizen, name.getLang()))
                    .forEach(citizenByMetroIdAndNameAndLangRepository::delete);
            });
    }

    @Override
    public boolean existsByMetroIdAndUsid(String metroId, String usid) {
        //
        Optional<CitizenByMetroIdAndUsidCmo> citizenByMetroIdAndUsidCmo = citizenByMetroIdAndUsidRepository.findByMetroIdAndUsid(metroId, usid);
        return citizenByMetroIdAndUsidCmo.isPresent();
    }

    @Override
    public boolean existsByEmail(String email) {
        //
        Optional<CitizenByEmailCmo> citizenByEmailCmo = citizenByEmailRepository.findByEmail(email);
        return citizenByEmailCmo.isPresent();
    }

    @Override
    public long countByMetroId(String metroId) {
        //
        List<CitizenByMetroIdAndUsidCmo> citizenByMetroIdAndUsidCmos = citizenByMetroIdAndUsidRepository.findAllByMetroId(metroId);
        return citizenByMetroIdAndUsidCmos.size();
    }

}
