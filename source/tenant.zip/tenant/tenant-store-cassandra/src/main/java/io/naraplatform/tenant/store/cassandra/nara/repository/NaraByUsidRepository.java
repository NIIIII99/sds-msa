package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraByUsidCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface NaraByUsidRepository extends CassandraRepository<NaraByUsidCmo, String> {
    //
    Optional<NaraByUsidCmo> findByUsid(String usid);
}
