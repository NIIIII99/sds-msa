package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamMemberByCitizenIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TeamMemberByCitizenIdRepository extends CassandraRepository<TeamMemberByCitizenIdCmo, String> {
    //
    List<TeamMemberByCitizenIdCmo> findAllByCitizenId(String teamId);
}
