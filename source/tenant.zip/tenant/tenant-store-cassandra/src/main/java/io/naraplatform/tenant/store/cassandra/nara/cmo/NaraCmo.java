package io.naraplatform.tenant.store.cassandra.nara.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.nara.Nara;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nara")
@Getter
@Setter
@NoArgsConstructor
public class NaraCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String usid;
    private String name;
    private boolean certified;
    private long time;

    public NaraCmo(Nara nara) {
        //
        this.id = nara.getId();
        this.usid = nara.getUsid();
        this.name = nara.getName();
        this.certified = nara.isCertified();
        this.time = nara.getTime();
    }

    public Nara toDomain() {
        //
        Nara nara = new Nara(this.id);
        nara.setUsid(this.usid);
        nara.setName(this.name);
        nara.setCertified(this.certified);
        nara.setTime(this.time);
        return nara;
    }
}
