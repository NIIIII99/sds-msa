package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.OrgChartCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface OrgChartRepository extends CassandraRepository<OrgChartCmo, String> {
}
