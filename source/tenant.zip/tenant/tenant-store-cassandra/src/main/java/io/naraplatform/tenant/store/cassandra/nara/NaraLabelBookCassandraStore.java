package io.naraplatform.tenant.store.cassandra.nara;

import io.naraplatform.tenant.entity.metro.type.MetroType;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByMetroTypeCmo;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByNaraCmo;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByTitleCmo;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookCmo;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraLabelBookByMetroTypeRepository;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraLabelBookByNaraRepository;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraLabelBookByTitleRepository;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraLabelBookRepository;
import io.naraplatform.tenant.store.nara.NaraLabelBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class NaraLabelBookCassandraStore implements NaraLabelBookStore {
    //
    @Autowired
    NaraLabelBookRepository naraLabelBookRepository;
    @Autowired
    NaraLabelBookByTitleRepository naraLabelBookByTitleRepository;
    @Autowired
    NaraLabelBookByNaraRepository naraLabelBookByNaraRepository;
    @Autowired
    NaraLabelBookByMetroTypeRepository naraLabelBookByMetroTypeRepository;

    @Override
    public void create(NaraLabelBook naraLabelBook) {
        //
        naraLabelBookRepository.save(new NaraLabelBookCmo(naraLabelBook));
        naraLabelBookByTitleRepository.save(new NaraLabelBookByTitleCmo(naraLabelBook));
        naraLabelBookByNaraRepository.save(new NaraLabelBookByNaraCmo(naraLabelBook));
        naraLabelBookByMetroTypeRepository.save(new NaraLabelBookByMetroTypeCmo(naraLabelBook));
    }

    @Override
    public NaraLabelBook retrieve(String id) {
        //
        Optional<NaraLabelBookCmo> naraLabelBookCmo = naraLabelBookRepository.findById(id);
        if (!naraLabelBookCmo.isPresent()) {
            throw new NoSuchElementException("NaraLabelBook is not found!");
        }

        return naraLabelBookCmo.get().toDomain();
    }

    @Override
    public NaraLabelBook retrieveByTitle(String title) {
        //
        Optional<NaraLabelBookByTitleCmo> naraLabelBookByTitleCmo = naraLabelBookByTitleRepository.findByTitle(title);
        if (!naraLabelBookByTitleCmo.isPresent()) {
            throw new NoSuchElementException("NaraLabelBook is not found!");
        }

        return naraLabelBookByTitleCmo.get().toDomain();
    }

    @Override
    public List<NaraLabelBook> retrieveByNaraId(String naraId) {
        //
        List<NaraLabelBookByNaraCmo> naraLabelBookByNaraCmos = naraLabelBookByNaraRepository.findAllByNaraId(naraId);
        return naraLabelBookByNaraCmos.stream()
            .map(NaraLabelBookByNaraCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<NaraLabelBook> retrieveByMetroType(MetroType metroType, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<NaraLabelBookByMetroTypeCmo> naraLabelBookByMetroTypeCmos = naraLabelBookByMetroTypeRepository.findAllByMetroType(metroType.toString(), pageable);
        return naraLabelBookByMetroTypeCmos.stream()
            .map(NaraLabelBookByMetroTypeCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<NaraLabelBook> retrieveByTitleLike(String titleLike, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<NaraLabelBookByTitleCmo> naraLabelBookByTitleCmos = naraLabelBookByTitleRepository.findAllByTitlesLike(titleLike, pageable);
        return naraLabelBookByTitleCmos.stream()
            .map(NaraLabelBookByTitleCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(NaraLabelBook naraLabelBook) {
        //
        naraLabelBookRepository.save(new NaraLabelBookCmo(naraLabelBook));
        naraLabelBookByTitleRepository.save(new NaraLabelBookByTitleCmo(naraLabelBook));
        naraLabelBookByNaraRepository.save(new NaraLabelBookByNaraCmo(naraLabelBook));
        naraLabelBookByMetroTypeRepository.save(new NaraLabelBookByMetroTypeCmo(naraLabelBook));
    }

    @Override
    public void delete(NaraLabelBook naraLabelBook) {
        //
        naraLabelBookRepository.delete(new NaraLabelBookCmo(naraLabelBook));
        naraLabelBookByTitleRepository.delete(new NaraLabelBookByTitleCmo(naraLabelBook));
        naraLabelBookByNaraRepository.delete(new NaraLabelBookByNaraCmo(naraLabelBook));
        naraLabelBookByMetroTypeRepository.delete(new NaraLabelBookByMetroTypeCmo(naraLabelBook));
    }

    @Override
    public boolean existsByTitle(String title) {
        //
        Optional<NaraLabelBookByTitleCmo> naraLabelBookByTitleCmo = naraLabelBookByTitleRepository.findByTitle(title);
        return naraLabelBookByTitleCmo.isPresent();
    }
}
