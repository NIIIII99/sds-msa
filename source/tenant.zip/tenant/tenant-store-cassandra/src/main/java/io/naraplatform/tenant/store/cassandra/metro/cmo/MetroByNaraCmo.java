package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Metro;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_by_nara")
@Getter
@Setter
@NoArgsConstructor
public class MetroByNaraCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "naraId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String naraId;
    @PrimaryKeyColumn(name = "metroId", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String metroId;
    private String json;

    public MetroByNaraCmo(Metro metro) {
        //
        this.naraId = metro.getNara().getId();
        this.metroId = metro.getId();

        this.json = metro.toJson();
    }

    public Metro toDomain() {
        //
        return Metro.fromJson(json);
    }
}
