package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TownRepository extends CassandraRepository<TownCmo, String> {
}
