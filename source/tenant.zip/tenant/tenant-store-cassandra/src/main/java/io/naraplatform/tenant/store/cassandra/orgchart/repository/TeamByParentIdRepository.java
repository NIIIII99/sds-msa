package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamByOrgChartIdCmo;
import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamByParentIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TeamByParentIdRepository extends CassandraRepository<TeamByParentIdCmo, String> {
    //
    List<TeamByParentIdCmo> findAllByParentId(String orgChartId);
}
