package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.ActiveTowner;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("towner_active_by_townId_and_name")
@Getter
@Setter
@NoArgsConstructor
public class ActiveTownerByTownIdAndNameCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "townId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String townId;
    @PrimaryKeyColumn(name = "name", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String name;
    @PrimaryKeyColumn(name = "id", ordinal = 3, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public ActiveTownerByTownIdAndNameCmo(ActiveTowner activeTowner) {
        //
        this.townId = activeTowner.getTownId();
        this.name = activeTowner.getName();
        this.id = activeTowner.getId();
        this.json = activeTowner.toJson();
    }

    public ActiveTowner toDomain() {
        //
        return ActiveTowner.fromJson(json);
    }
}
