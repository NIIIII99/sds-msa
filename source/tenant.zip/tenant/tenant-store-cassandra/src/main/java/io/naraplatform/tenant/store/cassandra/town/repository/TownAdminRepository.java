package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TownAdminRepository extends CassandraRepository<TownAdminCmo, String> {
}
