package io.naraplatform.tenant.store.cassandra.nara.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nara_label_book_by_metro")
@Getter
@Setter
@NoArgsConstructor
public class NaraLabelBookByMetroTypeCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "metroType", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String metroType;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public NaraLabelBookByMetroTypeCmo(NaraLabelBook naraLabelBook) {
        //
        this.metroType = naraLabelBook.getMetroType().toString();
        this.id = naraLabelBook.getId();
        this.json = naraLabelBook.toJson();
    }

    public NaraLabelBook toDomain() {
        //
        return NaraLabelBook.fromJson(json);
    }
}
