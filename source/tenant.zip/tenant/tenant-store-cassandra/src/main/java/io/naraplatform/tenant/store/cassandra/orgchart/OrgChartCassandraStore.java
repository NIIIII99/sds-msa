package io.naraplatform.tenant.store.cassandra.orgchart;

import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.store.cassandra.orgchart.cmo.*;
import io.naraplatform.tenant.store.cassandra.orgchart.repository.*;
import io.naraplatform.tenant.store.orgchart.OrgChartStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class OrgChartCassandraStore implements OrgChartStore {
    //
    @Autowired
    OrgChartRepository orgChartRepository;
    @Autowired
    OrgChartByMetroIdRepository orgChartByMetroIdRepository;
    @Autowired
    TeamNodeRepository teamNodeRepository;
    @Autowired
    TeamNodeByParentIdRepository teamNodeByParentIdRepository;
    @Autowired
    TeamNodeByOrgChartIdAndParentIdRepository teamNodeByOrgChartIdAndParentIdRepository;

    @Override
    public void create(OrgChart orgChart) {
        //
        orgChartRepository.save(new OrgChartCmo(orgChart));
        orgChartByMetroIdRepository.save(new OrgChartByMetroIdCmo(orgChart));
    }

    @Override
    public OrgChart retrieve(String id) {
        //
        Optional<OrgChartCmo> orgChartCmo = orgChartRepository.findById(id);
        if (!orgChartCmo.isPresent()) {
            throw new NoSuchElementException(String.format("OrgChart(%s) is not found.", id));
        }

        return orgChartCmo.get().toDomain();
    }

    @Override
    public List<OrgChart> retrieveByMetroId(String metroId) {
        //
        List<OrgChartByMetroIdCmo> orgChartByMetroIdCmos = orgChartByMetroIdRepository.findAllByMetroId(metroId);
        return orgChartByMetroIdCmos.stream()
            .map(OrgChartByMetroIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(OrgChart orgChart) {
        //
        orgChartRepository.save(new OrgChartCmo(orgChart));
        orgChartByMetroIdRepository.save(new OrgChartByMetroIdCmo(orgChart));
    }

    @Override
    public void delete(OrgChart orgChart) {
        //
        orgChartRepository.delete(new OrgChartCmo(orgChart));
        orgChartByMetroIdRepository.delete(new OrgChartByMetroIdCmo(orgChart));
    }

    @Override
    public void delete(String id) {
        //
        Optional<OrgChartCmo> orgChartCmo = orgChartRepository.findById(id);
        if (orgChartCmo.isPresent()) {
            OrgChart orgChart = orgChartCmo.get().toDomain();
            this.delete(orgChart);
        }
    }

    @Override
    public void createTeamNode(TeamNode node) {
        //
        teamNodeRepository.save(new TeamNodeCmo(node));
        teamNodeByParentIdRepository.save(new TeamNodeByParentIdCmo(node));
        teamNodeByOrgChartIdAndParentIdRepository.save(new TeamNodeByOrgChartIdAndParentIdCmo(node));
    }

    @Override
    public TeamNode retrieveTeamNode(String nodeId) {
        //
        Optional<TeamNodeCmo> teamNodeCmo = teamNodeRepository.findById(nodeId);
        if (!teamNodeCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TeamNode(%s) is not found.", nodeId));
        }

        return teamNodeCmo.get().toDomain();
    }

    @Override
    public List<TeamNode> retrieveTeamNodesByParentId(String parentId) {
        //
        List<TeamNodeByParentIdCmo> teamNodeByParentIdCmos = teamNodeByParentIdRepository.findAllByParentId(parentId);
        return teamNodeByParentIdCmos.stream()
            .map(TeamNodeByParentIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<TeamNode> retrieveTeamNodesByOrgChartId(String orgChartId) {
        //
        List<TeamNodeByOrgChartIdAndParentIdCmo> teamNodeByOrgChartIdAndParentIdCmos = teamNodeByOrgChartIdAndParentIdRepository.findAllByOrgChartId(orgChartId);
        return teamNodeByOrgChartIdAndParentIdCmos.stream()
            .map(TeamNodeByOrgChartIdAndParentIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateTeamNode(TeamNode teamNode) {
        //
        teamNodeRepository.save(new TeamNodeCmo(teamNode));
        teamNodeByParentIdRepository.save(new TeamNodeByParentIdCmo(teamNode));
        teamNodeByOrgChartIdAndParentIdRepository.save(new TeamNodeByOrgChartIdAndParentIdCmo(teamNode));
    }

    @Override
    public void updateTeamNodes(List<TeamNode> teamNodes) {
        //
        for (TeamNode teamNode: teamNodes) {
            teamNodeRepository.save(new TeamNodeCmo(teamNode));
            teamNodeByParentIdRepository.save(new TeamNodeByParentIdCmo(teamNode));
            teamNodeByOrgChartIdAndParentIdRepository.save(new TeamNodeByOrgChartIdAndParentIdCmo(teamNode));
        }
    }

    @Override
    public void deleteTeamNode(TeamNode teamNode) {
        //
        teamNodeRepository.delete(new TeamNodeCmo(teamNode));
        teamNodeByParentIdRepository.delete(new TeamNodeByParentIdCmo(teamNode));
        teamNodeByOrgChartIdAndParentIdRepository.delete(new TeamNodeByOrgChartIdAndParentIdCmo(teamNode));
    }

    @Override
    public void deleteTeamNode(String nodeId) {
        //
        TeamNode teamNode = this.retrieveTeamNode(nodeId);

        teamNodeRepository.delete(new TeamNodeCmo(teamNode));
        teamNodeByParentIdRepository.delete(new TeamNodeByParentIdCmo(teamNode));
        teamNodeByOrgChartIdAndParentIdRepository.delete(new TeamNodeByOrgChartIdAndParentIdCmo(teamNode));
    }

    @Override
    public void deleteTeamNodesByOrgChartId(String orgChartId) {
        //
        List<TeamNode> teamNodes = this.retrieveTeamNodesByOrgChartId(orgChartId);
        for (TeamNode teamNode: teamNodes) {
            this.deleteTeamNode(teamNode);
        }
    }

    @Override
    public void deleteTeamNodesByParentId(String parentId) {
        //
        List<TeamNode> teamNodes = this.retrieveTeamNodesByParentId(parentId);
        for (TeamNode teamNode: teamNodes) {
            this.deleteTeamNode(teamNode);
        }
    }

    @Override
    public void deleteTeamNodeByOrgChartIdAndParentId(String orgChartId, String parentId) {
        //
        List<TeamNodeByOrgChartIdAndParentIdCmo> teamNodeByOrgChartIdAndParentIdCmos = teamNodeByOrgChartIdAndParentIdRepository.findAllByOrgChartIdAndParentId(orgChartId, parentId);
        List<TeamNode> teamNodes = teamNodeByOrgChartIdAndParentIdCmos.stream().map(TeamNodeByOrgChartIdAndParentIdCmo::toDomain).collect(Collectors.toList());
        for (TeamNode teamNode: teamNodes) {
            this.deleteTeamNode(teamNode);
        }
    }

    @Override
    public int countTeamNodesByOrgChartId(String orgChartId) {
        //
        return this.retrieveTeamNodesByOrgChartId(orgChartId).size();
    }

    @Override
    public int countTeamNodesByParentId(String parentId) {
        //
        return this.retrieveTeamNodesByParentId(parentId).size();
    }
}
