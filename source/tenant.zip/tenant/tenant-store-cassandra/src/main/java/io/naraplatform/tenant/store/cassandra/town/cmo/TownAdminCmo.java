package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.enumtype.Tier;
import io.naraplatform.share.domain.granule.Contact;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.entity.town.TownAdmin;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_admin")
@Getter
@Setter
@NoArgsConstructor
public class TownAdminCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String citizenJson;
    private String tier;
    private String contactJson;
    private String townId;

    public TownAdminCmo(TownAdmin townAdmin) {
        //
        this.id = townAdmin.getId();
        this.citizenJson = townAdmin.getCitizen().toJson();
        this.tier = townAdmin.getTier().toString();
        this.contactJson = townAdmin.getContact().toJson();
        this.townId = townAdmin.getTownId();
    }

    public TownAdmin toDomain() {
        //
        TownAdmin townAdmin = new TownAdmin(id);
        townAdmin.setCitizen(IdName.fromJson(citizenJson));
        townAdmin.setTier(Tier.valueOf(tier));
        townAdmin.setContact(Contact.fromJson(contactJson));
        townAdmin.setTownId(townId);
        return townAdmin;
    }
}

