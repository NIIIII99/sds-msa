package io.naraplatform.tenant.store.cassandra.nara.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.nara.Nara;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("nara_by_usid")
@Getter
@Setter
@NoArgsConstructor
public class NaraByUsidCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "usid", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String usid;
    @PrimaryKeyColumn(name = "id", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String name;
    private long time;

    public NaraByUsidCmo(Nara nara) {
        //
        this.usid = nara.getUsid();
        this.name = nara.getName();
        this.id = nara.getId();
        this.time = nara.getTime();
    }

    public Nara toDomain() {
        //
        Nara nara = new Nara(this.id);
        nara.setUsid(this.usid);
        nara.setName(this.name);
        nara.setTime(this.time);
        return nara;
    }
}
