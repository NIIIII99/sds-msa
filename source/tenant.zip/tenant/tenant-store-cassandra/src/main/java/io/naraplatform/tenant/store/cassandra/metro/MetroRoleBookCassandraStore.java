package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleBookCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleByMetroIdAndNameCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.MetroRoleCmo;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroRoleBookRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroRoleByMetroIdAndNameRepository;
import io.naraplatform.tenant.store.cassandra.metro.repository.MetroRoleRepository;
import io.naraplatform.tenant.store.metro.MetroRoleBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class MetroRoleBookCassandraStore implements MetroRoleBookStore {
    //
    @Autowired
    MetroRoleBookRepository metroRoleBookRepository;
    @Autowired
    MetroRoleRepository metroRoleRepository;
    @Autowired
    MetroRoleByMetroIdAndNameRepository metroRoleByMetroIdAndNameRepository;

    @Override
    public void create(MetroRoleBook metroRoleBook) {
        //
        metroRoleBookRepository.save(new MetroRoleBookCmo(metroRoleBook));
    }

    @Override
    public MetroRoleBook retrieve(String metroId) {
        //
        Optional<MetroRoleBookCmo> metroRoleBookCmo = metroRoleBookRepository.findById(metroId);
        if (!metroRoleBookCmo.isPresent()) {
            throw new NoSuchElementException(String.format("MetroRoleBook(%s) is not found.", metroId));
        }

        return metroRoleBookCmo.get().toDomain();
    }

    @Override
    public void update(MetroRoleBook metroRoleBook) {
        //
        metroRoleBookRepository.save(new MetroRoleBookCmo(metroRoleBook));
    }

    @Override
    public void delete(MetroRoleBook metroRoleBook) {
        //
        metroRoleBookRepository.delete(new MetroRoleBookCmo(metroRoleBook));
    }

    @Override
    public boolean exists(String metroId) {
        //
        return metroRoleBookRepository.existsById(metroId);
    }

    @Override
    public void createMetroRole(MetroRole metroRole) {
        //
        metroRoleRepository.save(new MetroRoleCmo(metroRole));
        metroRoleByMetroIdAndNameRepository.save(new MetroRoleByMetroIdAndNameCmo(metroRole));
    }

    @Override
    public MetroRole retrieveMetroRole(String roleId) {
        //
        Optional<MetroRoleCmo> metroRoleCmo = metroRoleRepository.findById(roleId);
        if (!metroRoleCmo.isPresent()) {
            throw new NoSuchElementException(String.format("MetroRole(%s) is not found.", roleId));
        }

        return metroRoleCmo.get().toDomain();
    }

    @Override
    public List<MetroRole> retrieveMetroRolesByMetroId(String metroId) {
        //
        List<MetroRoleByMetroIdAndNameCmo> metroRoleByMetroIdAndNameCmos = metroRoleByMetroIdAndNameRepository.findAllByMetroId(metroId);
        return metroRoleByMetroIdAndNameCmos.stream()
            .map(MetroRoleByMetroIdAndNameCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateMetroRole(MetroRole metroRole) {
        //
        metroRoleRepository.save(new MetroRoleCmo(metroRole));
        metroRoleByMetroIdAndNameRepository.save(new MetroRoleByMetroIdAndNameCmo(metroRole));
    }

    @Override
    public void deleteMetroRole(MetroRole metroRole) {
        //
        metroRoleRepository.delete(new MetroRoleCmo(metroRole));
        metroRoleByMetroIdAndNameRepository.delete(new MetroRoleByMetroIdAndNameCmo(metroRole));
    }

    @Override
    public void deleteMetroRole(String roleId) {
        //
        Optional<MetroRoleCmo> metroRoleCmo = metroRoleRepository.findById(roleId);
        if (metroRoleCmo.isPresent()) {
            metroRoleRepository.delete(metroRoleCmo.get());
            metroRoleByMetroIdAndNameRepository.delete(new MetroRoleByMetroIdAndNameCmo(metroRoleCmo.get().toDomain()));
        }
    }

    @Override
    public void deleteMetroRolesByMetroId(String metroId) {
        //
        List<MetroRoleByMetroIdAndNameCmo> metroRoleByMetroIdAndNameCmos = metroRoleByMetroIdAndNameRepository.findAllByMetroId(metroId);
        metroRoleByMetroIdAndNameCmos.stream()
            .map(MetroRoleByMetroIdAndNameCmo::toDomain)
            .forEach((metroRole) -> {
                metroRoleRepository.delete(new MetroRoleCmo(metroRole));
                metroRoleByMetroIdAndNameRepository.delete(new MetroRoleByMetroIdAndNameCmo(metroRole));
            });

    }

    @Override
    public boolean existsMetroRoleByMetroIdAndRoleName(String metroId, String roleName) {
        //
        Optional<MetroRoleByMetroIdAndNameCmo> metroRoleByMetroIdAndNameCmo = metroRoleByMetroIdAndNameRepository.findByMetroIdAndName(metroId, roleName);
        return metroRoleByMetroIdAndNameCmo.isPresent();
    }
}
