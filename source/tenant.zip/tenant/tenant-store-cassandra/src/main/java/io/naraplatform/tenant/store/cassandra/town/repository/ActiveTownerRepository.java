package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.ActiveTownerCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface ActiveTownerRepository extends CassandraRepository<ActiveTownerCmo, String> {
}
