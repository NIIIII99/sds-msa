package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_member_by_teamId_and_citizenId")
@Getter
@Setter
@NoArgsConstructor
public class TeamMemberByTeamIdAndCitizenIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "teamId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String teamId;
    @PrimaryKeyColumn(name = "citizenId", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String citizenId;
    @PrimaryKeyColumn(name = "id", ordinal = 3, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public TeamMemberByTeamIdAndCitizenIdCmo(TeamMember teamMember) {
        //
        this.id = teamMember.getId();
        this.teamId = teamMember.getTeamId();
        this.citizenId = teamMember.getCitizen().getId();
        this.json = teamMember.toJson();
    }

    public TeamMember toDomain() {
        //
        return TeamMember.fromJson(this.json);
    }
}
