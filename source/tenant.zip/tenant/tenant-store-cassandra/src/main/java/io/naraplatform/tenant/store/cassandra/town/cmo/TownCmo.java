package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.policy.TownType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town")
@Getter
@Setter
@NoArgsConstructor
public class TownCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String usid;                    // team code, if exists
    private String supportLangsJson;
    private String titlesJson;
    private String pathNamesJson;          // NextreeConsulting/R&DCenter/TeamA
    private String type;
    private String policyJson;
    private String baseRoleName;            // User
    private long time;

    private String tinyAlbumId;             // from depot service
    private String profileId;               // from profile service
    private String townDiskId;              // from town service

    private String metroId;

    public TownCmo(Town town) {
        //
        this.id = town.getId();
        BeanUtils.copyProperties(town, this);
        this.supportLangsJson = JsonUtil.toJson(town.getSupportLangs());
        this.titlesJson = town.getTitles().toJson();
        this.pathNamesJson = town.getPathNames().toJson();
        this.type = town.getType().toString();
    }

    public Town toDomain() {
        //
        Town town = new Town(this.id);
        BeanUtils.copyProperties(this, town);
        town.setSupportLangs(JsonUtil.fromJsonList(this.supportLangsJson, String.class));
        town.setTitles(LangStrings.fromJson(titlesJson));
        town.setPathNames(LangStrings.fromJson(pathNamesJson));
        town.setType(TownType.valueOf(type));

        return town;
    }
}
