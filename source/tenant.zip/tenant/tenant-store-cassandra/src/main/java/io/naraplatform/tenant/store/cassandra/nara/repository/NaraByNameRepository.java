package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraByNameCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface NaraByNameRepository extends CassandraRepository<NaraByNameCmo, String> {
    //
    Optional<NaraByNameCmo> findByName(String name);
}
