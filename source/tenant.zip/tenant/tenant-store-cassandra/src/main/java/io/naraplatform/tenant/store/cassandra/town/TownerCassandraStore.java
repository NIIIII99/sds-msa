package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.ActiveTowner;
import io.naraplatform.tenant.entity.town.DormantTowner;
import io.naraplatform.tenant.entity.town.TownerIdentity;
import io.naraplatform.tenant.store.cassandra.town.cmo.*;
import io.naraplatform.tenant.store.cassandra.town.repository.*;
import io.naraplatform.tenant.store.town.TownerStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class TownerCassandraStore implements TownerStore {
    //
    @Autowired
    ActiveTownerRepository activeTownerRepository;
    @Autowired
    ActiveTownerByTownIdAndUsidRepository activeTownerByTownIdAndUsidRepository;
    @Autowired
    ActiveTownerByTownIdAndNameRepository activeTownerByTownIdAndNameRepository;

    @Autowired
    DormantTownerRepository dormantTownerRepository;
    @Autowired
    DormantTownerByTownIdAndCitizenIdRepository dormantTownerByTownIdAndCitizenIdRepository;

    @Override
    public void create(ActiveTowner towner) {
        //
        activeTownerRepository.save(new ActiveTownerCmo(towner));
        activeTownerByTownIdAndUsidRepository.save(new ActiveTownerByTownIdAndUsidCmo(towner));
        activeTownerByTownIdAndNameRepository.save(new ActiveTownerByTownIdAndNameCmo(towner));
    }

    @Override
    public ActiveTowner retrieveActiveTowner(String id) {
        //
        Optional<ActiveTownerCmo> activeTownerCmo = activeTownerRepository.findById(id);
        if (!activeTownerCmo.isPresent()) {
            throw new NoSuchElementException(String.format("ActiveTowner(%s) is not found.", id));
        }

        return activeTownerCmo.get().toDomain();
    }

    @Override
    public ActiveTowner retrieveActiveTownerByTownIdAndUsid(String townId, String usid) {
        //
        Optional<ActiveTownerByTownIdAndUsidCmo> activeTownerByTownIdAndUsidCmo = activeTownerByTownIdAndUsidRepository.findByTownIdAndUsid(townId, usid);
        if (!activeTownerByTownIdAndUsidCmo.isPresent()) {
            throw new NoSuchElementException(String.format("ActiveTowner(%s, %s) is not found.", townId, usid));
        }

        return activeTownerByTownIdAndUsidCmo.get().toDomain();
    }

    @Override
    public List<ActiveTowner> retrieveActiveTownerByTownIdAndNameLike(String townId, String nameLike) {
        //
        List<ActiveTownerByTownIdAndNameCmo> activeTownerByTownIdAndNameCmos = activeTownerByTownIdAndNameRepository.findAllByTownIdAndNameLike(townId, nameLike);
        return activeTownerByTownIdAndNameCmos.stream()
            .map(ActiveTownerByTownIdAndNameCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public List<ActiveTowner> retrieveActiveTownerByTownId(String townId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<ActiveTownerByTownIdAndUsidCmo> activeTownerByTownIdAndUsidCmos = activeTownerByTownIdAndUsidRepository.findAllByTownId(townId, pageable);
        return activeTownerByTownIdAndUsidCmos.stream()
            .map(ActiveTownerByTownIdAndUsidCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void updateActiveTowner(ActiveTowner towner) {
        //
        activeTownerRepository.save(new ActiveTownerCmo(towner));
        activeTownerByTownIdAndUsidRepository.save(new ActiveTownerByTownIdAndUsidCmo(towner));
        activeTownerByTownIdAndNameRepository.save(new ActiveTownerByTownIdAndNameCmo(towner));
    }

    @Override
    public void deleteActiveTowner(ActiveTowner towner) {
        //
        activeTownerRepository.delete(new ActiveTownerCmo(towner));
        activeTownerByTownIdAndUsidRepository.delete(new ActiveTownerByTownIdAndUsidCmo(towner));
        activeTownerByTownIdAndNameRepository.delete(new ActiveTownerByTownIdAndNameCmo(towner));
    }

    @Override
    public void deleteActiveTownersByTownerIds(List<String> townerIds) {
        //
        List<ActiveTownerCmo> activeTownerCmos = activeTownerRepository.findAllById(townerIds);
        activeTownerCmos.stream()
            .map(ActiveTownerCmo::toDomain)
            .forEach((activeTowner -> {
                deleteActiveTowner(activeTowner);
            }));
    }

    @Override
    public void deleteActiveTownersByTownId(String townId) {
        //
        List<ActiveTownerByTownIdAndUsidCmo> activeTownerByTownIdAndUsidCmos = activeTownerByTownIdAndUsidRepository.findAllByTownId(townId);
        activeTownerByTownIdAndUsidCmos.stream()
            .map(ActiveTownerByTownIdAndUsidCmo::toDomain)
            .forEach((activeTowner -> {
                deleteActiveTowner(activeTowner);
            }));
    }

    @Override
    public long countActiveTownerByTownId(String townId) {
        //
        return activeTownerByTownIdAndUsidRepository.findAllByTownId(townId).size();
    }

    @Override
    public void create(DormantTowner towner) {
        //
        dormantTownerRepository.save(new DormantTownerCmo(towner));
        dormantTownerByTownIdAndCitizenIdRepository.save(new DormantTownerByTownIdAndCitizenIdCmo(towner));
    }

    @Override
    public DormantTowner retrieveDormantTowner(String id) {
        //
        Optional<DormantTownerCmo> dormantTownerCmo = dormantTownerRepository.findById(id);
        if (!dormantTownerCmo.isPresent()) {
            throw new NoSuchElementException(String.format("DormantTowner(%s) is not found.", id));
        }

        return dormantTownerCmo.get().toDomain();
    }

    @Override
    public List<DormantTowner> retrieveDormantTownerByTownId(String townId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        List<DormantTownerByTownIdAndCitizenIdCmo> dormantTownerByTownIdAndCitizenIdCmos = dormantTownerByTownIdAndCitizenIdRepository.findAllByTownId(townId, pageable);
        return dormantTownerByTownIdAndCitizenIdCmos.stream()
            .map(DormantTownerByTownIdAndCitizenIdCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void deleteDormantTowner(DormantTowner towner) {
        //
        dormantTownerRepository.delete(new DormantTownerCmo(towner));
        dormantTownerByTownIdAndCitizenIdRepository.delete(new DormantTownerByTownIdAndCitizenIdCmo(towner));
    }

    @Override
    public void deleteDormantTownersByTownerIds(List<String> townerIds) {
        //
        List<DormantTownerCmo> dormantTownerCmos = dormantTownerRepository.findAllById(townerIds);
        dormantTownerCmos.stream()
            .map(DormantTownerCmo::toDomain)
            .forEach((dormantTowner -> {
                deleteDormantTowner(dormantTowner);
            }));
    }

    @Override
    public List<String> deleteDormantTownersByTownId(String townId) {
        //
        List<DormantTownerByTownIdAndCitizenIdCmo> dormantTownerByTownIdAndCitizenIdCmos = dormantTownerByTownIdAndCitizenIdRepository.findAllByTownId(townId);
        dormantTownerByTownIdAndCitizenIdCmos.stream()
            .map(DormantTownerByTownIdAndCitizenIdCmo::toDomain)
            .forEach((dormantTowner -> {
                deleteDormantTowner(dormantTowner);
            }));
        return dormantTownerByTownIdAndCitizenIdCmos.stream()
            .map(DormantTownerByTownIdAndCitizenIdCmo::getId)
            .collect(Collectors.toList());
    }

    @Override
    public void create(TownerIdentity identity) {

    }

    @Override
    public TownerIdentity retrieveIdentity(String townerId) {
        return null;
    }

    @Override
    public TownerIdentity retrieveIdentityByTownIdAndCitizenId(String townId, String citizenId) {
        return null;
    }

    @Override
    public List<TownerIdentity> retrieveIdentitiesByTownId(String townId, int offset, int limit) {
        return null;
    }

    @Override
    public boolean existsIdentityByTownIdAndCitizenId(String townId, String citizenId) {
        return false;
    }

    @Override
    public void updateIdentity(TownerIdentity identity) {

    }

    @Override
    public void deleteIdentity(String identity) {

    }

    @Override
    public void deleteIdentitiesByTownId(String townId) {

    }

    @Override
    public void deleteIdentitiesByTownerIds(List<String> townerIds) {

    }
}
