package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.domain.Expiration;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import io.naraplatform.tenant.entity.town.DormantTowner;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("towner_dormant")
@Getter
@Setter
@NoArgsConstructor
public class DormantTownerCmo implements JsonSerializable {
    //
    @PrimaryKey
    private String id;
    private String usid;
    private String name;
    private String title;
    private String nickname;
    private String roleNamesJson;
    private String expirationJson;
    private String citizenId;
    private String townId;

    public DormantTownerCmo(DormantTowner dormantTowner) {
        //
        this.id = dormantTowner.getId();
        BeanUtils.copyProperties(dormantTowner, this);
        this.roleNamesJson = JsonUtil.toJson(dormantTowner.getRoleNames());
        this.expirationJson = dormantTowner.getExpiration().toJson();
    }

    public DormantTowner toDomain() {
        //
        DormantTowner dormantTowner = new DormantTowner(this.id);
        BeanUtils.copyProperties(this, dormantTowner);
        dormantTowner.setRoleNames(JsonUtil.fromJsonList(roleNamesJson, String.class));
        dormantTowner.setExpiration(Expiration.fromJson(expirationJson));
        return dormantTowner;
    }
}
