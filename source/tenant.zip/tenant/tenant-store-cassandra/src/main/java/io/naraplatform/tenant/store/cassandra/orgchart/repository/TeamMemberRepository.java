package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamMemberCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TeamMemberRepository extends CassandraRepository<TeamMemberCmo, String> {
}
