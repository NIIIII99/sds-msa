package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.Team;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_by_parentId")
@Getter
@Setter
@NoArgsConstructor
public class TeamByParentIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "parentId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String parentId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;              // teamNode's id
    private String json;

    public TeamByParentIdCmo(Team team) {
        //
        this.parentId = team.getParentId();
        this.id = team.getId();
        this.json = team.toJson();
    }

    public Team toDomain() {
        //
        return Team.fromJson(json);
    }
}
