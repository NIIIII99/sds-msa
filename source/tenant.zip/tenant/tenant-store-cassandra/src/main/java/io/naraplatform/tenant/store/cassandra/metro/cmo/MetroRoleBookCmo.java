package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("metro_rolebook")
@Getter
@Setter
@NoArgsConstructor
public class MetroRoleBookCmo implements JsonSerializable {

    @PrimaryKey
    private String id;                      // id = metroId
    private String metroName;
    private String adminRoleName;
    private String baseUserRoleName;

    public MetroRoleBookCmo(MetroRoleBook metroRoleBook) {
        //
        BeanUtils.copyProperties(metroRoleBook, this);
    }

    public MetroRoleBook toDomain() {
        //
        MetroRoleBook metroRoleBook = new MetroRoleBook(this.id);
        BeanUtils.copyProperties(this, metroRoleBook);
        return metroRoleBook;
    }

}
