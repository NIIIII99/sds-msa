package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByEmailCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.Optional;

public interface CitizenByEmailRepository extends CassandraRepository<CitizenByEmailCmo, String> {
    //
    Optional<CitizenByEmailCmo> findByEmail(String email);
}
