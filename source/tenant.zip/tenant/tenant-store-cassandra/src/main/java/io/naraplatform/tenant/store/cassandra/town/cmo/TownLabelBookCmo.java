package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_labelbook")
@Getter
@Setter
@NoArgsConstructor
public class TownLabelBookCmo {
    //
    @PrimaryKey
    private String id;
    private String townLabelsJson;
    private String townerLabelsJson;

    public TownLabelBookCmo(TownLabelBook townLabelBook) {
        //
        this.id = townLabelBook.getId();
        this.townLabelsJson = townLabelBook.getTownLabels().toJson();
        this.townerLabelsJson = townLabelBook.getTownerLabels().toJson();
    }

    public TownLabelBook toDomain() {
        //
        TownLabelBook townLabelBook = new TownLabelBook(id);
        townLabelBook.setTownLabels(LangStrings.fromJson(townLabelsJson));
        townLabelBook.setTownerLabels(LangStrings.fromJson(townerLabelsJson));
        return townLabelBook;
    }
}

