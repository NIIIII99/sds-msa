package io.naraplatform.tenant.store.cassandra.metro.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.metro.Citizen;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("citizen_by_metroid_and_usid")
@Getter
@Setter
@NoArgsConstructor
public class CitizenByMetroIdAndUsidCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "metroId", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
    private String metroId;
    @PrimaryKeyColumn(name = "usid", ordinal = 1, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String usid;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;

    public CitizenByMetroIdAndUsidCmo(Citizen citizen) {
        //
        this.metroId = citizen.getMetroId();
        this.usid = citizen.getUsid();
        this.id = citizen.getId();
        this.json = citizen.toJson();
    }

    public Citizen toDomain() {
        //
        return Citizen.fromJson(json);
    }
}
