package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownAdminBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TownAdminBookRepository extends CassandraRepository<TownAdminBookCmo, String> {
}
