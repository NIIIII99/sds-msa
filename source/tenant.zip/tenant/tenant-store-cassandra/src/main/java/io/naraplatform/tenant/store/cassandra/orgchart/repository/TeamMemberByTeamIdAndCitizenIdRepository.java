package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamMemberByTeamIdAndCitizenIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface TeamMemberByTeamIdAndCitizenIdRepository extends CassandraRepository<TeamMemberByTeamIdAndCitizenIdCmo, String> {
    //
    Optional<TeamMemberByTeamIdAndCitizenIdCmo> findByTeamIdAndCitizenId(String teamId, String citizenId);
    List<TeamMemberByTeamIdAndCitizenIdCmo> findAllByTeamId(String teamId, Pageable pageable);
    List<TeamMemberByTeamIdAndCitizenIdCmo> findAllByTeamId(String teamId);
}
