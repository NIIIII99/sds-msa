package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownLabelBookCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface TownLabelBookRepository extends CassandraRepository<TownLabelBookCmo, String> {
}
