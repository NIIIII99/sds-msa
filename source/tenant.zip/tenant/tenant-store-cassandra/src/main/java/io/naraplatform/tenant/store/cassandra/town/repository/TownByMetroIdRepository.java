package io.naraplatform.tenant.store.cassandra.town.repository;

import io.naraplatform.tenant.store.cassandra.town.cmo.TownByMetroIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TownByMetroIdRepository extends CassandraRepository<TownByMetroIdCmo, String> {
    //
    List<TownByMetroIdCmo> findAllByMetroId(String metroId, Pageable pageable);
}
