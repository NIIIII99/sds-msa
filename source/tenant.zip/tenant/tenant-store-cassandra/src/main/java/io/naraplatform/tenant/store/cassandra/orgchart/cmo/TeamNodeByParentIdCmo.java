package io.naraplatform.tenant.store.cassandra.orgchart.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("team_node_by_parentId")
@Getter
@Setter
@NoArgsConstructor
public class TeamNodeByParentIdCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "parentId", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String parentId;
    @PrimaryKeyColumn(name = "id", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    @PrimaryKeyColumn(name = "levelSequence", ordinal = 3, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private int levelSequence;
    @PrimaryKeyColumn(name = "childSequence", ordinal = 4, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private int childSequence;
    private String json;

    public TeamNodeByParentIdCmo(TeamNode teamNode) {
        //
        this.parentId = teamNode.getParentId();
        this.id = teamNode.getId();
        this.levelSequence = teamNode.getLevelSequence();
        this.childSequence = teamNode.getChildSequence();
        this.json = teamNode.toJson();
    }

    public TeamNode toDomain() {
        //
        return TeamNode.fromJson(this.json);
    }

}
