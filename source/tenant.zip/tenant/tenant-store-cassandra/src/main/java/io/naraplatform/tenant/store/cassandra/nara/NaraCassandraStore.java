package io.naraplatform.tenant.store.cassandra.nara;

import io.naraplatform.tenant.entity.nara.Nara;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraByNameCmo;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraByUsidCmo;
import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraCmo;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraByNameRepository;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraByUsidRepository;
import io.naraplatform.tenant.store.cassandra.nara.repository.NaraRepository;
import io.naraplatform.tenant.store.nara.NaraStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class NaraCassandraStore implements NaraStore {
    //
    @Autowired
    NaraRepository naraRepository;
    @Autowired
    NaraByUsidRepository naraByUsidRepository;
    @Autowired
    NaraByNameRepository naraByNameRepository;

    @Override
    public void create(Nara nara) {
        //
        naraRepository.save(new NaraCmo(nara));
        naraByUsidRepository.save(new NaraByUsidCmo(nara));
        naraByNameRepository.save(new NaraByNameCmo(nara));
    }

    @Override
    public Nara retrieve(String id) {
        //
        Optional<NaraCmo> naraCmo = naraRepository.findById(id);
        if (!naraCmo.isPresent()) {
            throw new NoSuchElementException("Nara is not found!");
        }

        return naraCmo.get().toDomain();
    }

    @Override
    public Nara retrieveByUsid(String usid) {
        //
        Optional<NaraByUsidCmo> naraByUsidAndNameCmo = naraByUsidRepository.findByUsid(usid);
        if (!naraByUsidAndNameCmo.isPresent()) {
            throw new NoSuchElementException("Nara is not found!");
        }

        return naraByUsidAndNameCmo.get().toDomain();
    }

    @Override
    public List<Nara> retrieveAll() {
        //
        List<NaraCmo> naraCmos = naraRepository.findAll();
        return naraCmos.stream()
            .map(NaraCmo::toDomain)
            .collect(Collectors.toList());
    }

    @Override
    public void update(Nara nara) {
        //
        naraRepository.save(new NaraCmo(nara));
        naraByUsidRepository.save(new NaraByUsidCmo(nara));
        naraByNameRepository.save(new NaraByNameCmo(nara));
    }

    @Override
    public void delete(Nara nara) {
        //
        naraRepository.delete(new NaraCmo(nara));
        naraByUsidRepository.delete(new NaraByUsidCmo(nara));
        naraByNameRepository.delete(new NaraByNameCmo(nara));
    }

    @Override
    public boolean existsByUsidOrName(String usid, String name) {
        //
        Optional<NaraByUsidCmo> naraByUsidCmo = naraByUsidRepository.findByUsid(usid);
        if (naraByUsidCmo.isPresent()) {
            return true;
        }

        Optional<NaraByNameCmo> naraByNameCmo = naraByNameRepository.findByName(name);
        return naraByNameCmo.isPresent();
    }
}
