package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import io.naraplatform.tenant.store.cassandra.town.cmo.TownRoleBookCmo;
import io.naraplatform.tenant.store.cassandra.town.repository.TownRoleBookRepository;
import io.naraplatform.tenant.store.town.TownRoleBookStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.NoSuchElementException;
import java.util.Optional;

@Repository
public class TownRoleBookCassandraStore implements TownRoleBookStore {
    //
    @Autowired
    TownRoleBookRepository townRoleBookRepository;

    @Override
    public void create(TownRoleBook roleBook) {
        //
        townRoleBookRepository.save(new TownRoleBookCmo(roleBook));
    }

    @Override
    public TownRoleBook retrieve(String townId) {
        //
        Optional<TownRoleBookCmo> townRoleBookCmo = townRoleBookRepository.findById(townId);
        if (!townRoleBookCmo.isPresent()) {
            throw new NoSuchElementException(String.format("TownRoleBook(%s) is not found.", townId));
        }

        return townRoleBookCmo.get().toDomain();
    }

    @Override
    public void update(TownRoleBook roleBook) {
        //
        townRoleBookRepository.save(new TownRoleBookCmo(roleBook));
    }

    @Override
    public void delete(TownRoleBook roleBook) {
        //
        townRoleBookRepository.delete(new TownRoleBookCmo(roleBook));
    }

    @Override
    public boolean exists(String townId) {
        //
        return townRoleBookRepository.existsById(townId);
    }
}
