package io.naraplatform.tenant.store.cassandra.nara.repository;

import io.naraplatform.tenant.store.cassandra.nara.cmo.NaraLabelBookByMetroTypeCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface NaraLabelBookByMetroTypeRepository extends CassandraRepository<NaraLabelBookByMetroTypeCmo, String> {
    //
    List<NaraLabelBookByMetroTypeCmo> findAllByMetroType(String metroType, Pageable pageable);
}
