package io.naraplatform.tenant.store.cassandra.orgchart.repository;

import io.naraplatform.tenant.store.cassandra.orgchart.cmo.TeamByOrgChartIdCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.List;

public interface TeamByOrgChartIdRepository extends CassandraRepository<TeamByOrgChartIdCmo, String> {
    //
    List<TeamByOrgChartIdCmo> findAllByOrgChartId(String orgChartId);
}
