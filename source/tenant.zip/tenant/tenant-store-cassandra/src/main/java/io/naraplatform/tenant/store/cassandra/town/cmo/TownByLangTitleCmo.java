package io.naraplatform.tenant.store.cassandra.town.cmo;

import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.tenant.entity.town.Town;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("town_by_titleLang")
@Getter
@Setter
@NoArgsConstructor
public class TownByLangTitleCmo implements JsonSerializable {
    //
    @PrimaryKeyColumn(name = "title", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String title;
    @PrimaryKeyColumn(name = "langCode", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String langCode;
    @PrimaryKeyColumn(name = "id", ordinal = 3, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    private String id;
    private String json;


    public TownByLangTitleCmo(String langCode, Town town) {
        //
        this.title = town.getTitles().getString(langCode);
        this.langCode = langCode;
        this.id = town.getId();
        this.json = town.toJson();

    }

    public Town toDomain() {
        //
        return Town.fromJson(json);
    }
}
