package io.naraplatform.tenant.store.cassandra.metro.repository;

import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByEmailCmo;
import io.naraplatform.tenant.store.cassandra.metro.cmo.CitizenByMetroIdAndUsidCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface CitizenByMetroIdAndUsidRepository extends CassandraRepository<CitizenByMetroIdAndUsidCmo, String> {
    //
    List<CitizenByMetroIdAndUsidCmo> findAllByMetroId(String metroId);
    List<CitizenByMetroIdAndUsidCmo> findAllByMetroId(String metroId, Pageable pageable);
    Optional<CitizenByMetroIdAndUsidCmo> findByMetroIdAndUsid(String metroId, String usid);
}
