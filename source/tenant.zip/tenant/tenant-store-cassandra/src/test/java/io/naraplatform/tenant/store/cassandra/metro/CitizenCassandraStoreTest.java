package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.tenant.entity.metro.Citizen;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.metro.CitizenStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/citizen.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    CitizenCassandraStoreTest.class })
public class CitizenCassandraStoreTest {
    //
    @Autowired
    CitizenStore citizenStore;

    private static final String METRO_ID = "M0001";
    private Citizen citizen;

    @Before
    public void before() {
        //
        citizen = Citizen.sample();
        citizen.setMetroId(METRO_ID);
    }

    @Test
    public void testCreate() {
        //
        citizenStore.create(citizen);

        Citizen foundCitizen = citizenStore.retrieve(citizen.getId());
        Assert.assertNotNull(foundCitizen);
    }

    @Test
    public void testRetrieveByMetroIdAndUsid() {
        //
        citizenStore.create(citizen);

        Citizen foundCitizen = citizenStore.retrieveByMetroIdAndUsid(citizen.getMetroId(), citizen.getUsid());
        Assert.assertNotNull(foundCitizen);
    }

    @Test
    public void testRetrieveByMetroId() {
        //
        citizenStore.create(citizen);

        List<Citizen> foundCitizens = citizenStore.retrieveByMetroId(citizen.getMetroId(), 0, 10);
        Assert.assertEquals(foundCitizens.size(), 1);
    }

    @Test
    public void testRetrieveByMetroIdAndNameLike() {
        //
        citizenStore.create(citizen);

        List<Citizen> foundCitizens = citizenStore.retrieveByMetroIdAndNameLike(citizen.getMetroId(), "Stev%");
        Assert.assertTrue(foundCitizens.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteByMetroId() {
        //
        citizenStore.create(citizen);
        citizenStore.delete(citizen);

        citizenStore.retrieve(citizen.getId());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteByMetroIdAndUsid() {
        //
        citizenStore.create(citizen);
        citizenStore.delete(citizen);

        citizenStore.retrieveByMetroIdAndUsid(citizen.getMetroId(), citizen.getUsid());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteByMetroIdAndNameLike() {
        //
        citizenStore.create(citizen);
        citizenStore.delete(citizen);

        citizenStore.retrieveByMetroIdAndUsid(citizen.getMetroId(), citizen.getUsid());
    }

    @Test
    public void testExistsByMetroIdAndUsid() {
        //
        citizenStore.create(citizen);

        boolean exists = citizenStore.existsByMetroIdAndUsid(citizen.getMetroId(), citizen.getUsid());
        Assert.assertTrue(exists);
    }

    @Test
    public void testCountByMetroId() {
        //
        citizenStore.create(citizen);

        long count = citizenStore.countByMetroId(citizen.getMetroId());
        Assert.assertTrue(count > 0);
    }

//    void update(Citizen citizen);
//    void delete(Citizen citizen);
//    void deleteByMetroId(String metroId);
//    void deleteByCitizenIds(List<String> citizenIds);
//    boolean existsByMetroIdAndUsid(String metroId, String usid);
//    boolean existsByEmail(String email);
//    long countByMetroId(String metroId);
}
