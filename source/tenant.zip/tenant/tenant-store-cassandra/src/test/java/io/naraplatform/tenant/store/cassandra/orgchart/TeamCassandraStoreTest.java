package io.naraplatform.tenant.store.cassandra.orgchart;

import io.naraplatform.tenant.entity.orgchart.Team;
import io.naraplatform.tenant.entity.orgchart.TeamMember;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.orgchart.TeamStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/team_and_member.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TeamCassandraStoreTest.class })
public class TeamCassandraStoreTest {
    //
    @Autowired
    TeamStore teamStore;

    Team team;
    TeamMember teamMember;

    @Before
    public void before() {
        //
        team = Team.sample();
        teamMember = TeamMember.sample();
    }

    @Test
    public void testCreate() {
        //
        teamStore.create(team);

        Team foundTeam = teamStore.retrieve(team.getId());
        Assert.assertNotNull(foundTeam);
    }

    @Test
    public void testRetrieveByOrgChartId() {
        //
        team.setOrgChartId("orgchart-1");
        teamStore.create(team);

        List<Team> foundTeams = teamStore.retrieveByOrgChartId("orgchart-1");
        Assert.assertTrue(foundTeams.size() > 0);
    }

    @Test
    public void testRetrieveByParentId() {
        //
        Team childTeam = Team.sample();
        childTeam.setParentId(team.getId());

        teamStore.create(team);
        teamStore.create(childTeam);

        List<Team> foundTeams = teamStore.retrieveByParentId(team.getId());
        Assert.assertTrue(foundTeams.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        teamStore.create(team);
        teamStore.delete(team);

        teamStore.retrieve(team.getId());
    }

    @Test
    public void testDeleteWithParent() {
        //
        Team childTeam = Team.sample();
        childTeam.setParentId(team.getId());

        teamStore.create(childTeam);
        teamStore.delete(childTeam);

        List<Team> foundTeams = teamStore.retrieveByParentId(childTeam.getParentId());
        Assert.assertTrue(foundTeams.size() == 0);
    }

    @Test
    public void testDeleteWithOrgChart() {
        //
        teamStore.create(team);
        teamStore.delete(team);

        List<Team> foundTeams = teamStore.retrieveByOrgChartId("orgchart-1");
        Assert.assertTrue(foundTeams.size() == 0);
    }

    @Test
    public void testCountNotExists() {
        //
        Team childTeam = Team.sample();
        childTeam.setParentId(team.getId());

        teamStore.create(team);
        teamStore.create(childTeam);

        int count = teamStore.count("orgchart-0");
        Assert.assertEquals(0, count);
    }

    @Test
    public void testCount() {
        //
        team.setOrgChartId("orgchart-1");
        teamStore.create(team);

        int count = teamStore.count("orgchart-1");
        Assert.assertEquals(1, count);
    }

    @Test
    public void testCreateTeamMember() {
        //
        teamStore.createTeamMember(teamMember);

        TeamMember foundTeamMember = teamStore.retrieveTeamMember(teamMember.getId());
        Assert.assertNotNull(foundTeamMember);
    }

    @Test
    public void testRetrieveTeamMembersByTeamId() {
        //
        teamStore.createTeamMember(teamMember);

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByTeamId(teamMember.getTeamId(), 0, 1);
        Assert.assertTrue(foundTeamMembers.size() > 0);
    }

    @Test
    public void testRetrieveTeamMembersByCitizenId() {
        //
        teamStore.createTeamMember(teamMember);

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByCitizenId(teamMember.getCitizen().getId());
        Assert.assertTrue(foundTeamMembers.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteTeamMember() {
        //
        teamStore.createTeamMember(teamMember);
        teamStore.deleteTeamMember(teamMember);

        teamStore.retrieveTeamMember(team.getId());
    }

    @Test
    public void testDeleteTeamMemberByCitizenId() {
        //
        teamStore.createTeamMember(teamMember);
        teamStore.deleteTeamMember(teamMember);

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByCitizenId(teamMember.getCitizen().getId());
        Assert.assertTrue(foundTeamMembers.size() == 0);
    }

    @Test
    public void testDeleteTeamMemberByTeamId() {
        //
        teamStore.createTeamMember(teamMember);
        teamStore.deleteTeamMember(teamMember);

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByTeamId(teamMember.getTeamId(), 0, 10);
        Assert.assertTrue(foundTeamMembers.size() == 0);
    }

    @Test
    public void testDeleteTeamMembersByTeamId() {
        //
        teamStore.createTeamMember(teamMember);

        teamStore.deleteTeamMembersByTeamId(teamMember.getTeamId());

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByTeamId(teamMember.getTeamId(), 0, 10);
        Assert.assertTrue(foundTeamMembers.size() == 0);
    }

    @Test
    public void testDeleteTeamMembersByMemberIds() {
        //
        TeamMember otherMember = TeamMember.sample();

        teamStore.createTeamMember(teamMember);
        teamStore.createTeamMember(otherMember);

        List<String> teamMemberIds = Arrays.asList(teamMember.getId(), otherMember.getId());

        teamStore.deleteTeamMembersByMemberIds(teamMemberIds);

        List<TeamMember> foundTeamMembers = teamStore.retrieveTeamMembersByTeamId(teamMember.getTeamId(), 0, 10);
        Assert.assertTrue(foundTeamMembers.size() == 0);
    }

    @Test
    public void testExistsTeamMemberByTeamIdAndCitizenId() {
        //
        teamStore.createTeamMember(teamMember);

        boolean exists = teamStore.existsTeamMemberByTeamIdAndCitizenId(teamMember.getTeamId(), teamMember.getCitizen().getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsTeamMemberByTeamIdAndCitizenId() {
        //
        boolean exists = teamStore.existsTeamMemberByTeamIdAndCitizenId(teamMember.getTeamId(), teamMember.getCitizen().getId());
        Assert.assertFalse(exists);
    }

    @Test
    public void testCountTeamMembersByTeamId() {
        //
        TeamMember otherMember = TeamMember.sample();
        otherMember.setTeamId(teamMember.getTeamId());

        teamStore.createTeamMember(teamMember);
        teamStore.createTeamMember(otherMember);

        int count = teamStore.countTeamMembersByTeamId(teamMember.getTeamId());
        Assert.assertEquals(2, count);
    }

//    void update(Team team);

//    void updateTeamMember(TeamMember member);
//    boolean existsTeamMemberByTeamIdAndCitizenId(String teamId, String citizenId);
//    int countTeamMembersByTeamId(String teamId);
}
