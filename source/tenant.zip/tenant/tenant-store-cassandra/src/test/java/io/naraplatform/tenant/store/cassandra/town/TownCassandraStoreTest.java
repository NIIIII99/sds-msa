package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.town.TownStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/town.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TownCassandraStoreTest.class })
public class TownCassandraStoreTest {
    //
    @Autowired
    TownStore townStore;

    Town town;

    @Before
    public void before() {
        //
        town = Town.sample();
    }

    @Test
    public void testCreate() {
        //
        townStore.create(town);

        Town foundTown = townStore.retrieve(town.getId());
        Assert.assertNotNull(foundTown);
    }

    @Test
    public void testRetrieveByMetroId() {
        //
        townStore.create(town);

        List<Town> foundTown = townStore.retrieveByMetroId(town.getMetroId(), 0, 10);
        Assert.assertTrue(foundTown.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        townStore.create(town);
        townStore.delete(town);

        townStore.retrieve(town.getId());
    }

    @Test
    public void testExistsByTitles() {
        //
        townStore.create(town);

        boolean exists = townStore.existsByTitles(LangStrings.newString("ko", "나무소리").addString("en", "namoosori"));
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsByTitles() {
        //
        townStore.create(town);

        boolean exists = townStore.existsByTitles(LangStrings.newString("ko", "나무소").addString("en", "namooso"));
        Assert.assertFalse(exists);
    }

//    void update(Town town);
}
