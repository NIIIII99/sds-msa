package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.ActiveTowner;
import io.naraplatform.tenant.entity.town.DormantTowner;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.town.TownerStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/towner.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TownerCassandraStoreTest.class })
public class TownerCassandraStoreTest {
    //
    @Autowired
    TownerStore townerStore;

    ActiveTowner activeTowner;
    DormantTowner dormantTowner;

    @Before
    public void before() {
        //
        activeTowner = ActiveTowner.sample();
        dormantTowner = DormantTowner.sample();
    }

    @Test
    public void testCreate() {
        //
        townerStore.create(activeTowner);

        ActiveTowner foundActiveTowner = townerStore.retrieveActiveTowner(activeTowner.getId());
        Assert.assertNotNull(foundActiveTowner);
    }

    @Test
    public void testRetrieveActiveTownerByTownIdAndUsid() {
        //
        townerStore.create(activeTowner);

        ActiveTowner foundActiveTowner = townerStore.retrieveActiveTownerByTownIdAndUsid(activeTowner.getTownId(), activeTowner.getUsid());
        Assert.assertNotNull(foundActiveTowner);
    }

    @Test
    public void testRetrieveActiveTownerByTownIdAndNameLike() {
        //
        townerStore.create(activeTowner);

        List<ActiveTowner> foundActiveTowners = townerStore.retrieveActiveTownerByTownIdAndNameLike(activeTowner.getTownId(), "St%");
        Assert.assertTrue(foundActiveTowners.size() > 0);
    }

    @Test
    public void testRetrieveNoneActiveTownerByTownIdAndNameLike() {
        //
        townerStore.create(activeTowner);

        List<ActiveTowner> foundActiveTowners = townerStore.retrieveActiveTownerByTownIdAndNameLike(activeTowner.getTownId(), "Ks%");
        Assert.assertTrue(foundActiveTowners.size() == 0);
    }

    @Test
    public void testRetrieveActiveTownerByTownId() {
        //
        townerStore.create(activeTowner);

        List<ActiveTowner> foundActiveTowneres = townerStore.retrieveActiveTownerByTownId(activeTowner.getTownId(), 0, 10);
        Assert.assertTrue(foundActiveTowneres.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteActiveTowner() {
        //
        townerStore.create(activeTowner);
        townerStore.deleteActiveTowner(activeTowner);

        townerStore.retrieveActiveTowner(activeTowner.getId());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteActiveTownerWithTownIdAndUsid() {
        //
        townerStore.create(activeTowner);
        townerStore.deleteActiveTowner(activeTowner);

        townerStore.retrieveActiveTownerByTownIdAndUsid(activeTowner.getTownId(), activeTowner.getUsid());
    }

    @Test
    public void testDeleteActiveTownerWithTownIdAndNameLike() {
        //
        townerStore.create(activeTowner);
        townerStore.deleteActiveTowner(activeTowner);

        List<ActiveTowner> foundActiveTowneres = townerStore.retrieveActiveTownerByTownIdAndNameLike(activeTowner.getTownId(), "St%");
        Assert.assertEquals(0, foundActiveTowneres.size());
    }

    @Test
    public void testDeleteActiveTownersByTownerIds() {
        //
        ActiveTowner othwerActiveTowner = ActiveTowner.sample();

        townerStore.create(activeTowner);
        townerStore.create(othwerActiveTowner);

        List<String> activeTownerIds = Arrays.asList(activeTowner.getId(), othwerActiveTowner.getId());

        townerStore.deleteActiveTownersByTownerIds(activeTownerIds);

        List<ActiveTowner> foundActiveTowners = townerStore.retrieveActiveTownerByTownId(activeTowner.getTownId(), 0, 10);
        Assert.assertTrue(foundActiveTowners.size() == 0);
    }

    @Test
    public void testDeleteActiveTownersByTownId() {
        //
        ActiveTowner otherActiveTowner = ActiveTowner.sample();

        townerStore.create(activeTowner);
        townerStore.create(otherActiveTowner);

        townerStore.deleteActiveTownersByTownId(activeTowner.getTownId());

        List<ActiveTowner> foundActiveTowners = townerStore.retrieveActiveTownerByTownId(activeTowner.getTownId(), 0, 10);
        Assert.assertTrue(foundActiveTowners.size() == 0);
    }

    @Test
    public void testCountActiveTownerByTownId() {
        //
        ActiveTowner otherActiveTowner = ActiveTowner.sample();
        otherActiveTowner.setTownId(activeTowner.getTownId());

        townerStore.create(activeTowner);
        townerStore.create(otherActiveTowner);

        long count = townerStore.countActiveTownerByTownId(activeTowner.getTownId());
        Assert.assertEquals(2, count);
    }

    @Test
    public void testCreateDormantTowner() {
        //
        townerStore.create(dormantTowner);

        DormantTowner foundDormantTowner = townerStore.retrieveDormantTowner(dormantTowner.getId());
        Assert.assertNotNull(foundDormantTowner);
    }

    @Test
    public void testRetrieveDormantTownerByTownId() {
        //
        townerStore.create(dormantTowner);

        List<DormantTowner> dormantTowners = townerStore.retrieveDormantTownerByTownId(dormantTowner.getTownId(), 0, 1);
        Assert.assertTrue(dormantTowners.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteDormantTowner() {
        //
        townerStore.create(dormantTowner);
        townerStore.deleteDormantTowner(dormantTowner);

        townerStore.retrieveDormantTowner(dormantTowner.getId());
    }

    @Test
    public void testDeleteDormantTownerWithTownIdAndCitizenId() {
        //
        townerStore.create(dormantTowner);
        townerStore.deleteDormantTowner(dormantTowner);

        List<DormantTowner> foundDormantTowners = townerStore.retrieveDormantTownerByTownId(dormantTowner.getTownId(), 0, 10);
        Assert.assertEquals(0, foundDormantTowners.size());
    }

    @Test
    public void testDeleteDormantTownersByTownerIds() {
        //
        DormantTowner otherDormantTowner = DormantTowner.sample();
        otherDormantTowner.setTownId(dormantTowner.getTownId());

        townerStore.create(dormantTowner);
        townerStore.create(otherDormantTowner);

        List<String> dormantTownerIds = Arrays.asList(dormantTowner.getId(), otherDormantTowner.getId());

        townerStore.deleteDormantTownersByTownerIds(dormantTownerIds);

        List<DormantTowner> foundDormantTowners = townerStore.retrieveDormantTownerByTownId(dormantTowner.getTownId(), 0, 10);
        Assert.assertEquals(0, foundDormantTowners.size());
    }

    @Test
    public void testDeleteDormantTownersByTownId() {
        //
        DormantTowner otherDormantTowner = DormantTowner.sample();
        otherDormantTowner.setTownId(dormantTowner.getTownId());

        townerStore.create(dormantTowner);
        townerStore.create(otherDormantTowner);

        townerStore.deleteDormantTownersByTownId(dormantTowner.getTownId());

        List<DormantTowner> foundDormantTowners = townerStore.retrieveDormantTownerByTownId(dormantTowner.getTownId(), 0, 10);
        Assert.assertEquals(0, foundDormantTowners.size());
    }

//    void updateActiveTowner(ActiveTowner towner);

}
