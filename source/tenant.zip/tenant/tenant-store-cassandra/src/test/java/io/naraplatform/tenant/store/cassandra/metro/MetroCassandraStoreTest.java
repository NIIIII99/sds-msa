package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.metro.Metro;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.metro.MetroStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/metro.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    MetroCassandraStoreTest.class })
public class MetroCassandraStoreTest {

    @Autowired
    MetroStore metroStore;

    private Metro sample;

    @Before
    public void before() {
        sample = Metro.sample();
    }

    @Test
    public void testCreate() {
        //
        metroStore.create(sample);

        Metro foundMetro = metroStore.retrieve(sample.getId());
        Assert.assertNotNull(foundMetro);
    }

    @Test
    public void testRetrieveByName() {
        //
        metroStore.create(sample);

        boolean isFound = metroStore.existsByNames(sample.getNames());
        Assert.assertTrue(isFound);
    }

    @Test
    public void testRetrieveByNameNotFound() {
        //
        metroStore.create(sample);

        LangStrings langStrings = LangStrings.newString("ko", "test-test");

        boolean isFound = metroStore.existsByNames(langStrings);
        Assert.assertFalse(isFound);
    }

    @Test
    public void testRetrieveByNaraId() {
        //
        metroStore.create(sample);

        List<Metro> metros = metroStore.retrieveByNaraId("AAA", 0, 10);
        Assert.assertTrue(metros.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        metroStore.create(sample);
        metroStore.delete(sample);

        metroStore.retrieve(sample.getId());
    }

    @Test
    public void testDeleteRomByName() {
        //
        metroStore.create(sample);
        metroStore.delete(sample);

        LangStrings langStrings = LangStrings.newString("ko", "test-test");

        boolean isFound = metroStore.existsByNames(langStrings);
        Assert.assertFalse(isFound);
    }

    @Test
    public void testDeleteRomByNara() {
        //
        metroStore.create(sample);
        metroStore.delete(sample);

        List<Metro> foundMetros = metroStore.retrieveByNaraId("12AAA", 0, 10);
        Assert.assertTrue(foundMetros.size() == 0);
    }

}

