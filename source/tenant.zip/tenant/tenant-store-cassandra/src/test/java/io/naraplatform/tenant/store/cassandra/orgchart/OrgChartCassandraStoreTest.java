package io.naraplatform.tenant.store.cassandra.orgchart;

import io.naraplatform.tenant.entity.orgchart.OrgChart;
import io.naraplatform.tenant.entity.orgchart.TeamNode;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.orgchart.OrgChartStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/org_chart.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, OrgChartCassandraStoreTest.class })
public class OrgChartCassandraStoreTest {
    //
    @Autowired
    OrgChartStore orgChartStore;

    OrgChart orgChart;
    TeamNode rootNode, teamNode;

    @Before
    public void before() {
        //
        orgChart = OrgChart.sample();
        rootNode = TeamNode.sampleRoot();
        teamNode = TeamNode.sampleNode();
    }

    @Test
    public void testCreate() {
        //
        orgChartStore.create(orgChart);

        OrgChart foundOrgChart = orgChartStore.retrieve(orgChart.getId());
        Assert.assertNotNull(foundOrgChart);
    }

    @Test
    public void testRetrieveByMetroId() {
        //
        orgChartStore.create(orgChart);

        List<OrgChart> foundOrgCharts = orgChartStore.retrieveByMetroId(orgChart.getMetroId());
        Assert.assertTrue(foundOrgCharts.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        orgChartStore.create(orgChart);
        orgChartStore.delete(orgChart);

        orgChartStore.retrieve(orgChart.getId());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteById() {
        //
        orgChartStore.create(orgChart);
        orgChartStore.delete(orgChart.getId());

        orgChartStore.retrieve(orgChart.getId());
    }

    @Test
    public void testCreateTeamNode() {
        //
        orgChartStore.createTeamNode(rootNode);

        System.out.println(rootNode.toJson());

        TeamNode foundTeamNode = orgChartStore.retrieveTeamNode(rootNode.getId());
        Assert.assertNotNull(foundTeamNode);
    }

    @Test
    public void testRetrieveTeamNodesByParentId() {
        //
        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode);

        List<TeamNode> foundTeamNodes = orgChartStore.retrieveTeamNodesByParentId(teamNode.getParentId());
        Assert.assertTrue(foundTeamNodes.size() == 1);
    }

    @Test
    public void testRetrieveTeamNodesByOrgChartId() {
        //
        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode);

        List<TeamNode> foundTeamNodes = orgChartStore.retrieveTeamNodesByOrgChartId(rootNode.getOrgChartId());
        Assert.assertTrue(foundTeamNodes.size() >= 1);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteTeamNode() {
        //
        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode);

        orgChartStore.deleteTeamNode(teamNode);

        orgChartStore.retrieveTeamNode(teamNode.getId());
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteTeamNodeById() {
        //
        orgChartStore.createTeamNode(teamNode);
        orgChartStore.deleteTeamNode(teamNode.getId());
        orgChartStore.retrieveTeamNode(teamNode.getId());
    }

    @Test
    public void testDeleteTeamNodesByOrgChartId() {
        //
        TeamNode teamNode1 = TeamNode.sampleNode();
        teamNode1.setParentId(rootNode.getId());
        TeamNode teamNode2 = TeamNode.sampleNode();
        teamNode2.setParentId(rootNode.getId());

        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode1);
        orgChartStore.createTeamNode(teamNode2);

        orgChartStore.deleteTeamNodesByOrgChartId(rootNode.getOrgChartId());

        List<TeamNode> foundTeamNodes = orgChartStore.retrieveTeamNodesByOrgChartId(rootNode.getOrgChartId());
        Assert.assertTrue(foundTeamNodes.size() == 0);
    }

    @Test
    public void testDeleteTeamNodesByParentId() {
        //
        TeamNode teamNode1 = TeamNode.sampleNode();
        teamNode1.setParentId(rootNode.getId());
        TeamNode teamNode2 = TeamNode.sampleNode();
        teamNode2.setParentId(rootNode.getId());

        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode1);
        orgChartStore.createTeamNode(teamNode2);

        orgChartStore.deleteTeamNodesByParentId(rootNode.getId());

        List<TeamNode> foundTeamNodes = orgChartStore.retrieveTeamNodesByOrgChartId(rootNode.getOrgChartId());
        Assert.assertTrue(foundTeamNodes.size() == 1);
    }

    @Test
    public void testDeleteTeamNodeByOrgChartIdAndParentId() {
        //
        TeamNode teamNode1 = TeamNode.sampleNode();
        teamNode1.setParentId(rootNode.getId());
        TeamNode teamNode2 = TeamNode.sampleNode();
        teamNode2.setParentId(rootNode.getId());

        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode1);
        orgChartStore.createTeamNode(teamNode2);

        orgChartStore.deleteTeamNodeByOrgChartIdAndParentId(rootNode.getOrgChartId(), "test-test");

        List<TeamNode> foundTeamNodes = orgChartStore.retrieveTeamNodesByParentId(rootNode.getId());
        Assert.assertTrue(foundTeamNodes.size() == 2);
    }

    @Test
    public void testCountTeamNodesByOrgChartId() {
        //
        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode);

        int count = orgChartStore.countTeamNodesByOrgChartId(rootNode.getOrgChartId());
        Assert.assertEquals(1, count);
    }

    @Test
    public void testCountTeamNodesByParentId() {
        //
        TeamNode teamNode1 = TeamNode.sampleNode();
        teamNode1.setParentId(rootNode.getId());
        TeamNode teamNode2 = TeamNode.sampleNode();
        teamNode2.setParentId(rootNode.getId());

        orgChartStore.createTeamNode(rootNode);
        orgChartStore.createTeamNode(teamNode1);
        orgChartStore.createTeamNode(teamNode2);

        int count = orgChartStore.countTeamNodesByParentId(rootNode.getId());
        Assert.assertEquals(2, count);
    }

//    void update(OrgChart orgChart);
//
//    void updateTeamNode(TeamNode teamNode);
//    void updateTeamNodes(List<TeamNode> teamNodes);
}
