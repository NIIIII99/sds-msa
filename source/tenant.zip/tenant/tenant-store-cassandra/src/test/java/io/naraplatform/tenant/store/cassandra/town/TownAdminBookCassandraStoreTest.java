package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.TownAdmin;
import io.naraplatform.tenant.entity.town.book.TownAdminBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.town.TownAdminBookStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = {"cql/town_book.cql", "cql/town_admin.cql"})
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TownAdminBookCassandraStoreTest.class })
public class TownAdminBookCassandraStoreTest {
    //
    @Autowired
    TownAdminBookStore townAdminBookStore;

    TownAdminBook townAdminBook;
    TownAdmin townAdmin;

    @Before
    public void before() {
        //
        townAdminBook = TownAdminBook.sample();
        townAdmin = TownAdmin.sample();
    }

    @Test
    public void testCreate() {
        //
        townAdminBookStore.create(townAdminBook);

        TownAdminBook foundTownAdminBook = townAdminBookStore.retrieve(townAdminBook.getId());
        Assert.assertNotNull(foundTownAdminBook);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        townAdminBookStore.create(townAdminBook);
        townAdminBookStore.delete(townAdminBook);

        townAdminBookStore.retrieve(townAdminBook.getId());
    }

    @Test
    public void testExists() {
        //
        townAdminBookStore.create(townAdminBook);

        boolean exists = townAdminBookStore.exists(townAdminBook.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExists() {
        //
        boolean exists = townAdminBookStore.exists(townAdminBook.getId());
        Assert.assertFalse(exists);
    }

    @Test
    public void testCreateTownAdmin() {
        //
        townAdminBookStore.createTownAdmin(townAdmin);

        TownAdmin foundTownAdmin = townAdminBookStore.retrieveTownAdmin(townAdmin.getId());
        Assert.assertNotNull(foundTownAdmin);
    }

    @Test
    public void testRetrieveTwownAdminsByTownId() {
        //
        townAdminBookStore.createTownAdmin(townAdmin);

        List<TownAdmin> foundTownAdmins = townAdminBookStore.retrieveTownAdminsByTownId(townAdmin.getTownId());
        Assert.assertTrue(foundTownAdmins.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteTownAdmin() {
        //
        townAdminBookStore.createTownAdmin(townAdmin);
        townAdminBookStore.deleteTownAdmin(townAdmin);

        townAdminBookStore.retrieveTownAdmin(townAdmin.getId());
    }

    @Test
    public void testDeleteTownAdmins() {
        //
        TownAdmin otherTownAdmin = TownAdmin.sample();
        otherTownAdmin.setTownId(townAdmin.getTownId());

        townAdminBookStore.createTownAdmin(townAdmin);
        townAdminBookStore.createTownAdmin(otherTownAdmin);

        List<String> townAdminIds = Arrays.asList(townAdmin.getId(), otherTownAdmin.getId());

        townAdminBookStore.deleteTownAdmins(townAdminIds);

        List<TownAdmin> foundTownAdmins = townAdminBookStore.retrieveTownAdminsByTownId(townAdmin.getTownId());
        Assert.assertEquals(0, foundTownAdmins.size());
    }

    @Test
    public void testDeleteTownAdminsByTownId() {
        //
        //
        TownAdmin otherTownAdmin = TownAdmin.sample();
        otherTownAdmin.setTownId(townAdmin.getTownId());

        townAdminBookStore.createTownAdmin(townAdmin);
        townAdminBookStore.createTownAdmin(otherTownAdmin);

        townAdminBookStore.deleteTownAdminsByTownId(townAdmin.getTownId());

        List<TownAdmin> foundTownAdmins = townAdminBookStore.retrieveTownAdminsByTownId(townAdmin.getTownId());
        Assert.assertEquals(0, foundTownAdmins.size());
    }

    @Test
    public void testExistsTownAdminByCitizenId() {
        //
        townAdminBookStore.createTownAdmin(townAdmin);

        boolean exists = townAdminBookStore.existsTownAdminByCitizenId(townAdmin.getCitizen().getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsTownAdminByCitizenId() {
        //
        boolean exists = townAdminBookStore.existsTownAdminByCitizenId(townAdmin.getCitizen().getId());
        Assert.assertFalse(exists);
    }

//    void update(TownAdminBook adminBook);
//    void updateTownAdmin(TownAdmin admin);
}
