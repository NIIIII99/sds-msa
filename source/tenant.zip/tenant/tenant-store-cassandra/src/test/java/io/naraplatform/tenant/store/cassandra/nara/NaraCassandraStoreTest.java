package io.naraplatform.tenant.store.cassandra.nara;

import io.naraplatform.tenant.entity.nara.Nara;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.nara.NaraStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/nara.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, NaraCassandraStoreTest.class })
public class NaraCassandraStoreTest {
    //
    @Autowired
    NaraStore naraStore;

    Nara nara;

    @Before
    public void before() {
        //
        nara = Nara.sample();
    }

    @Test
    public void testCreate() {
        //
        naraStore.create(nara);

        Nara foundNara = naraStore.retrieve(nara.getId());
        Assert.assertNotNull(foundNara);
    }

    @Test
    public void testRetrieveByUsid() {
        //
        naraStore.create(nara);

        Nara foundNara = naraStore.retrieveByUsid(nara.getUsid());
        Assert.assertNotNull(foundNara);
    }

    @Test
    public void testRetrieveAll() {
        //
        naraStore.create(nara);

        List<Nara> foundNaras = naraStore.retrieveAll();
        Assert.assertTrue(foundNaras.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        naraStore.create(nara);
        naraStore.delete(nara);

        naraStore.retrieve(nara.getId());
    }

    @Test
    public void testExistsByUsidOrName() {
        //
        naraStore.create(nara);

        boolean exists = naraStore.existsByUsidOrName(nara.getUsid(), nara.getName());
        Assert.assertTrue(exists);
    }

    @Test
    public void testExistsByUsid() {
        //
        naraStore.create(nara);

        boolean exists = naraStore.existsByUsidOrName("1234", nara.getName());
        Assert.assertTrue(exists);
    }

    @Test
    public void testExistsByName() {
        //
        naraStore.create(nara);

        boolean exists = naraStore.existsByUsidOrName(nara.getUsid(), "test-nara");
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsByUsidOrName() {
        //
        naraStore.create(nara);

        boolean exists = naraStore.existsByUsidOrName("1234", "test-nara");
        Assert.assertFalse(exists);
    }

//    Nara retrieve(String id);
//    void update(Nara nara);
//    void delete(Nara nara);
//    boolean existsByUsidOrName(String usid, String name);
}
