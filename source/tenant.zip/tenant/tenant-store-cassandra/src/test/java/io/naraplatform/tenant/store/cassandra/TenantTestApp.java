package io.naraplatform.tenant.store.cassandra;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TenantTestApp {

}
