package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.tenant.entity.metro.MetroOfficial;
import io.naraplatform.tenant.entity.metro.book.MetroOfficialBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.metro.MetroOfficialBookStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/metro_official_and_book.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    MetroOfficialBookCassandraStoreTest.class })
public class MetroOfficialBookCassandraStoreTest {
    //
    @Autowired
    MetroOfficialBookStore metroOfficialBookStore;

    private MetroOfficialBook metroOfficialBook;
    private MetroOfficial metroPrimaryOfficial;
    private MetroOfficial metroSecondaryOfficial;

    @Before
    public void before() {
        //
        metroOfficialBook = MetroOfficialBook.sample();
        metroPrimaryOfficial = MetroOfficial.samplePrimary();
        metroSecondaryOfficial = MetroOfficial.sampleSecondary();
    }

    @Test
    public void testCreate() {
        //
        metroOfficialBookStore.create(metroOfficialBook);

        MetroOfficialBook foundMetroOfficialBook = metroOfficialBookStore.retrieve(metroOfficialBook.getId());
        Assert.assertNotNull(foundMetroOfficialBook);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        metroOfficialBookStore.create(metroOfficialBook);
        metroOfficialBookStore.delete(metroOfficialBook);

        metroOfficialBookStore.retrieve(metroOfficialBook.getId());
    }

    @Test
    public void testExists() {
        //
        metroOfficialBookStore.create(metroOfficialBook);

        boolean exists = metroOfficialBookStore.exists(metroOfficialBook.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testCreateMetroOfficial() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);

        MetroOfficial foundMetroOfficial = metroOfficialBookStore.retrieveMetroOfficial(metroPrimaryOfficial.getId());
        Assert.assertNotNull(foundMetroOfficial);
    }

    @Test
    public void testRetrieveMetroOfficialByMetroId() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);

        List<MetroOfficial> foundMetroOfficials = metroOfficialBookStore.retrieveMetroOfficialsByMetroId(metroPrimaryOfficial.getMetroId());
        Assert.assertTrue(foundMetroOfficials.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteMetroOfficial() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);
        metroOfficialBookStore.deleteMetroOfficial(metroPrimaryOfficial);

        metroOfficialBookStore.retrieveMetroOfficial(metroPrimaryOfficial.getId());
    }

    @Test
    public void testDeleteMetroOfficialWithMetroId() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);
        metroOfficialBookStore.deleteMetroOfficial(metroPrimaryOfficial);

        List<MetroOfficial> foundMetroOfficials = metroOfficialBookStore.retrieveMetroOfficialsByMetroId("metro-id");
        Assert.assertTrue(foundMetroOfficials.size() == 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDeleteMetroOfficials() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);

        metroSecondaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroSecondaryOfficial);

        metroOfficialBookStore.deleteMetroOfficials(new ArrayList<String>(Arrays.asList(metroPrimaryOfficial.getId(), metroSecondaryOfficial.getId())));

        metroOfficialBookStore.retrieveMetroOfficial(metroPrimaryOfficial.getId());
    }

    @Test
    public void testDeleteMetroOfficialsByMetro() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);

        metroSecondaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroSecondaryOfficial);

        metroOfficialBookStore.deleteMetroOfficialsInMetro("metro-id");

        List<MetroOfficial> foundMetroOfficials = metroOfficialBookStore.retrieveMetroOfficialsByMetroId("metro-id");
        Assert.assertTrue(foundMetroOfficials.size() == 0);
    }

    @Test
    public void testExistsMetroOfficialByCitizenId() {
        //
        metroPrimaryOfficial.setMetroId("metro-id");
        metroOfficialBookStore.createMetroOfficial(metroPrimaryOfficial);

        boolean exists = metroOfficialBookStore.existsMetroOfficialByCitizenId(metroPrimaryOfficial.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsMetroOfficialByCitizenId() {
        //
        boolean exists = metroOfficialBookStore.existsMetroOfficialByCitizenId(metroPrimaryOfficial.getId());
        Assert.assertFalse(exists);
    }

//    void update(MetroOfficialBook officialBook);
//    void updateMetroOfficial(MetroOfficial metroOfficial);
}
