package io.naraplatform.tenant.store.cassandra.nara;

import io.naraplatform.tenant.entity.nara.NaraLabelBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.nara.NaraLabelBookStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/nara_book.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, NaraLabelBookCassandraStoreTest.class })
public class NaraLabelBookCassandraStoreTest {
    //
    @Autowired
    NaraLabelBookStore naraLabelBookStore;

    NaraLabelBook naraLabelBook;

    @Before
    public void before() {
        //
        naraLabelBook = NaraLabelBook.naraSample();
    }

    @Test
    public void testCreate() {
        //
        naraLabelBookStore.create(naraLabelBook);

        NaraLabelBook foundNaraLabelBook = naraLabelBookStore.retrieve(naraLabelBook.getId());
        Assert.assertNotNull(foundNaraLabelBook);
    }

    @Test
    public void testRetrieveByTitle() {
        //
        naraLabelBookStore.create(naraLabelBook);

        NaraLabelBook foundNaraLabelBook = naraLabelBookStore.retrieveByTitle("NaraLabel");
        Assert.assertNotNull(foundNaraLabelBook);
    }

    @Test
    public void testRetrieveByNaraId() {
        //
        naraLabelBookStore.create(naraLabelBook);

        List<NaraLabelBook> naraLabelBooks = naraLabelBookStore.retrieveByNaraId(naraLabelBook.getNara().getId());
        Assert.assertTrue(naraLabelBooks.size() > 0);
    }

    @Test
    public void testRetrieveByMetroType() {
        //
        naraLabelBookStore.create(naraLabelBook);

        List<NaraLabelBook> naraLabelBooks = naraLabelBookStore.retrieveByMetroType(naraLabelBook.getMetroType(), 0, 10);
        Assert.assertTrue(naraLabelBooks.size() > 0);
    }

    @Test
    public void testRetrieveByTitleLike() {
        //
        naraLabelBookStore.create(naraLabelBook);

        List<NaraLabelBook> naraLabelBooks = naraLabelBookStore.retrieveByTitleLike("Nar%", 0, 1);
        Assert.assertTrue(naraLabelBooks.size() > 0);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        naraLabelBookStore.create(naraLabelBook);
        naraLabelBookStore.delete(naraLabelBook);

        naraLabelBookStore.retrieve(naraLabelBook.getId());
    }

    @Test
    public void testExistsByTitle() {
        //
        naraLabelBookStore.create(naraLabelBook);

        boolean exists = naraLabelBookStore.existsByTitle("NaraLabel");
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsByTitle() {
        //
        naraLabelBookStore.create(naraLabelBook);

        boolean exists = naraLabelBookStore.existsByTitle("NaraLabels");
        Assert.assertFalse(exists);
    }

//    void update(NaraLabelBook naraLabelBook);
}
