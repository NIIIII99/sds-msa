package io.naraplatform.tenant.store.cassandra.metro;

import io.naraplatform.tenant.entity.metro.MetroRole;
import io.naraplatform.tenant.entity.metro.book.MetroRoleBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.metro.MetroRoleBookStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/metro_role_and_book.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class,
    MetroRoleBookCassandraStoreTest.class })
public class MetroRoleBookCassandraStoreTest {
    //
    @Autowired
    MetroRoleBookStore metroRoleBookStore;

    private MetroRoleBook metroRoleBook;
    private MetroRole metroAdminRole;
    private MetroRole metroUserRole;

    @Before
    public void before() {
        //
        metroRoleBook = MetroRoleBook.sample();
        metroAdminRole = MetroRole.sampleAdmin();
        metroUserRole = MetroRole.sampleUser();
    }

    @Test
    public void testCreate() {
        //
        metroRoleBookStore.create(metroRoleBook);
        MetroRoleBook foundMetroRolebook = metroRoleBookStore.retrieve(metroRoleBook.getId());
        Assert.assertNotNull(foundMetroRolebook);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        metroRoleBookStore.create(metroRoleBook);
        metroRoleBookStore.delete(metroRoleBook);
        metroRoleBookStore.retrieve(metroRoleBook.getId());
    }

    @Test
    public void testExists() {
        //
        metroRoleBookStore.create(metroRoleBook);
        boolean exists = metroRoleBookStore.exists(metroRoleBook.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testCreateMetroRole() {
        //
        metroRoleBookStore.createMetroRole(metroAdminRole);
        MetroRole foundAdminRole = metroRoleBookStore.retrieveMetroRole(metroAdminRole.getId());
        Assert.assertNotNull(foundAdminRole);
    }

    @Test
    public void testExistsMetroRole() {
        //
        metroRoleBookStore.createMetroRole(metroAdminRole);
        boolean exists = metroRoleBookStore.existsMetroRoleByMetroIdAndRoleName(metroAdminRole.getMetroId(), metroAdminRole.getName());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExistsMetroRole() {
        //
        metroRoleBookStore.createMetroRole(metroUserRole);
        boolean exists = metroRoleBookStore.existsMetroRoleByMetroIdAndRoleName(metroUserRole.getMetroId(), "test-test");
        Assert.assertFalse(exists);
    }

    @Test
    public void testDeleteMetroRoleByObject() {
        //
        metroRoleBookStore.createMetroRole(metroUserRole);
        metroRoleBookStore.deleteMetroRole(metroUserRole);
        List<MetroRole> foundMetroRoles = metroRoleBookStore.retrieveMetroRolesByMetroId(metroUserRole.getMetroId());
        Assert.assertEquals(0, foundMetroRoles.size());
    }

    @Test
    public void testDeleteMetroRoleById() {
        //
        metroRoleBookStore.createMetroRole(metroUserRole);
        metroRoleBookStore.deleteMetroRole(metroUserRole.getId());
        List<MetroRole> foundMetroRoles = metroRoleBookStore.retrieveMetroRolesByMetroId(metroUserRole.getMetroId());
        Assert.assertEquals(0, foundMetroRoles.size());
    }

    @Test
    public void testDeleteMetroRolesByMetroId() {
        //
        metroRoleBookStore.createMetroRole(metroUserRole);
        metroRoleBookStore.deleteMetroRolesByMetroId(metroUserRole.getMetroId());
        List<MetroRole> foundMetroRoles = metroRoleBookStore.retrieveMetroRolesByMetroId(metroUserRole.getMetroId());
        Assert.assertEquals(0, foundMetroRoles.size());
    }



//    void update(MetroRoleBook metroRoleBook);
//
//    void updateMetroRole(MetroRole metroRole);
}
