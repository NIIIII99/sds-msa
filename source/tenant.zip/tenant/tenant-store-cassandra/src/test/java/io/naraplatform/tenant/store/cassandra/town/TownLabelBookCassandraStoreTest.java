package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.tenant.entity.town.book.TownLabelBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.town.TownLabelBookStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/town_book.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TownLabelBookCassandraStoreTest.class })
public class TownLabelBookCassandraStoreTest {
    //
    @Autowired
    TownLabelBookStore townLabelBookStore;

    TownLabelBook townLabelBook;

    @Before
    public void before() {
        //
        townLabelBook = TownLabelBook.sample();
    }

    @Test
    public void testCreate() {
        //
        townLabelBookStore.create(townLabelBook);

        TownLabelBook foundTownLabelBook = townLabelBookStore.retrieve(townLabelBook.getId());
        Assert.assertNotNull(foundTownLabelBook);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        townLabelBookStore.create(townLabelBook);
        townLabelBookStore.delete(townLabelBook);

        townLabelBookStore.retrieve(townLabelBook.getId());
    }

    @Test
    public void testExists() {
        //
        townLabelBookStore.create(townLabelBook);

        boolean exists = townLabelBookStore.exists(townLabelBook.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExists() {
        //
        boolean exists = townLabelBookStore.exists(townLabelBook.getId());
        Assert.assertFalse(exists);
    }


//    void update(TownLabelBook labelBook);
//    void delete(TownLabelBook labelBook);
//    boolean exists(String townId);
}
