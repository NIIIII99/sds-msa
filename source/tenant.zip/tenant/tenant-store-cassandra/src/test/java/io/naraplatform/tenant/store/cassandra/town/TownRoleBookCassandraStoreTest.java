package io.naraplatform.tenant.store.cassandra.town;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.tenant.entity.town.Town;
import io.naraplatform.tenant.entity.town.book.TownRoleBook;
import io.naraplatform.tenant.store.cassandra.CassandraConfig;
import io.naraplatform.tenant.store.cassandra.TenantTestApp;
import io.naraplatform.tenant.store.town.TownRoleBookStore;
import io.naraplatform.tenant.store.town.TownStore;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= TenantTestApp.class)
@CassandraDataSet(keyspace = "tenant", value = "cql/town_book.cql")
@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
    CassandraUnitDependencyInjectionTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class}
)
@ContextConfiguration(classes = { CassandraConfig.class, TownRoleBookCassandraStoreTest.class })
public class TownRoleBookCassandraStoreTest {
    //
    @Autowired
    TownRoleBookStore townRoleBookStore;

    TownRoleBook townRoleBook;

    @Before
    public void before() {
        //
        townRoleBook = TownRoleBook.sample();
    }

    @Test
    public void testCreate() {
        //
        townRoleBookStore.create(townRoleBook);

        TownRoleBook foundTownRoleBook = townRoleBookStore.retrieve(townRoleBook.getId());
        Assert.assertNotNull(foundTownRoleBook);
    }

    @Test(expected = NoSuchElementException.class)
    public void testDelete() {
        //
        townRoleBookStore.create(townRoleBook);
        townRoleBookStore.delete(townRoleBook);

        townRoleBookStore.retrieve(townRoleBook.getId());
    }

    @Test
    public void testExists() {
        //
        townRoleBookStore.create(townRoleBook);

        boolean exists = townRoleBookStore.exists(townRoleBook.getId());
        Assert.assertTrue(exists);
    }

    @Test
    public void testNotExists() {
        //
        boolean exists = townRoleBookStore.exists(townRoleBook.getId());
        Assert.assertFalse(exists);
    }

//    void update(TownRoleBook roleBook);
}
