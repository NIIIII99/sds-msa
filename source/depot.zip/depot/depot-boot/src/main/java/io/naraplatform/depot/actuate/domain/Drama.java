package io.naraplatform.depot.actuate.domain;


import io.naraplatform.share.domain.IdLangName;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Drama {
    //
    private String id;
    private String version;

    private String defaultLang;
    private LangStrings categoryNames;
    private LangStrings titles;
    private LangStrings descriptions;
    private IdLangName troupe;
    private String base64Icon;
    private String feedbackId;
    private String date;

    @Override
    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

}
