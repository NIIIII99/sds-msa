package io.naraplatform.depot.actuate.bind;

import io.naraplatform.depot.actuate.domain.DramaVersionCdo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="artcenter")
public interface ArtcenterAdapter {

    @PostMapping(value="/drama/version")
    String registerVersion(@RequestBody DramaVersionCdo dramaVersionCdo);

}
