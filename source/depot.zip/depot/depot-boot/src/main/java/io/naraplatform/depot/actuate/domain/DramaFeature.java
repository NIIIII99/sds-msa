package io.naraplatform.depot.actuate.domain;

import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DramaFeature {
    //
    private String id;
    private String defaultLang;
    private int index;
    private LangStrings names;
    private LangStrings descriptions;
    private List<String> editionKeys;
    private List<String> authorizedRoleKeys;

    @Override
    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

}
