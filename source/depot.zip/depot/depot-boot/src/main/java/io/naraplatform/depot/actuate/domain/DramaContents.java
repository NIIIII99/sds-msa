package io.naraplatform.depot.actuate.domain;

import io.naraplatform.share.domain.drama.DramaRole;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DramaContents  {
    //
    private List<DramaEdition> editions;
    private List<DramaRole> roles;

    @Override
    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

}
