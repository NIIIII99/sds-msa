package io.naraplatform.depot.actuate.endpoint;

import io.naraplatform.depot.actuate.domain.DramaVersionCdo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id = "drama", enableByDefault=true)
public class DramaEndPoint {

    @Autowired
    DramaVersionCdo dramaVersionCdo;

    @ReadOperation
    public DramaVersionCdo drama() {
        return dramaVersionCdo;
    }

}
