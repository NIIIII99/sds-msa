package io.naraplatform.depot.actuate.bind;

import io.naraplatform.depot.actuate.domain.DramaVersionCdo;
import io.naraplatform.depot.actuate.proxy.ArtcenterProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ArtcenterDelegator implements ArtcenterProxy {

    @Autowired
    ArtcenterAdapter artcenterAdapter;

    @Override
    public String registerVersion(DramaVersionCdo dramaVersionCdo) {
        //
        return artcenterAdapter.registerVersion(dramaVersionCdo);
    }
}
