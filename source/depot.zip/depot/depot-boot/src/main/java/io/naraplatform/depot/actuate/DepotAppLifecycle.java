package io.naraplatform.depot.actuate;

import io.naraplatform.depot.actuate.domain.DramaVersionCdo;
import io.naraplatform.depot.actuate.proxy.ArtcenterProxy;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
@NoArgsConstructor
public class DepotAppLifecycle implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    ArtcenterProxy artcenterProxy;

    @Autowired
    DramaVersionCdo dramaVersionCdo;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        //
        System.out.println("==========================");
        System.out.println("PREPARE");
        System.out.println("==========================");
        System.out.println(JsonUtil.toJson(dramaVersionCdo));
        System.out.println("==========================");

        artcenterProxy.registerVersion(dramaVersionCdo);

        System.out.println("==========================");
        System.out.println("REGISTERED");
        System.out.println("==========================");
    }
}
