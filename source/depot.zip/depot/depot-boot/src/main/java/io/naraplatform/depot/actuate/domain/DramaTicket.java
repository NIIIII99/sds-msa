package io.naraplatform.depot.actuate.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DramaTicket {

    private String id;
    private String dramaId;
    private String troupeId;

}
