package io.naraplatform.depot.actuate.domain;

import io.naraplatform.share.domain.lang.GlobalPrice;
import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DramaVersion {
    //
    private String id;
    private String versionName;                     // 1.2.1, 1.3.12
    private LangStrings releaseNotes;
    private LangStrings supportLangs;
    private GlobalPrice price;
    private String releaseDate;                     // ISO, 2018-10-18
    private String dramaId;

    private DramaContents dramaContents;            // 1:1

    public String toString() {
        //
        return JsonUtil.toJson(this);
    }
}
