package io.naraplatform.depot.actuate.proxy;

import io.naraplatform.depot.actuate.domain.DramaVersionCdo;

public interface ArtcenterProxy {

    String registerVersion(DramaVersionCdo dramaVersionCdo);

}
