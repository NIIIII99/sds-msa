package io.naraplatform.depot.actuate.domain;

import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Getter
@Setter
@ConfigurationProperties(prefix = "nara")
public class DramaVersionCdo implements JsonSerializable {

    private String ticketId;
    private DramaVersion dramaVersion;
    private List<DramaFeature> dramaFeatures;

    public DramaVersionCdo() {
        //
        dramaFeatures = new ArrayList<DramaFeature>();
    }

    public String getDramaTicketJson() {
        //
        return ticketId;
    }

    public String getDramaVersionJson() {
        //
        return dramaVersion.toString();
    }

    public List<String> getDramaFeatureJsons() {
        //
        return dramaFeatures.stream().map(feature -> feature.toString()).collect(Collectors.toList());
    }

}
