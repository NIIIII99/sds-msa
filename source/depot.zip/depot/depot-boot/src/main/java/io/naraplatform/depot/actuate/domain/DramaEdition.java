package io.naraplatform.depot.actuate.domain;


import io.naraplatform.share.domain.lang.LangStrings;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DramaEdition {
    //
    private String key;
    private LangStrings names;
    private LangStrings memos;

    @Override
    public String toString() {
        //
        return JsonUtil.toJson(this);
    }

}
