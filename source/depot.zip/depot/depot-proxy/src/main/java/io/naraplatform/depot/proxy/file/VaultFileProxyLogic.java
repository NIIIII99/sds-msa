package io.naraplatform.depot.proxy.file;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.proxy.VaultFileProxy;
import io.naraplatform.depot.domain.proxy.FileActionFailureException;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.stream.Stream;

import static java.nio.file.StandardOpenOption.CREATE_NEW;

@Repository("vaultFileProxy")
public class VaultFileProxyLogic implements VaultFileProxy {
    //
    private final static String TEMP_DIR_NAME = "temp";
    private final static String POST_FIX_FOR_BACKUP = "_back";

    @Override
    public void saveToDisk(VaultFile vaultFile, String sequence, InputStream fileStream) throws FileActionFailureException {
        //
        String pathName = vaultFile.getPath() + File.separator + TEMP_DIR_NAME + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        Path path = Paths.get(pathName);
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                throw new FileActionFailureException("fail to make directory", e);
            }
        }

        String fileName =  pathName + File.separator + sequence;
        File file = new File(fileName);

        if (file.exists() && file.isFile()) {
            throw new FileActionFailureException("exist same file name for deviding");
        }

        try {
            OutputStream os = Files.newOutputStream(Paths.get(fileName));
            IOUtils.copy(fileStream, os);
            os.close();
        } catch (IOException e) {
            throw new FileActionFailureException(e);
        }
    }

    @Override
    public void combineToDisk(VaultFile vaultFile, int numberOfChunks) throws FileActionFailureException {
        //
        String tempPathName = vaultFile.getPath() + File.separator + TEMP_DIR_NAME;
        String chunkPathName = tempPathName + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        Path chunkPath = Paths.get(chunkPathName);
        if (!Files.exists(chunkPath)) {
            throw new FileActionFailureException("no exist directory");
        }

        String finalFileName = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        File finalFile = new File(finalFileName);
        if (finalFile.exists() && finalFile.isFile()) {
            throw new FileActionFailureException("exist same file name");
        }

        try {
            try (OutputStream os = Files.newOutputStream(Paths.get(finalFileName))) {

                for (int sequence = 1; sequence <= numberOfChunks; sequence++) {
                    //
                    String chunkFileName = chunkPathName + File.separator + String.valueOf(sequence);
                    InputStream chunkFileStream = Files.newInputStream(Paths.get(chunkFileName));
                    IOUtils.copy(chunkFileStream, os);
                    chunkFileStream.close();
                }
            }

            File chunkPathFile = new File(chunkPathName);
            Arrays.asList(chunkPathFile.listFiles()).stream().forEach(file ->
                { if(!file.delete()) throw new FileActionFailureException("Failed to delete temp directory."); }
            );
            if(!chunkPathFile.delete()) {
                throw new FileActionFailureException("Failed to delete temp directory.");
            }

            File tempPathFile = new File(tempPathName);
            try (Stream<Path> path = Files.list(Paths.get(tempPathName))) {
                if(path.count() == 0) {
                    if(!tempPathFile.delete()){
                        throw new FileActionFailureException("Failed to delete temp directory.");
                    }
                }
            }

        } catch (IOException e) {
            throw new FileActionFailureException(e);
        }

    }

    @Override
    public boolean exist(VaultFile vaultFile) {
        //
        String originalFilePath = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        File originalFile = new File(originalFilePath);

        return originalFile.exists() && originalFile.isFile();
    }

    @Override
    public InputStream readFileFromDisk(VaultFile vaultFile) {
        //
        return null;
    }

    @Override
    public boolean delete(VaultFile vaultFile) throws FileActionFailureException {
        return false;
    }

    @Override
    public void copyFile(VaultFile sourceVaultFile, VaultFile targetVaultFile) {
        //
        Path targetPath = Paths.get(targetVaultFile.getPath());
        if (!Files.exists(targetPath)) {
            try {
                Files.createDirectories(targetPath);
            } catch (IOException e) {
                throw new FileActionFailureException("fail to make directory", e);
            }
        }

        String sourceFilePath = sourceVaultFile.getPath() + File.separator + sourceVaultFile.getId() + "-" + sourceVaultFile.getVersion();
        String targetFilePath = targetVaultFile.getPath() + File.separator + targetVaultFile.getId() + "-" + targetVaultFile.getVersion();

        try {
            try (InputStream is = Files.newInputStream(Paths.get(sourceFilePath))) {
                OutputStream os = Files.newOutputStream(Paths.get(targetFilePath), CREATE_NEW);
                IOUtils.copy(is, os);
                os.close();
            }

        } catch (IOException e) {
            throw new FileActionFailureException(e);
        }
    }

    @Override
    public void changeToBackupFile(VaultFile vaultFile) throws FileActionFailureException {
        //
        String originalFilePath = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        File originalFile = new File(originalFilePath);
        File backupFile = new File(originalFilePath + POST_FIX_FOR_BACKUP);
        if (backupFile.exists() && backupFile.isFile()) {
            throw new FileActionFailureException("exist same backup file");
        }

        if(!originalFile.renameTo(backupFile)) {
            throw new FileActionFailureException("Failed to backup original file for overwriting.");
        }
    }

    @Override
    public void deleteBackupFile(VaultFile vaultFile) {
        //
        String originalFilePath = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        File backupFile = new File(originalFilePath + POST_FIX_FOR_BACKUP);
        if (backupFile.exists() && backupFile.isFile()) {
            //
            if(!backupFile.delete()) {
                throw new FileActionFailureException("Failed to delete backup file.");
            }
        }
    }

    @Override
    public boolean existBackup(VaultFile vaultFile) {
        //
        String backupFilePath = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion() + POST_FIX_FOR_BACKUP;
        File backupFile = new File(backupFilePath);

        return backupFile.exists() && backupFile.isFile();
    }
}
