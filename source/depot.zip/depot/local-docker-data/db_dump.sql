CREATE DATABASE IF NOT EXISTS nara_db;

USE nara_db;

CREATE TABLE `vault_jpo` (
  `id` varchar(255) NOT NULL,
  `file_system` varchar(255) DEFAULT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `root_path` varchar(255) DEFAULT NULL,
  `time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


insert into `nara_db`.`vault_jpo`(`id`,`file_system`,`org_name`,`root_path`,`time`) values ('812446a3-8dd3-45eb-95c0-7b8f8cd0aa88','Linux','Nextree Consulting','/var/nara-vault',1527468217112);
insert into `nara_db`.`vault_jpo`(`id`,`file_system`,`org_name`,`root_path`,`time`) values ('92467e3e-0379-45ee-8188-a7af0027e4db','Linux','Nextree Soft','/var/nara-vault2',1528195655691);

CREATE TABLE `disk_file_jpo` (
  `id` varchar(255) NOT NULL,
  `creation_time` bigint(20) DEFAULT NULL,
  `encrypted` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `reference_count` int(11) DEFAULT NULL,
  `registration_time` bigint(20) DEFAULT NULL,
  `size` bigint(20) DEFAULT NULL,
  `tags_json` longtext,
  `vault_id` varchar(255) NOT NULL,
  `version` bigint(20) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `ticket_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IF_DISKFILE_VAULTID` (`vault_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `file_container_jpo` (
  `id` varchar(255) NOT NULL,
  `client_json` longtext,
  `time` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `primary_file_id` varchar(255) DEFAULT NULL,
  `ticket_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


insert into `nara_db`.`file_container_jpo`(`id`,`client_json`,`time`,`title`,`type`,`primary_file_id`,`ticket_id`) values ('019e7441-3812-4077-b28e-50519c177a77','{
  "id": "af367e71-f379-493b-a2b4-c7e13c2edea5",
  "name": "io.naraplatform.depot.domain.spec.container.sdo.FileContainerCdo"
}',1527766755058,'TinyAlbum 1','TinyAlbum','541d088c-3924-4a10-8e51-28ab0e397432','ca045ba2-7238-431d-af20-b3d544825125');
insert into `nara_db`.`file_container_jpo`(`id`,`client_json`,`time`,`title`,`type`,`primary_file_id`,`ticket_id`) values ('0449aa38-97ea-408a-a034-61d36413a774','{
  "id": "af367e71-f379-493b-a2b4-c7e13c2edea5",
  "name": "io.naraplatform.depot.domain.spec.container.sdo.FileContainerCdo"
}',1527501391592,'Posting 11-attachment','PersonalDrive',null,'17b1ad28-18fa-4828-b406-811850bda97e');
insert into `nara_db`.`file_container_jpo`(`id`,`client_json`,`time`,`title`,`type`,`primary_file_id`,`ticket_id`) values ('2a411eaf-7d97-4e33-8ad9-1bd3004eef24','{
  "id": "af367e71-f379-493b-a2b4-c7e13c2edea5",
  "name": "io.naraplatform.depot.domain.spec.container.sdo.FileContainerCdo"
}',1527570401594,'PersonalDrive 2','PersonalDrive',null,'ca045ba2-7238-431d-af20-b3d544825125');
insert into `nara_db`.`file_container_jpo`(`id`,`client_json`,`time`,`title`,`type`,`primary_file_id`,`ticket_id`) values ('8850a1ad-416b-4a69-814a-912275c40f97','{
  "id": "af367e71-f379-493b-a2b4-c7e13c2edea5",
  "name": "io.naraplatform.depot.domain.spec.container.sdo.FileContainerCdo"
}',1528196674223,'Personal Test','PersonalDrive',null,'4d46f7b9-ae69-435a-beda-ce2391f20628');

CREATE TABLE `depot_file_jpo` (
  `id` varchar(255) NOT NULL,
  `container_id` varchar(255) NOT NULL,
  `creation_time` bigint(20) DEFAULT NULL,
  `disk_file_id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `size` bigint(20) DEFAULT NULL,
  `tags_json` longtext,
  PRIMARY KEY (`id`),
  KEY `IF_DEPOTFILE_DISKFILEID` (`disk_file_id`),
  KEY `IF_DEPOTFILE_CONTAINERID` (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE `depot_ticket_jpo` (
  `id` varchar(255) NOT NULL,
  `org_id` varchar(255) DEFAULT NULL,
  `scope` varchar(255) NOT NULL,
  `service_id` varchar(255) DEFAULT NULL,
  `team_id` varchar(255) DEFAULT NULL,
  `time` bigint(20) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `user_json` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('02d6b51b-64d2-416c-860e-6d5f7d2915eb','23afa707-a1aa-4983-b274-a06c3516325d','Team','f9eca348-e563-4509-94c9-4103a36c30d3','7aa8fcdc-f5d5-407e-955a-4f29e44b2733',1528168428849,'6cd97c85-27a9-4841-935a-e69ab29e116d','{
  "service": {
    "id": "f9eca348-e563-4509-94c9-4103a36c30d3",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "7aa8fcdc-f5d5-407e-955a-4f29e44b2733",
    "name": "Platform"
  },
  "user": {
    "id": "6cd97c85-27a9-4841-935a-e69ab29e116d",
    "name": "고길동"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('17b1ad28-18fa-4828-b406-811850bda97e','23afa707-a1aa-4983-b274-a06c3516325d','User','f9eca348-e563-4509-94c9-4103a36c30d3','458e49e4-be6e-4b39-9bc8-d29b9100c798',1528167803684,'70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f','{
  "service": {
    "id": "f9eca348-e563-4509-94c9-4103a36c30d3",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "458e49e4-be6e-4b39-9bc8-d29b9100c798",
    "name": "Consulting"
  },
  "user": {
    "id": "70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f",
    "name": "홍길동"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('4d46f7b9-ae69-435a-beda-ce2391f20628','23295119-c542-44f3-b051-1a89cf0951d0','User','93a6f83d-9434-417f-b7dd-155b44294f0b','c18d20b5-d892-4c20-a0d2-5ca17de440bb',1528195460959,'5801662b-9f2a-42ba-9971-84bb43f0a03d','{
  "service": {
    "id": "93a6f83d-9434-417f-b7dd-155b44294f0b",
    "name": "nara-board"
  },
  "org": {
    "id": "23295119-c542-44f3-b051-1a89cf0951d0",
    "name": "nextree Soft"
  },
  "team": {
    "id": "c18d20b5-d892-4c20-a0d2-5ca17de440bb",
    "name": "k-project team A"
  },
  "user": {
    "id": "5801662b-9f2a-42ba-9971-84bb43f0a03d",
    "name": "이대리"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('812446a3-8dd3-45eb-95c0-7b8f8cd0aa88','23afa707-a1aa-4983-b274-a06c3516325d','Org','f9eca348-e563-4509-94c9-4103a36c30d3','458e49e4-be6e-4b39-9bc8-d29b9100c798',1528168418213,'70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f','{
  "service": {
    "id": "f9eca348-e563-4509-94c9-4103a36c30d3",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "458e49e4-be6e-4b39-9bc8-d29b9100c798",
    "name": "Consulting"
  },
  "user": {
    "id": "70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f",
    "name": "홍길동"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('92467e3e-0379-45ee-8188-a7af0027e4db','23295119-c542-44f3-b051-1a89cf0951d0','Org','93a6f83d-9434-417f-b7dd-155b44294f0b','c18d20b5-d892-4c20-a0d2-5ca17de440bb',1528195433482,'5801662b-9f2a-42ba-9971-84bb43f0a03d','{
  "service": {
    "id": "93a6f83d-9434-417f-b7dd-155b44294f0b",
    "name": "nara-board"
  },
  "org": {
    "id": "23295119-c542-44f3-b051-1a89cf0951d0",
    "name": "nextree Soft"
  },
  "team": {
    "id": "c18d20b5-d892-4c20-a0d2-5ca17de440bb",
    "name": "k-project team A"
  },
  "user": {
    "id": "5801662b-9f2a-42ba-9971-84bb43f0a03d",
    "name": "이대리"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('a49beed9-2fb5-42ea-bacd-2e7fca8f431f','23afa707-a1aa-4983-b274-a06c3516325d','Team','f9eca348-e563-4509-94c9-4103a36c30d3','458e49e4-be6e-4b39-9bc8-d29b9100c798',1528168418124,'70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f','{
  "service": {
    "id": "f9eca348-e563-4509-94c9-4103a36c30d3",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "458e49e4-be6e-4b39-9bc8-d29b9100c798",
    "name": "Consulting"
  },
  "user": {
    "id": "70fddf01-bc2a-44d2-9f0b-0fe0d9e15f1f",
    "name": "홍길동"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('ac3a2cd3-9ddb-4fac-a1ef-5d491868115c','23afa707-a1aa-4983-b274-a06c3516325d','User','93a6f83d-9434-417f-b7dd-155b44294f0b','c18d20b5-d892-4c20-a0d2-5ca17de440bb',1528164458768,'3faaa845-0425-4baa-af0e-ab809824486a','{
  "service": {
    "id": "93a6f83d-9434-417f-b7dd-155b44294f0b",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "c18d20b5-d892-4c20-a0d2-5ca17de440bb",
    "name": "k-project team A"
  },
  "user": {
    "id": "3faaa845-0425-4baa-af0e-ab809824486a",
    "name": "Hong, Gildong"
  }
}');
insert into `nara_db`.`depot_ticket_jpo`(`id`,`org_id`,`scope`,`service_id`,`team_id`,`time`,`user_id`,`user_json`) values ('ca045ba2-7238-431d-af20-b3d544825125','23afa707-a1aa-4983-b274-a06c3516325d','User','f9eca348-e563-4509-94c9-4103a36c30d3','7aa8fcdc-f5d5-407e-955a-4f29e44b2733',1528168428806,'6cd97c85-27a9-4841-935a-e69ab29e116d','{
  "service": {
    "id": "f9eca348-e563-4509-94c9-4103a36c30d3",
    "name": "nara-board"
  },
  "org": {
    "id": "23afa707-a1aa-4983-b274-a06c3516325d",
    "name": "nextree consulting"
  },
  "team": {
    "id": "7aa8fcdc-f5d5-407e-955a-4f29e44b2733",
    "name": "Platform"
  },
  "user": {
    "id": "6cd97c85-27a9-4841-935a-e69ab29e116d",
    "name": "고길동"
  }
}');

