# DEPOT

[![pipeline status](https://git.nextree.co.kr:8088/nara/depot/badges/master/pipeline.svg)](https://git.nextree.co.kr:8088/nara/depot/commits/master)
[![quality gate](http://sonar.nextree.co.kr:19000/api/project_badges/measure?project=io.naraplatform%3Adepot&metric=alert_status)](http://sonar.nextree.co.kr:19000/dashboard?id=io.naraplatform%3Adepot)

## Depot Service
- io.naraplatform.depot:depot-boot:0.1.0-SNAPSHOT
- local port : 9000
- spring.boot.version : 2.0.1.RELEASE
- spring.cloud.version : Finchley.M7


## 로컬에서의 실행방법 (UI를 포함한 방법)
 - 플랫폼 환경에 배포하기 전 임시로 사용

#### DB환경 구성

 - DEPOT_PROJECT_PATH/local-docker-data 위치로 이동

 - docker 이미지 생성 (콘솔에서 실행)
 ```
 docker build --tag depot_maria:0.1 .
 ```
 
 - docker 컨테이너 실행 (콘솔에서 실행)
 ```
 docker run --name depot_db -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root -d depot_maria:0.1
 ```
 
 - boot2docker 를 사용하는 윈도우환경에서는 localhost 주소와 boo2docker의 기본 주소와의 바인딩 필요 (콘솔에서 실행)
 ```
 boot2docker ssh -L 0.0.0.0:3306:localhost:3306
 ```

 - 이후 중지할 때 (콘솔에서 실행)
 ```
 docker stop depot_db
 ```
 
 - 이후 시작할 때 (콘솔에서 실행)
 ```
 - docker start depot_db
 ```

#### 서비스의 서버 구성

 - IntelliJ IDE 에서 build 후 boot 실행

#### 서비스의 UI 구성 (nodeJS 필요)

 - depot-front 소스를 내려밨음
 ```
 git clone https://git.nextree.co.kr:8088/nara/depot-front.git
 ```
 
 - package.json 파일이 존재하는 PROJECT_PATH로 이동
 
 - npm install   실행
 - npm start   실행  (혹은 yarn 사용 시 yarn start)
 
 - localhost:8081/depot/depotFiles 으로 화면이동
 
 - (참고: npm install 실패시 .npmrc 내용을 # 으로 주석처리후 다시 실행)
