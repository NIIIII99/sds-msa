package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.logic.DepotLogic;
import io.naraplatform.depot.domain.spec.depot.sdo.DepotCdo;
import io.naraplatform.depot.domain.store.DepotStoreLycler;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("DepotService")
public class DepotSpringService extends DepotLogic {
    //
    @Autowired
    public DepotSpringService(DepotStoreLycler depotStoreLycler) {
        super(depotStoreLycler);
    }

    @Override
    @Transactional
    public String registerFileBox(DepotCdo depotCdo) {
        return super.registerFileBox(depotCdo);
    }

    @Override
    @Transactional
    public String registerPersonalDrive(DepotCdo depotCdo) {
        return super.registerPersonalDrive(depotCdo);
    }

    @Override
    @Transactional
    public String registerTeamDrive(DepotCdo depotCdo) {
        return super.registerTeamDrive(depotCdo);
    }

    @Override
    public String registerTinyAlbum(DepotCdo depotCdo) {
        return super.registerTinyAlbum(depotCdo);
    }

    @Override
    public Depot findDepot(String depotId) {
        return super.findDepot(depotId);
    }

    @Override
    public Depot findDepot(String ticketId, DepotType type) {
        return super.findDepot(ticketId, type);
    }

    @Override
    public Depot findFileBox(String depotId) {
        return super.findFileBox(depotId);
    }

    @Override
    public Depot findPersonalDrive(String ticketId) {
        return super.findPersonalDrive(ticketId);
    }

    @Override
    public Depot findTeamDrive(String ticketId) {
        return super.findTeamDrive(ticketId);
    }

    @Override
    public List<Depot> findAllDepots(int offset, int limit) {
        return super.findAllDepots(offset, limit);
    }

    @Override
    public List<Depot> findAllDepotsByType(DepotType type, String ticketId, String keyword) {
        return super.findAllDepotsByType(type, ticketId, keyword);
    }

    @Override
    @Transactional
    public void modifyDepot(String depotId, NameValueList nameValues) {
        super.modifyDepot(depotId, nameValues);
    }

    @Override
    @Transactional
    public void removeDepot(String depotId) {
        super.removeDepot(depotId);
    }

    @Override
    @Transactional
    public List<String> addDepotFiles(String depotId, List<String> vaultFileIds) {
        return super.addDepotFiles(depotId, vaultFileIds);
    }

    @Override
    @Transactional
    public void removeDepotFiles(String depotId, List<String> depotFileIds, String ticketId) {
        super.removeDepotFiles(depotId, depotFileIds, ticketId);
    }

    @Override
    public DepotFile findDepotFile(String depotId, String depotFileId) {
        return super.findDepotFile(depotId, depotFileId);
    }

    @Override
    public List<DepotFile> findDepotFiles(String depotId, int offset, int limit) {
        return super.findDepotFiles(depotId, offset, limit);
    }

    @Override
    public DepotFile findDepotFileByName(String depotId, String name) {
        return super.findDepotFileByName(depotId, name);
    }

    @Override
    public boolean existDuplicationByNames(String depotId, List<String> fileNames) {
        return super.existDuplicationByNames(depotId, fileNames);
    }

    @Override
    public boolean existDuplicationByVaultFileIds(String depotId, List<String> vaultFileIds) {
        return super.existDuplicationByVaultFileIds(depotId, vaultFileIds);
    }

    @Override
    public int countDepotFiles(String depotId) {
        return super.countDepotFiles(depotId);
    }

    @Override
    public VaultFile findVaultFileForDownload(String depotId, String depotFileId, String ticketId) {
        return super.findVaultFileForDownload(depotId, depotFileId, ticketId);
    }

    @Override
    public boolean isDepotThatNeedCopying(String depotId, String ticketId) {
        return super.isDepotThatNeedCopying(depotId, ticketId);
    }
}
