package io.naraplatform.depot.sp.spring;

import io.naraplatform.depot.cp.spring.DepotHandlerSpringLycler;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.depot.domain.logic.VaultFileHandler;
import io.naraplatform.depot.domain.spec.vault.VaultService;
import io.naraplatform.depot.domain.spec.vault.sdo.VaultFileCdo;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.exception.NaraException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("depot-api/vaults")
public class VaultResource {
    //
    @Autowired
    private VaultService vaultService;

    private VaultFileHandler vaultFileHandler;

    @Autowired
    public VaultResource(DepotHandlerSpringLycler depotHandlerSpringLycler) {
        this.vaultFileHandler = depotHandlerSpringLycler.requestVaultFileHandler();
    }


    @RequestMapping(method = RequestMethod.POST)
    public String registerVault(@RequestBody Vault vault,
                                @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        return vaultService.registerVault(vault, ticketId);
    }


    @RequestMapping(method = RequestMethod.GET, value = "{id}")
    public Vault findVault(@PathVariable("id") String vaultId) {
        //
        return vaultService.findVault(vaultId);
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<Vault> findAllVault(@RequestParam(required = true, defaultValue = "0", value = "offset") int offset,
                                    @RequestParam(required = true, defaultValue = "10", value = "limit") int limit) {
        //
        return vaultService.findAllVault(offset, limit);
    }

    @RequestMapping(method = RequestMethod.GET, value="existId")
    public String findVaultIdByTicketId(@RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        Vault vault = vaultService.findVaultByTicketId(ticketId);
        return vault.getId();
    }


    @RequestMapping(method = RequestMethod.DELETE, value = "{id}")
    public void removeVault(@PathVariable("id") String vaultId) {
        //
        vaultService.removeVault(vaultId);
    }


    @RequestMapping(method = RequestMethod.POST, value = "{id}/vaultFiles")
    public String addVaultFile(@PathVariable("id") String vaultId,
                               @RequestBody VaultFileCdo vaultFileCdo,
                               @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        vaultFileCdo.setTicketId(ticketId);
        return vaultService.addVaultFile(vaultId, vaultFileCdo);
    }


    @RequestMapping(method = RequestMethod.POST, value = "{id}/vaultFiles/list")
    public List<String> addVaultFiles(@PathVariable("id") String vaultId,
                                      @RequestBody List<VaultFileCdo> vaultFileCdos,
                                      @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        return vaultService.addVaultFiles(vaultId, vaultFileCdos, ticketId);
    }

    @RequestMapping(method = RequestMethod.POST, value = "{id}/vaultFiles/{vaultFileId}/upgrade")
    public String addNewVersionVaultFile(@PathVariable("id") String vaultId,
                                         @PathVariable("vaultFileId") String vaultFileId,
                                         @RequestBody VersionPart versionPart,
                                         @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        return vaultService.addNewVersionVaultFile(vaultFileId, versionPart, ticketId);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "{id}/vaultFiles")
    public void removeVaultFile(@PathVariable("id") String vaultId,
                                @RequestParam("vaultFileIds") List<String> vaultFileIds) {
        //
        vaultService.removeVaultFiles(vaultId, vaultFileIds);
    }


    @RequestMapping(method = RequestMethod.PUT, value = "{id}/vaultFiles/{vaultFileId}")
    public void updateVaultFile(@PathVariable("id") String id,
                                @PathVariable("vaultFileId") String vaultFileId,
                                @RequestBody NameValueList nameValues,
                                @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        vaultService.modifyVaultFile(vaultFileId, nameValues, ticketId);
    }

    @RequestMapping(method = RequestMethod.POST, value = "copyVaultFiles")
    public List<String> copyVaultFilesToOtherOrg(@RequestParam("vaultFileIds") List<String> sourceVaultFileIds,
                                                 @RequestParam("depotId") String targetDepotId,
                                                 @RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        List<VaultFile> sourceVaultFiles = findVaultFiles(sourceVaultFileIds);
        List<VaultFile> targetValutFiles = vaultService.copyVaultFilesToOtherOrg(sourceVaultFileIds, targetDepotId);
        vaultFileHandler.copyVaultFiles(sourceVaultFiles, targetValutFiles);

        return targetValutFiles.stream().map(VaultFile::getId).collect(Collectors.toList());
    }

    @RequestMapping(method = RequestMethod.POST, value = "{id}/vaultFiles/{vaultFileId}/chunks/{sequence}")
    public void uploadFile(@PathVariable("id") String vaultId,
                           @PathVariable("vaultFileId") String vaultFileId,
                           @PathVariable("sequence") String sequence,
                           @RequestPart("file") MultipartFile multipartFile,
                           @RequestHeader("Depot-Ticket-Id") String ticketId ) throws IOException {
        //
        VaultFile vaultFile = findVaultFile(vaultFileId);
        vaultFileHandler.uploadFile(vaultFile, sequence, multipartFile.getInputStream(), ticketId);
    }

    @RequestMapping(method = RequestMethod.POST, value = "{id}/vaultFiles/{vaultFileId}/combine/{chunksCount}")
    public void combineFile(@PathVariable("id") String vaultId,
                            @PathVariable("vaultFileId") String vaultFileId,
                            @PathVariable("chunksCount") String chunksCount,
                            @RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        VaultFile vaultFile = findVaultFile(vaultFileId);
        vaultFileHandler.combineToDisk(vaultFile, chunksCount, ticketId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "vaultFiles/{vaultFileId}/download")
    public void downloadFile(@PathVariable("vaultFileId") String vaultFileId,
                             @RequestHeader("Depot-Ticket-Id") String ticketId,
                             HttpServletRequest request,
                             HttpServletResponse response ) throws IOException {
        //
        VaultFile vaultFile = findVaultFile(vaultFileId);
        if(!vaultFile.getTicketId().equals(ticketId)) {throw new NaraException(String.format("No match TicketId [%s]", ticketId));}
        String fileName = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        Path path = Paths.get(fileName);

        response.setContentType("application/octet-stream");
        response.setContentLength( (int)((long) vaultFile.latestVersion().getSize()) );
        response.setHeader("Content-Disposition", "attachment; filename=\"" + vaultFile.getName() + "\"");

        Files.copy(path, response.getOutputStream());
        response.flushBuffer();
    }

    @RequestMapping(method = RequestMethod.GET, value = "vaultFiles/{id}/downloadAs/{fileName}")
    public void downloadResourceFile(@PathVariable("id") String vaultFileId,
                                     @PathVariable("fileName") String fileName,
                                     HttpServletRequest request,
                                     HttpServletResponse response ) throws IOException {
        //
        VaultFile vaultFile = findVaultFile(vaultFileId);
        String filePath = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + vaultFile.getVersion();
        Path path = Paths.get(filePath);

        response.setContentType("application/octet-stream");
        response.setContentLength( (int)((long) vaultFile.latestVersion().getSize()) );
        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

        Files.copy(path, response.getOutputStream());
        response.flushBuffer();
    }

    private VaultFile findVaultFile(String vaultFileId) {
        //
        return vaultService.findVaultFile(vaultFileId);
    }

    private List<VaultFile> findVaultFiles(List<String> vaultFileIds) {
        //
        return vaultService.findVaultFiles(vaultFileIds);
    }

    @RequestMapping(method = RequestMethod.GET, value = "vaultFiles/{vaultFileId}/modifiable")
    public boolean isModifiableVaultFile(@PathVariable("vaultFileId") String vaultFileId,
                                         @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        return vaultService.isModifiableVaultFile(vaultFileId, ticketId);
    }
}
