package io.naraplatform.depot.sp.spring;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.spec.ticket.DepotTicketService;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("depot-api/depotTickets")
public class DepotTicketResource implements DepotTicketService {

    @Autowired
    private DepotTicketService depotTicketService;

    @Override
    @RequestMapping(method = RequestMethod.POST, value = "issue/{scope}")
    public String issueDepotTicket(@RequestBody ServiceUser user, @PathVariable("scope") ServiceScope scope) {
        //
        return depotTicketService.issueDepotTicket(user, scope);
    }

    @Override
    @RequestMapping(method = RequestMethod.GET, value = "services/{serviceId}")
    public List<DepotTicket> findDepotTicketByService(@PathVariable("serviceId") String serviceId) {
        //
        return depotTicketService.findDepotTicketByService(serviceId);
    }

    @Override
    @RequestMapping(method = RequestMethod.GET, value = "services/{serviceId}/org/{orgId}")
    public List<DepotTicket> findDepotTicketByServiceAndOrg(@PathVariable("serviceId") String serviceId,
                                                            @PathVariable("orgId") String orgId) {
        //
        return depotTicketService.findDepotTicketByServiceAndOrg(serviceId, orgId);
    }
}
