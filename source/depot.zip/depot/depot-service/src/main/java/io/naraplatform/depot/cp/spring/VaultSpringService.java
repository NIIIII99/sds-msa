package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.depot.domain.logic.VaultLogic;
import io.naraplatform.depot.domain.spec.vault.sdo.VaultFileCdo;
import io.naraplatform.depot.domain.store.DepotStoreLycler;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("vaultService")
public class VaultSpringService extends VaultLogic {
    //
    public VaultSpringService(DepotStoreLycler depotStoreLycler) {
        super(depotStoreLycler);
    }

    @Override
    @Transactional
    public String registerVault(Vault vault, String ticketId) {
        return super.registerVault(vault, ticketId);
    }

    @Override
    public Vault findVault(String vaultId) {
        return super.findVault(vaultId);
    }

    @Override
    public List<Vault> findAllVault(int offset, int limit) {
        return super.findAllVault(offset, limit);
    }

    @Override
    @Transactional
    public void removeVault(String vaultId) {
        super.removeVault(vaultId);
    }

    @Override
    public Vault findVaultByTicketId(String ticketId) {
        return super.findVaultByTicketId(ticketId);
    }

    @Override
    @Transactional
    public String addVaultFile(String vaultId, VaultFileCdo vaultFileCdo) {
        return super.addVaultFile(vaultId, vaultFileCdo);
    }

    @Override
    @Transactional
    public List<String> addVaultFiles(String vaultId, List<VaultFileCdo> vaultFileCdos, String ticketId) {
        return super.addVaultFiles(vaultId, vaultFileCdos, ticketId);
    }

    @Override
    public String addNewVersionVaultFile(String vaultFileId, VersionPart versionPart, String ticketId) {
        return super.addNewVersionVaultFile(vaultFileId, versionPart, ticketId);
    }

    @Override
    public VaultFile findVaultFile(String vaultFileId) {
        return super.findVaultFile(vaultFileId);
    }

    @Override
    public List<VaultFile> findVaultFiles(List<String> vaultFileIds) {
        return super.findVaultFiles(vaultFileIds);
    }

    @Override
    @Transactional
    public void removeVaultFiles(String vaultId, List<String> vaultFileIds) {
        super.removeVaultFiles(vaultId, vaultFileIds);
    }

    @Override
    @Transactional
    public void modifyVaultFile(String vaultFileId, NameValueList nameValues, String ticketId) {
        super.modifyVaultFile(vaultFileId, nameValues, ticketId);
    }

    @Override
    @Transactional
    public List<VaultFile> copyVaultFilesToOtherOrg(List<String> sourceVaultFileIds, String targetDepotId) {
        return super.copyVaultFilesToOtherOrg(sourceVaultFileIds, targetDepotId);
    }

    @Override
    public boolean isModifiableVaultFile(String vaultFileId, String ticketId) {
        return super.isModifiableVaultFile(vaultFileId, ticketId);
    }
}
