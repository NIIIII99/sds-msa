package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.store.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DepotStoreSpringLycler implements DepotStoreLycler {
    //
    @Autowired
    private DepotFileStore depotFileStore;

    @Autowired
    private VaultFileStore vaultFileStore;

    @Autowired
    private DepotStore depotStore;

    @Autowired
    private VaultStore vaultStore;

    @Autowired
    private DepotTicketStore depotTicketStore;

    @Override
    public DepotFileStore requestDepotFileStore() {
        return this.depotFileStore;
    }

    @Override
    public VaultFileStore requestVaultFileStore() {
        return this.vaultFileStore;
    }

    @Override
    public DepotStore requestDepotStore() {
        return this.depotStore;
    }

    @Override
    public VaultStore requestVaultStore() {
        return this.vaultStore;
    }

    @Override
    public DepotTicketStore requestDepotTicketStore() {
        return this.depotTicketStore;
    }
}
