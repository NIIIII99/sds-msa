package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.logic.DepotTicketLogic;
import io.naraplatform.depot.domain.store.DepotStoreLycler;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service("depotTicketService")
public class DepotTicketSpringService extends DepotTicketLogic {
    //
    @Autowired
    public DepotTicketSpringService(DepotStoreLycler depotStoreLycler) {
        super(depotStoreLycler);
    }

    @Override
    @Transactional
    public String issueDepotTicket(ServiceUser user, ServiceScope scope) {
        return super.issueDepotTicket(user, scope);
    }

    @Override
    public List<DepotTicket> findDepotTicketByService(String serviceId) {
        return super.findDepotTicketByService(serviceId);
    }

    @Override
    public List<DepotTicket> findDepotTicketByServiceAndOrg(String serviceId, String orgId) {
        return super.findDepotTicketByServiceAndOrg(serviceId, orgId);
    }
}
