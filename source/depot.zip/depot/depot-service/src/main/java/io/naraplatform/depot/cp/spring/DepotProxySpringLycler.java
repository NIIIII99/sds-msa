package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.proxy.DepotProxyLycler;
import io.naraplatform.depot.domain.proxy.VaultFileProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DepotProxySpringLycler implements DepotProxyLycler {
    //
    @Autowired
    private VaultFileProxy vaultFileProxy;

    @Override
    public VaultFileProxy requestVaultFileProxy() {
        return this.vaultFileProxy;
    }
}
