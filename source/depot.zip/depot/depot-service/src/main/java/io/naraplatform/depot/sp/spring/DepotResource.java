package io.naraplatform.depot.sp.spring;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.spec.depot.DepotService;
import io.naraplatform.depot.domain.spec.depot.sdo.DepotCdo;
import io.naraplatform.share.domain.NameValueList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("depot-api/depots")
public class DepotResource {
    //
    @Autowired
    private DepotService depotService;

    @RequestMapping(method = RequestMethod.POST)
    public String registerFileBox(@RequestBody DepotCdo depotCdo,
                                  @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        depotCdo.setTicketId(ticketId);
        return depotService.registerFileBox(depotCdo);
    }

    @RequestMapping(method = RequestMethod.POST, value = "isPersonal")
    public String registerPersonalDrive(@RequestBody DepotCdo depotCdo,
                                        @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        depotCdo.setTicketId(ticketId);
        return depotService.registerPersonalDrive(depotCdo);
    }

    @RequestMapping(method = RequestMethod.POST, value = "isTeam")
    public String registerTeamDrive(@RequestBody DepotCdo depotCdo,
                                    @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        depotCdo.setTicketId(ticketId);
        return depotService.registerTeamDrive(depotCdo);
    }

    @RequestMapping(method = RequestMethod.POST, value = "isTinyAlbum")
    public String registerTinyAlbum(@RequestBody DepotCdo depotCdo,
                                    @RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        depotCdo.setTicketId(ticketId);
        return depotService.registerTinyAlbum(depotCdo);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}")
    public Depot findDepot(@PathVariable("id") String depotId) {
        //
        return depotService.findDepot(depotId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "type/{type}")
    public Depot findDepot(@RequestHeader("Depot-Ticket-Id") String ticketId,
                           @PathVariable("type") DepotType type) {
        //
        return depotService.findDepot(ticketId, type);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/isFileBox")
    public Depot findFileBox(@PathVariable("id") String depotId) {
        //
        return depotService.findFileBox(depotId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "isPersonal")
    public Depot findPersonalDrive(@RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        return depotService.findPersonalDrive(ticketId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "isTeam")
    public Depot findTeamDrive(@RequestHeader("Depot-Ticket-Id") String ticketId) {
        //
        return depotService.findTeamDrive(ticketId);
    }

    @RequestMapping(method = RequestMethod.GET)
    public List<Depot> findAllDepots(@RequestParam(required = true, defaultValue="0", value = "offset") int offset,
                                     @RequestParam(required = true, defaultValue="10", value = "limit") int limit) {
        //
        return depotService.findAllDepots(offset, limit);
    }

    @RequestMapping(method = RequestMethod.GET, value = "isSharingTargets")
    public List<Depot> findAllDepotsByType(@RequestParam(required = true, value = "type") DepotType type,
                                           @RequestParam(required = false, value = "keyword") String keyword,
                                           @RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        return depotService.findAllDepotsByType(type, ticketId, keyword);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{id}")
    public void modifyDepot(@PathVariable("id") String depotId,
                            @RequestBody NameValueList nameValues) {
        //
        depotService.modifyDepot(depotId, nameValues);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "{id}")
    public void removeDepot(@PathVariable("id") String depotId) {
        //
        depotService.removeDepot(depotId);
    }

    @RequestMapping(method = RequestMethod.POST, value = "{id}/depotFiles")
    public List<String> addDepotFiles(@PathVariable("id") String depotId,
                                      @RequestBody List<String> vaultFileIds) {
        //
        return depotService.addDepotFiles(depotId, vaultFileIds);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "{id}/depotFiles")
    public void removeDepotFiles(@PathVariable("id") String depotId,
                                 @RequestParam("depotFileIds") List<String> depotFileIds,
                                 @RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        depotService.removeDepotFiles(depotId, depotFileIds, ticketId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles")
    public List<DepotFile> findDepotFiles(@PathVariable("id") String depotId,
                                          @RequestParam(required = true, defaultValue="0", value = "offset") int offset,
                                          @RequestParam(required = true, defaultValue="10", value = "limit") int limit) {
        //
        return depotService.findDepotFiles(depotId, offset, limit);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles/sameName")
    public DepotFile findDepotFileByName(@PathVariable("id") String depotId,
                                         @RequestParam("name") String name) {
        //
        return depotService.findDepotFileByName(depotId, name);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles/existSameNameByDiskId")
    public boolean existSameNameByVaultFileIds(@PathVariable("id") String depotId,
                                              @RequestParam("vaultFileIds") List<String> vaultFileIds) {
        //
        return depotService.existDuplicationByVaultFileIds(depotId, vaultFileIds);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles/existSameNames")
    public boolean existSameNameByNames(@PathVariable("id") String depotId,
                                        @RequestParam("fileNames") List<String> fileNames) {
        //
        return depotService.existDuplicationByNames(depotId, fileNames);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles/count")
    public int countDepotFiles(@PathVariable("id") String depotId) {
        //
        return depotService.countDepotFiles(depotId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/needCopying")
    public boolean isDepotThatNeedCopying(@PathVariable("id") String depotId,
                                          @RequestHeader("Depot-Ticket-Id") String ticketId ) {
        //
        return depotService.isDepotThatNeedCopying(depotId, ticketId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{id}/depotFiles/{depotFileId}/download")
    public void downloadFile(@PathVariable("id") String depotId,
                             @PathVariable("depotFileId") String depotFileId,
                             @RequestHeader("Depot-Ticket-Id") String ticketId,
                             HttpServletRequest request,
                             HttpServletResponse response ) throws IOException {
        //
        VaultFile vaultFile = depotService.findVaultFileForDownload(depotId, depotFileId, ticketId);
        DepotFile depotFile = depotService.findDepotFile(depotId, depotFileId);

        String fileName = vaultFile.getPath() + File.separator + vaultFile.getId() + "-" + depotFile.getTargetVersion();
        Path path = Paths.get(fileName);

        response.setContentType("application/octet-stream");
        response.setHeader("Connection", "Transfer-Encoding");
        response.setHeader("Transfer-Encoding", "chunked");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + vaultFile.getName() + "\"");

        Files.copy(path, response.getOutputStream());
        response.flushBuffer();
    }
}
