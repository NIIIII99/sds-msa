package io.naraplatform.depot.cp.spring;

import io.naraplatform.depot.domain.logic.VaultFileHandler;
import io.naraplatform.depot.domain.proxy.DepotProxyLycler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DepotHandlerSpringLycler {
    //
    private VaultFileHandler vaultFileHandler;

    @Autowired
    public DepotHandlerSpringLycler(DepotProxyLycler depotProxyLycler) {
        this.vaultFileHandler = new VaultFileHandler(depotProxyLycler);
    }

    public VaultFileHandler requestVaultFileHandler () {
        //
        return this.vaultFileHandler;
    }
}
