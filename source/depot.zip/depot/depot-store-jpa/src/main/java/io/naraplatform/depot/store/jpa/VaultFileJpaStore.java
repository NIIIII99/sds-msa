package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.store.VaultFileStore;
import io.naraplatform.depot.store.jpa.jpo.VaultFileJpo;
import io.naraplatform.depot.store.jpa.springdata.VaultFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository("vaultFileStore")
public class VaultFileJpaStore implements VaultFileStore {
    //
    @Autowired
    private VaultFileRepository vaultFileRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No VaultFile[%s] to retrieve.";

    @Override
    public void create(VaultFile vaultFile) {
        //
        VaultFileJpo vaultFileJpo = new VaultFileJpo(vaultFile);
        vaultFileRepository.save(vaultFileJpo);
    }

    @Override
    public void create(List<VaultFile> vaultFiles) {
        //
        List<VaultFileJpo> vaultFileJpos = vaultFiles.stream().map(VaultFileJpo::new).collect(Collectors.toList());
        vaultFileRepository.saveAll(vaultFileJpos);
    }

    @Override
    public VaultFile retrieve(String id) {
        //
        Optional<VaultFileJpo> vaultFileJpo = vaultFileRepository.findById(id);
        if (!vaultFileJpo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, id));
        }

        return vaultFileJpo.get().toDomain();
    }

    @Override
    public List<VaultFile> retrieve(List<String> vaultFileIds) {
        //
        List<VaultFileJpo> vaultFileJpos = (List<VaultFileJpo>)vaultFileRepository.findAllById(vaultFileIds);

        return vaultFileJpos.stream().map(VaultFileJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<VaultFile> retrieveByVaultId(String vaultId, int offset, int limit) {
        //
        int size = limit > 0 ? limit : 10;
        int page = (offset / size);
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "creationTime");
        List<VaultFileJpo> vaultFileJpos =  vaultFileRepository.findByVaultId(vaultId, pageable);

        return vaultFileJpos.stream().map(VaultFileJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(VaultFile vaultFile) {
        //
        VaultFileJpo vaultFileJpo = new VaultFileJpo(vaultFile);
        vaultFileRepository.save(vaultFileJpo);
    }

    @Override
    public void update(List<VaultFile> vaultFiles) {
        //
        List<VaultFileJpo> vaultFileJpos = vaultFiles.stream().map(VaultFileJpo::new).collect(Collectors.toList());
        vaultFileRepository.saveAll(vaultFileJpos);
    }

    @Override
    public void delete(VaultFile vaultFile) {
        //
        String id = vaultFile.getId();
        vaultFileRepository.deleteById(id);
    }

    @Override
    public void delete(List<String> vaultFileIds) {
        //
        vaultFileRepository.deleteByIdIn(vaultFileIds);
    }
}
