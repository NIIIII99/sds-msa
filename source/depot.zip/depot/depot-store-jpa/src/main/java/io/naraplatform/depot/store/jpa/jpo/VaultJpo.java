package io.naraplatform.depot.store.jpa.jpo;

//import io.naraplatform.depot.domain.entity.user.Owner;
import io.naraplatform.depot.domain.entity.vault.VaultType;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity(name = "VAULT")
@Table(indexes = {
        //@Index(name = "IU_VAULT_ORGKEY", unique = true, columnList = "ORG_KEY")
})
public class VaultJpo implements JsonSerializable {
    //
    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "ORG_NAME")
    private String orgName;

    @Column(name = "ROOT_PATH")
    private String rootPath;

    @Enumerated(EnumType.STRING)
    @Column(name = "VAULT_TYPE")
    private VaultType vaultType;

    @Column(name = "TIME")
    private long time;

    public VaultJpo(Vault vault) {
        //
        BeanUtils.copyProperties(vault, this);
    }

    public Vault toDomain() {
        //
        Vault vault = new Vault(id);
        BeanUtils.copyProperties(this, vault);

        return vault;
    }

    public String toString() {
        //
        return toJson();
    }

    public static VaultJpo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, VaultJpo.class);
    }

    public static VaultJpo sample() {
        //
        return new VaultJpo(Vault.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
