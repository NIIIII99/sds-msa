package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.store.DepotTicketStore;
import io.naraplatform.depot.store.jpa.jpo.DepotTicketJpo;
import io.naraplatform.depot.store.jpa.springdata.DepotTicketRepository;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.exception.store.NaraStoreException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository("depotTicketStore")
public class DepotTicketJpaStore implements DepotTicketStore {
    //
    @Autowired
    private DepotTicketRepository depotTicketRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DepotTicket[%s] to retrieve.";

    @Override
    public void create(DepotTicket depotTicket) {
        //
        DepotTicketJpo depotTicketJpo = new DepotTicketJpo(depotTicket);
        depotTicketRepository.save(depotTicketJpo);
    }

    @Override
    public DepotTicket retrieve(String id) {
        //
        Optional<DepotTicketJpo> depotTicket = depotTicketRepository.findById(id);
        if (!depotTicket.isPresent()) {
            throw new NaraStoreException(String.format(NO_SUCH_ELEMENT_MESSAGE, id));
        }

        return depotTicket.get().toDomain();
    }

    @Override
    public DepotTicket retrieveServiceTicket(String serviceId) {
        //
        Optional<DepotTicketJpo> depotTicketJpo = depotTicketRepository.findByScopeAndServiceId(ServiceScope.Service, serviceId);
        if (!depotTicketJpo.isPresent()) {
            return null;
        }

        return depotTicketJpo.get().toDomain();
    }

    @Override
    public DepotTicket retrieveOrgTicket(String serviceId, String orgId) {
        //
        Optional<DepotTicketJpo> depotTicketJpo = depotTicketRepository.findByScopeAndServiceIdAndOrgId(ServiceScope.Org, serviceId, orgId);
        if (!depotTicketJpo.isPresent()) {
            return null;
        }

        return depotTicketJpo.get().toDomain();
    }

    @Override
    public DepotTicket retrieveTeamTicket(String serviceId, String orgId, String teamId) {
        //
        Optional<DepotTicketJpo> depotTicketJpo = depotTicketRepository.findByScopeAndServiceIdAndOrgIdAndTeamId(ServiceScope.Team, serviceId, orgId, teamId);
        if (!depotTicketJpo.isPresent()) {
            return null;
        }

        return depotTicketJpo.get().toDomain();
    }

    @Override
    public DepotTicket retrieveUserTicket(String serviceId, String orgId, String userId) {
        //
        Optional<DepotTicketJpo> depotTicketJpo = depotTicketRepository.findByScopeAndServiceIdAndOrgIdAndUserId(ServiceScope.User, serviceId,orgId, userId);
        if (!depotTicketJpo.isPresent()) {
            return null;
        }

        return depotTicketJpo.get().toDomain();
    }

    @Override
    public List<DepotTicket> retrieveByServiceId(String serviceId) {
        //
        List<DepotTicketJpo> depotTicketJpos = depotTicketRepository.findByServiceId(serviceId);

        return depotTicketJpos.stream().map(DepotTicketJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<DepotTicket> retrieveByServiceIdAndOrgId(String serviceId, String orgId) {
        //
        List<DepotTicketJpo> depotTicketJpos = depotTicketRepository.findByServiceIdAndOrgId(serviceId, orgId);

        return depotTicketJpos.stream().map(DepotTicketJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(DepotTicket depotTicket) {
        //
        DepotTicketJpo depotTicketJpo = new DepotTicketJpo(depotTicket);
        depotTicketRepository.save(depotTicketJpo);
    }

    @Override
    public void delete(DepotTicket depotTicket) {
        //
        String id = depotTicket.getId();
        depotTicketRepository.deleteById(id);
    }
}
