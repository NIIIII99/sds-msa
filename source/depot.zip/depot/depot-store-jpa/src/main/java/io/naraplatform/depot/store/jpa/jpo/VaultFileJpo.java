package io.naraplatform.depot.store.jpa.jpo;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity(name = "VAULT_FILE")
@Table(indexes = {
        @Index(name = "IF_VAULTFILE_VAULTID", unique = false, columnList = "VAULT_ID"),
})
public class VaultFileJpo implements JsonSerializable {
    //
    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "VERSION")
    private long version;

    @Column(name = "TICKET_ID", nullable = false)
    private String ticketId;

    @Column(name = "PATH")
    private String path;

    @Column(name = "NAME")
    private String name;

    @Column(name = "OWNER_NAME")
    private String ownerName;

    @Column(name = "CREATION_TIME")
    private long creationTime;

    @Column(name = "VERSION_PARTS_JSON")
    @Lob
    private String versionPartsJson;

    @Column(name = "TAGS_JSON")
    @Lob
    private String tagsJson;

    @Column(name = "ENCRYPTED")
    private boolean encrypted;

    @Column(name = "TOTAL_REFERENCE_COUNT")
    private int totalReferenceCount;

    @Column(name = "VAULT_ID", nullable = false)
    private String vaultId;

    public VaultFileJpo(VaultFile vaultFile) {
        //
        BeanUtils.copyProperties(vaultFile, this);
        this.versionPartsJson = JsonUtil.toJson(vaultFile.getVersionParts());
        this.tagsJson = JsonUtil.toJson(vaultFile.getTags());
    }

    public VaultFile toDomain() {
        //
        VaultFile vaultFile = new VaultFile(id);
        BeanUtils.copyProperties(this, vaultFile);
        vaultFile.setVersionParts(JsonUtil.fromJsonList(versionPartsJson, VersionPart.class));
        vaultFile.setTags(JsonUtil.fromJsonList(tagsJson, String.class));

        return vaultFile;
    }

    public String toString() {
        //
        return toJson();
    }

    public static VaultFileJpo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, VaultFileJpo.class);
    }

    public static VaultFileJpo sample() {
        //
        VaultFile vaultFile = VaultFile.sample();
        vaultFile.increaseReferenceCount();
        return new VaultFileJpo(vaultFile);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
