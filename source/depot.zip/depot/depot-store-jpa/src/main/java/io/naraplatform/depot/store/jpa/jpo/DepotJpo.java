package io.naraplatform.depot.store.jpa.jpo;

import io.naraplatform.depot.domain.entity.depot.DepotConfig;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.Depot;
//import io.naraplatform.depot.domain.entity.user.Owner;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity(name = "DEPOT")
@Table(indexes = {
    @Index(name = "IU_DEPOT_TICKETID_TYPE", unique = true, columnList = "TICKET_ID,TYPE"),
})
public class DepotJpo {
    //
    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "TYPE", nullable = false)
    @Enumerated(EnumType.STRING)
    private DepotType type;

    @Column(name = "TICKET_ID", nullable = false)
    private String ticketId;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "CURRENT_SEQUENCE")
    private int currentSequence;

    @Column(name = "CLIENT_JSON")
    @Lob
    private String clientJson;              // client classs or team

    @Column(name = "CONFIG_JSON")
    @Lob
    private String configJson;

    @Column(name = "TIME")
    private long time;

    @Column(name = "REP_DEPOT_FILE_ID")
    private String repDepotFileId;

    @Column(name = "VAULT_ID")
    private String vaultId;

    public DepotJpo(Depot depot) {
        //
        BeanUtils.copyProperties(depot, this);
        this.clientJson = depot.getClient().toJson();
        this.configJson = depot.getConfig().toJson();
    }

    public Depot toDomain() {
        //
        Depot depot = new Depot(id);
        BeanUtils.copyProperties(this, depot);
        depot.setClient(JsonUtil.fromJson(clientJson, IdName.class));
        depot.setConfig(JsonUtil.fromJson(configJson, DepotConfig.class));

        return depot;
    }
}
