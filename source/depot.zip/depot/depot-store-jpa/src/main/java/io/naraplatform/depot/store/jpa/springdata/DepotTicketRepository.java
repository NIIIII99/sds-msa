package io.naraplatform.depot.store.jpa.springdata;

import io.naraplatform.depot.store.jpa.jpo.DepotTicketJpo;
import io.naraplatform.share.domain.drama.ServiceScope;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Optional;

public interface DepotTicketRepository extends PagingAndSortingRepository<DepotTicketJpo, String> {
    //
    Optional<DepotTicketJpo> findByScopeAndServiceId(ServiceScope scope, String serviceId);
    Optional<DepotTicketJpo> findByScopeAndServiceIdAndOrgId(ServiceScope scope, String serviceId, String orgId);
    Optional<DepotTicketJpo> findByScopeAndServiceIdAndOrgIdAndTeamId(ServiceScope scope, String serviceId, String orgId, String teamId);
    Optional<DepotTicketJpo> findByScopeAndServiceIdAndOrgIdAndUserId(ServiceScope scope, String serviceId, String orgId, String userId);

    List<DepotTicketJpo> findByServiceId(String serviceId);
    List<DepotTicketJpo> findByServiceIdAndOrgId(String serviceId, String orgId);
}
