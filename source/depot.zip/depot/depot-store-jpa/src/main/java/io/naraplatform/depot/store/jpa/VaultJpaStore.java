package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.store.VaultStore;
import io.naraplatform.depot.store.jpa.jpo.VaultJpo;
import io.naraplatform.depot.store.jpa.springdata.VaultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository("vaultStore")
public class VaultJpaStore implements VaultStore {
    //
    @Autowired
    private VaultRepository vaultRepository;

    @Override
    public void create(Vault vault) {
        //
        VaultJpo vaultJpo = new VaultJpo(vault);
        vaultRepository.save(vaultJpo);
    }

    @Override
    public Vault retrieve(String id) {
        //
        Optional<VaultJpo> vaultJpo = vaultRepository.findById(id);
        if (!vaultJpo.isPresent()) {
            return null;
        }

        return vaultJpo.get().toDomain();
    }

//    @Override
//    public Vault retrieveByOrgKey(String orgKey) {
//        //
//        Optional<VaultJpo> vaultJpo = vaultRepository.findByOrgKey(orgKey);
//        if (!vaultJpo.isPresent()) {
//            return null;
//        }
//
//        return vaultJpo.get().toDomain();
//    }

    @Override
    public List<Vault> retrieveAll(int offset, int limit) {
        //
        int size = limit > 0 ? limit : 10;
        int page = (offset / size);
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "time");
        Page<VaultJpo> vaultJpoPage = vaultRepository.findAll(pageable);

        return vaultJpoPage.stream().map(VaultJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(Vault vault) {
        //
        VaultJpo vaultJpo = new VaultJpo(vault);
        vaultRepository.save(vaultJpo);
    }

    @Override
    public void delete(Vault vault) {
        //
        String id = vault.getId();
        vaultRepository.deleteById(id);
    }

    @Override
    public boolean existsById(String id) {
        //
        return vaultRepository.existsById(id);
    }

//    @Override
//    public boolean existsByOrgKey(String orgKey) {
//        //
//        return vaultRepository.existsByOrgKey(orgKey);
//    }
}
