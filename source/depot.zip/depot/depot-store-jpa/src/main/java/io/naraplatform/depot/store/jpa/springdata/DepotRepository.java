package io.naraplatform.depot.store.jpa.springdata;

import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.store.jpa.jpo.DepotJpo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface DepotRepository extends PagingAndSortingRepository<DepotJpo, String>, JpaSpecificationExecutor<DepotJpo> {
    //
    Optional<DepotJpo> findByTicketIdAndType(String ticketId, DepotType type);
    boolean existsByTicketIdAndType(String ticketId, DepotType type);
}
