package io.naraplatform.depot.store.jpa.springdata;

import io.naraplatform.depot.store.jpa.jpo.VaultFileJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface VaultFileRepository extends PagingAndSortingRepository<VaultFileJpo, String> {
    //
    List<VaultFileJpo> findByVaultId(String vaultId, Pageable pageable);
    void deleteByIdIn(List<String> ids);
}
