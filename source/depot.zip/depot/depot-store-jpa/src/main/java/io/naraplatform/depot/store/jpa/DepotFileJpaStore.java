package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.store.DepotFileStore;
import io.naraplatform.depot.store.jpa.jpo.DepotFileJpo;
import io.naraplatform.depot.store.jpa.springdata.DepotFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository("depotFileStore")
public class DepotFileJpaStore implements DepotFileStore {
    //
    @Autowired
    private DepotFileRepository depotFileRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No DepotFile[%s] to retrieve.";

    @Override
    public void create(DepotFile depotFile) {
        //
        DepotFileJpo depotFileJpo = new DepotFileJpo(depotFile);
        depotFileRepository.save(depotFileJpo);
    }

    @Override
    public void create(List<DepotFile> depotFiles) {
        //
        List<DepotFileJpo> depotFileJpos = depotFiles.stream().map(DepotFileJpo::new).collect(Collectors.toList());
        depotFileRepository.saveAll(depotFileJpos);
    }

    @Override
    public DepotFile retrieve(String id) {
        //
        Optional<DepotFileJpo> depotFileJpo = depotFileRepository.findById(id);
        if (!depotFileJpo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, id));
        }

        return depotFileJpo.get().toDomain();
    }

    @Override
    public List<DepotFile> retrieveByVaultFileId(String vaultFileId) {
        //
        List<DepotFileJpo> depotFileJpos = depotFileRepository.findByVaultFileId(vaultFileId);

        return depotFileJpos.stream().map(DepotFileJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<DepotFile> retrieveByDepotId(String depotId) {
        //
        Pageable pageable = PageRequest.of(0, Integer.MAX_VALUE, Sort.Direction.ASC, "sequence");
        List<DepotFileJpo> depotFileJpos = depotFileRepository.findByDepotId(depotId, pageable);

        return depotFileJpos.stream().map(DepotFileJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<DepotFile> retrieveByDepotId(String depotId, int offset, int limit) {
        //
        int size = limit > 0 ? limit : 10;
        int page = (offset / size);
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "creationTime");
        List<DepotFileJpo> depotFileJpos =  depotFileRepository.findByDepotId(depotId, pageable);

        return depotFileJpos.stream().map(DepotFileJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(DepotFile depotFile) {
        //
        DepotFileJpo depotFileJpo = new DepotFileJpo(depotFile);
        depotFileRepository.save(depotFileJpo);
    }

    @Override
    public void update(List<DepotFile> depotFiles) {
        //
        List<DepotFileJpo> depotFileJpos = depotFiles.stream().map(DepotFileJpo::new).collect(Collectors.toList());
        depotFileRepository.saveAll(depotFileJpos);
    }

    @Override
    public void delete(DepotFile depotFile) {
        //
        String id = depotFile.getId();
        depotFileRepository.deleteById(id);
    }

    @Override
    public void delete(List<String> depotFileIds) {
        //
        depotFileRepository.deleteByIdIn(depotFileIds);
    }

    @Override
    public void deleteAllInDepot(String depotId) {
        //
        depotFileRepository.deleteByDepotId(depotId);
    }

    @Override
    public int countAllInDepot(String depotId) {
        //
        return depotFileRepository.countByDepotId(depotId);
    }
}
