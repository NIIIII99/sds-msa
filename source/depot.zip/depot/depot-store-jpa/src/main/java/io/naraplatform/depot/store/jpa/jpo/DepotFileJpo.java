package io.naraplatform.depot.store.jpa.jpo;

import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity(name = "DEPOT_FILE")
@Table(indexes = {
    @Index(name = "IF_DEPOTFILE_VAULTFILEID", unique = false, columnList = "VAULT_FILE_ID"),
    @Index(name = "IF_DEPOTFILE_DEPOTID", unique = false, columnList = "DEPOT_ID")
})
public class DepotFileJpo implements JsonSerializable {
    //
    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "SEQUENCE")
    private int sequence;

    @Column(name = "TARGET_VERSION")
    private long targetVersion;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SIZE")
    private long size;

    @Column(name = "CREATION_TIME")
    private long creationTime;

    @Column(name = "REGISTRATION_TIME")
    private long registrationTime;

    @Column(name = "VAULT_FILE_ID", nullable = false)
    private String vaultFileId;

    @Column(name = "DEPOT_ID", nullable = false)
    private String depotId;

    public DepotFileJpo(DepotFile depotFile) {
        //
        BeanUtils.copyProperties(depotFile, this);
    }

    public DepotFile toDomain() {
        //
        DepotFile depotFile = new DepotFile(id);
        BeanUtils.copyProperties(this, depotFile);

        return depotFile;
    }

    public String toString() {
        //
        return toJson();
    }

    public static DepotFileJpo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotFileJpo.class);
    }

    public static DepotFileJpo sample() {
        //
        return new DepotFileJpo(DepotFile.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
