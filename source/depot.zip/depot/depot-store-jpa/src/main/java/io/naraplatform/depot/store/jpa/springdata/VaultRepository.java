package io.naraplatform.depot.store.jpa.springdata;

import io.naraplatform.depot.store.jpa.jpo.VaultJpo;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface VaultRepository extends PagingAndSortingRepository<VaultJpo, String> {
    //
//    Optional<VaultJpo> findByOrgKey(String orgKey);
//    boolean existsByOrgKey(String orgKey);
}
