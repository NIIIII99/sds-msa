package io.naraplatform.depot.store.jpa.util;


import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class QueryUtil {
    //
    public QueryUtil() {
    }

    public static <T, U> Specification<T> equal(final String key, final Object value, Class<U> paramType) {
        //
        return new Specification<T>() {
            @Override
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder cb) {
                return cb.equal(root.get(key), value);
            }
        };
    }

    public static <T> Specification<T> like(final String key, final String value) {
        //
        return new Specification<T>() {
            @Override
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder cb) {
                return cb.like(cb.upper(root.get(key)), "%" + value.toUpperCase() + "%");
            }
        };
    }
}
