package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.store.DepotStore;
import io.naraplatform.depot.store.jpa.jpo.DepotJpo;
import io.naraplatform.depot.store.jpa.util.QueryUtil;
import io.naraplatform.depot.store.jpa.springdata.DepotFileRepository;
import io.naraplatform.depot.store.jpa.springdata.DepotRepository;
import io.naraplatform.share.util.string.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository("depotStore")
public class DepotJpaStore implements DepotStore {
    //
    @Autowired
    private DepotRepository depotRepository;

    @Autowired
    private DepotFileRepository depotFileRepository;

    @Override
    public void create(Depot depot) {
        //
        DepotJpo depotJpo = new DepotJpo(depot);
        depotRepository.save(depotJpo);
    }

    @Override
    public Depot retrieve(String id) {
        //
        Optional<DepotJpo> depotJpo = depotRepository.findById(id);
        if(!depotJpo.isPresent()) {
            return null;
        }

        return depotJpo.get().toDomain();
    }

    @Override
    public List<Depot> retrieve(List<String> depotIds) {
        //
        List<DepotJpo> depotJpos = (List<DepotJpo>)depotRepository.findAllById(depotIds);

        return depotJpos.stream().map(DepotJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<Depot> retrieveAll(int offset, int limit) {
        //
        int size = limit > 0 ? limit : 10;
        int page = (offset / size);
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "time");
        Page<DepotJpo> depotJpos = depotRepository.findAll(pageable);

        return depotJpos.getContent().stream().map(DepotJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<Depot> retrieve(String vaultId, DepotType type, String title) {
        //
        Specification<DepotJpo> specification = Specification.where(QueryUtil.equal("type", type, DepotType.class));
        if (type != DepotType.FileBox) {    // not org scope
            specification = specification.and(QueryUtil.equal("vaultId", vaultId, String.class));
        }
        if(!StringUtil.isBlank(title)) {
            specification = specification.and(QueryUtil.like("title", title));
        }

        List<DepotJpo> depotJpos = depotRepository.findAll(specification, Sort.by(Sort.Direction.ASC, "title"));

        return depotJpos.stream().map(DepotJpo::toDomain).collect(Collectors.toList());
    }

    @Override
    public Depot retrieve(String ticketId, DepotType type) {
        //
        Optional<DepotJpo> depotJpo = depotRepository.findByTicketIdAndType(ticketId, type);
        if(!depotJpo.isPresent()) {
            return null;
        }

        return depotJpo.get().toDomain();
    }

    @Override
    public Depot retrievePersonalDrive(String ticketId) {
        //
        Optional<DepotJpo> depotJpo = depotRepository.findByTicketIdAndType(ticketId, DepotType.PersonalDrive);
        if(!depotJpo.isPresent()) {
            return null;
        }

        return depotJpo.get().toDomain();
    }

    @Override
    public Depot retrieveTeamDrive(String ticketId) {
        Optional<DepotJpo> depotJpo = depotRepository.findByTicketIdAndType(ticketId, DepotType.TeamDrive);
        if(!depotJpo.isPresent()) {
            return null;
        }

        return depotJpo.get().toDomain();
    }

    @Override
    public void update(Depot depot) {
        //
        DepotJpo depotJpo = new DepotJpo(depot);
        depotRepository.save(depotJpo);
    }

    @Override
    public void delete(Depot depot) {
        //
        String id = depot.getId();
        depotRepository.deleteById(id);
    }

    @Override
    public boolean existsPersonalDrive(String ticketId) {
        //
        return depotRepository.existsByTicketIdAndType(ticketId, DepotType.PersonalDrive);
    }

    @Override
    public boolean existsTeamDrive(String ticketId) {
        //
        return depotRepository.existsByTicketIdAndType(ticketId, DepotType.TeamDrive);
    }

    @Override
    public boolean hasAnyDepotFile(String depotId) {
        //
        int count = depotFileRepository.countByDepotId(depotId);

        return count > 0;
    }
}
