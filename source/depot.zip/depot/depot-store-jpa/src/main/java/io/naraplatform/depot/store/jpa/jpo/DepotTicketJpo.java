package io.naraplatform.depot.store.jpa.jpo;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.BeanUtils;

import javax.persistence.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity(name = "DEPOT_TICKET")
public class DepotTicketJpo implements JsonSerializable {
    //
    @Id
    @Column(name = "ID", nullable = false)
    private String id;

    @Column(name = "USER_JSON", nullable = false)
    @Lob
    private String userJson;

    @Column(name = "SERVICE_ID")
    private String serviceId;

    @Column(name = "ORG_ID")
    private String orgId;

    @Column(name = "TEAM_ID")
    private String teamId;

    @Column(name = "USER_ID")
    private String userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "SCOPE", nullable = false)
    private ServiceScope scope;

    @Column(name = "TIME")
    private long time;

    public DepotTicketJpo(DepotTicket depotTicket) {
        //
        this.id = depotTicket.getId();
        this.userJson = JsonUtil.toJson(depotTicket.getUser());
        this.scope = depotTicket.getScope();
        this.time = depotTicket.getTime();

        ServiceUser user = depotTicket.getUser();
        this.serviceId = user.getService().getId();

        if (user.getOrg() != null) {
            this.orgId = user.getOrg().getId();
        }
        if (user.getTeam() != null) {
            this.teamId = user.getTeam().getId();
        }
        if (user.getUser() != null) {
            this.userId = user.getUser().getId();
        }
    }

    public DepotTicket toDomain() {
        //
        DepotTicket depotTicket = new DepotTicket(id);
        BeanUtils.copyProperties(this, depotTicket);
        depotTicket.setUser(JsonUtil.fromJson(userJson, ServiceUser.class));

        return depotTicket;
    }

    public String toString() {
        //
        return toJson();
    }

    public static DepotTicketJpo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotTicketJpo.class);
    }

    public static DepotTicketJpo sample() {
        //
        return new DepotTicketJpo(DepotTicket.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
