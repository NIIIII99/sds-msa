package io.naraplatform.depot.store.jpa.springdata;

import io.naraplatform.depot.store.jpa.jpo.DepotFileJpo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface DepotFileRepository extends PagingAndSortingRepository<DepotFileJpo, String> {
    //
    List<DepotFileJpo> findByVaultFileId(String vaultFileId);
    List<DepotFileJpo> findByDepotId(String depotId);
    List<DepotFileJpo> findByDepotId(String depotId, Pageable pageable);
    void deleteByIdIn(List<String> ids);
    void deleteByDepotId(String depotId);
    int countByDepotId(String depotId);
}
