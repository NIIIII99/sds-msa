package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.store.DepotFileStore;
import io.naraplatform.depot.domain.store.DepotStore;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DepotStoreTestApplication.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DepotJpaStoreTest {

    @Autowired
    private DepotStore depotStore;
    @Autowired
    private DepotFileStore depotFileStore;

    private Depot sample1;
    private Depot sample2;
    private String sampleId1;
    private String sampleId2;

    @Before
    public void setUp() throws Exception {
        //
        sample1 = Depot.sample();
        sampleId1 = sample1.getId();
        sample1.setType(DepotType.PersonalDrive);
        depotStore.create(sample1);

        sample2 = Depot.sample();
        sampleId2 = sample2.getId();
        sample2.setType(DepotType.TeamDrive);
        depotStore.create(sample2);
    }

    @After
    public void tearDown() throws Exception {
        //
    }

    @Test
    public void testRetrieve() {
        //
        Depot result = depotStore.retrieve(sampleId1);
        assertEquals(sample1.getId(), result.getId());
        assertEquals(sample1.getType(), result.getType());
        assertEquals(sample1.getTicketId(), result.getTicketId());
        assertEquals(sample1.getTitle(), result.getTitle());
        assertEquals(sample1.getCurrentSequence(), result.getCurrentSequence());
        assertEquals(sample1.getClient().toJson(), result.getClient().toJson());
        assertEquals(sample1.getConfig().toJson(), result.getConfig().toJson());
        assertEquals(sample1.getTime(), result.getTime());
        assertEquals(sample1.getRepDepotFileId(), result.getRepDepotFileId());
        assertEquals(sample1.getVaultId(), result.getVaultId());
    }

    @Test
    public void testRetrieveLIst() {
        //
        depotStore.create(Depot.sample());
        List<String> ids = Arrays.asList(sampleId1, sampleId2);
        List<Depot> depots = depotStore.retrieve(ids);

        assertNotNull(depots);
        assertSame(2, depots.size());
    }

    @Test
    public void testRetrieveAll() {
        //
        depotStore.create(Depot.sample());
        depotStore.create(Depot.sample());
        depotStore.create(Depot.sample());
        depotStore.create(Depot.sample());
        depotStore.create(Depot.sample());
        depotStore.create(Depot.sample());

        List<Depot> containers = depotStore.retrieveAll(0, 3);
        assertNotNull(containers);
        assertSame(3, containers.size());

        containers = depotStore.retrieveAll(3, 3);
        assertNotNull(containers);
        assertSame(3, containers.size());

        containers = depotStore.retrieveAll(6, 3);
        assertNotNull(containers);
        assertSame(2, containers.size());
    }

    @Test
    public void testRetrievePersonalDrive() {
        //
        //String userId = sample1.getOwner().getUser().getId();
        String ticketId = sample1.getTicketId();
        Depot result = depotStore.retrievePersonalDrive(ticketId);
        assertEquals(sample1.getId(), result.getId());

        result = depotStore.retrievePersonalDrive("NotExistedId");
        assertNull(result);
    }

    @Test
    public void testRetrieveTeamDrive() {
        //
        String ticketId = sample2.getTicketId();
        Depot result = depotStore.retrieveTeamDrive(ticketId);
        assertEquals(sample2.getId(), result.getId());

        result = depotStore.retrieveTeamDrive("NotExistedId");
        assertNull(result);
    }

    @Test
    public void testRetrieveByTicketIdAndType() {
        //
        Depot sample3 = Depot.sample();
        sample3.setType(DepotType.TinyAlbum);

        Depot result1 = depotStore.retrieve(sample3.getTicketId(), sample3.getType());
        assertNull(result1);
        depotStore.create(sample3);
        Depot result2 = depotStore.retrieve(sample3.getTicketId(), sample3.getType());
        assertNotNull(result2);
    }

    @Test
    public void testRetrieveByVaultIdAndTypeAndTitle() {
        //
        List<Depot> result1 = depotStore.retrieve(sample1.getVaultId(), sample1.getType(), sample1.getTitle());
        assertSame(1, result1.size());

        Depot sample3 = Depot.sample();
        sample3.setType(sample1.getType());
        sample3.setVaultId(sample1.getVaultId());
        sample3.setTitle("test");
        depotStore.create(sample3);

        List<Depot> result2 = depotStore.retrieve(sample1.getVaultId(), sample1.getType(), sample1.getTitle());
        assertSame(1, result2.size());

        List<Depot> result3 = depotStore.retrieve(sample1.getVaultId(), sample1.getType(), "");
        assertSame(2, result3.size());
    }

    @Test
    public void testUpdate() {
        //
        String title = "chagned" + sample1.getTitle();
        Depot depot = depotStore.retrieve(sampleId1);
        depot.setTitle(title);
        depot.setRepDepotFileId("changePrimaryFileId");

        depotStore.update(depot);

        Depot result = depotStore.retrieve(sampleId1);
        assertEquals(sample1.getId(), result.getId());
        assertNotEquals(sample1.getTitle(), result.getTitle());
        assertNotEquals(sample1.getRepDepotFileId(), result.getRepDepotFileId());
        assertEquals(depot.getTitle(), result.getTitle());
        assertEquals(depot.getRepDepotFileId(), result.getRepDepotFileId());
    }

    @Test
    public void testDelete() {
        //
        assertEquals(DepotType.PersonalDrive, sample1.getType());
        String userTicketId = sample1.getTicketId();
        boolean exist = depotStore.existsPersonalDrive(userTicketId);
        assertTrue(exist);

        Depot personalDrive = depotStore.retrievePersonalDrive(userTicketId);
        depotStore.delete(personalDrive);
        exist = depotStore.existsPersonalDrive(userTicketId);
        assertFalse(exist);

        assertEquals(DepotType.TeamDrive, sample2.getType());
        String teamTicketId = sample2.getTicketId();
        exist = depotStore.existsTeamDrive(teamTicketId);
        assertTrue(exist);

        Depot teamDrive = depotStore.retrieveTeamDrive(teamTicketId);
        depotStore.delete(teamDrive);
        exist = depotStore.existsTeamDrive(teamTicketId);
        assertFalse(exist);
    }

    @Test
    public void testHasAnyDepotFile() {
        //
        String containerId = sample1.getId();
        boolean exist = depotStore.hasAnyDepotFile(containerId);
        assertFalse(exist);

        DepotFile depotFile = DepotFile.sample();
        depotFile.setDepotId(containerId);
        depotFileStore.create(depotFile);

        exist = depotStore.hasAnyDepotFile(containerId);
        assertTrue(exist);
    }
}
