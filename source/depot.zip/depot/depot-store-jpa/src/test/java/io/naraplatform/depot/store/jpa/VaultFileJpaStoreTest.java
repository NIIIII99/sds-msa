package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.store.VaultFileStore;
import io.naraplatform.share.exception.store.AlreadyExistsException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DepotStoreTestApplication.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class VaultFileJpaStoreTest {

    @Autowired
    private VaultFileStore vaultFileStore;

    private String sampleId1;
    private String sampleId2;
    private VaultFile sample1;

    @Before
    public void setUp() throws Exception {
        //
        VaultFile vaultFile1 = VaultFile.sample();
        sampleId1 = vaultFile1.getId();
        vaultFileStore.create(vaultFile1);
        System.out.println("[TEST INFO] vaultFile create => ID : " + sampleId1);

        sample1 = vaultFile1;

        VaultFile vaultFile2 = VaultFile.sample();
        vaultFile2.setVaultId(sample1.getVaultId());
        sampleId2 = vaultFile2.getId();
        vaultFileStore.create(vaultFile2);
        System.out.println("[TEST INFO] vaultFile create => ID : " + sampleId2);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testCreateList() {
        //
        List<VaultFile> newVaultFiles = new ArrayList<>();
        newVaultFiles.add(VaultFile.sample());
        newVaultFiles.add(VaultFile.sample());

        try {
            vaultFileStore.create(newVaultFiles);
            assertTrue(true);
        } catch (AlreadyExistsException e) {
            assertTrue(false);
        }
    }

    @Test
    public void testRetrieveOne() {
        //
        VaultFile result = vaultFileStore.retrieve(sampleId1);
        assertEquals(sample1.getId(), result.getId());
        assertEquals(sample1.getVersion(), result.getVersion());
        assertEquals(sample1.getPath(), result.getPath());
        assertEquals(sample1.getName(), result.getName());
        assertEquals(sample1.getOwnerName(), result.getOwnerName());
        assertEquals(sample1.getCreationTime(), result.getCreationTime());
        assertEquals(sample1.getVersionParts().size(), result.getVersionParts().size());
        assertEquals(sample1.getVersionParts().get(0).getSize(), result.getVersionParts().get(0).getSize());
        assertEquals(sample1.getVersionParts().get(0).getRegistrationTime(), result.getVersionParts().get(0).getRegistrationTime());
        assertEquals(sample1.isEncrypted(), result.isEncrypted());
        assertEquals(sample1.getTotalReferenceCount(), result.getTotalReferenceCount());
        assertEquals(sample1.getVaultId(), result.getVaultId());
    }

    @Test
    public void testRetrieveNotExistedOne() {
        //
        try {
            vaultFileStore.retrieve("NoneId");
            assertTrue(false);
        } catch (NoSuchElementException e) {
            assertTrue(true);
        }
    }

    @Test
    public void testRetrieveLIst() {
        //
        vaultFileStore.create(VaultFile.sample());
        List<String> ids = Arrays.asList(sampleId1, sampleId2);
        List<VaultFile> vaultFiles = vaultFileStore.retrieve(ids);

        assertNotNull(vaultFiles);
        assertSame(2, vaultFiles.size());
    }

    @Test
    public void testRetrieveByVaultId() {
        //
        List<VaultFile> samples = new ArrayList<>();
        VaultFile changedSample = VaultFile.sample();
        changedSample.setVaultId("changedVaultId");
        List<VaultFile> samplesPart = Arrays.asList(VaultFile.sample(), VaultFile.sample(), VaultFile.sample(),VaultFile.sample(), VaultFile.sample(), VaultFile.sample());
        samplesPart = samplesPart.stream().map(vaultFile->{vaultFile.setVaultId(sample1.getVaultId());return vaultFile;}).collect(Collectors.toList());
        samples.add(changedSample);
        samples.addAll(samplesPart);
        vaultFileStore.create(samples);

        String vaultId = sample1.getVaultId();
        List<VaultFile> vaultFiles = vaultFileStore.retrieveByVaultId(vaultId, 0, 3);
        assertNotNull(vaultFiles);
        assertSame(3, vaultFiles.size());

        vaultFiles = vaultFileStore.retrieveByVaultId(vaultId, 3, 3);
        assertNotNull(vaultFiles);
        assertSame(3, vaultFiles.size());

        vaultFiles = vaultFileStore.retrieveByVaultId(vaultId, 6, 3);
        assertNotNull(vaultFiles);
        assertSame(2, vaultFiles.size());
    }

    @Test
    public void testUpdate() {
        //
        VaultFile vaultFile = vaultFileStore.retrieve(sampleId1);
        vaultFile.increaseVersion();
        vaultFile.increaseReferenceCount();
        vaultFile.getVersionParts().get(0).setSize(vaultFile.getVersionParts().get(0).getSize() + 1000L);

        vaultFileStore.update(vaultFile);
        VaultFile result = vaultFileStore.retrieve(sampleId1);

        assertEquals(vaultFile.getVersion(), result.getVersion());
        assertSame(vaultFile.getTotalReferenceCount(), result.getTotalReferenceCount());
        assertEquals(vaultFile.getVersionParts().get(0).getSize(), result.getVersionParts().get(0).getSize());
    }

    @Test
    public void testUpdateMultiple() {
        //
        VaultFile vaultFile3 = VaultFile.sample();
        vaultFile3.setVaultId(sample1.getVaultId());
        vaultFileStore.create(vaultFile3);

        String vaultId = sample1.getVaultId();
        long newSize = sample1.getVersionParts().get(0).getSize() + 1000L;
        List<VaultFile> vaultFiles = vaultFileStore.retrieveByVaultId(vaultId, 0, Integer.MAX_VALUE);

        vaultFiles = vaultFiles.stream().map(vaultFile -> {
            vaultFile.getVersionParts().get(0).setSize(newSize);
            vaultFile.increaseReferenceCount();
            return vaultFile;
        }).collect(Collectors.toList());

        vaultFileStore.update(vaultFiles);

        List<VaultFile> results = vaultFileStore.retrieveByVaultId(vaultId, 0, Integer.MAX_VALUE);
        boolean allMatch = results.stream().allMatch(depotFile -> (depotFile.getVersionParts().get(0).getSize() == newSize));
        assertTrue(allMatch);
    }

    @Test
    public void testDeleteOne() {
        //
        vaultFileStore.delete(sample1);

        try {
            vaultFileStore.retrieve(sampleId1);
            assertTrue(false);
        } catch (NoSuchElementException e) {
            assertTrue(true);
        }
    }

    @Test
    @Transactional
    public void testDeleteMultiple() {
        //
        List<String> ids = Arrays.asList(sampleId1, sampleId2);

        List<VaultFile> before = vaultFileStore.retrieve(ids);
        assertSame(2, before.size());

        vaultFileStore.delete(ids);

        List<VaultFile> after = vaultFileStore.retrieve(ids);
        assertSame(0, after.size());
    }
}
