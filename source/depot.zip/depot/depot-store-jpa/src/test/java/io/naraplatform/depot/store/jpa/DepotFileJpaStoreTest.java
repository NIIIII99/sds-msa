package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.store.DepotFileStore;
import io.naraplatform.share.util.json.JsonUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DepotStoreTestApplication.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DepotFileJpaStoreTest {

    @Autowired
    private DepotFileStore depotFileStore;

    private DepotFile sample1;
    private String sampleId1;

    @Before
    public void setUp() throws Exception {
        //
        sample1 = DepotFile.sample();
        sampleId1 = sample1.getId();
        depotFileStore.create(sample1);

        DepotFile sample2 = DepotFile.sample();
        depotFileStore.create(sample2);

        DepotFile sample3 = DepotFile.sample();
        sample3.setVaultFileId(sample1.getVaultFileId());
        depotFileStore.create(sample3);

        DepotFile sample4 = DepotFile.sample();
        sample4.setDepotId(sample1.getDepotId());
        depotFileStore.create(sample4);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testCreateMultiple() {
        //
        String depotId = sample1.getDepotId();

        int beforeCount = depotFileStore.countAllInDepot(depotId);

        DepotFile sample5 = DepotFile.sample();
        sample5.setDepotId(depotId);
        DepotFile sample6 = DepotFile.sample();
        sample6.setDepotId(depotId);
        DepotFile sample7 = DepotFile.sample();
        sample7.setDepotId(depotId);
        DepotFile sample8 = DepotFile.sample();
        sample8.setDepotId(depotId);
        List<DepotFile> depotFiles = Arrays.asList(sample5, sample6, sample7, sample8);
        depotFileStore.create(depotFiles);

        int afterCount = depotFileStore.countAllInDepot(depotId);
        assertSame( beforeCount+4, afterCount );
    }

    @Test
    public void testRetrieve() {
        //
        DepotFile result = depotFileStore.retrieve(sampleId1);

        assertEquals(sample1.getId(), result.getId());
        assertEquals(sample1.getSequence(), result.getSequence());
        assertEquals(sample1.getTargetVersion(), result.getTargetVersion());
        assertEquals(sample1.getName(), result.getName());
        assertEquals(sample1.getSize(), result.getSize());
        assertEquals(sample1.getCreationTime(), result.getCreationTime());
        assertEquals(sample1.getRegistrationTime(), result.getRegistrationTime());
        assertEquals(sample1.getVaultFileId(), result.getVaultFileId());
        assertEquals(sample1.getDepotId(), result.getDepotId());
    }

    @Test
    public void testRetrieveByVaultFileId() {
        //
        String vaultFileId = sample1.getVaultFileId();
        List<DepotFile> results = depotFileStore.retrieveByVaultFileId(vaultFileId);
        assertSame(2, results.size());
    }

    @Test
    public void testRetrieveByDepotId() {
        //
        String depotId = sample1.getDepotId();
        List<DepotFile> results = depotFileStore.retrieveByDepotId(depotId);
        assertSame(2, results.size());
    }

    @Test
    public void testRetrieveByDepotIdWithPage() {
        //
        String depotId = sample1.getDepotId();
        DepotFile sample5 = DepotFile.sample();
        sample5.setDepotId(depotId);
        DepotFile sample6 = DepotFile.sample();
        sample6.setDepotId(depotId);
        DepotFile sample7 = DepotFile.sample();
        sample7.setDepotId(depotId);
        DepotFile sample8 = DepotFile.sample();
        sample8.setDepotId(depotId);
        DepotFile sample9 = DepotFile.sample();
        sample9.setDepotId(depotId);
        DepotFile sample10 = DepotFile.sample();
        sample10.setDepotId(depotId);
        List<DepotFile> depotFiles = Arrays.asList(sample5, sample6, sample7, sample8, sample9, sample10);
        depotFileStore.create(depotFiles);

        List<DepotFile> results = depotFileStore.retrieveByDepotId(depotId, 0, 3);
        assertNotNull(results);
        assertSame(3, results.size());

        results = depotFileStore.retrieveByDepotId(depotId, 3, 3);
        assertNotNull(results);
        assertSame(3, results.size());

        results = depotFileStore.retrieveByDepotId(depotId, 6, 3);
        assertNotNull(results);
        assertSame(2, results.size());

        results = depotFileStore.retrieveByDepotId(UUID.randomUUID().toString(), 0, Integer.MAX_VALUE);
        assertNotNull(results);
        assertSame(0, results.size());
    }

    @Test
    public void testUpdate() {
        //
        DepotFile depotFile = depotFileStore.retrieve(sampleId1);
        depotFile.setName( "changed"+ depotFile.getName());
        depotFile.setSize(depotFile.getSize() + 1000L);
        //depotFile.setTags(Arrays.asList("태그","테스트"));

        depotFileStore.update(depotFile);
        DepotFile result = depotFileStore.retrieve(sampleId1);

        assertNotEquals(sample1.getName(), result.getName());
        assertNotEquals(sample1.getSize(), result.getSize());
    }

    @Test
    public void testUpdateMultiple() {
        //
        String vaultFileId = sample1.getVaultFileId();
        long newSize = sample1.getSize() + 1000L;
        List<DepotFile> depotFiles = depotFileStore.retrieveByVaultFileId(vaultFileId);

        depotFiles = depotFiles.stream().map(depotFile -> {
            depotFile.setSize(newSize);
            return depotFile;
        }).collect(Collectors.toList());

        depotFileStore.update(depotFiles);

        List<DepotFile> results = depotFileStore.retrieveByVaultFileId(vaultFileId);
        boolean allMatch = results.stream().allMatch(depotFile -> (depotFile.getSize() == newSize));
        assertTrue(allMatch);
    }

    @Test
    public void testDelete() {
        //
        DepotFile before = depotFileStore.retrieve(sampleId1);
        assertNotNull(before);

        depotFileStore.delete(sample1);

        try {
            DepotFile after = depotFileStore.retrieve(sampleId1);
            assertTrue(false);
        } catch (NoSuchElementException e) {
            assertTrue(true);
        }
    }

    @Test
    @Transactional
    public void testDeleteMultiple() {
        //
        String vaultFileId = sample1.getVaultFileId();
        List<DepotFile> depotFiles = depotFileStore.retrieveByVaultFileId(vaultFileId);
        assertTrue(depotFiles.size() > 0);

        List<String> idList = depotFiles.stream().map(DepotFile::getId).collect(Collectors.toList());
        depotFileStore.delete(idList);

        List<DepotFile> results = depotFileStore.retrieveByVaultFileId(vaultFileId);
        assertSame( 0, results.size() );
    }

    @Test
    @Transactional
    public void deleteAllInDepot() {
        //
        String depotId = sample1.getDepotId();

        int count = depotFileStore.countAllInDepot(depotId);
        assertTrue( 0 < count );

        depotFileStore.deleteAllInDepot(depotId);

        count = depotFileStore.countAllInDepot(depotId);
        assertSame(0, count);
    }
}
