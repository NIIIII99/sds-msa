package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.vault.VaultType;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.store.VaultStore;
import io.naraplatform.depot.store.jpa.jpo.VaultJpo;
import io.naraplatform.share.util.string.StringUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DepotStoreTestApplication.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class VaultJpaStoreTest {

    @Autowired
    private VaultStore vaultStore;

    private String sampleId1;
    private Vault sample1;
    private Vault sample2;

    @Before
    public void setUp() throws Exception {
        //
        sample1 = Vault.sample();
        sampleId1 = sample1.getId();
        vaultStore.create(sample1);

        sample2 = this.getVaultSample("조직2");
        vaultStore.create(sample2);
    }

    @After
    public void tearDown() throws Exception {
    }


    @Test
    public void testRetrieve() {
        //
        Vault result = vaultStore.retrieve(sampleId1);
        assertEquals(sample1.getId(), result.getId());
        assertEquals(sample1.getOrgName(), result.getOrgName());
        assertEquals(sample1.getRootPath(), result.getRootPath());
        assertEquals(sample1.getVaultType(), result.getVaultType());
        assertEquals(sample1.getTime(), result.getTime());
    }

    @Test
    public void testRetrieveAll() {
        //
        vaultStore.create(this.getVaultSample("조직3"));
        vaultStore.create(this.getVaultSample("조직4"));
        vaultStore.create(this.getVaultSample("조직5"));
        vaultStore.create(this.getVaultSample("조직6"));
        vaultStore.create(this.getVaultSample("조직7"));
        vaultStore.create(this.getVaultSample("조직8"));

        List<Vault> vaults = vaultStore.retrieveAll(0, 3);
        assertNotNull(vaults);
        assertSame(3, vaults.size());

        vaults = vaultStore.retrieveAll(3, 3);
        assertNotNull(vaults);
        assertSame(3, vaults.size());

        vaults = vaultStore.retrieveAll(6, 3);
        assertNotNull(vaults);
        assertSame(2, vaults.size());
    }

    @Test
    public void tsetUpdate() {
        //
        Vault vault = vaultStore.retrieve(sampleId1);
        vault.setOrgName( "changed"+sample1.getOrgName() );
        vault.setRootPath( "changed"+sample1.getRootPath() );
        vault.setVaultType( VaultType.AmazonS3 );
        assertNotEquals(sample1.getVaultType(), VaultType.AmazonS3);

        vaultStore.update(vault);
        Vault result = vaultStore.retrieve(sampleId1);

        assertEquals(sample1.getId(), result.getId());
        assertNotEquals(sample1.getOrgName(), result.getOrgName());
        assertNotEquals(sample1.getRootPath(), result.getRootPath());
        assertNotEquals(sample1.getVaultType(), result.getVaultType());
    }

    @Test
    public void testDelete() {
        //
        String id = sample1.getId();

        Vault beforeVault = vaultStore.retrieve(id);
        assertNotNull(beforeVault);

        boolean exist = vaultStore.existsById(id);
        assertTrue(exist);

        vaultStore.delete(beforeVault);

        Vault afterVault = vaultStore.retrieve(id);
        assertNull(afterVault);

        exist = vaultStore.existsById(id);
        assertFalse(exist);
    }

    private Vault getVaultSample(String orgKey) {
        //
        Vault sample = Vault.sample();
        VaultJpo sampleJpo = new VaultJpo(sample);
        if (!StringUtil.isEmpty(orgKey)) {
            sampleJpo.setId(orgKey);
            sample = sampleJpo.toDomain();
        } else {
            sample = sampleJpo.toDomain();
        }

        return sample;
    }
}
