package io.naraplatform.depot.store.jpa;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepotStoreTestApplication {
}
