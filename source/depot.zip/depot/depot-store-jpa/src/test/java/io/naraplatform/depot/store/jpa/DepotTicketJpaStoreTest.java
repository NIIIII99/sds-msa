package io.naraplatform.depot.store.jpa;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.store.DepotTicketStore;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.exception.store.NaraStoreException;
import io.naraplatform.share.util.json.JsonUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = DepotStoreTestApplication.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DepotTicketJpaStoreTest {

    @Autowired
    private DepotTicketStore depotTicketStore;

    private DepotTicket sample1;
    private String sampleId1;

    @Before
    public void setUp() throws Exception {
        //
        sample1 = DepotTicket.sample();
        sampleId1 = sample1.getId();
        depotTicketStore.create(sample1);

        DepotTicket sample2 = DepotTicket.sample();
        sample2.getUser().setService( sample1.getUser().getService() );
        sample2.getUser().setOrg( sample1.getUser().getOrg() );
        depotTicketStore.create(sample2);

        DepotTicket sample3 = DepotTicket.sample();
        sample3.getUser().setService( sample1.getUser().getService() );
        depotTicketStore.create(sample3);

        DepotTicket sample4 = DepotTicket.sample();
        depotTicketStore.create(sample4);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testRetrieve() {
        //
        DepotTicket result = depotTicketStore.retrieve(sampleId1);
        assertEquals(sample1.getId(), result.getId());
        assertEquals(JsonUtil.toJson(sample1.getUser()), JsonUtil.toJson(result.getUser()));
        assertEquals(sample1.getScope(), result.getScope());
    }

    @Test
    public void testRetrieveServiceTicket() {
        //
        DepotTicket sample = DepotTicket.sample();
        sample.setScope(ServiceScope.Service);
        String serviceId = sample.getUser().getService().getId();
        depotTicketStore.create(sample);

        DepotTicket result = depotTicketStore.retrieveServiceTicket(serviceId);
        assertNotNull(result);
        assertEquals(serviceId, result.getUser().getService().getId());
        assertEquals(sample.getScope(), result.getScope());
    }

    @Test
    public void testRetrieveOrgTicket() {
        //
        DepotTicket sample = DepotTicket.sample();
        sample.setScope(ServiceScope.Org);
        String serviceId = sample.getUser().getService().getId();
        String orgId = sample.getUser().getOrg().getId();
        depotTicketStore.create(sample);

        DepotTicket result = depotTicketStore.retrieveOrgTicket(serviceId, orgId);
        assertNotNull(result);
        assertEquals(serviceId, result.getUser().getService().getId());
        assertEquals(orgId, result.getUser().getOrg().getId());
        assertEquals(sample.getScope(), result.getScope());
    }

    @Test
    public void testRetrieveTeamTicket() {
        //
        DepotTicket sample = DepotTicket.sample();
        sample.setScope(ServiceScope.Team);
        String serviceId = sample.getUser().getService().getId();
        String orgId = sample.getUser().getOrg().getId();
        String teamId = sample.getUser().getTeam().getId();
        depotTicketStore.create(sample);

        DepotTicket result = depotTicketStore.retrieveTeamTicket(serviceId, orgId, teamId);
        assertNotNull(result);
        assertEquals(serviceId, result.getUser().getService().getId());
        assertEquals(orgId, result.getUser().getOrg().getId());
        assertEquals(teamId, result.getUser().getTeam().getId());
        assertEquals(sample.getScope(), result.getScope());
    }

    @Test
    public void testretrieveUserTicket() {
        //
        DepotTicket sample = DepotTicket.sample();
        sample.setScope(ServiceScope.User);
        String serviceId = sample.getUser().getService().getId();
        String orgId = sample.getUser().getOrg().getId();
        String userId = sample.getUser().getUser().getId();
        depotTicketStore.create(sample);

        DepotTicket result = depotTicketStore.retrieveUserTicket(serviceId, orgId, userId);
        assertNotNull(result);
        assertEquals(serviceId, result.getUser().getService().getId());
        assertEquals(orgId, result.getUser().getOrg().getId());
        assertEquals(userId, result.getUser().getUser().getId());
        assertEquals(sample.getScope(), result.getScope());
    }

    @Test
    public void testRetrieveByServiceId() {
        //
        String serviceId = sample1.getUser().getService().getId();
        List<DepotTicket> depotTickets = depotTicketStore.retrieveByServiceId(serviceId);
        assertNotNull(depotTickets);
        assertSame(3, depotTickets.size());
    }

    @Test
    public void testRetrieveByServiceIdAndOrgId() {
        //
        String serviceId = sample1.getUser().getService().getId();
        String orgId = sample1.getUser().getOrg().getId();
        List<DepotTicket> depotTickets = depotTicketStore.retrieveByServiceIdAndOrgId(serviceId, orgId);
        assertNotNull(depotTickets);
        assertSame(2, depotTickets.size());
    }

    @Test
    public void testUpdate() {
        //
        String serviceName = sample1.getUser().getService().getName();
        String changedServiceName = serviceName + "_change";
        sample1.getUser().getService().setName(changedServiceName);

        depotTicketStore.update(sample1);
        DepotTicket result = depotTicketStore.retrieve(sampleId1);

        assertNotEquals(serviceName, result.getUser().getService().getName());
        assertEquals(changedServiceName, result.getUser().getService().getName());
    }

    @Test
    //@Transactional
    public void testDelete() {
        //
        DepotTicket before = depotTicketStore.retrieve(sampleId1);
        assertNotNull(before);

        depotTicketStore.delete(sample1);

        try {
            DepotTicket after = depotTicketStore.retrieve(sampleId1);
            assertTrue(false);
        } catch (NaraStoreException e) {
            assertTrue(true);
        }
    }
}
