package io.naraplatform.depot.store.cassandra;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepotBootTestApp {

}
