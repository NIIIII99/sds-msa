package io.naraplatform.depot.store.cassandra;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.store.VaultFileStore;
import io.naraplatform.share.util.json.JsonUtil;
import org.cassandraunit.spring.CassandraDataSet;
import org.cassandraunit.spring.CassandraUnitDependencyInjectionTestExecutionListener;
import org.cassandraunit.spring.EmbeddedCassandra;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= DepotBootTestApp.class)
@CassandraDataSet(keyspace = "depot", value = "cql/vaultfile.cql")


@EmbeddedCassandra(timeout=60000)
@TestExecutionListeners(listeners = {
		CassandraUnitDependencyInjectionTestExecutionListener.class,
		DependencyInjectionTestExecutionListener.class}
		)
@ContextConfiguration(classes = { CassandraConfig.class, 
		VaultFileCassandraStoreTest.class })
public class VaultFileCassandraStoreTest {

	@Autowired
    VaultFileStore vaultFileStore;

	private VaultFile createdVaultfile;

	@BeforeClass
	public static void beforeClass() {
		//System.setProperty("java.library.path", "./sigar-libs");
	}

	@Before
	public void before() {
	}

	@Test
	public void testCreate() {
		createdVaultfile = VaultFile.sample();

		String vaultFileId = createdVaultfile.getId();
		System.out.println(JsonUtil.toJson(vaultFileId));

		vaultFileStore.create(createdVaultfile);
		VaultFile vaultFile = vaultFileStore.retrieve(vaultFileId);

		assertNotNull(vaultFile);
	}

	@Test
	public void testRetrieve() {
		//
		VaultFile vaultFile = vaultFileStore.retrieve("d1cf43a5-b06e-41a3-834f-af00f1385ad0");
		System.out.println(JsonUtil.toJson(vaultFile));
		assertNotNull(vaultFile);
	}

	@Test
	public void testFindByAllVaultId() {
		List<VaultFile> vaultFiles = vaultFileStore.retrieveByVaultId("nextree", 0, 4);
		assertTrue(vaultFiles.size() > 0);
	}

}
