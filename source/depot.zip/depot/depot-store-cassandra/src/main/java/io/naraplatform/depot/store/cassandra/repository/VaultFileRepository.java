package io.naraplatform.depot.store.cassandra.repository;

import io.naraplatform.depot.store.cassandra.cmo.VaultFileCmo;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

@Repository
public interface VaultFileRepository extends CassandraRepository<VaultFileCmo, String> {

    Slice<VaultFileCmo> findAllByVaultId(String vaultId, Pageable pageable);

}
