package io.naraplatform.depot.store.cassandra;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.store.VaultFileStore;
import io.naraplatform.depot.store.cassandra.cmo.VaultFileCmo;
import io.naraplatform.depot.store.cassandra.repository.VaultFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class VaultFileCassandraStore implements VaultFileStore {

    @Autowired
    VaultFileRepository vaultFileRepository;

    private static final String NO_SUCH_ELEMENT_MESSAGE = "No VaultFile[%s] to retrieve.";

    @Override
    public void create(VaultFile vaultFile) {
        //
        VaultFileCmo vaultFileCmo = new VaultFileCmo(vaultFile);
        vaultFileRepository.save(vaultFileCmo);
    }

    @Override
    public void create(List<VaultFile> vaultFiles) {
        //
        List<VaultFileCmo> vaultFileCmos = vaultFiles.stream().map(VaultFileCmo::new).collect(Collectors.toList());
        vaultFileRepository.saveAll(vaultFileCmos);
    }

    @Override
    public VaultFile retrieve(String id) {
        //
        Optional<VaultFileCmo> vaultFileCmo = vaultFileRepository.findById(id);
        if (!vaultFileCmo.isPresent()) {
            throw new NoSuchElementException(String.format(NO_SUCH_ELEMENT_MESSAGE, id));
        }

        return vaultFileCmo.get().toDomain();
    }

    @Override
    public List<VaultFile> retrieve(List<String> vaultFileIds) {
        //
        Collection<VaultFileCmo> vaultFileCmos = vaultFileRepository.findAllById(vaultFileIds);
        return vaultFileCmos.stream().map(VaultFileCmo::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<VaultFile> retrieveByVaultId(String vaultId, int offset, int limit) {
        //
        Pageable pageable = PageRequest.of(offset, limit);
        Slice<VaultFileCmo> vaultFileCmos = vaultFileRepository.findAllByVaultId(vaultId, pageable);

        return vaultFileCmos.stream().map(VaultFileCmo::toDomain).collect(Collectors.toList());
    }

    @Override
    public void update(VaultFile vaultFile) {
        //
        vaultFileRepository.save(new VaultFileCmo(vaultFile));
    }

    @Override
    public void update(List<VaultFile> vaultFiles) {
        //
        List<VaultFileCmo> vaultFileCmos = vaultFiles.stream().map(VaultFileCmo::new).collect(Collectors.toList());
        vaultFileRepository.saveAll(vaultFileCmos);
    }

    @Override
    public void delete(VaultFile vaultFile) {
        //
        vaultFileRepository.deleteById(vaultFile.getId());
    }

    @Override
    public void delete(List<String> vaultFileIds) {
        //
        List<VaultFileCmo> vaultFileCmos = vaultFileRepository.findAllById(vaultFileIds);
        vaultFileRepository.deleteAll(vaultFileCmos);
    }
}
