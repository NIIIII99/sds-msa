package io.naraplatform.depot.store.cassandra.cmo;


import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.share.util.json.JsonSerializable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("vaultfile")
@Getter
@Setter
@NoArgsConstructor
public class VaultFileCmo implements JsonSerializable {

    @PrimaryKey
    private String id;

    @Indexed
    private String vaultId;

    private String json;

    public VaultFileCmo(VaultFile vaultFile) {
        //
        this.id = vaultFile.getId();
        this.vaultId = vaultFile.getVaultId();

        this.json = vaultFile.toJson();
    }

    public VaultFile toDomain() {
        //
        return VaultFile.fromJson(json);
    }

}
