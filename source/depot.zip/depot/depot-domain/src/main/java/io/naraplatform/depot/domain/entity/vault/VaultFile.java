package io.naraplatform.depot.domain.entity.vault;

import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class VaultFile extends NaraEntity implements NaraAggregate {
    //
    private String ticketId;
    private String path;
    private String name;
    private String ownerName;       // for display
    private long creationTime;
    private List<VersionPart> versionParts;

    private List<String> tags;
    private boolean encrypted;
    private int totalReferenceCount;

    private String vaultId;
    transient List<DepotFile> depotFiles;

    public VaultFile(String id) {
        //
        super(id);
    }

    public VaultFile(DepotTicket ticket,
                     Vault vault,
                     String name,
                     long size,
                     long creationTime) {
        //
        super();
        this.ticketId = ticket.getId();
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        this.path = vault.path() + File.separator + today;
        this.name = name;
        this.ownerName = ticket.getUser().getUser().getName();
        this.creationTime = creationTime;
        this.versionParts = new ArrayList<>();
        this.versionParts.add(new VersionPart(getVersion(), size));
        this.tags = null;                   // extension point
        this.encrypted = false;             // extension point
        this.totalReferenceCount = 0;

        this.vaultId = vault.getId();
    }

    public static VaultFile sample() {
        //
        DepotTicket ticket = DepotTicket.sample();
        Vault vault = Vault.sample();
        String fileName = "hello.zip";
        long fileSize = 1200L;
        long fileTime = System.currentTimeMillis();

        return new VaultFile(ticket, vault, fileName, fileSize, fileTime);
    }

    public static VaultFile fromJson(String json) {
        //
        return JsonUtil.fromJson(json, VaultFile.class);
    }

    public VersionPart latestVersion() {
        //
        return VersionPart.latest(this.versionParts);
    }

    public VersionPart version(long version) {
        //
        return VersionPart.version(this.versionParts, version);
    }

    public VaultFile increaseReferenceCount(long version) {
        //
        VersionPart versionPart = VersionPart.version(this.versionParts, version);
        if (versionPart != null) {
            versionPart.increaseReferenceCount();
            this.totalReferenceCount++;
        }
        return this;
    }

    public VaultFile increaseReferenceCount() {
        //
        VersionPart versionPart = VersionPart.latest(this.versionParts);
        if (versionPart != null) {
            versionPart.increaseReferenceCount();
            this.totalReferenceCount++;
        }
        return this;
    }

    public VaultFile decreaseReferenceCount(long version) {
        //
        if(totalReferenceCount <= 0) {
            return this;
        }

        VersionPart versionPart = VersionPart.version(this.versionParts, version);
        if (versionPart != null) {
            versionPart.decreaseReferenceCount();
            this.totalReferenceCount--;
        }
        return this;
    }

    public VaultFile decreaseReferenceCount() {
        //
        if(totalReferenceCount <= 0) {
            return this;
        }

        VersionPart versionPart = VersionPart.latest(this.versionParts);
        if (versionPart != null) {
            versionPart.decreaseReferenceCount();
            this.totalReferenceCount--;
        }
        return this;
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "name":
                    this.name = value;
                    break;
                case "size":
                    this.latestVersion().setSize(Long.parseLong(value));
                    break;
                case "tags":
                    this.tags = JsonUtil.fromJsonList(value, String.class);
                    break;
                case "encrypted":
                    this.encrypted = Boolean.parseBoolean(value);
                    break;
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
