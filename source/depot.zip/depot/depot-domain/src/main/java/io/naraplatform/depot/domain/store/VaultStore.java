package io.naraplatform.depot.domain.store;

import io.naraplatform.depot.domain.entity.vault.Vault;

import java.util.List;

public interface VaultStore {
    //
    void create(Vault vault);
    Vault retrieve(String id);
    List<Vault> retrieveAll(int offset, int limit);
    void update(Vault vault);
    void delete(Vault vault);

    boolean existsById(String id);
}
