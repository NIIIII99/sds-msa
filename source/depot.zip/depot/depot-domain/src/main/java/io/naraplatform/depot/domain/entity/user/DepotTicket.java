package io.naraplatform.depot.domain.entity.user;

import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DepotTicket extends NaraEntity implements NaraAggregate {
    //
    private ServiceUser user;
    private ServiceScope scope;
    private long time;

    public DepotTicket(String id) {
        //
        super(id);
    }

    public DepotTicket(ServiceUser user, ServiceScope scope) {
        //
        super();
        this.user = user;
        this.scope = scope;
        this.time = System.currentTimeMillis();
    }

    public String toString() {
        //
        return toJson();
    }

    public static DepotTicket fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotTicket.class);
    }

    public static DepotTicket sample() {
        //
        return new DepotTicket(ServiceUser.sample(), ServiceScope.User);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
