package io.naraplatform.depot.domain.store;

import io.naraplatform.depot.domain.entity.vault.VaultFile;

import java.util.List;

public interface VaultFileStore {
    //
    void create(VaultFile vaultFile);
    void create(List<VaultFile> vaultFiles);
    VaultFile retrieve(String id);
    List<VaultFile> retrieve(List<String> vaultFileIds);
    List<VaultFile> retrieveByVaultId(String vaultId, int offset, int limit);
    void update(VaultFile vaultFile);
    void update(List<VaultFile> vaultFiles);
    void delete(VaultFile vaultFile);
    void delete(List<String> vaultFileIds);
}
