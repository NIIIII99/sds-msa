package io.naraplatform.depot.domain.entity.viewdisk;

import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/*
 * This is like a "C" drive or "D" drive in Windows OS.
 */

@Getter
@Setter
@NoArgsConstructor
public class ViewDrive extends NaraEntity implements NaraAggregate {
    //
    private ViewCriteria viewCriteria;
    private String name;                // A, B, C, D
    private boolean treeStructured;     // tree or plate(plate is default)
    private String viewDiskId;

    transient private List<ViewFolder> viewFolders;

    public ViewDrive(String id) {
        //
        super(id);
    }

    public ViewDrive(ViewDisk disk, ViewCriteria viewCriteria, String name) {
        //
        super();
        this.viewCriteria = viewCriteria;
        this.name = name;
        this.treeStructured = false;
        this.viewDiskId = disk.getId();
    }

    public String toString() {
        //
        return toJson();
    }

    public static ViewDrive fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ViewDrive.class);
    }

    public static ViewDrive sample() {
        //
        ViewDisk disk = ViewDisk.sample();
        return new ViewDrive(disk, ViewCriteria.CreationDate, "A");
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
