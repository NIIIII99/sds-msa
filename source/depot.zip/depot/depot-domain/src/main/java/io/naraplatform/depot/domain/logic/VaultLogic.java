package io.naraplatform.depot.domain.logic;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.depot.domain.spec.vault.VaultService;
import io.naraplatform.depot.domain.spec.vault.sdo.VaultFileCdo;
import io.naraplatform.depot.domain.store.*;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.exception.NaraException;
import io.naraplatform.share.exception.store.AlreadyExistsException;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class VaultLogic implements VaultService {
    //
    private VaultStore vaultStore;
    private VaultFileStore vaultFileStore;
    private DepotStore depotStore;
    private DepotFileStore depotFileStore;
    private DepotTicketStore depotTicketStore;

    public VaultLogic(DepotStoreLycler storeLycler) {
        //
        this.vaultStore = storeLycler.requestVaultStore();
        this.vaultFileStore = storeLycler.requestVaultFileStore();
        this.depotStore = storeLycler.requestDepotStore();
        this.depotFileStore = storeLycler.requestDepotFileStore();
        this.depotTicketStore = storeLycler.requestDepotTicketStore();
    }

    @Override
    public String registerVault(Vault vaultCdo, String ticketId) {
        //
        DepotTicket depotTicket = depotTicketStore.retrieve(ticketId);

        if (ServiceScope.Service != depotTicket.getScope() && ServiceScope.Org != depotTicket.getScope()) {
            throw new NaraException(String.format("Invalid TicketId[%s]", ticketId));
        }

        if (vaultStore.existsById(depotTicket.getUser().getOrg().getId())) {
            throw new AlreadyExistsException("TicketId: " + ticketId);
        }

        Vault vault = new Vault(depotTicket, vaultCdo.getOrgName(), vaultCdo.getRootPath(), vaultCdo.getVaultType());
        vaultStore.create(vault);

        return vault.getId();
    }

    @Override
    public Vault findVault(String vaultId) {
        //
        Vault vault = vaultStore.retrieve(vaultId);
        if(vault == null) {
            throw new NoSuchElementException("Vault id: " + vaultId);
        }

        return vault;
    }

    @Override
    public Vault findVaultByTicketId(String ticketId) {
        //
        DepotTicket depotTicket = depotTicketStore.retrieve(ticketId);
        String serviceId = depotTicket.getUser().getService().getId();
        String orgId = depotTicket.getUser().getOrg().getId();

        DepotTicket orgTicket = depotTicketStore.retrieveOrgTicket(serviceId, orgId);
        String vaultId = orgTicket.getId();
        Vault vault = vaultStore.retrieve(vaultId);
        if (vault == null) {
            throw new NaraException("No exist vault");
        }

        return vault;
    }

    @Override
    public List<Vault> findAllVault(int offset, int limit) {
        //
        return vaultStore.retrieveAll(offset, limit);
    }

    @Override
    public void removeVault(String vaultId) {
        //
        Vault vault = findVault(vaultId);
        vaultStore.delete(vault);
    }

    @Override
    public String addVaultFile(String vaultId, VaultFileCdo vaultFileCdo) {
        //
        String ticketId = vaultFileCdo.getTicketId();
        DepotTicket ticket = depotTicketStore.retrieve(ticketId);
        Vault vault = vaultStore.retrieve(vaultId);

        VaultFile vaultFile = new VaultFile(
            ticket,
            vault,
            vaultFileCdo.getName(),
            vaultFileCdo.getSize(),
            vaultFileCdo.getCreationTime());

        vaultFileStore.create(vaultFile);

        return vaultFile.getId();
    }

    @Override
    public List<String> addVaultFiles(String vaultId, List<VaultFileCdo> vaultFileCdos, String ticketId) {
        //
        DepotTicket ticket = depotTicketStore.retrieve(ticketId);
        Vault vault = vaultStore.retrieve(vaultId);
        List<String> vaultFileIds = new ArrayList<>(10);
        List<VaultFile> vaultFiles = new ArrayList<>(10);
        for(VaultFileCdo vaultFileCdo : vaultFileCdos) {
            VaultFile vaultFile =
                new VaultFile(
                    ticket,
                    vault,
                    vaultFileCdo.getName(),
                    vaultFileCdo.getSize(),
                    vaultFileCdo.getCreationTime());
            vaultFiles.add(vaultFile);
            vaultFileIds.add(vaultFile.getId());
        }

        vaultFileStore.create(vaultFiles);
        return vaultFileIds;
    }

    @Override
    public String addNewVersionVaultFile(String vaultFileId, VersionPart versionPart, String ticketId) {
        //
        VaultFile vaultFile = findVaultFile(vaultFileId);
        vaultFile.increaseVersion();
        vaultFile.getVersionParts().add(new VersionPart(vaultFile.getVersion(), versionPart.getSize()));

        List<DepotFile> depotFiles = depotFileStore.retrieveByVaultFileId(vaultFileId);
        if(!depotFiles.stream().allMatch(depotFile -> vaultFile.getName().equals( depotFile.getName() ))) {
            throw new NaraException("No match VaultFile name and DepotFile name");
        }
        List<String> depotIds = depotFiles.stream().map(DepotFile::getDepotId).collect(Collectors.toList());
        List<Depot> depots = depotStore.retrieve(depotIds);

        if (depotIds.size() != depots.size()) {
            throw new NaraException("No match Depot count.");
        }

        depots.sort(Comparator.comparing(Depot::getId));
        depotFiles.sort(Comparator.comparing(DepotFile::getDepotId));

        List<DepotFile> synchronizedDepotFiles = IntStream.range(0, depotFiles.size())
            .filter(index -> depots.get(index).getConfig().isVersionSynchronized() || depots.get(index).getTicketId().equals(ticketId))
            .mapToObj(index -> (DepotFile)depotFiles.get(index)).collect(Collectors.toList());

        VersionPart latestVersionPart = vaultFile.latestVersion();

        synchronizedDepotFiles.forEach(depotFile -> {
            //
            VersionPart oldTargetVersion = VersionPart.version(vaultFile.getVersionParts(), depotFile.getTargetVersion());
            if(oldTargetVersion == null) {
                throw new NaraException(String.format("No exist versionPart for depot file. [%s]", depotFile.getTargetVersion()));
            }
            oldTargetVersion.decreaseReferenceCount();
            depotFile.setSize(latestVersionPart.getSize());
            depotFile.setTargetVersion(latestVersionPart.getVersion());
            latestVersionPart.increaseReferenceCount();
        });

        vaultFileStore.update(vaultFile);
        depotFileStore.update(synchronizedDepotFiles);

        return vaultFile.getId();
    }

    @Override
    public VaultFile findVaultFile(String vaultFileId) {
        //
        VaultFile vaultFile = vaultFileStore.retrieve(vaultFileId);
        if (vaultFile == null) {
            throw new NoSuchElementException("vaultFile id: " + vaultFileId);
        }

        return vaultFile;
    }

    @Override
    public List<VaultFile> findVaultFiles(List<String> vaultFileIds) {
        //
        List<VaultFile> vaultFiles = vaultFileStore.retrieve(vaultFileIds);
        if (vaultFiles.size() != vaultFileIds.size() ) {
            throw new NaraException("Vault file results count is not enough.");
        }

        return vaultFiles;
    }

    @Override
    public void removeVaultFiles(String vaultId, List<String> vaultFileIds) {
        //
        vaultFileStore.delete(vaultFileIds);
    }

    @Override
    public void modifyVaultFile(String vaultFileId, NameValueList nameValues, String ticketId) {
        //
        VaultFile vaultFile = vaultFileStore.retrieve(vaultFileId);
        vaultFile.setValues(nameValues);
        vaultFileStore.update(vaultFile);

        List<DepotFile> depotFiles = depotFileStore.retrieveByVaultFileId(vaultFileId);
        if(!depotFiles.stream().allMatch(depotFile -> vaultFile.getName().equals( depotFile.getName() ))) {
            throw new NaraException("No match VaultFile name and DepotFile name");
        }
        List<String> depotIds = depotFiles.stream().map(DepotFile::getDepotId).collect(Collectors.toList());
        List<Depot> depots = depotStore.retrieve(depotIds);

        depotFiles.sort(Comparator.comparing(DepotFile::getDepotId));
        depots.sort(Comparator.comparing(Depot::getId));

        List<DepotFile> synchronizedDepotFiles = IntStream.range(0, depotFiles.size())
            .filter(index -> depots.get(index).getConfig().isVersionSynchronized() || depots.get(index).getTicketId().equals(ticketId))
            .mapToObj(index -> depotFiles.get(index)).collect(Collectors.toList());

        for(DepotFile depotFile : synchronizedDepotFiles) {
            depotFile.setValues(nameValues);
        }

        depotFileStore.update(synchronizedDepotFiles);
    }

    @Override
    public List<VaultFile> copyVaultFilesToOtherOrg(List<String> sourceVaultFileIds, String targetDepotId) {
        //
        Depot targetDepot = depotStore.retrieve(targetDepotId);
        String targetVaultId = targetDepot.getVaultId();
        Vault targetVault = vaultStore.retrieve(targetVaultId);
        String targetTicketId = targetVault.getId();  // orgTicketId
        DepotTicket orgTicket = depotTicketStore.retrieve(targetTicketId);

        List<VaultFile> sourceVaultFiles = vaultFileStore.retrieve(sourceVaultFileIds);

        List<VaultFile> targetVaultFiles = new ArrayList<>(10);
        for(VaultFile sourceVaultFile : sourceVaultFiles) {
            VaultFile vaultFile =
                new VaultFile(
                    orgTicket,
                    targetVault,
                    sourceVaultFile.getName(),
                    sourceVaultFile.latestVersion().getSize(),
                    sourceVaultFile.getCreationTime());
            targetVaultFiles.add(vaultFile);
        }

        vaultFileStore.create(targetVaultFiles);

        return targetVaultFiles;
    }

    @Override
    public boolean isModifiableVaultFile(String vaultFileId, String ticketId) {
        //
        boolean modifiable = false;
        VaultFile vaultFile = vaultFileStore.retrieve(vaultFileId);
        int totalReferenceCount = vaultFile.getTotalReferenceCount();

        if(totalReferenceCount == 1) {
            modifiable = true;

        } else if (totalReferenceCount > 1) {
            List<DepotFile> depotFiles = depotFileStore.retrieveByVaultFileId(vaultFileId);
            List<String> depotIds = depotFiles.stream().map(DepotFile::getDepotId).collect(Collectors.toList());

            List<Depot> depots = depotStore.retrieve(depotIds);
            modifiable = depots.stream()
                .filter(depot->!depot.getTicketId().equals(ticketId))
                .allMatch(depot->depot.getConfig().isVersionSynchronized());
        }

        return modifiable;
    }
}
