package io.naraplatform.depot.domain.entity.viewdisk;

import io.naraplatform.depot.domain.entity.depot.FileSortKey;
import io.naraplatform.share.domain.enumtype.SortOrder;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class ViewFolder extends NaraEntity implements NaraAggregate {
    //
    private String name;
    private String parentId;            // null if it's a root folder
    private SortOrder sortOrder;
    private FileSortKey fileSortKey;

    private String viewDriveId;

    transient private List<ViewFile> viewFiles;

    public ViewFolder(String id) {
        //
        super(id);
    }

    public ViewFolder(String viewDriveId, String name) {
        //
        super();
        this.name = name;
        this.sortOrder = SortOrder.Ascending;
        this.fileSortKey = FileSortKey.FileName;
        this.viewDriveId = viewDriveId;
    }

    public String toString() {
        //
        return toJson();
    }

    public static ViewFolder fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ViewFolder.class);
    }

    public static ViewFolder sample() {
        //
        String driveId = ViewDrive.sample().getId();
        return new ViewFolder(driveId, "2018-10-10");
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
