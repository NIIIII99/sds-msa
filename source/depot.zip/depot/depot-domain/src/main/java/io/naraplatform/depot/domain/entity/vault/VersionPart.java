package io.naraplatform.depot.domain.entity.vault;

import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class VersionPart implements ValueObject {
    //
    private long version;
    private long size;
    private long registrationTime;
    private int referenceCount;

    public VersionPart(long version,
                       long size) {
        //
        this.version = version;
        this.size = size;
        this.registrationTime = System.currentTimeMillis();
        this.referenceCount = 1;
    }

    public String toString() {
        //
        return toJson();
    }

    public static VersionPart version(List<VersionPart> parts, long version) {
        //
        for(VersionPart part : parts) {
            if (part.getVersion() == version) {
                return part;
            }
        }

        return null;
    }

    public static VersionPart latest(List<VersionPart> parts) {
        //
        return parts.get(parts.size()-1);
    }


    public static VersionPart sample() {
        //
        int version = 2;
        long fileSize = 1200L;

        return new VersionPart(version, fileSize);
    }

    public static VersionPart fromJson(String json) {
        //
        return JsonUtil.fromJson(json, VersionPart.class);
    }

    public VersionPart increaseReferenceCount() {
        //
        this.referenceCount++;
        return this;
    }

    public VersionPart decreaseReferenceCount() {
        //
        if (this.referenceCount == -1) {
            return this;
        }

        this.referenceCount--;
        return this;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
