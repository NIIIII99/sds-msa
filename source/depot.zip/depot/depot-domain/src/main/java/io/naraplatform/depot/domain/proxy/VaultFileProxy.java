package io.naraplatform.depot.domain.proxy;

import io.naraplatform.depot.domain.entity.vault.VaultFile;

import java.io.InputStream;

public interface VaultFileProxy {
    //
    void saveToDisk(VaultFile vaultFile, String sequence, InputStream fileStream) throws FileActionFailureException;
    void combineToDisk(VaultFile vaultFile, int numberOfChunks) throws FileActionFailureException;
    InputStream readFileFromDisk(VaultFile vaultFile);
    boolean delete(VaultFile vaultFile) throws FileActionFailureException;
    boolean exist(VaultFile vaultFile);
    void copyFile(VaultFile sourceVaultFile, VaultFile targetVaultFile);

    void changeToBackupFile(VaultFile vaultFile) throws FileActionFailureException;
    void deleteBackupFile(VaultFile vaultFile);
    boolean existBackup(VaultFile vaultFile);
}
