package io.naraplatform.depot.domain.store;

import io.naraplatform.depot.domain.entity.depot.DepotFile;

import java.util.List;

public interface DepotFileStore {
    //
    void create(DepotFile depotFile);
    void create(List<DepotFile> depotFiles);
    DepotFile retrieve(String id);
    List<DepotFile> retrieveByVaultFileId(String vaultFileId);
    List<DepotFile> retrieveByDepotId(String depotId);
    List<DepotFile> retrieveByDepotId(String depotId, int offset, int limit);
    void update(DepotFile depotFile);
    void update(List<DepotFile> depotFiles);
    void delete(DepotFile depotFile);
    void delete(List<String> depotFileIds);
    void deleteAllInDepot(String depotId);
    int countAllInDepot(String depotId);
}
