package io.naraplatform.depot.domain.entity.depot;

import io.naraplatform.share.domain.ValueObject;
import io.naraplatform.share.domain.enumtype.SortOrder;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DepotConfig implements ValueObject {
    //
    private boolean versionSynchronized;
    private boolean driveSupported;
    private SortOrder sortOrder;
    private FileSortKey fileSortKey;
    private DepotType type;
    private int maxFileCount;

    private DepotConfig(DepotType type) {
        //
        this.versionSynchronized = false;
        this.driveSupported = false;
        this.sortOrder = SortOrder.Ascending;
        this.fileSortKey = FileSortKey.FileName;
        this.type = type;
        this.maxFileCount = type.maxFileCount();
    }

    public static DepotConfig buildDefaultConfig() {
        //
        return new DepotConfig(DepotType.FileBox);
    }

    public static DepotConfig buildConfig(DepotType type) {
        //
        return new DepotConfig(type);
    }

    public String toString() {
        //
        return toJson();
    }

    public static DepotConfig fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotConfig.class);
    }

    public static DepotConfig sample() {
        //
        DepotConfig sample = new DepotConfig();
        sample.setMaxFileCount(13);
        sample.setVersionSynchronized(true);

        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
