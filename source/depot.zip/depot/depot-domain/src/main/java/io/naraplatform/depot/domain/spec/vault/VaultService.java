package io.naraplatform.depot.domain.spec.vault;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.depot.domain.spec.vault.sdo.VaultFileCdo;
import io.naraplatform.share.domain.NameValueList;

import java.util.List;

public interface VaultService {
    //
    String registerVault(Vault vault, String ticketId);
    Vault findVault(String vaultId);
    List<Vault> findAllVault(int offset, int limit);
    void removeVault(String vaultId);
    Vault findVaultByTicketId(String ticketId);

    String addVaultFile(String vaultId, VaultFileCdo vaultFileCdo);
    List<String> addVaultFiles(String vaultId, List<VaultFileCdo> vaultFileCdos, String ticketId);
    String addNewVersionVaultFile(String vaultFileId, VersionPart versionPart, String ticketId);
    VaultFile findVaultFile(String vaultFileId);
    List<VaultFile> findVaultFiles(List<String> vaultFileIds);
    void removeVaultFiles(String vaultId, List<String> vaultFileIds);
    void modifyVaultFile(String vaultFileId, NameValueList nameValues, String ticketId);

    List<VaultFile> copyVaultFilesToOtherOrg(List<String> sourceVaultFileIds, String targetDepotId);
    boolean isModifiableVaultFile(String vaultFileId, String ticketId);
}
