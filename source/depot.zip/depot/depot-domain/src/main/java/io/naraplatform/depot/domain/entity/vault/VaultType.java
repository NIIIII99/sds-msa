package io.naraplatform.depot.domain.entity.vault;

public enum VaultType {
    //
    UnixFileSystem,
    LinuxFileSystem,
    WindowsFileSystem,
    AmazonS3,
    MongoGridFS
}
