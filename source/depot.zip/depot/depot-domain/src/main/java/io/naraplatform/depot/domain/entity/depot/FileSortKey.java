package io.naraplatform.depot.domain.entity.depot;

public enum FileSortKey {
    //
    Sequence,
    FileName,
    CreationDate,
    RegistrationDate,
    Size,
    Owner
}
