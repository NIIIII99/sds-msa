package io.naraplatform.depot.domain.entity.viewdisk;

import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ViewFile extends NaraEntity implements NaraAggregate {
    //
    private String name;
    private long size;
    private long creationTime;
    private long registrationTime;

    private String depotFileId;
    private String viewFolderId;

    transient DepotFile depotFile;

    public ViewFile(String id) {
        //
        super(id);
    }

    public ViewFile(ViewFolder folder, DepotFile depotFile) {
        //
        super();
        this.name = depotFile.getName();
        this.size = depotFile.getSize();
        this.creationTime = depotFile.getCreationTime();
        this.registrationTime = depotFile.getRegistrationTime();

        this.viewFolderId = folder.getId();
        this.depotFileId = depotFile.getId();
    }

    public String toString() {
        //
        return toJson();
    }

    public static ViewFile fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ViewFile.class);
    }

    public static ViewFile sample() {
        //
        ViewFolder viewFolder = ViewFolder.sample();
        DepotFile depotFile = DepotFile.sample();

        return new ViewFile(viewFolder, depotFile);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
