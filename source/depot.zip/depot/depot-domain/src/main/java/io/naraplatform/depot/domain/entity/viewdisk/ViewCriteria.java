package io.naraplatform.depot.domain.entity.viewdisk;

public enum ViewCriteria {
    //
    CreationDate,               // 생성일자별 폴더
    Owner,                      // 소유자별 폴더
    FileType,                   // 파일 유형별 폴더
    Tag,                        // 태그별 폴더
    UserDefined                 // 사용자 정의 폴더
}
