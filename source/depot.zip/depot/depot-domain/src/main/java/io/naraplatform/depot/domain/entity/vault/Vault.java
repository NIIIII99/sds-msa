package io.naraplatform.depot.domain.entity.vault;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.File;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Vault extends NaraEntity implements NaraAggregate {
    //
    private String orgName;         //
    private String rootPath;        //
    private VaultType vaultType;
    private long time;

    transient private List<VaultFile> vaultFiles;

    public Vault(String id) {
        //
        super(id);
    }

    public Vault(DepotTicket ticket, String orgName, String rootPath, VaultType vaultType) {
        //
        super(ticket.getUser().getOrg().getId());       // rule: vault 단위는 org
        this.orgName = orgName;
        this.rootPath = rootPath;
        this.vaultType = vaultType;
        this.time = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Vault fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Vault.class);
    }

    public static Vault sample() {
        //
        DepotTicket ticket = DepotTicket.sample();
        String orgName = "Nextree Consulting";
        String rootPath = "/var/nara-vault";

        return new Vault(ticket, orgName, rootPath, VaultType.LinuxFileSystem);
    }

    public String path() {
        //
        return rootPath + File.separator + getId();
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
