package io.naraplatform.depot.domain.store;

public interface DepotStoreLycler {
    //
    DepotFileStore requestDepotFileStore();
    VaultFileStore requestVaultFileStore();
    DepotStore requestDepotStore();
    VaultStore requestVaultStore();
    DepotTicketStore requestDepotTicketStore();
}
