package io.naraplatform.depot.domain.store;

import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.Depot;

import java.util.List;

public interface DepotStore {
    //
    void create(Depot depot);
    Depot retrieve(String id);
    Depot retrieve(String ticketId, DepotType type);
    List<Depot> retrieve(List<String> depotIds);
    List<Depot> retrieveAll(int offset, int limit);
    List<Depot> retrieve(String vaultId, DepotType type, String title);
    Depot retrievePersonalDrive(String ticketId);
    Depot retrieveTeamDrive(String ticketId);
    void update(Depot depot);
    void delete(Depot depot);

    boolean existsPersonalDrive(String ticketId);
    boolean existsTeamDrive(String ticketId);
    boolean hasAnyDepotFile(String depotId);
}
