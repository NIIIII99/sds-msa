package io.naraplatform.depot.domain.entity.depot;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class Depot extends NaraEntity implements NaraAggregate {
    //
    private DepotType type;
    private String ticketId;
    private String title;
    private int currentSequence;
    private IdName client;                              // client classs or team
    private DepotConfig config;
    private long time;
    private String repDepotFileId;                      // representative file id for tiny album

    private String vaultId;

    transient private List<DepotFile> depotFiles;       // Don't use this attribute

    public Depot(String id) {
        //
        super(id);
    }

    public Depot(Vault vault,
                 DepotType type,
                 String ticketId,
                 String title,
                 IdName client) {
        //
        super();
        this.type = type;
        this.ticketId = ticketId;
        this.title = title;
        this.currentSequence = 1;
        this.client = client;
        this.config = DepotConfig.buildDefaultConfig();
        this.config.setType(type);
        this.time = System.currentTimeMillis();
        this.vaultId = vault.getId();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static Depot sample() {
        //
        Vault vault = Vault.sample();
        String ticketId = DepotTicket.sample().getId();
        IdName client = new IdName(
            UUID.randomUUID().toString(),
            Depot.class.getSimpleName());     // board id, member id, etc
        String title = "첨부파일";

        return new Depot(vault, DepotType.FileBox, ticketId, title, client);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch (nameValue.getName()) {
                case "title":
                    this.title = value;
                    break;
                case "repDepotFileId":
                    this.repDepotFileId = value;
                    break;
                case "config":
                    this.config = DepotConfig.fromJson(value);
                    break;
            }
        }
    }

    public boolean isAddableFileExtension(List<String> fileNames) {
        //
        if (DepotType.TinyAlbum == type) {
            return fileNames.stream().allMatch( fileName -> fileName.toLowerCase().matches(".+\\.(bmp|jpg|png|jpeg|gif)"));
        }

        return true;
    }

    public static Depot fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Depot.class);
    }

    public int nextSequence() {
        //
        return currentSequence++;
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
