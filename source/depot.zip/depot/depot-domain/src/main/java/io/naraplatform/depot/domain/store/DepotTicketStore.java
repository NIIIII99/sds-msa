package io.naraplatform.depot.domain.store;

import io.naraplatform.depot.domain.entity.user.DepotTicket;

import java.util.List;

public interface DepotTicketStore {
    //
    void create(DepotTicket depotTicket);
    DepotTicket retrieve(String id);
    DepotTicket retrieveServiceTicket(String serviceId);
    DepotTicket retrieveOrgTicket(String serviceId, String orgId);
    DepotTicket retrieveTeamTicket(String serviceId, String orgId, String teamId);
    DepotTicket retrieveUserTicket(String serviceId, String orgId, String userId);
    List<DepotTicket> retrieveByServiceId(String serviceId);
    List<DepotTicket> retrieveByServiceIdAndOrgId(String serviceId, String orgId);
    void update(DepotTicket depotTicket);
    void delete(DepotTicket depotTicket);
}
