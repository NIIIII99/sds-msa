package io.naraplatform.depot.domain.logic;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.spec.ticket.DepotTicketService;
import io.naraplatform.depot.domain.store.DepotStoreLycler;
import io.naraplatform.depot.domain.store.DepotTicketStore;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;

import java.util.List;

public class DepotTicketLogic implements DepotTicketService {
    //
    private DepotTicketStore depotTicketStore;

    public DepotTicketLogic(DepotStoreLycler depotStoreLycler) {
        //
        this.depotTicketStore = depotStoreLycler.requestDepotTicketStore();
    }

    @Override
    public String issueDepotTicket(ServiceUser user, ServiceScope scope) {
        //
        DepotTicket depotTicket = findDepotTicket(user, scope);
        if (depotTicket != null) {
            return depotTicket.getId();
        }

        depotTicket = new DepotTicket(user, scope);
        depotTicketStore.create(depotTicket);

        return depotTicket.getId();
    }

    @Override
    public List<DepotTicket> findDepotTicketByService(String serviceId) {
        //
        return depotTicketStore.retrieveByServiceId(serviceId);
    }

    @Override
    public List<DepotTicket> findDepotTicketByServiceAndOrg(String serviceId, String orgId) {
        //
        return depotTicketStore.retrieveByServiceIdAndOrgId(serviceId, orgId);
    }

    private DepotTicket findDepotTicket(ServiceUser user, ServiceScope scope) {
        //
        String serviceId = user.getService().getId();

        if (ServiceScope.Service == scope) {
            return depotTicketStore.retrieveServiceTicket(serviceId);

        } else if (ServiceScope.Org == scope) {
            return depotTicketStore.retrieveOrgTicket(serviceId, user.getOrg().getId());

        } else if (ServiceScope.Team == scope) {
            return depotTicketStore.retrieveTeamTicket(serviceId, user.getOrg().getId(), user.getTeam().getId());

        } else if (ServiceScope.User == scope) {
            return depotTicketStore.retrieveUserTicket(serviceId, user.getOrg().getId(), user.getUser().getId());
        }

        return null;
    }
}
