package io.naraplatform.depot.domain.spec.depot.sdo;

import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.share.domain.IdName;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DepotCdo implements JsonSerializable {
    //
    private String vaultId;
    private DepotType type;
    private String ticketId;
    private String title;
    private IdName client;              // clientId and owner class name;

    public String toString() {
        //
        return toJson();
    }

    public static DepotCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotCdo.class);
    }

    public static DepotCdo sample() {
        //
        String depotId = UUID.randomUUID().toString();
        String ticketId = UUID.randomUUID().toString();
        String title = "Posting 11-attachment";
        IdName client = new IdName(UUID.randomUUID().toString(), DepotCdo.class.getName());

        return new DepotCdo(depotId, DepotType.FileBox, ticketId, title, client);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
