package io.naraplatform.depot.domain.proxy;

public interface DepotProxyLycler {
    //
    VaultFileProxy requestVaultFileProxy();
}
