package io.naraplatform.depot.domain.spec.ticket;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.domain.drama.ServiceUser;

import java.util.List;

public interface DepotTicketService {
    //
    String issueDepotTicket(ServiceUser user, ServiceScope scope);
    List<DepotTicket> findDepotTicketByService(String serviceId);
    List<DepotTicket> findDepotTicketByServiceAndOrg(String serviceId, String orgId);
}
