package io.naraplatform.depot.domain.spec.depot;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.spec.depot.sdo.DepotCdo;
import io.naraplatform.share.domain.NameValueList;

import java.util.List;

public interface DepotService {
    //
    String registerFileBox(DepotCdo depotCdo);
    String registerPersonalDrive(DepotCdo depotCdo);
    String registerTeamDrive(DepotCdo depotCdo);
    String registerTinyAlbum(DepotCdo depotCdo);
    Depot findDepot(String depotId);
    Depot findDepot(String ticketId, DepotType type);
    Depot findFileBox(String depotId);
    Depot findPersonalDrive(String ticketId);
    Depot findTeamDrive(String ticketId);
    List<Depot> findAllDepots(int offset, int limit);
    List<Depot> findAllDepotsByType(DepotType type, String ticketId, String keyword);
    void modifyDepot(String depotId, NameValueList nameValues);
    void removeDepot(String depotId);

    List<String> addDepotFiles(String depotId, List<String> vaultFileIds);
    void removeDepotFiles(String depotId, List<String> depotFileIds, String ticketId);
    DepotFile findDepotFile(String depotId, String depotFileId);
    List<DepotFile> findDepotFiles(String depotId, int offset, int limit);
    DepotFile findDepotFileByName(String depotId, String name);
    boolean existDuplicationByNames(String depotId, List<String> fileNames);
    boolean existDuplicationByVaultFileIds(String depotId, List<String> vaultFileIds);
    int countDepotFiles(String depotId);
    VaultFile findVaultFileForDownload(String depotId, String depotFileId, String ticketId);

    boolean isDepotThatNeedCopying(String depotId, String ticketId);
}
