package io.naraplatform.depot.domain.logic;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.proxy.DepotProxyLycler;
import io.naraplatform.depot.domain.proxy.VaultFileProxy;
import io.naraplatform.share.exception.NaraException;

import java.io.InputStream;
import java.util.List;
import java.util.stream.IntStream;

public class VaultFileHandler {
    //
    private VaultFileProxy vaultFileProxy;

    public VaultFileHandler(DepotProxyLycler depotProxyLycler) {
        this.vaultFileProxy = depotProxyLycler.requestVaultFileProxy();
    }

    public void uploadFile(VaultFile vaultFile, String sequence, InputStream inputStream, String ticketId) {
        //
        if (!vaultFile.getTicketId().equals(ticketId)) {
            throw new NaraException(String.format("No match TicketId [%s]", ticketId));
        }
        boolean exist = vaultFileProxy.exist(vaultFile);
        if (exist) {
            vaultFileProxy.changeToBackupFile(vaultFile);
        }
        vaultFileProxy.saveToDisk(vaultFile, sequence, inputStream);
    }

    public void combineToDisk (VaultFile vaultFile, String chunkCountStr, String ticketId) {
        //
        if (!vaultFile.getTicketId().equals(ticketId)) {
            throw new NaraException(String.format("No match TicketId [%s]", ticketId));
        }
        int chunkCount = Integer.parseInt(chunkCountStr);
        if (!String.valueOf(chunkCount).equals(chunkCountStr)) {
            throw new NumberFormatException(String.format("chunkCount must be number[%s]", chunkCountStr));
        }

        vaultFileProxy.combineToDisk(vaultFile, chunkCount);

        boolean existBackup = vaultFileProxy.existBackup(vaultFile);
        if (existBackup) {
            vaultFileProxy.deleteBackupFile(vaultFile);
        }

    }

    public void copyVaultFiles(List<VaultFile> sourceVaultFiles, List<VaultFile> targetValutFiles) {
        //
        if (sourceVaultFiles.size() != targetValutFiles.size()) {
            throw new NaraException("No match source vaultFiles and target vaultFiles");
        }

        boolean match = IntStream.range(0, sourceVaultFiles.size())
            .allMatch(index -> sourceVaultFiles.get(index).getName().equals( targetValutFiles.get(index).getName() ));
        if (!match) {
            throw new NaraException("No match source and target vaultFile name.");
        }

        IntStream.range(0, sourceVaultFiles.size())
            .forEach(index ->
                vaultFileProxy.copyFile(sourceVaultFiles.get(index), targetValutFiles.get(index))
            );
    }
}
