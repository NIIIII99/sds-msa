package io.naraplatform.depot.domain.entity.viewdisk;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.share.domain.nara.NaraAggregate;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/*
 * ViewDisk is for Depot with DepotType.PersonalDrive or DepotType.TeamDrive
 */

@Getter
@Setter
@NoArgsConstructor
public class ViewDisk extends NaraEntity implements NaraAggregate {
    // Depot : ViewDisk = 1:1
    private String title;

    transient private List<ViewDrive> viewDrives;
    transient private Depot depot;

    public ViewDisk(String id) {
        //
        super(id);
    }

    public ViewDisk(Depot depot) {
        //
        super(depot.getId());
        if (!depot.getType().isDiskDrive()) {
            throw new IllegalArgumentException("Supports PersonalDrive or TeamDrive only.");
        }

        // depot.getConfig().setDriveSupported(true);      // 로직에서 설정해야 함

        this.title = depot.getTitle();
    }

    public String toString() {
        //
        return toJson();
    }

    public static ViewDisk fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ViewDisk.class);
    }

    public static ViewDisk sample() {
        //
        return new ViewDisk(Depot.sample());
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
