package io.naraplatform.depot.domain.entity.depot;

public enum DepotType {
    //
    FileBox(100),
    PersonalDrive(100),
    TeamDrive(1000),
    TinyAlbum(100);

    private int maxFileCount;

    private DepotType(int maxFileCount) {
        //
        this.maxFileCount = maxFileCount;
    }

    public int maxFileCount() {
        //
        return maxFileCount;
    }

    public boolean isDiskDrive() {
        //
        if (this.equals(PersonalDrive) || this.equals(TeamDrive)) {
            return true;
        }

        return false;
    }
}
