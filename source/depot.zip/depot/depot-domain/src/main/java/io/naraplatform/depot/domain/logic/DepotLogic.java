package io.naraplatform.depot.domain.logic;

import io.naraplatform.depot.domain.entity.depot.Depot;
import io.naraplatform.depot.domain.entity.depot.DepotFile;
import io.naraplatform.depot.domain.entity.depot.DepotType;
import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.depot.domain.entity.vault.Vault;
import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.spec.depot.DepotService;
import io.naraplatform.depot.domain.spec.depot.sdo.DepotCdo;
import io.naraplatform.depot.domain.store.*;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.drama.ServiceScope;
import io.naraplatform.share.exception.NaraException;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DepotLogic implements DepotService {
    //
    private DepotStore depotStore;
    private DepotFileStore depotFileStore;
    private VaultStore vaultStore;
    private VaultFileStore vaultFileStore;
    private DepotTicketStore depotTicketStore;

    public DepotLogic(DepotStoreLycler storeLycler) {
        //
        this.depotStore = storeLycler.requestDepotStore();
        this.depotFileStore = storeLycler.requestDepotFileStore();
        this.vaultStore = storeLycler.requestVaultStore();
        this.vaultFileStore = storeLycler.requestVaultFileStore();
        this.depotTicketStore = storeLycler.requestDepotTicketStore();
    }

    @Override
    public String registerFileBox(DepotCdo depotCdo) {
        //
        Vault vault = findVault(depotCdo.getVaultId());
        Depot depot = new Depot(
            vault,
            depotCdo.getType(),
            depotCdo.getTicketId(),
            depotCdo.getTitle(),
            depotCdo.getClient());

        if (DepotType.FileBox != depot.getType()) {
            throw new RuntimeException(String.format("DepotType is not FileBox [%s]", depot.getType()));
        }

        depotStore.create(depot);
        return depot.getId();
    }

    @Override
    public String registerPersonalDrive(DepotCdo depotCdo) {
        //
        Vault vault = findVault(depotCdo.getVaultId());
        Depot depot = new Depot(
            vault,
            depotCdo.getType(),
            depotCdo.getTicketId(),
            depotCdo.getTitle(),
            depotCdo.getClient());

        if (DepotType.PersonalDrive != depot.getType()) {
            throw new RuntimeException(String.format("DepotType is not PersonalDrive [%s]", depot.getType()));
        }

        depotStore.create(depot);
        return depot.getId();
    }

    @Override
    public String registerTeamDrive(DepotCdo depotCdo) {
        //
        Vault vault = findVault(depotCdo.getVaultId());
        Depot depot = new Depot(
            vault,
            depotCdo.getType(),
            depotCdo.getTicketId(),
            depotCdo.getTitle(),
            depotCdo.getClient());

        if (DepotType.TeamDrive != depot.getType()) {
            throw new RuntimeException(String.format("DepotType is not TeamDrive [%s]", depot.getType()));
        }

        depotStore.create(depot);
        return depot.getId();
    }

    @Override
    public String registerTinyAlbum(DepotCdo depotCdo) {
        //
        Vault vault = findVault(depotCdo.getVaultId());
        Depot depot = new Depot(
            vault,
            depotCdo.getType(),
            depotCdo.getTicketId(),
            depotCdo.getTitle(),
            depotCdo.getClient());

        if (DepotType.TinyAlbum != depot.getType()) {
            throw new RuntimeException(String.format("DepotType is not TinyAlbum [%s]", depot.getType()));
        }

        depotStore.create(depot);
        return depot.getId();
    }

    @Override
    public Depot findDepot(String depotId) {
        //
        Depot depot = depotStore.retrieve(depotId);
        if (depot == null) {
            throw new NoSuchElementException("DepotId: " + depotId);
        }

        return depot;
    }

    @Override
    public Depot findDepot(String ticketId, DepotType type) {
        //
        Depot depot = depotStore.retrieve(ticketId, type);

        if (depot == null) {
            throw new NoSuchElementException("ticket id: " + ticketId + ", type: "+type);
        }

        return depot;
    }

    @Override
    public Depot findFileBox(String depotId) {
        //
        Depot depot = depotStore.retrieve(depotId);
        if (depot == null) {
            throw new NoSuchElementException("Depot id: " + depotId);
        }

        return depot;
    }

    @Override
    public Depot findPersonalDrive(String ticketId) {
        //
        Depot depot = depotStore.retrievePersonalDrive(ticketId);

        if (depot == null) {
            throw new NoSuchElementException("ticket id: " + ticketId);
        }

        return depot;
    }

    @Override
    public Depot findTeamDrive(String ticketId) {
        //
        Depot depot = depotStore.retrieveTeamDrive(ticketId);
        if (depot == null) {
            throw new NoSuchElementException("ticket id: " + ticketId);
        }

        return depot;
    }

    @Override
    public List<Depot> findAllDepots(int offset, int limit) {
        //
        return depotStore.retrieveAll(offset, limit);
    }

    @Override
    public List<Depot> findAllDepotsByType(DepotType type, String ticketId, String keyword) {
        //
        DepotTicket ticket = depotTicketStore.retrieve(ticketId);
        String serviceId = ticket.getUser().getService().getId();
        String orgId = ticket.getUser().getOrg().getId();
        DepotTicket orgTicket = depotTicketStore.retrieveOrgTicket(serviceId, orgId);
        String vaultId = orgTicket.getId();

        return depotStore.retrieve(vaultId, type, keyword);
    }

    @Override
    public void modifyDepot(String depotId, NameValueList nameValues) {
        //
        Depot depot = findDepot(depotId);

        depot.setValues(nameValues);
        depotStore.update(depot);
    }

    @Override
    public void removeDepot(String depotId) {
        //
        Depot depot = findDepot(depotId);

        if(depotStore.hasAnyDepotFile(depotId)) {
            depotFileStore.deleteAllInDepot(depotId);
        }

        depotStore.delete(depot);
    }

    @Override
    public List<String> addDepotFiles(String depotId, List<String> vaultFileIds) {
        //
        Depot depot = findDepot(depotId);
        String vaultIdOfDepot = depot.getVaultId();
        List<DepotFile> existedDepotFiles = depotFileStore.retrieveByDepotId(depotId);
        List<String> existedFileNames = existedDepotFiles.stream().map(DepotFile::getName).collect(Collectors.toList());

        List<VaultFile> vaultFiles = vaultFileStore.retrieve(vaultFileIds);
        List<String> vaultIds = vaultFiles.stream().map(VaultFile::getVaultId).collect(Collectors.toList());
        List<String> newFileNames = vaultFiles.stream().map(VaultFile::getName).collect(Collectors.toList());

        if( !vaultIds.stream().allMatch(vaultId -> vaultId.equals(vaultIdOfDepot)) ) {
            throw new NaraException("Exist other org's vault files");
        }
        if (newFileNames.stream().anyMatch(newFileName->existedFileNames.contains(newFileName))) {
            throw new NaraException("Exist same file name.");
        }
        if (!depot.isAddableFileExtension(newFileNames)) {
            throw new NaraException("Not supported File Extension.(Tiny album support only image type.)");
        }
        if (depot.getConfig().getMaxFileCount() < existedDepotFiles.size() + vaultFiles.size()) {
            throw new NaraException("Exceeded maximum count of depot's files.");
        }

        List<DepotFile> depotFiles = new ArrayList<>(10);
        List<String> depotFileIds = new ArrayList<>(10);
        for(VaultFile vaultFile : vaultFiles) {
            DepotFile depotFile = new DepotFile(depot, vaultFile);
            depotFile.setSequence( depot.nextSequence() );
            depotFiles.add(depotFile);
            depotFileIds.add(depotFile.getId());
        }
        depotFileStore.create(depotFiles);
        depotStore.update(depot);

        vaultFiles.forEach( vaultFile ->
            vaultFile.increaseReferenceCount( vaultFile.getVersion() )
        );
        vaultFileStore.update(vaultFiles);

        return depotFileIds;
    }

    @Override
    public void removeDepotFiles(String depotId, List<String> depotFileIds, String ticketId) {
        //
        Depot depot = findDepot(depotId);   // for existence check
        if(!depot.getTicketId().equals(ticketId)) {
            throw new NaraException(String.format("No match ticketId[%s]", ticketId));
        }

        List<DepotFile> depotFiles = depotFileStore.retrieveByDepotId(depotId);
        if(!depotFiles.stream().allMatch(depotFile->depotFile.getDepotId().equals(depotId))) {
            throw new NaraException(String.format("No match depot Id[%s]", depotId));
        }

        List<String> existingDepotFileIds = depotFiles.stream().map(DepotFile::getId).collect(Collectors.toList());
        if (!existingDepotFileIds.containsAll(depotFileIds)) {
            throw new NaraException("It's not depot file id contained in depot.");
        }

        List<DepotFile> depotFilesToDelete = depotFiles.stream().filter( depotFile->(depotFileIds.contains(depotFile.getId())) ).collect(Collectors.toList());
        List<String> vaultFileIds = depotFilesToDelete.stream().map(DepotFile::getVaultFileId).collect(Collectors.toList());
        List<VaultFile> vaultFiles = vaultFileStore.retrieve(vaultFileIds);
        if (vaultFiles.size() < vaultFileIds.size() ) {
            throw new NaraException("Could be exist duplicate vault file id.");
        }

        depotFilesToDelete.sort(Comparator.comparing(DepotFile::getVaultFileId));
        vaultFiles.sort(Comparator.comparing(VaultFile::getId));

        IntStream.range(0, vaultFiles.size()).forEach(index ->
            vaultFiles.get(index).decreaseReferenceCount( depotFilesToDelete.get(index).getTargetVersion() )
        );

        depotFileStore.delete(depotFileIds);
        vaultFileStore.update(vaultFiles);
    }

    @Override
    public DepotFile findDepotFile(String depotId, String depotFileId) {
        //
        DepotFile depotFile = depotFileStore.retrieve(depotFileId);
        if (!depotFile.getDepotId().equals(depotId)) {
            throw new NaraException(String.format("No match depot id [%s]", depotId));
        }

        return depotFile;
    }

    @Override
    public List<DepotFile> findDepotFiles(String depotId, int offset, int limit) {
        //
        return depotFileStore.retrieveByDepotId(depotId, offset, limit);
    }

    @Override
    public DepotFile findDepotFileByName(String depotId, String name) {
        //
        Depot depot = findDepot(depotId);

        List<DepotFile> depotFiles = depotFileStore.retrieveByDepotId(depotId);
        List<String> existedFileNames = depotFiles.stream().map(DepotFile::getName).collect(Collectors.toList());
        int index = existedFileNames.indexOf(name);
        if (index < 0) {
            return null;
        }

        return depotFiles.get(index);
    }

    @Override
    public boolean existDuplicationByNames(String depotId, List<String> fileNames) {
        //
        Depot depot = findDepot(depotId);

        List<DepotFile> depotFiles = depotFileStore.retrieveByDepotId(depotId);
        List<String> existedFileNames = depotFiles.stream().map(DepotFile::getName).collect(Collectors.toList());

        return existedFileNames.containsAll(fileNames);
    }

    @Override
    public int countDepotFiles(String depotId) {
        //
        return depotFileStore.countAllInDepot(depotId);
    }

    @Override
    public boolean existDuplicationByVaultFileIds(String depotId, List<String> vaultFileIds) {
        //
        Depot depot = findDepot(depotId);

        List<DepotFile> depotFiles = depotFileStore.retrieveByDepotId(depotId);
        List<String> existedFileNames = depotFiles.stream().map(DepotFile::getName).collect(Collectors.toList());

        List<VaultFile> vaultFiles = vaultFileStore.retrieve(vaultFileIds);

        return vaultFiles.stream().anyMatch(vaultFile->existedFileNames.contains(vaultFile.getName()));
    }

    @Override
    public VaultFile findVaultFileForDownload(String depotId, String depotFileId, String ticketId) {
        //
        Depot container = depotStore.retrieve(depotId);
        if(!container.getTicketId().equals(ticketId)) {
            throw new NaraException("No match ticketId : " + ticketId);
        }

        DepotFile depotFile = depotFileStore.retrieve(depotFileId);
        if(!depotFile.getDepotId().equals(depotId)) {
            throw new NaraException("No match depotId : " + depotId);
        }

        return vaultFileStore.retrieve(depotFile.getVaultFileId());
    }

    public static void main(String[] args) {
        //
        System.out.println(UUID.randomUUID().toString());
    }

    private Vault findVault(String vaultId) {
        //
        Vault vault = vaultStore.retrieve(vaultId);
        if (vault == null) {
            throw new NoSuchElementException("Vault id: " + vaultId);
        }

        return vault;
    }

    @Override
    public boolean isDepotThatNeedCopying(String depotId, String ticketId) {
        //
        DepotTicket depotTicket = depotTicketStore.retrieve(ticketId);

        if (depotTicket.getScope() != ServiceScope.Org) {
            String serviceId = depotTicket.getUser().getService().getId();
            String orgId = depotTicket.getUser().getOrg().getId();
            depotTicket = depotTicketStore.retrieveOrgTicket(serviceId, orgId);
            if (depotTicket == null) {
                throw new NaraException("No existing depot ticket for org");
            }
        }

        String orgTicketId = depotTicket.getId();
        Depot depot = depotStore.retrieve(depotId);
        if (depot == null) {
            throw new NaraException("No existing Depot Id");
        }

        return !orgTicketId.equals(depot.getVaultId());
    }
}
