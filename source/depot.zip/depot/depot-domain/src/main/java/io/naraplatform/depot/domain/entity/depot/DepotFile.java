package io.naraplatform.depot.domain.entity.depot;

import io.naraplatform.depot.domain.entity.vault.VaultFile;
import io.naraplatform.depot.domain.entity.vault.VersionPart;
import io.naraplatform.share.domain.NameValue;
import io.naraplatform.share.domain.NameValueList;
import io.naraplatform.share.domain.nara.NaraEntity;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DepotFile extends NaraEntity {
    //
    private int sequence;
    private long targetVersion;
    private String name;
    private long size;
    private long creationTime;
    private long registrationTime;

    private String vaultFileId;
    private String depotId;

    public DepotFile(String id) {
        //
        super(id);
    }

    public DepotFile(Depot depot, VaultFile vaultFile) {
        //
        super();
        this.targetVersion = vaultFile.getVersion();
        this.name = vaultFile.getName();
        VersionPart versionPart = vaultFile.latestVersion();
        this.size = versionPart.getSize();
        this.registrationTime = versionPart.getRegistrationTime();
        this.creationTime = vaultFile.getCreationTime();

        this.vaultFileId = vaultFile.getId();
        this.depotId = depot.getId();
    }

    @Override
    public String toString() {
        //
        return toJson();
    }

    public static DepotFile sample() {
        //
        Depot depot = Depot.sample();
        VaultFile vaultFile = VaultFile.sample();

        return new DepotFile(depot, vaultFile);
    }

    public static DepotFile fromJson(String json) {
        //
        return JsonUtil.fromJson(json, DepotFile.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        for(NameValue nameValue : nameValues.list()) {
            String value = nameValue.getValue();
            switch(nameValue.getName()) {
                case "name":
                    this.name = value;
                    break;
                case "size":
                    this.size = Long.parseLong(value);
                    break;
            }
        }
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
