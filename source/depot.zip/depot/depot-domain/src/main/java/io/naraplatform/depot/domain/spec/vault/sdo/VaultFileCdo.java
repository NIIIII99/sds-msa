package io.naraplatform.depot.domain.spec.vault.sdo;

import io.naraplatform.depot.domain.entity.user.DepotTicket;
import io.naraplatform.share.util.json.JsonSerializable;
import io.naraplatform.share.util.json.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VaultFileCdo implements JsonSerializable {
    //
    private String ticketId;
    private String name;
    private long size;
    private long creationTime;

    public String toString() {
        //
        return toJson();
    }

    public static VaultFileCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, VaultFileCdo.class);
    }

    public static VaultFileCdo sample() {
        //
        String ticketId = DepotTicket.sample().getId();
        String fileName = "Hello.txt";
        long fileSize = 129L;
        long fileTime = System.currentTimeMillis();

        return new VaultFileCdo(ticketId, fileName, fileSize, fileTime);
    }

    public static void main(String[] args) {
        //
        System.out.println(sample());
    }
}
