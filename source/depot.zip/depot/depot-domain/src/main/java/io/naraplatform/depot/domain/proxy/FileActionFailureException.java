package io.naraplatform.depot.domain.proxy;


import io.naraplatform.share.exception.NaraException;

public class FileActionFailureException extends NaraException {
    //
    public FileActionFailureException(String message) {
        super(message);
    }

    public FileActionFailureException(String message, Throwable t) {
        super(message, t);
    }

    public FileActionFailureException(Throwable t) {
        super(t);
    }
}
